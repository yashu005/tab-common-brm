
PIN_IMPORT void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

PIN_IMPORT int32
fm_tab_utils_common_global_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


PIN_IMPORT time_t
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

PIN_IMPORT char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_service_from_msisdn(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_sub_enrich_extend_validity(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_update_service(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_subscr_bill_debit(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int32			curr,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_ece_balances(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void	
fm_tab_utils_common_get_offering_details(
	pcm_context_t 		*ctxp,
	poid_t         		*account_pdp,
	pin_flist_t     	**out_flistpp,
	int64               db_no,
	pin_errbuf_t        *ebufp);	
	
PIN_IMPORT void
fm_tab_utils_common_get_service_from_account(
	pcm_context_t     	*ctxp,
	poid_t				*poid_pdp,
	int64  				db_no,
	pin_flist_t         **ret_flistpp,
	pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_search_bill_no(
	pcm_context_t 		*ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t     	**out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
PIN_IMPORT void 
fm_tab_utils_common_search_item_bill_pdp(
	pcm_context_t 		*ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t     	**out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
PIN_IMPORT void
fm_tab_utils_common_get_billinfo (
	pcm_context_t           *ctxp,
	poid_t                  *acc_pdp,
	int32                   active_flag,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_account_details(
        pcm_context_t           *ctxp,
        char                    *account_no,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_owner_billinfo_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_billinfo_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT int fm_tab_utils_common_call_opcode(
        pcm_context_t           *ctxp,
        u_int                   opcode,
        u_int                   flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        char                    *log_info,
        int                     set_error,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_read_object(
        pcm_context_t           *ctxp,
        poid_t                  *poid_pdp,
        pin_flist_t             **ret_flistpp,
        pin_errbuf_t            *ebufp);


PIN_IMPORT unsigned long
fm_tab_utils_common_get_max_elemid(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   fld_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_get_profile_sub_preferences(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_subscr_get_current_main_balance(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_utils_common_resume_service(
        pcm_context_t           *ctxp,
        pin_flist_t             *in_flistp,
        pin_flist_t             **out_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *in_flistp,
        pin_errbuf_t            *ebufp);

PIN_IMPORT void
fm_tab_utils_common_create_limit_event(
    pcm_context_t        *ctxp,
    int64            db_no,
    poid_t            *event_pdp,
    pin_flist_t        *in_flistp,
    pin_flist_t        **out_flistpp,
    pin_errbuf_t        *ebufp);

#define TAB_LOG_ERR(err_flistp, err_log_msg, ebufp) \
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, err_log_msg, err_flistp); \
	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, err_log_msg, ebufp);

#define TAB_LOG_SET_ERR(err_flistp, err_code, err_log_msg, ebufp) \
	pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE, err_code, 0, 0, 0);\
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, err_log_msg, err_flistp); \
	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, err_log_msg, ebufp);
