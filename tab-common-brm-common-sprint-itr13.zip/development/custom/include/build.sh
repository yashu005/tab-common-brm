#!/bin/bash

#================================================================================
# build the include files by
# 1) running parse_custom_ops_fields with an output folder of $TARGETDIR/brm/lib
# 2) copying all *.h files into $TARGETDIR/brm/include
#
# if $TARGETDIR is not set then use the older legacy build approach
#================================================================================

echo ""
echo "***************************************"
echo "* building custom/include folder"
echo "***************************************"

if [[ -z "${TARGETDIR}" ]]; then
    echo "Environment Variable TARGETDIR is not set - defaulting to ../lib"
    OUTDIR=${PIN_HOME}/custom/lib
    JARDIR=${PIN_HOME}/jars
else
    OUTDIR=${TARGETDIR}/brm/lib
    JARDIR=${PIN_HOME}/jars
fi

CUSTOM_FLD_FILE="tab_ops_flds.h"
CUSTOM_DAT_FILE="tab_ops_flds"

echo "Creating the tab_ops_flds:"
echo "Running parse_custom_ops_fields.pl -L pcmc -I ${CUSTOM_FLD_FILE} -O $TARGETDIR/brm/lib/${CUSTOM_DAT_FILE}"

mkdir -p $OUTDIR

parse_custom_ops_fields.pl -L pcmc -I ${CUSTOM_FLD_FILE} -O $OUTDIR/${CUSTOM_DAT_FILE}

mkdir customJarDirectory
echo "Copying header file"
cp ${CUSTOM_FLD_FILE} ./customJarDirectory
cd customJarDirectory

ls -lrt $JARDIR/pcm.jar

parse_custom_ops_fields.pl -L pcmjava -I ${CUSTOM_FLD_FILE} -O CustomOp.java -P com.telenor.brm.customfields
javac -classpath $JARDIR/pcm.jar:$JARDIR/pcmext.jar:. -d . *.java
jar -cvf CustomFields.jar com/telenor/brm/customfields/*.class

echo "CustomFields.jar Generated"
cp CustomFields.jar $OUTDIR/CustomFields.jar

cd ..
rm -rf customJarDirectory
