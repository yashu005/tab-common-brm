/***********************************
 * TAB Common Header File for 
 * Global Values
 * Error Messages
 * Error Codes
 ***********************************/

/****** Opcode Return Status ******/
#define TAB_FAIL				0
#define TAB_SUCCESS				1
#define TAB_UNALLOCATED_FLAG_TRUE		1
#define TAB_ALLOCATED_FLAG_TRUE              	1

/****** Custom object /tab_order Status ******/
#define TAB_ORDER_SUCCESS			1
#define TAB_ORDER_FAILURE			0
#define TAB_ORDER_NO_EXCEPTION			0
#define TAB_ORDER_EXCEPTION			1
#define TAB_ORDER_CREATE			1

/****** Purchase Offer API Status ******/
#define TAB_FOUND				1
#define TAB_NOT_FOUND				0

/****** Value for converting timestamp to date ******/
#define MAX 256

//Action Codes
#define TAB_ACTION_ADD				"add"
#define TAB_ACTION_DELETE			"delete"
#define TAB_ACTION_CSG_CREATE			"create_csg"
#define TAB_ACTION_DSG_CREATE			"create_dsg"
#define TAB_ACTION_MODIFY_OFFER_CSG     "modify_offer_csg"
#define TAB_ACTION_MODIFY_OFFER_DSG     "modify_offer_dsg"
#define TAB_ACTION_MODIFY_MEMBER_CSG    "modify_member_csg"
#define TAB_ACTION_MODIFY_MEMBER_DSG    "modify_member_dsg"
#define TAB_ACTION_MODIFY			"Modify"

//Get account info - Dunning status
#define TAB_DUNNING_STATUS_YES			"Yes"
#define TAB_DUNNING_STATUS_NO			"No"

//Get account info - Object Types
#define TAB_OBJECT_TYPE_ALL                  	"All"
#define TAB_OBJECT_TYPE_PAYMENT_INFO         	"paymentInfo"
#define TAB_OBJECT_TYPE_BILL_UNIT            	"billUnit"
#define TAB_OBJECT_TYPE_SERVICES             	"Services"
#define TAB_OBJECT_TYPE_ACCOUNT_PROFILE      	"accountProfile"

//NCR Adjustment Action Modes
#define ADDENTRY_FLAG 1
#define UPDATEENTRY_FLAG 0

/*getPurchaseOffer Offering Status*/
#define TAB_FLG_OFFERING_STATUS_ACTIVE          1
#define TAB_FLG_OFFERING_STATUS_INACTIVE        2
#define TAB_FLG_OFFERING_STATUS_CLOSED          3
#define TAB_FLG_OFFERING_STATUS_ACTIVE_INACTIVE 4

//Get account info - Auto pay type
#define	TAB_PAY_TYPE_AUTOPAY			20007

/*Service Terminate - Program Name*/
#define TAB_TERMINATE_SERVICE                   "Service Terminate"

/*31 days value*/
#define TAB_VAL_ONE_MONTH_DAYS_IN_SEC			2678400				 
/* Notification event type */
#define TAB_NOTIFY_EVENT_CHANGE_OFFER           		"/event/notification/custom/changeOffer"
#define TAB_NOTIFY_EVENT_CANCEL_OFFERS          		"/event/notification/custom/cancelOffers"
#define TAB_NOTIFY_EVENT_PURCHASE_OFFERS        		"/event/notification/custom/purchaseOffers"
#define TAB_NOTIFY_EVENT_UPDATE_ADDRESSES       		"/event/notification/custom/updateAddresses"
#define TAB_NOTIFY_EVENT_CREATE_ACCOUNT         		"/event/notification/custom/createAccount"
#define TAB_NOTIFY_EVENT_CREATE_SUBSCRIBER      		"/event/notification/custom/createSubscriber"
#define TAB_NOTIFY_EVENT_MANAGE_CUG             		"/event/notification/custom/manageCug"
#define TAB_NOTIFY_EVENT_MANAGE_FNF             		"/event/notification/custom/manageFnf"
#define TAB_NOTIFY_EVENT_MANAGE_MSISDN_SIM      		"/event/notification/custom/manageMsisdnSim"
#define TAB_NOTIFY_EVENT_UPDATE_INVOICE_PREFERENCE      "/event/notification/custom/updateInvoicePreference"
#define TAB_NOTIFY_EVENT_MAKE_ADJUSTMENT				"/event/notification/custom/makeAdjustment"
#define TAB_NOTIFY_ENABLE                     		  	1
#define TAB_NOTIFY_DISABLE                    		  	0
#define TAB_NOTIFY_EVENT_UPDATE_SUBSCRIBER_PREFERENCES		"/event/notification/custom/updateServicePreferences"
#define TAB_NOTIFY_EVENT_CANCEL_BUDGET_LIMIT            "/event/notification/custom/cancelBudgetLimit"
#define TAB_NOTIFY_EVENT_SET_BUDGET_LIMIT                       "/event/notification/custom/setBudgetLimit"
#define TAB_NOTIFY_EVENT_CHANGE_BDOM                            "/event/notification/custom/changeBdom"
#define TAB_NOTIFY_EVENT_MAKE_PAYMENT_REVERSAL			"/event/notification/custom/makePaymentReversal"
#define TAB_NOTIFY_EVENT_UPDATE_PAYTYPE                         "/event/notification/custom/updatePaytype"
#define TAB_NOTIFY_EVENT_DELETE_SHARING_GROUP                    "/event/notification/custom/deleteSharingGroup"
#define TAB_NOTIFY_EVENT_AD_CHARGE_SHARING_GROUP                "/event/notification/custom/addRemoveMemberCSG"
#define TAB_NOTIFY_EVENT_AD_DISCOUNT_SHARING_GROUP              "/event/notification/custom/addRemoveMemberDSG"
#define TAB_NOTIFY_EVENT_ADD_GROUP_MEMBER                       "/event/notification/custom/addGroupMember"
#define TAB_NOTIFY_EVENT_DELETE_GROUP_MEMBER                       "/event/notification/custom/deleteGroupMember"
#define TAB_NOTIFY_EVENT_UPDATE_ACCOUNT_PROFILE		"/event/notification/custom/updateAccountProfile"
#define TAB_NOTIFY_EVENT_MAKE_SETTLEMENT                        "/event/notification/custom/makeSettlement"
#define TAB_NOTIFY_EVENT_MAKE_REFUND				"/event/notification/custom/makeRefund"
#define TAB_NOTIFY_EVENT_UPDATE_ACCOUNT_STATUS                  "/event/notification/custom/updateAccountStatus"
#define TAB_NOTIFY_EVENT_MAKE_DEPOSIT                           "/event/notification/custom/makeDeposit"
#define TAB_NOTIFY_EVENT_MAKE_DISPUTE                   "/event/notification/custom/makeDispute"
#define TAB_NOTIFY_EVENT_MAKE_WRITEOFF                  "/event/notification/custom/makeWriteoff"
#define TAB_NOTIFY_EVENT_CREATE_CHARGE_SHARING_GROUP      "/event/notification/custom/createCSG"
#define TAB_NOTIFY_EVENT_CREATE_DISCOUNT_SHARING_GROUP     "/event/notification/custom/createDSG"
#define TAB_NOTIFY_EVENT_ADD_REMOVE_CHARGE_SHARING_OFFER                "/event/notification/custom/addRemoveOfferCSG"
#define TAB_NOTIFY_EVENT_ADD_REMOVE_DISCOUNT_SHARING_OFFER                "/event/notification/custom/addRemoveOfferDSG"
#define TAB_NOTIFY_EVENT_MOVE_GROUP_MEMBER                       "/event/notification/custom/moveGroupMember"

/*BudgetLimitOpcode*/
#define TAB_CL_TYPE_DOMESTIC			        1
#define TAB_CL_TYPE_IR_BUDGET                   2
#define TAB_CL_TYPE_SERVICE_WISE                3

#define TAB_SERVICE_VOICE			"Voice"
#define TAB_SERVICE_SMS				"SMS"
#define TAB_SERVICE_DATA			"Data"

//Generic Message
#define TAB_ACTION_MSISDN_NAME				"msisdn"
#define TAB_ACTION_IMSI_NAME				"imsi"  
#define TAB_ACTION_SWAPIMSI				"swapIMSI"
#define TAB_FLAG_TRUE					"true"
#define TAB_FLAG_FALSE					"false"
#define TAB_TEMP_SWAP_IMSI_1				"temp_swap_imsi_1"
#define TAB_TEMP_SWAP_IMSI_2				"temp_swap_imsi_2"
#define TAB_PROFILE_SERV_EXTRATING			"/profile/serv_extrating"
#define TAB_PROFILE_MULTISIM_MAP			"/profile/tab_multisim_map"
#define TAB_PROFILE_SUSBCRIBER_PREF			"/profile/subscriber_preferences"
#define TAB_GROUP_CHARGE_SHARING			"/group/sharing/charges"
#define TAB_GROUP_DISCOUNT_SHARING			"/group/sharing/discounts"
#define TAB_PROGRAM_NAME_INTERNAL			"internal"

#define TAB_TYPE_EVENT_CYCLE_ROLLOVER_MONTHLY 		"/event/billing/cycle/rollover/monthly"	
#define TAB_OBJ_TYPE_PREPAID_SUB_RECHARGE		"/tab_prepaid_subscriber_recharge"
#define TAB_OBJ_TYPE_RECHARGE_NOTIFICATION		"/event/notification/custom/recharge"
#define TAB_OBJ_TYPE_REVERSE_RECHARGE_NOTIFICATION	"/event/notification/custom/reverserecharge"
#define TAB_OBJ_TYPE_REQUEST_LOAN_NOTIFICATION	        "/event/notification/custom/requestloan"
#define TAB_OBJ_TYPE_PAYINFO_PREPAID			"/payinfo/prepaid"
#define TAB_OBJ_TYPE_PAYINFO_AUTOPAY			"/payinfo/autopay"
#define TAB_OBJ_TYPE_SERVICE_GSM			"/service/telco/gsm"
#define TAB_OBJ_TYPE_PAYMENT_NOTIFICATION		"/event/notification/custom/payment"
#define TAB_OBJ_TYPE_CORP_PAYMENT_NOTIFICATION		"/event/notification/custom/corp_payment"
#define TAB_OBJ_TYPE_MODIFY_CL_NOTIFICATION		"/event/notification/custom/modify_cl"
#define TAB_OBJ_TYPE_PURCHASED_DEPOSIT                  "/purchased_deposit"
#define TAB_OBJ_TYPE_RELEASE_DEPOSIT_NOTIFICATION	"/event/notification/custom/release_deposit"
#define TAB_OBJ_TYPE_CREATE_INSTALLMENT                 "/event/notification/custom/createinstallment"

#define TAB_NAME_BILLINFO_ID				"Bill Unit(1)"
#define TAB_PAYINFO_PREPAID				"Prepaid"
#define TAB_PAYINFO_POSTPAID				"Postpaid"

#define ITEM_GSM "VoiceUsage"
#define ITEM_GPRS "DataUsage"
#define ITEM_MMS "MMSUsage"
#define ITEM_SMS "SMSUsage"
#define ITEM_ROAMING "RoamingVoiceUsage"
#define CHARGE "Charge"
#define DISCOUNT "Discount"
#define ITEM_CONTENT "ContentUsage"
#define ITEM_ROAMING_DATA "RoamingDataUsage"
#define ITEM_ROAMING_SMS "RoamingSMSUsage"

#define ONEDAY 	86400
#define TAB_VAL_ONE_MONTH_DAYS_IN_SEC  2678400
#define SUCCESS "Success"
#define FAILURE "Failure"

#define TAB_INSTL_TYPE_EQUAL                            1
#define TAB_INSTL_TYPE_UNEQUAL                          2


/****** BILL_WHEN ******/
#define TAB_BILL_TYPE_MONTHLY            1
#define TAB_BILL_TYPE_QUARTERLY          3
#define TAB_BILL_TYPE_SEMIANNUAL         6
#define TAB_BILL_TYPE_ANNUAL             12

/****** Common Flag Value ******/
#define TAB_COMMON_FLAG_YES             "Yes"
#define TAB_COMMON_FLAG_NO              "No"

/****** AR TAX Flag value ******/
#define TAB_AR_NO_TAX                   1
#define TAB_AR_WITH_TAX                 2

/**** AR Deposit Status Value ****/
#define TAB_AR_DRAFT_DEPOSIT            "1"
#define TAB_AR_NON_DRAFT_DEPOSIT        "0"

/**** Collections Flag Value  ***/
#define TAB_COLL_EXEMPT_FLAG_TRUE                    0
#define TAB_COLL_EXEMPT_FLAG_FALSE                   1


/****** Custom Structure ******/
typedef struct field {
	pin_fld_num_t		fld_name;
	void			*fld_value;
	int			elem_id;
	} field_t;

/*** To Include error header file */
#include "tab_error.h"

/*** To Include custom header file */
#include "tab_common_custom.h"
