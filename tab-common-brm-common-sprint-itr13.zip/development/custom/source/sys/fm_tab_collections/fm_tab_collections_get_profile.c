/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 26-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_GET_PROFILE operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"



/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_get_profile(
		cm_nap_connection_t     *connp,
		int                     opcode,
		int                     flags,
		pin_flist_t             *in_flistp,
		pin_flist_t             **out_flistpp,
		pin_errbuf_t            *ebufp);

void fm_tab_collections_get_profile(
		pcm_context_t       	*ctxp,
		pin_flist_t         	*in_flistp,
		pin_flist_t         	**out_flistpp,
		int64                   db_no,
		pin_errbuf_t        	*ebufp);



/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_GET_PROFILE is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 1
 0 PIN_FLD_MSISDN    STR [0] "6091001011"
 0 PIN_FLD_ACCOUNT_NO    STR [0] "6091001011"
 0 PIN_FLD_CORRELATION_ID    STR [0] "er2345XR"
 0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"


 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_GET_PROFILE operation.
 *************************************************************************/
void op_tab_collections_get_profile(
		cm_nap_connection_t      *connp,
		int                       opcode,
		int                       flags,
		pin_flist_t               *in_flistp,
		pin_flist_t               **ret_flistpp,
		pin_errbuf_t              *ebufp)
{
	pcm_context_t            *ctxp = connp->dm_ctx;
	pin_flist_t              *r_flistp = NULL;
	int32                    error_clear_flag = 1;
	int32                    cerror_code = 0;
	char                     log_msg[512]= "";
	int64                    db_no = 0;
	int32                    status = PIN_BOOLEAN_TRUE;
	pin_flist_t              *enrich_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_profile error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_GET_PROFILE) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_profile opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_profile input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"before dropping PIN_FLD_MSISDN "
			" input flist", in_flistp);

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_profile: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_get_profile:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);



	/*	 call main function */
	fm_tab_collections_get_profile(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_get_profile error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_profile:"
				" fm_tab_collections_get_profile input flist", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_profile:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_profile:"
				" Error while getting collections profile details ", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_COLLECTION_PROFILE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_COLLECTION_PROFILE )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_COLLECTION_PROFILE, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_profile output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_get_profile(
		pcm_context_t       *ctxp,
		pin_flist_t         *in_flistp,
		pin_flist_t         **out_flistpp,
		int64               db_no,
		pin_errbuf_t        *ebufp)
{
	pin_flist_t                     *billinfo_flistp= NULL;
	pin_flist_t                     *ret_get_profile_flistp = NULL;
	pin_flist_t                     *ret_flistp = NULL;
	pin_flist_t                     *get_profile_flistp = NULL;
	pin_flist_t                     *scenario_readobj_iflistp = NULL;
	pin_flist_t                     *bill_readobj_iflistp = NULL;
	pin_flist_t                     *config_scenario_readobj_iflistp = NULL;
	pin_flist_t                     *config_scenario_readobj_rflistp = NULL;
	pin_flist_t                     *scenario_readobj_rflistp = NULL;
	pin_flist_t                     *bill_readobj_rflistp = NULL;
	pin_flist_t                     *enrich_profile_flistp = NULL;
	pin_flist_t                     *enrich_get_profile_flistp = NULL;
	poid_t                          *account_pdp = NULL;
	char                            log_msg[256]="";
	int32                           active_flag = 0;
	int32                           paytype_i = 0;
	poid_t  			*scenario_obj  = NULL;
	poid_t  			*bill_obj  = NULL;
	poid_t  			*config_scenario_obj  = NULL;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;
	char                            *scenario_name = NULL;
	char                            *due_t_str = NULL;
	int32                   	error_code = 0;
	pin_decimal_t                   *total_due_amount = NULL;
	pin_decimal_t                   *overdue_amount = NULL;
	pin_decimal_t                   *outstanding_amount = NULL;
	time_t                          *due_t = NULL;
	void                            *vp = NULL;


	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_profile error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_profile:"
				" input flist", in_flistp);
		return;
	}


	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}



	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_get_profile:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_get_profile:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_SCENARIO_OBJ, in_flistp, PIN_FLD_SCENARIO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_LAST_BILL_OBJ, in_flistp, PIN_FLD_LAST_BILL_OBJ, ebufp);

	vp=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp != NULL)
	{
		paytype_i = *(int32 *)vp;
	}


	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
        {
                if(account_no != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }


	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			"Validated to be postpaid account");

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"in flist", in_flistp)



		/*Read_Obj of scenario_obj*/

		scenario_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SCENARIO_OBJ,1,ebufp);
	if (PIN_POID_IS_NULL(scenario_obj))
			{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_obj:"
					"Account not in collections,Error while getting  SCENARIO obj_id", ebufp);
			goto cleanup;
			}

			scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(scenario_readobj_iflistp,PIN_FLD_POID, scenario_obj, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj input flist",
				scenario_readobj_iflistp);
			PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, scenario_readobj_iflistp,&scenario_readobj_rflistp, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Account not in collections,scenario_read_obj input flist",
					scenario_readobj_iflistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
					"Error while doing SCENARIO  read_obj", ebufp);
			goto cleanup;
			}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj return flist",
			scenario_readobj_rflistp);

	if(scenario_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Account not in collections,Error while doing SCENARIO  read_obj", ebufp);
		goto cleanup;
	}


	overdue_amount=PIN_FLIST_FLD_GET(scenario_readobj_rflistp,PIN_FLD_OVERDUE_AMOUNT, 1, ebufp);

	/*Read_Obj of bill_obj*/
	bill_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_LAST_BILL_OBJ,0,ebufp);
	bill_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(bill_readobj_iflistp,PIN_FLD_POID, bill_obj, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," BILL  Read_Obj input flist",
			bill_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, bill_readobj_iflistp,&bill_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"bill_read_obj input flist",
				bill_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"bill_read_obj:"
				"Error while doing BILL  read_obj", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," BILL  Read_Obj return flist",
			bill_readobj_rflistp);

	if(bill_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"bill_read_obj input flist",
				bill_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"bill_read_obj:"
				"Error while doing BILL  read_obj", ebufp);
		goto cleanup;
	}
	total_due_amount=PIN_FLIST_FLD_GET(bill_readobj_rflistp,PIN_FLD_TOTAL_DUE,1,ebufp);


	due_t=PIN_FLIST_FLD_GET(bill_readobj_rflistp,PIN_FLD_DUE_T,1,ebufp);
	if(due_t != NULL )
	{
		/*Convert date in string format to unix timestamp*/
		due_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp, due_t, ebufp);

	}


	 config_scenario_obj= PIN_FLIST_FLD_GET(scenario_readobj_rflistp,PIN_FLD_CONFIG_SCENARIO_OBJ,1,ebufp);
        if (PIN_POID_IS_NULL(config_scenario_obj))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"config_scenario_obj :"
				"Error while getting  config_scenario_obj for the scenario", ebufp);
		goto cleanup;
	}


	/*Read_Obj of config_scenario_obj*/
	//config_scenario_obj = PIN_FLIST_FLD_GET(scenario_readobj_rflistp,PIN_FLD_CONFIG_SCENARIO_OBJ,0,ebufp);
	config_scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(config_scenario_readobj_iflistp,PIN_FLD_POID, config_scenario_obj, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," config scenario  Read_Obj input flist",
			config_scenario_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, config_scenario_readobj_iflistp,&config_scenario_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"config scenario not found , config scenario_obj input flist",
				config_scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"config scenario:"
				"Error, scenario config info not found", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"  config scenario return flist",
			config_scenario_readobj_rflistp);

	if(config_scenario_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"config scenario input flist",
				config_scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"config scenario:"
				"Error, scenario config info not found", ebufp);
		goto cleanup;
	}
	scenario_name=PIN_FLIST_FLD_GET(config_scenario_readobj_rflistp,PIN_FLD_NAME,1,ebufp);
	outstanding_amount = pbo_decimal_add(total_due_amount, overdue_amount, ebufp);

	get_profile_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_profile_flistp, PIN_FLD_POID, ebufp); 
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, get_profile_flistp, PIN_FLD_ACCOUNT_NO, ebufp); 
	PIN_FLIST_FLD_SET(get_profile_flistp,PIN_FLD_SCENARIO_OBJ, scenario_obj, ebufp);
	PIN_FLIST_FLD_SET(get_profile_flistp,PIN_FLD_NAME, scenario_name, ebufp);
	PIN_FLIST_FLD_SET(get_profile_flistp,TAB_FLD_DUE_T_STR, due_t_str, ebufp);
	PIN_FLIST_FLD_SET(get_profile_flistp,PIN_FLD_TOTAL_DUE, total_due_amount, ebufp);
	PIN_FLIST_FLD_SET(get_profile_flistp,PIN_FLD_OVERDUE_AMOUNT, overdue_amount, ebufp);
	PIN_FLIST_FLD_SET(get_profile_flistp,PIN_FLD_AMOUNT, outstanding_amount, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, get_profile_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, get_profile_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	free(due_t_str);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			" TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE input flist ", get_profile_flistp);

	enrich_get_profile_flistp=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrich_get_profile_flistp, get_profile_flistp, PIN_FLD_OUT_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			" TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE enrich_get_profile_flistp flist ", enrich_get_profile_flistp);


	pbo_decimal_destroy(&outstanding_amount);
	PIN_ERR_CLEAR_ERR(ebufp);

	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE, 0, enrich_get_profile_flistp, &enrich_profile_flistp, ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error in TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_profile : TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE:"
				"Enrich input flist", get_profile_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrich_profile_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (enrich_profile_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_PROFILE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_profile: Error in TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE enrich_iflistp is NULL.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_profile:"
				"Enrich input flist : TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE : ", get_profile_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			"TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE : After Enrich output flist :", enrich_profile_flistp);

	ret_flistp = PIN_FLIST_COPY(enrich_profile_flistp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_profile:"
			"output flist :", ret_flistp);


	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_profile_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&config_scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&bill_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_get_profile_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&get_profile_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_get_profile_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&config_scenario_readobj_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&bill_readobj_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_iflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_get_profile output flist : ", *out_flistpp);

	return;
}
