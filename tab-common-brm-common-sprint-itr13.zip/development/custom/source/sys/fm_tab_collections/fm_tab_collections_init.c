
/*******************************************************************************
 *
 *	This material is the confidential property of Oracle corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 * Change History
 *
 * No | Date       | Programmer  | Req/bug/Gap   			| Change details
 *
 * 1  | 14-04-2022 | Akshay Gund | 					| Common init function for collection cache
 * 1  | 24-04-2022 | Rashmi Shete | 					| Common init function for collection action/scenario and instalment cache.
 *																 
 **************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "pcm.h"
#include "pinlog.h"
#include "pin_errs.h"
#include "cm_fm.h"
#include "cm_cache.h"
#include "pin_cust.h"

#define FILE_SOURCE_ID          "fm_tab_collections_init.c"
/*******************************************************************
 * Global Variable declaration
 *******************************************************************/

static void
fm_tab_collections_init_create_installment(
		pcm_context_t   *ctxp,
		int32 *errp);

static void
fm_tab_collections_init_get_collection_scenarios(
		pcm_context_t   *ctxp,
		int32            *errp);

void
fm_tab_collections_init_get_config_collection_actions(
		pcm_context_t           *ctxp,
		int32            *errp);


/***********************************************************************
 *Forward declaration
 ***********************************************************************/
EXPORT_OP void fm_tab_collections_init(int32 *errp);


PIN_EXPORT cm_cache_t *tab_get_collections_status_config_cache_ptr = (cm_cache_t *)0;


PIN_EXPORT cm_cache_t *fm_collections_config_scenario_cache_ptr  = (cm_cache_t *)0;

PIN_EXPORT pin_flist_t  *config_collection_actions_flistp;




	void
fm_tab_collections_init(int32 *errp)
{
	pcm_context_t		*ctxp = NULL;
	pin_errbuf_t		ebuf;
	int32			 *err_p;

	PIN_ERR_CLEAR_ERR(&ebuf);
	/***********************************************************
	 * open the context and get the database number. Don't do this
	 * first, otherwise we don't cleanup.
	 ***********************************************************/
	PCM_CONTEXT_OPEN(&ctxp, (pin_flist_t *)0, &ebuf);

	if(PIN_ERR_IS_ERR(&ebuf)) 
	{
		pin_set_err(&ebuf, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_DM_CONNECT_FAILED, 0, 0, ebuf.pin_err);

		PIN_FLIST_LOG_ERR("fm_tab_collections_init pcm_context_open err", 
				&ebuf);

		*errp = PIN_ERR_NAP_CONNECT_FAILED;
		return;
	}

	/***********************************************************
	 * Load custom beid mapping information
	 ***********************************************************/
	fm_tab_collections_init_create_installment(ctxp,err_p);

	fm_tab_collections_init_get_collection_scenarios(ctxp,err_p);


	fm_tab_collections_init_get_config_collection_actions( ctxp, err_p );

	PCM_CONTEXT_CLOSE(ctxp, 0, &ebuf);
	*errp = ebuf.pin_err;
	return;
}

/***********************************************************************
 *  fm_tab_collections_init_get_collection_scenarios
 *
 * Frame the global flist with /config/collections/scenario object
 ***********************************************************************/

	static 
void fm_tab_collections_init_get_collection_scenarios(
		pcm_context_t   *ctxp, 
		int32		 *errp)
{
	pin_errbuf_t            ebuf;
	int64                   database;
	poid_t                  *pdp = NULL;
	poid_t                  *s_pdp = NULL;
	char                    s_template[BUFSIZ];
	int32                   err = 0;
	pin_flist_t             *s_flistp = NULL;
	pin_flist_t             *arg_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t 		*temp_act_flistp = NULL;
	pin_flist_t 		*temp_flistp = NULL;
	int32                   s_flags = SRCH_DISTINCT;
	cm_cache_key_poid_t     cache_key;
	int32                   nconfig;
	int32 					res_elemid = 0;
	int32 					act_elemid = 0;
	pin_cookie_t            res_cookie = NULL;
	pin_cookie_t 			act_cookie = NULL;
	
	/***********************************************************
	 * open the context and get the database number.
	 ***********************************************************/
	PIN_ERR_CLEAR_ERR(&ebuf);

	pdp = PCM_GET_USERID(ctxp);
	database = PIN_POID_GET_DB(pdp);
	PIN_POID_DESTROY(pdp, NULL);
	/***********************************************************
	 * Get all /config_instl_sch_spec objects
	 ***********************************************************/

	s_flistp = PIN_FLIST_CREATE(&ebuf);

	s_pdp = PIN_POID_CREATE(database, "/search", -1, &ebuf);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, &ebuf);

	/* setup arguments */
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, &ebuf);

	s_pdp = PIN_POID_CREATE(database, "/config/collections/scenario", -1, &ebuf);
	PIN_FLIST_FLD_PUT(arg_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);

	sprintf(s_template, "select X from /config where  F1.type like V1");
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, &ebuf);

	PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_RESULTS, PCM_RECID_ALL, &ebuf);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Search flist", s_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &r_flistp, &ebuf);

	if (PIN_ERR_IS_ERR(&ebuf)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_init_get_collection_scenarios: error loading "
				"/config/collections/scenario object", &ebuf);
		goto cleanup;
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"Config Collection Scenarios return flist ", r_flistp);

	/* Housekeeping..  Free un-needed memory allocated so far */
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);

	while ((temp_flistp = PIN_FLIST_ELEM_GET_NEXT(r_flistp,
											PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, &ebuf)) != (pin_flist_t *)NULL)
	{	act_elemid = 0;
		act_cookie = NULL;
		
		nconfig++;
		
		while ((temp_act_flistp = PIN_FLIST_ELEM_GET_NEXT(temp_flistp,
										PIN_FLD_ACTIONS, &act_elemid, 1, &act_cookie, &ebuf)) != (pin_flist_t *)NULL)
		{
			nconfig++;
		}
	}

	if (nconfig == 0) {
		fm_collections_config_scenario_cache_ptr = NULL;
		goto cleanup;

	} else {
		/*
		 * This cache doesn't need configuration because its size
		 * is computed
		 */
		fm_collections_config_scenario_cache_ptr =
			cm_cache_init("tab_get_collections_scenario_cache",
					nconfig,
					nconfig * 1024 ,
					1, CM_CACHE_KEY_POID, &err);

		if (err != PIN_ERR_NONE) {
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_init_get_collection_scenarios: error initing cm_cache", &ebuf);
			goto cleanup;
		}
	}

	cache_key.db = 0;
	cache_key.id = 1;

	cm_cache_add_entry (fm_collections_config_scenario_cache_ptr,
			(void *)&cache_key, r_flistp, &err);
	switch (err) {
		case PIN_ERR_NONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_DEBUG
					,
					"Added fm_tab_collections_init_get_collection_scenarios  cache entry: "
					"cache key [%" I64_PRINTF_PATTERN "d.%"
					I64_PRINTF_PATTERN "d] : ",
					cache_key.db, cache_key.id);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"cache value :", r_flistp);
			break;
		case PIN_ERR_OP_ALREADY_DONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_WARNING
					,
					"add fm_tab_collections_init_get_collection_scenarios  cache entry already done: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
		default:
			pin_set_err(&ebuf, PIN_ERRLOC_FM,
					PIN_ERRCLASS_SYSTEM_DETERMINATE,
					PIN_ERR_NO_MEM, 0, 0, err);
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_ERROR,
					"bad fm_tab_collections_init_get_collection_scenarios  cache add entry: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
	}

	return;
cleanup:
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	fm_collections_config_scenario_cache_ptr = NULL;
	return;
}


/***********************************************************************
 * fm_tab_collections_init_create_installment
 * Frame the global flist with custom /config/installment/schedule_spec object 
 ***********************************************************************/
	static
void fm_tab_collections_init_create_installment(
		pcm_context_t   *ctxp,
		int32            *errp)
{
	pin_errbuf_t            ebuf;
	int64                   database;
	poid_t                  *pdp = NULL;
	poid_t                  *s_pdp = NULL;
	char                    s_template[BUFSIZ];
	int32                   err = 0;
	pin_flist_t             *s_flistp = NULL;
	pin_flist_t             *arg_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t             *value_flistp = NULL;
	int32                   s_flags = SRCH_DISTINCT;
	cm_cache_key_poid_t     cache_key;
	int32                   nconfig;


	/***********************************************************
	 * open the context and get the database number.
	 ***********************************************************/
	PIN_ERR_CLEAR_ERR(&ebuf);

	pdp = PCM_GET_USERID(ctxp);
	database = PIN_POID_GET_DB(pdp);
	PIN_POID_DESTROY(pdp, NULL);
	/***********************************************************
	 * Get all /config_instl_sch_spec objects
	 ***********************************************************/

	s_flistp = PIN_FLIST_CREATE(&ebuf);

	s_pdp = PIN_POID_CREATE(database, "/search", -1, &ebuf);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, &ebuf);

	/* setup arguments */
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, &ebuf);

	s_pdp = PIN_POID_CREATE(database, "/config/installment/schedule_spec", -1, &ebuf);
	PIN_FLIST_FLD_PUT(arg_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);

	sprintf(s_template, "select X from /config/installment/schedule_spec where  F1=V1");
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, &ebuf);

	PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_RESULTS, PCM_RECID_ALL, &ebuf);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Search flist", s_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &r_flistp, &ebuf);

	if (PIN_ERR_IS_ERR(&ebuf)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_init_create_installment: error loading "
				"/config/installment/schedule_spec object", &ebuf);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"Config installment schedule spec return flist ", r_flistp);

	/* Housekeeping..  Free un-needed memory allocated so far */
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);


	value_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, &ebuf);
	if ( value_flistp != NULL)
	{
		nconfig = PIN_FLIST_COUNT(value_flistp, &ebuf);
	}

	if (nconfig == 0) {
		tab_get_collections_status_config_cache_ptr  = NULL;
		goto cleanup;

	} else {
		/*
		 * This cache doesn't need configuration because its size
		 * is computed
		 */
		tab_get_collections_status_config_cache_ptr  =
			cm_cache_init("tab_get_collections_status_cache",
					nconfig,
					nconfig * 2048 ,
					10, CM_CACHE_KEY_POID, &err);

		if (err != PIN_ERR_NONE) {
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_init_create_installment: error initing cm_cache", &ebuf);
			goto cleanup;
		}
	}

	cache_key.db = 0;
	cache_key.id = 1;

	cm_cache_add_entry (tab_get_collections_status_config_cache_ptr ,
			(void *)&cache_key, r_flistp, &err);
	switch (err) {
		case PIN_ERR_NONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_DEBUG
					,
					"Added fm_tab_collections_init_create_installment  cache entry: "
					"cache key [%" I64_PRINTF_PATTERN "d.%"
					I64_PRINTF_PATTERN "d] : ",
					cache_key.db, cache_key.id);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"cache value :", r_flistp);
			break;
		case PIN_ERR_OP_ALREADY_DONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_WARNING
					,
					"add fm_tab_collections_init_create_installment  cache entry already done: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
		default:
			pin_set_err(&ebuf, PIN_ERRLOC_FM,
					PIN_ERRCLASS_SYSTEM_DETERMINATE,
					PIN_ERR_NO_MEM, 0, 0, err);
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_ERROR,
					"bad fm_tab_collections_init_create_installment  cache add entry: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
	}

	return;
cleanup:
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	tab_get_collections_status_config_cache_ptr  = NULL;
	return;
}





/***********************************************************************
 * fm_tab_collections_init_get_config_collection_actions.c
 * Frame the global flist with custom /config/collections/action object
 ***********************************************************************/
	void
fm_tab_collections_init_get_config_collection_actions(
		pcm_context_t           *ctxp,
		int32            *errp)
{
	pin_errbuf_t            ebuf;
	int64                   database;
	poid_t                  *pdp = NULL;
	poid_t                  *s_pdp = NULL;
	char                    s_template[BUFSIZ];
	pin_flist_t             *s_flistp = NULL;
	pin_flist_t             *arg_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	int32                   s_flags = SRCH_DISTINCT;


	/***********************************************************
	 * open the context and get the database number.
	 ***********************************************************/
	PIN_ERR_CLEAR_ERR(&ebuf);

	pdp = PCM_GET_USERID(ctxp);
	database = PIN_POID_GET_DB(pdp);
	PIN_POID_DESTROY(pdp, NULL);

	/***********************************************************
	 * Get all /config/collections/action objects
	 ***********************************************************/

	s_flistp = PIN_FLIST_CREATE(&ebuf);

	s_pdp = PIN_POID_CREATE(database, "/search", -1, &ebuf);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, &ebuf);

	/* setup arguments */
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, &ebuf);

	s_pdp = PIN_POID_CREATE(database, "/config/collections/action%", -1, &ebuf);
	PIN_FLIST_FLD_PUT(arg_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);

	sprintf(s_template, "select X from /config/collections/action  where  F1 like V1 ");
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, &ebuf);

	PIN_FLIST_ELEM_SET(s_flistp, NULL, PIN_FLD_RESULTS, 0, &ebuf);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Search flist", s_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &r_flistp, &ebuf);
	if (PIN_ERR_IS_ERR(&ebuf)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_init_get_config_collection_actions: error loading "
				"/config/collections/action object", &ebuf);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"Config Collection Actions Return flist ", r_flistp);

	res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS,
			PIN_ELEMID_ANY, 1, &ebuf);

	if(res_flistp != NULL) {
		config_collection_actions_flistp = PIN_FLIST_COPY(r_flistp, &ebuf);
	}

	/* Housekeeping..  Free un-needed memory allocated so far */
cleanup:

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_init_get_config_collection_actions: "
			"config_collection_actions_flistp :", config_collection_actions_flistp);

	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	return;


}



