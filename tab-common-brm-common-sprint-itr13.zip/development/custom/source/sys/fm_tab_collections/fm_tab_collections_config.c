/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_collections_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_collections_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_COLLECTIONS_UPDATE_EXEMPTION,"op_tab_collections_update_exemption"  },
	{ TAB_OP_COLLECTIONS_REPLACE_SCENARIO, "op_tab_collections_replace_scenario"},
	{ TAB_OP_COLLECTIONS_CREATE_INSTALLMENT , "op_tab_collections_create_installment"},
	{ TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT , "op_tab_collections_cancel_installment" },
	{ TAB_OP_COLLECTIONS_GET_INSTALLMENT , "op_tab_collections_get_installment" },
	{ TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY , "op_tab_collections_create_promise_to_pay" },
	{ TAB_OP_COLLECTIONS_GET_PROFILE , "op_tab_collections_get_profile" },
	{ TAB_OP_COLLECTIONS_RESCHEDULE_ACTION , "op_tab_collections_reschedule_action" },
    { TAB_OP_COLLECTIONS_GET_ACTIONS , "op_tab_collections_get_actions" },
        { 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_collections_config_func()
{
  return ((void *) (fm_tab_collections_config));
}
#endif
