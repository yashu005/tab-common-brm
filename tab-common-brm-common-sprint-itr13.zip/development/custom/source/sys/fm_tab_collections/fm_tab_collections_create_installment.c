/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 04-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_CREATE_INSTALLMENT operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"
#include "ops/installment.h"
#include "fm_bill_utils.h"

extern cm_cache_t *tab_get_collections_status_config_cache_ptr;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_create_installment(
	cm_nap_connection_t    	*connp,
	int                     opcode,
	int                     flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **out_flistpp,
	pin_errbuf_t           	*ebufp);

void fm_tab_collections_create_installment(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	int64                  	db_no,
	pin_errbuf_t        	*ebufp);

static void
fm_tab_collections_create_installment_enrich_notification(
	pcm_context_t  		*ctxp,
	pin_flist_t    		*i_flistp,
	pin_flist_t   		*ret_flistp,
	int64          		db_no,
	pin_flist_t    		**r_flistpp,
	pin_errbuf_t   		*ebufp);

void fm_tab_mandatory_field_validation(
	pcm_context_t 		*ctxp,
	pin_flist_t    		*in_flistp,
	pin_flist_t    		**ret_flistpp,
	int64          		 db_no,
	pin_errbuf_t   		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern int32	*cfg_tab_system_currency;

extern void
fm_tab_utils_common_search_bill_no_with_account(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t   	*ebufp);

extern void
fm_tab_utils_common_get_bill_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern int
fm_tab_utils_calculate_number_of_days(
        int months,
        time_t *effective_tp);

/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_CREATE_INSTALLMENT is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 0
 0 PIN_FLD_ACCOUNT_NO	STR[0] "14422173"
 0 PIN_FLD_MSISDN      STR [0] "60020211229 "
 0 PIN_FLD_INSTALLMENT_TYPE   ENUM [0] 1
 0 PIN_FLD_TOTAL_AMOUNT        DECIMAL [0] 1500
 0 PIN_FLD_TERM            INT [0] 3
 0 PIN_FLD_CHARGE_AMT        DECIMAL [0] 500
 0 PIN_FLD_INVOICE_DATA	STR [0] "939393"
 0 PIN_FLD_START_T      TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_END_T        TSTAMP [0] (1672039389) Sun Dec 25 23:23:09 2022
 0 PIN_FLD_INSTALLMENTS 	ARRAY [0]
 1	PIN_FLD_AMOUNT	DECIMAL [0] 500
 1	PIN_FLD_EFFECTIVE_T	TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_EXTERNAL_USER              STR [0] "CRM"
 0 PIN_FLD_CORRELATION_ID             STR [0] "820345239"

 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_CREATE_INSTALLMENT operation.
 *************************************************************************/

void
op_tab_collections_create_installment(
	cm_nap_connection_t             *connp,
	int                              opcode,
	int                              flags,
	pin_flist_t                      *in_flistp,
	pin_flist_t                      **ret_flistpp,
	pin_errbuf_t                    *ebufp)

{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t			*r_flistp = NULL;
	int32				tab_order_flag = 0;
	int32				error_clear_flag = 1;
	int32				cerror_code = 0;
	char				log_msg[512]= "";
	int64				db_no = 0;
	poid_t				*account_pdp = NULL;
	int32				status = PIN_BOOLEAN_TRUE;
	pin_flist_t			*enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_collections_create_installment error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_CREATE_INSTALLMENT) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_collections_create_installment opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_installment input flist", in_flistp);

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/


	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_PAYMENT_INSTALLMENT, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_installment: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_collections_create_installment:"
				" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_installment:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_collections_create_installment(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_create_installment error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_collections_create_installment:"
				" fm_tab_collections_create_installment input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_installment:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_collections_create_installment: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_COLLECTIONS_CREATE_INSTALLMENT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_installment:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_installment:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_PAYMENT_INSTALLMENT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_installment output flist", *ret_flistpp);
	return;
}


void fm_tab_collections_create_installment(
	pcm_context_t       		*ctxp,
	pin_flist_t         		*in_flistp,
	pin_flist_t         		**out_flistpp,
	int64                          	db_no,
	pin_errbuf_t        		*ebufp)
{
	pin_flist_t			*billinfo_flistp= NULL;
	pin_flist_t			*enrich_iflistp = NULL;
	pin_flist_t			*ret_create_instl_flistp = NULL;
	pin_flist_t			*ret_flistp = NULL;
	pin_flist_t			*create_instl_flistp = NULL;
	pin_flist_t			*instl_flist = NULL;
	pin_flist_t			*r_flistp = NULL;
	pin_flist_t			*v_flistp = NULL;
	pin_flist_t			*i_validate_flistp = NULL;
	pin_flist_t			*o_validate_flistp = NULL;
	pin_flist_t			*res_flistp = NULL;
	pin_flist_t			*res_flistp1 = NULL;
	pin_flist_t			*in_freeze_collections = NULL;
	pin_flist_t			*out_freeze_collections = NULL;
	pin_flist_t			*update_service_flistp = NULL;
	pin_flist_t			*notify_oflistp = NULL;
	pin_flist_t			*notification_create_instl_flistp = NULL;
	poid_t				*account_pdp = NULL;
	poid_t				*instl_poid = NULL;
	poid_t				*instl_spec_obj = NULL;
	char				log_msg[256]="";
	int32				active_flag = 0;
	int32				paytype_i = 0;
	int32				elemid = 0;
	void				*vp = NULL;
	cm_cache_key_poid_t		cache_key;
	int32				err = 0;
	int				status = 100;
	int				flag = 0;

	char				*effective_date= NULL;

	time_t				effective_t=0;
	time_t				prev_date=0;
	int32				term=0;
	int32				count=0;
	int32				instl_type;
	int32				coll_action_elemid = 0;
	pin_cookie_t			coll_action_cookie = NULL;
	char				*account_no = NULL;
	int32				error_code = 0;
	pin_flist_t         		*get_bill_details_iflistp = NULL;
    	pin_flist_t         		*get_bill_details_oflistp = NULL;
    	pin_flist_t         		*bill_results_flistp = NULL;
	pin_flist_t 			*bill_res_flistp = NULL;
    	pin_flist_t         		*charge_flistp =  NULL;
	char				*invoice_data = NULL;
	pin_flist_t			*bill_oflistp = NULL;
	char 				*input_start_date = NULL;
	char 				*input_end_date = NULL;
	time_t 				start_date = 0;
	time_t 				end_date = 0;
	time_t 				temp_end_date = 0;
	int 				total_days = 0 ;

	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
			" input flist", in_flistp);
		return;
	}

	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		" input flist", in_flistp);

	fm_tab_mandatory_field_validation(ctxp, in_flistp, &v_flistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error in mandatory filed validation", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment input flist", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_mandatory_field_validation:"
		" Mandatory fileds validated successfully.", v_flistp);


	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment input flist", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

	/*********************************************************
	 * Validation if the account is postpaid.
	 *********************************************************/
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	paytype_i = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
	{
		if(account_no != NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				"Error Subord Paytype found for the given account", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				"Error SubordPaytype  input flist", billinfo_flistp);
			goto cleanup;
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				"Error Subord Paytype found for the given MSISDN", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				"Error SubordPaytype  input flist", billinfo_flistp);
			goto cleanup;
		}
	}

	input_start_date = PIN_FLIST_FLD_GET(in_flistp,	TAB_FLD_START_T_STR, 1, ebufp);

	if(input_start_date==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_STARTDATE_MISSING , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
		"Error start date is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
		"Error start date is missing input flist", billinfo_flistp);
		goto cleanup;

	}
	else
	{
		start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_start_date,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_installment: "
				"fm_tab_utils_common_convert_date_to_timestamp start date error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				" input flist", in_flistp);
			goto cleanup;
		}
	}

	if((input_end_date=PIN_FLIST_FLD_GET(in_flistp,	TAB_FLD_END_T_STR,1, ebufp))!=NULL)
	{
		end_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_end_date,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_installment: "
				"fm_tab_utils_common_convert_date_to_timestamp error end date", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment:"
				" input flist", in_flistp);
			goto cleanup;
		}
	}

	if((PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_INVOICE_DATA,1,ebufp))!=NULL)
	{
		fm_tab_utils_common_search_bill_no_with_account(ctxp,in_flistp,&bill_oflistp,db_no,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
				"Error in fm_tab_utils_common_search_bill_no_with_account  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
				"fm_tab_utils_common_search_bill_no_with_account: input flist",in_flistp);
			goto cleanup;
		}

		bill_res_flistp = PIN_FLIST_ELEM_GET(bill_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	}

	i_validate_flistp=PIN_FLIST_COPY(in_flistp, ebufp);

	/***********************************************************************************************
	 * Call Init to get the /config/installment/schedule_spec poid
	 ***********************************************************************************************/

	cache_key.id = 1;
	cache_key.db = 0;

	r_flistp = cm_cache_find_entry (tab_get_collections_status_config_cache_ptr,
			(void *)&cache_key, &err);

	if ( r_flistp != (pin_flist_t *)NULL )
	{
		res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if ( res_flistp != (pin_flist_t *)NULL )
		{
			PIN_FLIST_SUBSTR_SET(i_validate_flistp, r_flistp, PIN_FLD_IN_FLIST, ebufp);
		}

	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error in get_collections_status_config_cache details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment input flist", in_flistp);
		goto cleanup;

	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment: TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT "
		"input flist", i_validate_flistp);

	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT , 0,i_validate_flistp, &o_validate_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
			"Error in TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
			"TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT: input flist",i_validate_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(o_validate_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		"TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT : output flist :", o_validate_flistp);

	if (o_validate_flistp != (pin_flist_t *)NULL )
	{
		res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_POID, 0, ebufp);
		if(vp)
		{
			instl_spec_obj=(poid_t *)vp;

		}
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
			"Error in TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
			"TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT:"
			"input flist",i_validate_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_bill_details:"
	   " input flist ", in_flistp);

    	invoice_data = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_INVOICE_DATA, 1, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_bill_details:"
	   " input flist ", in_flistp);
    	if((invoice_data != NULL && strlen(invoice_data) != 0))
	{
        	get_bill_details_iflistp = PIN_FLIST_CREATE(ebufp);
        	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_INVOICE_DATA,get_bill_details_iflistp, PIN_FLD_BILL_NO, ebufp);
        	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ,get_bill_details_iflistp, PIN_FLD_POID, ebufp);
        	fm_tab_utils_common_get_bill_details(ctxp, get_bill_details_iflistp, &get_bill_details_oflistp, db_no, ebufp);
        	if(PIN_ERR_IS_ERR(ebufp))
        	{
            		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
               		" input flist ", in_flistp);
            		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
                	" Error while getting bill object", ebufp);
            		goto cleanup;
        	}
        	if(get_bill_details_oflistp != NULL && (bill_results_flistp =
			PIN_FLIST_ELEM_GET(get_bill_details_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
        	{
            		PIN_FLIST_FLD_COPY(bill_results_flistp, PIN_FLD_POID,in_flistp, PIN_FLD_CHARGE_OBJ, ebufp);
        	}
    	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_bill_details:"
	   " input flist ", in_flistp);

	/*********************************************************
	  * Flist creation of PCM_OP_INSTALLMENT_CREATE_INSTALLMENT
	 *********************************************************/
	/*
	 *Sample Input Flist to call the opcode:
	 0 PIN_FLD_POID           POID [0] 0.0.0.1 /installment -1 1
	 0 PIN_FLD_PROGRAM_NAME    STR [0] "CRM"
	 0 PIN_FLD_INSTALLMENT_SPEC_OBJ   POID [0] 0.0.0.1 /config/installment/schedule_spec 2636452 0
	 0 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2636100 0
	 0 PIN_FLD_FLAGS           INT [0] 0
	 0 PIN_FLD_INSTALLMENT_TYPE   ENUM [0] 1
	 0 PIN_FLD_START_T      TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
	 0 PIN_FLD_END_T        TSTAMP [0] (1672039389) Sun Dec 25 23:23:09 2022
	 0 PIN_FLD_TERM            INT [0] 1
	 0 PIN_FLD_TOTAL_AMOUNT DECIMAL [0] 290
	 0 PIN_FLD_DUE          DECIMAL [0] 100
	 0 PIN_FLD_STATUS         ENUM [0] 100
	 0 PIN_FLD_INSTALLMENTS  ARRAY [0] allocated 20, used 3
	 1     PIN_FLD_AMOUNT       DECIMAL [0] 100
	 1     PIN_FLD_STATUS         ENUM [0] 100
	 1     PIN_FLD_EFFECTIVE_T  TSTAMP [0] (1649228150) Tue Apr  5 23:55:50 2022

	 *
	 **/

	create_instl_flistp = PIN_FLIST_CREATE(ebufp);
	instl_poid = PIN_POID_CREATE(db_no, "/installment_schedule", -1, ebufp);
	PIN_FLIST_FLD_PUT(create_instl_flistp, PIN_FLD_POID, (void *)instl_poid, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, create_instl_flistp, PIN_FLD_PROGRAM_NAME, ebufp); //PROGRAM_NAME
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_INSTALLMENT_TYPE, create_instl_flistp, PIN_FLD_INSTALLMENT_TYPE, ebufp); //INSTALLMENT_TYPE
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, create_instl_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TOTAL_AMOUNT, create_instl_flistp, PIN_FLD_TOTAL_AMOUNT, ebufp); //TOTAL_AMOUNT

	PIN_FLIST_FLD_SET(create_instl_flistp, PIN_FLD_START_T,(void*)&start_date, ebufp);

	if(end_date)
		PIN_FLIST_FLD_SET(create_instl_flistp, PIN_FLD_END_T,(void*)&end_date, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TERM, create_instl_flistp, PIN_FLD_TERM, ebufp); //TEM
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TOTAL_AMOUNT, create_instl_flistp, PIN_FLD_DUE, ebufp);  //DUE

	if (bill_res_flistp!=NULL)
	{
		charge_flistp = PIN_FLIST_ELEM_ADD(create_instl_flistp,PIN_FLD_CHARGES, 0, ebufp);
		PIN_FLIST_FLD_COPY(bill_res_flistp, PIN_FLD_POID, charge_flistp, PIN_FLD_CHARGE_OBJ, ebufp);
	}
	PIN_FLIST_FLD_SET(create_instl_flistp,PIN_FLD_INSTALLMENT_SPEC_OBJ, instl_spec_obj, ebufp); //INSTALLMENT_SPEC_OBJ
	PIN_FLIST_FLD_SET(create_instl_flistp,PIN_FLD_FLAGS,&flag, ebufp); //FLAG(reg bill)
	PIN_FLIST_FLD_SET(create_instl_flistp,PIN_FLD_STATUS,&status, ebufp);  //STATUS(OPEN)

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_reschedule_action: create_instl_flistp", create_instl_flistp);

	instl_type = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_INSTALLMENT_TYPE, 0, ebufp);
	if(instl_type == TAB_INSTL_TYPE_EQUAL )
	{
		term= *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TERM, 0, ebufp);
		sprintf(log_msg,"term = %d",term);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		prev_date=start_date;
		struct tm *ptm = localtime(&prev_date);
		sprintf(log_msg,"The start day is: :%02d", ptm->tm_mday);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(ptm->tm_mday <= 28)
		{
			sprintf(log_msg,"The start day : %02d is less than 28", ptm->tm_mday);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		}
		else
		{
			sprintf(log_msg,"The start day : %02d is greater than 28. Invalid start date, can't process the create installment if DOM in start_t is > 28.", ptm->tm_mday);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INSTL_INCORRECT_START_T, 0, 0, 0);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment:"
				" input flist ", create_instl_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment:"
				" Error in PCM_OP_INSTALLMENT_CREATE_INSTALLMENT", ebufp);
			goto cleanup;

		}

		total_days = fm_tab_utils_calculate_number_of_days(term-1,&start_date);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
				"Error in fm_tab_utils_calculate_number_of_days  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
				"fm_tab_utils_calculate_number_of_days: input flist",in_flistp);
			goto cleanup;
		}

		sprintf(log_msg,"total_days = %d",total_days);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		sprintf(log_msg,"start_date = %ld",start_date);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(!end_date)
		{
			end_date = start_date;
			fm_utils_add_n_days(total_days,&end_date);
			PIN_FLIST_FLD_SET(create_instl_flistp,PIN_FLD_END_T,&end_date, ebufp);
		}
		for(count=0;count<term;count++)
		{

			sprintf(log_msg,"count = %d",count);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			instl_flist  = PIN_FLIST_ELEM_ADD(create_instl_flistp, PIN_FLD_INSTALLMENTS , count, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, instl_flist, PIN_FLD_AMOUNT, ebufp); //Equal Amount

			temp_end_date = start_date;

			int temp_days = fm_tab_utils_calculate_number_of_days(count,&temp_end_date);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
				"Error in fm_tab_utils_calculate_number_of_days  ", ebufp);
				goto cleanup;
			}

			fm_utils_add_n_days(temp_days,&temp_end_date);

			PIN_FLIST_FLD_SET(instl_flist,PIN_FLD_EFFECTIVE_T,&temp_end_date, ebufp); //EFFECTIVE_T
			
			PIN_FLIST_FLD_SET(instl_flist,PIN_FLD_STATUS,&status, ebufp);

		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_reschedule_action: "
			"TAB_INSTL_TYPE_EQUAL : create_instl_flistp", create_instl_flistp);
	}
	else
	{
		while((res_flistp1= PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_INSTALLMENTS,
			&coll_action_elemid, 1, &coll_action_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			instl_flist  = PIN_FLIST_ELEM_ADD(create_instl_flistp, PIN_FLD_INSTALLMENTS , coll_action_elemid, ebufp);

			if((effective_date=PIN_FLIST_FLD_GET(in_flistp,	TAB_FLD_EFFECTIVE_T_STR,1, ebufp))!=NULL)
			{
				effective_t=fm_tab_utils_common_convert_date_to_timestamp(ctxp,effective_date,ebufp);
				PIN_FLIST_FLD_SET(instl_flist,PIN_FLD_EFFECTIVE_T,&effective_t, ebufp);
			}

			PIN_FLIST_FLD_COPY(res_flistp1, PIN_FLD_AMOUNT, instl_flist, PIN_FLD_AMOUNT, ebufp);
			PIN_FLIST_FLD_SET(instl_flist,PIN_FLD_STATUS,&status, ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_reschedule_action: "
			"TAB_INSTL_TYPE_UNEQUAL : create_instl_flistp", create_instl_flistp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		" PCM_OP_INSTALLMENT_CREATE_INSTALLMENT input flist ", create_instl_flistp);

	/***************************************
	 * PCM_OP_INSTALLMENT_CREATE_INSTALLMENT  Opcode Call
	 ***************************************/
	PCM_OP(ctxp,PCM_OP_INSTALLMENT_CREATE_INSTALLMENT, 0, create_instl_flistp, &ret_create_instl_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp) || ret_create_instl_flistp == (pin_flist_t *)NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment:"
			" input flist ", create_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment:"
			" Error in PCM_OP_INSTALLMENT_CREATE_INSTALLMENT , Error in getting result.", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		" PCM_OP_INSTALLMENT_CREATE_INSTALLMENT output flist ", ret_create_instl_flistp);

	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	in_freeze_collections=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(in_freeze_collections, create_instl_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment: TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT "
		"input flist", in_freeze_collections);


	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT , 0,in_freeze_collections, &out_freeze_collections, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_installment: "
			"Error in TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
			"TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT: input flist", in_freeze_collections);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(out_freeze_collections, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		"TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT : output flist :", out_freeze_collections);

	/***************************************************************************************
	 * Update service status 
	 ***************************************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment: TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS "
		"input flist", in_freeze_collections);

	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS , 0, in_freeze_collections, &update_service_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment: Error in TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_installment : "
			"TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS: input flist", in_freeze_collections);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(update_service_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		"TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS : output flist :", update_service_flistp);

	/***************************************************************************************
	 * Notification
	 ***************************************************************************************/

	notification_create_instl_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, notification_create_instl_flistp, PIN_FLD_POID, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, notification_create_instl_flistp, PIN_FLD_MSISDN, ebufp); //MSISDN
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_END_T_STR, notification_create_instl_flistp, TAB_FLD_END_T_STR, ebufp); //START
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_START_T_STR, notification_create_instl_flistp, TAB_FLD_START_T_STR, ebufp); //END
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_INSTALLMENT_TYPE, notification_create_instl_flistp, PIN_FLD_INSTALLMENT_TYPE, ebufp); //INSTALLMENT_TYPE
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TERM, notification_create_instl_flistp, PIN_FLD_TERM, ebufp); //TERM

	elemid = 0;

	if (ret_create_instl_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(notification_create_instl_flistp, ret_create_instl_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}

	if (out_freeze_collections != NULL)
	{
		PIN_FLIST_ELEM_SET(notification_create_instl_flistp, out_freeze_collections, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}

	if (update_service_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(notification_create_instl_flistp, update_service_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}


	/* NOTIFICATION GENERATION
	 ********************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment:"
		"Notification Input FLIST ", notification_create_instl_flistp);

	fm_tab_collections_create_installment_enrich_notification(ctxp, in_freeze_collections, 
		notification_create_instl_flistp, db_no, &notify_oflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment output flist : ", *out_flistpp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment_enrich_notification:"
			" input flist ", notification_create_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment_enrich_notification:"
			" Error in Notification", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(notify_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	if (notify_oflistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
				ret_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(ret_flistp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment output flist : ", *out_flistpp);

	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&o_validate_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&update_service_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_create_instl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&out_freeze_collections, ebufp);
	PIN_FLIST_DESTROY_EX(&v_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&get_bill_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&in_freeze_collections, NULL);
	PIN_FLIST_DESTROY_EX(&out_freeze_collections, NULL);
	PIN_FLIST_DESTROY_EX(&notification_create_instl_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&i_validate_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_oflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment output flist : ", *out_flistpp);

	return;
}

static void
fm_tab_collections_create_installment_enrich_notification(
	pcm_context_t          	*ctxp,
	pin_flist_t            	*i_flistp,
	pin_flist_t            	*ret_flistp,
	int64                  	db_no,
	pin_flist_t            	**r_flistpp,
	pin_errbuf_t           	*ebufp)
{
	pin_flist_t            	*enrich_notify_flistp = NULL;
	pin_flist_t            	*notify_iflistp = NULL;
	pin_flist_t            	*notify_flistp = NULL;
	pin_flist_t            	*out_flistp = NULL;
	poid_t                 	*notify_pdp = NULL;
	int32			error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_collections_create_installment_enrich_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_create_installment_enrich_notification: "
			"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, notify_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);
	// Create Notification Flist

	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_CREATE_INSTALLMENT, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_POID, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp); //MSISDN
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_START_T_STR, notify_flistp, TAB_FLD_START_T_STR, ebufp); //START
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_END_T, notify_flistp, PIN_FLD_END_T, ebufp); //END
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_INSTALLMENT_TYPE, notify_flistp, PIN_FLD_INSTALLMENT_TYPE, ebufp); //INSTALLMENT_TYPE
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TERM, notify_flistp, PIN_FLD_TERM, ebufp); //TERM

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);



	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_COLLECTIONS_CREATE_INSTALLMENT input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_COLLECTIONS_CREATE_INSTALLMENT, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment_enrich_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_installment_enrich_notification:"
			" Error in Loan Notification", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_PAYMENT_INSTALLMENT, 0, 0, 0);
		goto cleanup;
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_installment_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_COLLECTIONS_CREATE_INSTALLMENT output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		out_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);

	}
	*r_flistpp = out_flistp;

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_collections_create_installment_enrich_notification output flist", *r_flistpp);
	return;
}



void fm_tab_mandatory_field_validation(
	pcm_context_t 			*ctxp,
	pin_flist_t    			*in_flistp,
	pin_flist_t    			**ret_flistpp,
	int64                           db_no,
	pin_errbuf_t   			*ebufp)
{
	void                            *vp = NULL;
	int32                           instl_type = 0;
	pin_flist_t                     *instl_flistp = NULL;
	pin_decimal_t                   *equalAmount = NULL;
	pin_decimal_t                   *installmentAmount = NULL;
	pin_decimal_t                   *totalAmount = NULL;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;
	char                          	*installmentDate = NULL;
	char                          	*start_t = NULL;

	/*********************************
	 * Insanity Check
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_mandatory_field_validation error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_mandatory_field_validation:"
			" input flist", in_flistp);
		return;
	}

	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_mandatory_field_validation:"
		" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}

	/***********************************************************
	 *PIN_FLD_INSTALLMENT_TERM
	 ***********************************************************/

	vp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TERM, 0, ebufp);

	if (PIN_ERR_IS_ERR(ebufp) || vp ==  NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INSTL_TERM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_INSTALLMENT_TERM", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing PIN_FLD_INSTALLMENT_TERM", in_flistp);
		goto cleanup;
	}

	/***********************************************************
	 *PIN_FLD_INSTALLMENT_TYPE
	 ***********************************************************/

	vp  = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_INSTALLMENT_TYPE, 0, ebufp);

	if (PIN_ERR_IS_ERR(ebufp) || vp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INSTL_TYPE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_INSTALLMENT_TYPE  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing PIN_FLD_INSTALLMENT_TYPE", in_flistp);
		goto cleanup;
	}

	if (vp != NULL)
	{
		instl_type = *(int *)vp;
	}

	if(instl_type == TAB_INSTL_TYPE_EQUAL )
	{
		equalAmount = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CHARGE_AMT, 0, ebufp);
		if(PIN_ERR_IS_ERR(ebufp) || equalAmount == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INSTL_EQUAL_AMT_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing equalAmount,PIN_FLD_CHARGE_AMT", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing equalAmount, PIN_FLD_CHARGE_AMT", in_flistp);
			goto cleanup;
		}
	}
	else
	{
		instl_flistp=PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_INSTALLMENTS,PIN_ELEMID_ANY, 0, ebufp);
		if(PIN_ERR_IS_ERR(ebufp) || instl_flistp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INSTL_ARRAY_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_INSTALLMENTS Array", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_INSTALLMENTS Array", in_flistp);
			goto cleanup;

		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_mandatory_field_validation: PIN_FLD_INSTALLMENTS Array", instl_flistp);

		installmentAmount=PIN_FLIST_FLD_GET(instl_flistp,PIN_FLD_AMOUNT,0,ebufp);
		if(PIN_ERR_IS_ERR(ebufp) || installmentAmount == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INSTL_EQUAL_AMT_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing installmentAmount,PIN_FLD_AMOUNT", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing installmentAmount, PIN_FLD_AMOUNT", in_flistp);
			goto cleanup;

		}
		installmentDate=PIN_FLIST_FLD_GET(instl_flistp,TAB_FLD_EFFECTIVE_T_STR,0,ebufp);
		if(PIN_ERR_IS_ERR(ebufp) || installmentDate == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INSTL_DATE_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing installmentDate,TAB_FLD_EFFECTIVE_T_STR", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing installmentDate, TAB_FLD_EFFECTIVE_T_STR", in_flistp);
			goto cleanup;

		}
	}

	totalAmount = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_TOTAL_AMOUNT,0,ebufp);
	if(PIN_ERR_IS_ERR(ebufp) || totalAmount == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INSTL_TOTAL_AMT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing totalAmount,PIN_FLD_TOTAL_AMOUNT", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing totalAmount, PIN_FLD_TOTAL_AMOUNT", in_flistp);
		goto cleanup;
	}

	start_t = PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_START_T_STR,0,ebufp);
	if(PIN_ERR_IS_ERR(ebufp) || start_t == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INSTL_START_T_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing START_T", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_mandatory_field_validation: Missing START_T", in_flistp);
	}

cleanup:
	return;
}
