/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 26-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_RESCHEDULE_ACTION operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"



/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_reschedule_action(
	cm_nap_connection_t		*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_collections_reschedule_action(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);



/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_RESCHEDULE_ACTION is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 1
 0 PIN_FLD_MSISDN    STR [0] "6091001011"
 0 PIN_FLD_ACCOUNT_NO    STR [0] "6091001011"
 0 PIN_FLD_ACTION_NAME STR [0] "collection action”
 0 PIN_FLD_DAYS   INT [0]    2
 0 PIN_FLD_DUE_T   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_USER_NAME    STR [0] "123456"
 0 TAB_FLD_ADDITIONAL_INFO    STR [0] " reason for rescheduling the action "
 0 PIN_FLD_CORRELATION_ID    STR [0] "er2345XR"
 0 PIN_FLD_EXTERNAL_USER    STR [0] " CRM "


 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_RESCHEDULE_ACTION operation.
 *************************************************************************/
void op_tab_collections_reschedule_action(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_reschedule_action error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_RESCHEDULE_ACTION) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_reschedule_action opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_reschedule_action input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RESCHEDULE_COLLECTION_ACTION, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_reschedule_action: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_reschedule_action:"
					" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_reschedule_action:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/*	 call main function */
		fm_tab_collections_reschedule_action(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_reschedule_action error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_reschedule_action:"
					" fm_tab_collections_reschedule_action input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_reschedule_action:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_reschedule_action: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_COLLECTIONS_RESCHEDULE_ACTION", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_reschedule_action:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_reschedule_action:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RESCHEDULE_COLLECTION_ACTION, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX (&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_reschedule_action output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_reschedule_action(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*billinfo_flistp= NULL;
	pin_flist_t		*ret_get_rsch_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	pin_flist_t		*get_rsch_flistp = NULL;
	pin_flist_t		*scenario_readobj_iflistp = NULL;
	pin_flist_t		*scenario_readobj_rflistp = NULL;
	pin_flist_t		*enrich_PTP_flistp = NULL;
	pin_flist_t		*context_flistp=NULL;
	pin_flist_t		*i_coll_action_flistp=NULL;
	pin_flist_t		*o_coll_action_flistp=NULL;
	pin_flist_t		*args_flistp=NULL;
	int32			coll_action_elemid = 0;
	pin_cookie_t		coll_action_cookie = NULL;
	pin_flist_t		*res_flistp=NULL;
	pin_flist_t		*res_flistp1=NULL;
	pin_flist_t		*config_action_readobj_iflistp=NULL;
	pin_flist_t		*config_action_readobj_rflistp=NULL;
	pin_flist_t		*config_action_flistp=NULL;
	char			*action_name_inp=NULL;
	char			*config_action_name=NULL;
	poid_t			*account_pdp = NULL;
	poid_t			*config_action_obj = NULL;
	char			log_msg[256]="";
	int32			active_flag = 0;
	int32			action_flag = 0;
	int32			paytype_i = 0;
	poid_t			*scenario_obj  = NULL;
	poid_t			*action_obj  = NULL;
	char			*account_no= NULL;
	char			*msisdn_strp = NULL;
	int32			s_flags = 256;
	poid_t			*srchp  = NULL;
	void			*vp = NULL;


	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_reschedule_action error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_reschedule_action:"
				" input flist", in_flistp);
		return;
	}


	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_reschedule_action:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_reschedule_action:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_reschedule_action:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_SCENARIO_OBJ, in_flistp, PIN_FLD_SCENARIO_OBJ, ebufp);

	vp=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp != NULL)
	{
		paytype_i = *(int32 *)vp;
	}   

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
	{
		if(account_no != NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
				"Error Subord Paytype found for the given account", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
				"Error SubordPaytype  input flist", billinfo_flistp);
			goto cleanup;
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
				"Error Subord Paytype found for the given MSISDN", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
				"Error SubordPaytype  input flist", billinfo_flistp);
			goto cleanup;
		}
	}


	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_reschedule_action:"
			"Validated to be postpaid account");
	/* check for due_t*/
	vp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_DUE_T,0,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUEDATE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error due_t missing in request.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error due_t missing in input flist", billinfo_flistp);
		goto cleanup;
	}

	if(vp==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUEDATE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error due_t missing in request.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error due_t missing in input flist", billinfo_flistp);
		goto cleanup;
	}

	vp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACTION_NAME, 0, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACTIONNAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error action name missing in request.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error action name missing in input flist", billinfo_flistp);
		goto cleanup;
	}

	if(vp==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACTIONNAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error action name missing in request.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error action name missing in input flist", billinfo_flistp);
		goto cleanup;
	}



	/*Read_Obj of scenario_obj*/
	scenario_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SCENARIO_OBJ,0,ebufp);
	scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(scenario_readobj_iflistp,PIN_FLD_POID, scenario_obj, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj input flist",
			scenario_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, scenario_readobj_iflistp,&scenario_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Account not in collections,scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Error while doing SCENARIO  read_obj", ebufp);
		PIN_FLIST_DESTROY_EX (&scenario_readobj_iflistp, NULL);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj return flist",
			scenario_readobj_rflistp);

	if(scenario_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Account not in collections,Error while doing SCENARIO  read_obj", ebufp);
		PIN_FLIST_DESTROY_EX (&scenario_readobj_iflistp, NULL);
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX (&scenario_readobj_iflistp, NULL);


	/***********************************************************************************************
	 * Search  the /collection_action 
	 ***********************************************************************************************/
	i_coll_action_flistp  = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(i_coll_action_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(i_coll_action_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =(void *)"select X from /collections_action  where  F1 = V1";
	PIN_FLIST_FLD_SET(i_coll_action_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_coll_action_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);

	PIN_FLIST_ELEM_SET(i_coll_action_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to get collections_action  : "
			"input flist", i_coll_action_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0,i_coll_action_flistp, &o_coll_action_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Base search opcode error",i_coll_action_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Base search opcode error", ebufp);
		PIN_FLIST_DESTROY_EX (&i_coll_action_flistp, NULL);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_reschedule_action: Base search opcode output", o_coll_action_flistp);
	if (o_coll_action_flistp != (pin_flist_t *)NULL )
	{

		res_flistp = PIN_FLIST_ELEM_GET(o_coll_action_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_collections_reschedule_action: res_flistp", res_flistp);
		if (res_flistp != (pin_flist_t *)NULL )
		{
			while((res_flistp1= PIN_FLIST_ELEM_GET_NEXT(o_coll_action_flistp, PIN_FLD_RESULTS,
							&coll_action_elemid, 1, &coll_action_cookie, ebufp)) != (pin_flist_t *)NULL)
			{

				/*Read_Obj of config_action_obj*/
				config_action_obj = PIN_FLIST_FLD_GET(res_flistp1,PIN_FLD_CONFIG_ACTION_OBJ,0,ebufp);
				config_action_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(config_action_readobj_iflistp,PIN_FLD_POID, config_action_obj, ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," config action  Read_Obj input flist",
						config_action_readobj_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, config_action_readobj_iflistp,&config_action_readobj_rflistp, ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_collections_reschedule_action: Error in reading config_action_obj", config_action_readobj_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_collections_reschedule_action: Error in reading config_action_obj", ebufp);
					PIN_FLIST_DESTROY_EX (&config_action_readobj_iflistp, ebufp);
					goto cleanup;
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," config action  Read_Obj output flist",
						config_action_readobj_rflistp);
				PIN_FLIST_DESTROY_EX (&config_action_readobj_iflistp, ebufp);
				
				action_name_inp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACTION_NAME, 0, ebufp);
				config_action_flistp = PIN_FLIST_ELEM_GET(config_action_readobj_rflistp, PIN_FLD_CONFIG_ACTION_INFO, PIN_ELEMID_ANY, 1, ebufp);
				config_action_name=PIN_FLIST_FLD_GET(config_action_flistp,PIN_FLD_ACTION_NAME, 1, ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," config action  Read_Obj config_action_flistp",
						config_action_flistp);

				if ( strcmp(config_action_name,action_name_inp) == 0 )	
				{
					action_obj = PIN_FLIST_FLD_GET(res_flistp1,PIN_FLD_POID, 0, ebufp);
					action_flag=1;
					break;

				}
			}
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_reschedule_action: No collection_action found  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_reschedule_action : No collection_action found:"
					"input flist",i_coll_action_flistp);
			PIN_FLIST_DESTROY_EX (&i_coll_action_flistp, NULL);
			goto cleanup;

		}
	}
	else
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Error in collection_action search  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_reschedule_action : collection_action search:"
				"input flist",i_coll_action_flistp);
		PIN_FLIST_DESTROY_EX (&i_coll_action_flistp, NULL);
		goto cleanup;
	}
	 PIN_FLIST_DESTROY_EX (&i_coll_action_flistp, NULL);
	if (action_flag == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_reschedule_action: Invalid action code for the account.  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_reschedule_action : Invalid action code for the account,Action code note found:"
				"input flist",in_flistp);
		goto cleanup;


	}



	/*********************************************************
	 * Flist creation of PCM_OP_COLLECTIONS_RESCHEDULE_ACTION
	 *********************************************************/
	/*
	 *Sample Input Flist to call the opcode:
	 0 PIN_FLD_POID           POID  [0] 0.0.0.1  /collections_action 43780269  1
	 0 PIN_FLD_ACCOUNT_OBJ               POID [0] 0.0.0.1 /account 67779166 0
	 0 PIN_FLD_DAYS   INT [0]   2
	 0 PIN_FLD_DUE_T   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
	 0 PIN_FLD_USER_NAME    STR [0] "123456"
	 0 PIN_FLD_CONTEXT_INFO SUBSTRUCT [0]
	 1   PIN_FLD_CORRELATION_ID            STR [0] "er2345"
	 1   PIN_FLD_EXTERNAL_USER             STR [0] "CRM"
	 0 PIN_FLD_PROGRAM_NAME                STR [0] "er2345|CRM"


	 *
	 **/

	get_rsch_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(get_rsch_flistp,PIN_FLD_POID, action_obj, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, get_rsch_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, get_rsch_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DAYS,get_rsch_flistp,PIN_FLD_DAYS,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DUE_T,get_rsch_flistp,PIN_FLD_DUE_T,ebufp);
	//	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME,get_rsch_flistp,PIN_FLD_USER_NAME,ebufp);

	context_flistp=PIN_FLIST_SUBSTR_ADD(get_rsch_flistp,PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_flistp,PIN_FLD_EXTERNAL_USER,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_reschedule_action:"
			" PCM_OP_COLLECTIONS_RESCHEDULE_ACTION input flist ", get_rsch_flistp);


	/***************************************
	 * PCM_OP_COLLECTIONS_RESCHEDULE_ACTION  Opcode Call
	 ***************************************/
	PCM_OP(ctxp,PCM_OP_COLLECTIONS_RESCHEDULE_ACTION, 0, get_rsch_flistp, &ret_get_rsch_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_reschedule_action:"
				" input flist ", get_rsch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_reschedule_action:"
				" Error in PCM_OP_COLLECTIONS_RESCHEDULE_ACTION", ebufp);
		PIN_FLIST_DESTROY_EX (&get_rsch_flistp, NULL);
		goto cleanup;
	}        
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_reschedule_action:"
			" PCM_OP_COLLECTIONS_RESCHEDULE_ACTION output flist ", ret_get_rsch_flistp);

	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN,ret_flistp, PIN_FLD_MSISDN, ebufp);

	if (ret_get_rsch_flistp == (pin_flist_t *)NULL )
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_RESCHEDULE_COLLECTION_ACTION, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_reschedule_action:"
				" input flist ", get_rsch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_reschedule_action:"
				" Error in PCM_OP_COLLECTIONS_RESCHEDULE_ACTION , Error in PCM_OP_COLLECTIONS_RESCHEDULE_ACTION , output flist is NULL", ebufp);
		PIN_FLIST_DESTROY_EX (&get_rsch_flistp, NULL);
		goto cleanup;
	}
	PIN_FLIST_DESTROY_EX (&get_rsch_flistp, NULL);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_reschedule_action:"
			"output flist :", ret_flistp);


	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_PTP_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&o_coll_action_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&config_action_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_get_rsch_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&config_action_readobj_rflistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_reschedule_action output flist : ", *out_flistpp);

	return;
}
