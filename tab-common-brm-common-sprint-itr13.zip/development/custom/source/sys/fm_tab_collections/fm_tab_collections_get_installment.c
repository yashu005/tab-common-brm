/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 14-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_GET_INSTALLMENT operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"
#include "ops/installment.h"


/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_get_installment(
		cm_nap_connection_t     *connp,
		int                     opcode,
		int                     flags,
		pin_flist_t             *in_flistp,
		pin_flist_t             **out_flistpp,
		pin_errbuf_t            *ebufp);

void fm_tab_collections_get_installment(
		pcm_context_t       	*ctxp,
		pin_flist_t         	*in_flistp,
		pin_flist_t         	**out_flistpp,
		int64                   db_no,
		pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_GET_INSTALLMENT is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0		PIN_FLD_POID           POID [0] 0.0.0.1 /account 0
 0		PIN_FLD_ACCOUNT_NO	STR[0] "0.0.0.1-14422173"
 0 		PIN_FLD_MSISDN      STR [0] "60020211229 "
 0	        PIN_FLD_EXTERNAL_USER              STR [0] "CRM"
 0 		PIN_FLD_CORRELATION_ID             STR [0] "820345239"

 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_GET_INSTALLMENT operation.
 *************************************************************************/
void op_tab_collections_get_installment(
		cm_nap_connection_t      *connp,
		int                       opcode,
		int                       flags,
		pin_flist_t               *in_flistp,
		pin_flist_t               **ret_flistpp,
		pin_errbuf_t              *ebufp)
{
	pcm_context_t            *ctxp = connp->dm_ctx;
	pin_flist_t              *r_flistp = NULL;
	int32                    error_clear_flag = 1;
	int32                    cerror_code = 0;
	char                     log_msg[512]= "";
	int64                    db_no = 0;
	int32                    status = PIN_BOOLEAN_TRUE;
	pin_flist_t              *enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_installment error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_GET_INSTALLMENT) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_installment opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_installment input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	//r_flistp = PIN_FLIST_CREATE(ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}


	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_loan_details: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_loan_details:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);



	/*	 call main function */
	fm_tab_collections_get_installment(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_get_installment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_installment:"
				" fm_tab_collections_get_installment input flist", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_installment:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_installment:"
				" Error while getting installment details", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PAYMENT_INSTALLMENTS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}

	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_installment output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_get_installment(
		pcm_context_t       *ctxp,
		pin_flist_t         *in_flistp,
		pin_flist_t         **out_flistpp,
		int64               db_no,
		pin_errbuf_t        *ebufp)
{
	pin_flist_t                     *billinfo_flistp= NULL;
	pin_flist_t                     *enrich_iflistp = NULL;
	pin_flist_t                     *ret_get_instl_flistp = NULL;
	pin_flist_t                     *ret_flistp = NULL;
	pin_flist_t                     *get_instl_flistp = NULL;
	pin_flist_t                     *update_service_flistp = NULL;
	pin_flist_t                     *i_install_sche_flistp = NULL;
	pin_flist_t                     *o_install_sche_flistp = NULL;
	pin_flist_t                     *res_flistp = NULL;
	pin_flist_t                     *args_flistp = NULL;
	pin_flist_t                     *instl_in_flistp = NULL;
	pin_flist_t                     *instl_res_flistp = NULL;
	pin_flist_t                     *instl_flist = NULL;
	pin_flist_t                     *enrich_get_instl_flistp = NULL;
	poid_t                          *account_pdp = NULL;
	char                            log_msg[256]="";
	int32                           active_flag = 0;
	int32                           paytype_i = 0;
	void                            *vp = NULL;
	poid_t                          *instl_spec_obj = NULL;
	poid_t          				*srchp  = NULL;
	int32           				s_flags = 256;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;
	int32                    	error_code = 0;
	char                            *start_t_str = NULL;
	time_t                          *start_t = NULL;

	char                            *end_t_str = NULL;
	time_t                          *end_t = NULL;

	char                            *effective_t_str = NULL;
	time_t                          *effective_t = NULL;



	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment:"
				" input flist", in_flistp);
		return;
	}

	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}



	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_get_installment:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_get_installment:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	paytype_i = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
        if (paytype_i == PIN_PAY_TYPE_SUBORD)
        {
                if(account_no != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment:"
                                        "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment:"
                                        "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }


	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment:"
			"Validated to be postpaid account");



	/***********************************************************************************************
	 * Search  the /installment_schedule poid
	 ***********************************************************************************************/
	i_install_sche_flistp  = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(i_install_sche_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(i_install_sche_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =(void *)"select X from /installment_schedule where  F1 = V1";
	PIN_FLIST_FLD_SET(i_install_sche_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_install_sche_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);

	PIN_FLIST_ELEM_SET(i_install_sche_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to get installment_schedule : "
			"input flist", i_install_sche_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0,i_install_sche_flistp, &o_install_sche_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Base (installment_schedule) search opcode error", i_install_sche_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment: Base (installment_schedule) search opcode error", ebufp);

		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_get_installment: Base search opcode output", o_install_sche_flistp);

	if (o_install_sche_flistp && (o_install_sche_flistp != NULL ))
	{

		res_flistp = PIN_FLIST_ELEM_GET(o_install_sche_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0, ebufp);

		if (res_flistp != (pin_flist_t *)NULL )
		{
			vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_POID, 0, ebufp); 
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_get_installment:  No installment_schedule found  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment : No installment_schedule found:"
					"input flist",i_install_sche_flistp);
			goto cleanup;

		}

		if(vp)
		{
			instl_spec_obj=(poid_t *)vp;

		}
		else 
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_get_installment:  No installment_schedule found  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment : No installment_schedule found:"
					"input flist",i_install_sche_flistp);

			goto cleanup;

		}

	}
	else
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment:  No installment_schedule found  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment : No installment_schedule found:"
				"input flist",i_install_sche_flistp);

		goto cleanup;
	}


	/*********************************************************
	 * Flist creation of PCM_OP_INSTALLMENT_GET_INSTALLMENT
	 *********************************************************/
	/*
	 *Sample Input Flist to call the opcode:
	 0      PIN_FLD_POID           POID [0] 0.0.0.1 /installment_schedule 23546 1
	 0     PIN_FLD_ACCOUNT_OBJ	STR[0] "0.0.0.1-2636100 "
	 0     PIN_FLD_PROGRAM_NAME    STR [0] "CRM"
	 *
	 **/

	get_instl_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(get_instl_flistp,PIN_FLD_POID, instl_spec_obj, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, get_instl_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, get_instl_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment:"
			" PCM_OP_INSTALLMENT_GET_INSTALLMENT input flist ", get_instl_flistp);



	/***************************************
	 * PCM_OP_INSTALLMENT_GET_INSTALLMENTS  Opcode Call
	 ***************************************/
	PCM_OP(ctxp,PCM_OP_INSTALLMENT_GET_INSTALLMENTS, 0, get_instl_flistp, &ret_get_instl_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_get_installment:"
				" input flist ", get_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_get_installment:"
				" Error in PCM_OP_INSTALLMENT_GET_INSTALLMENT", ebufp);
		goto cleanup;
	}        

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment:"
			" PCM_OP_INSTALLMENT_GET_INSTALLMENT output flist ", ret_get_instl_flistp);


	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT, 0, ret_get_instl_flistp, &enrich_get_instl_flistp, ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment : Error in TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment  : TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT:"
				"Enrich input flist", ret_get_instl_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrich_get_instl_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (enrich_get_instl_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_installment : Error in TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT enrich_iflistp is NULL.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_installment :"
				"Enrich input flist : TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT : ", ret_get_instl_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment :"
			"TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT : After Enrich output flist :", enrich_get_instl_flistp);


	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);


	if (enrich_get_instl_flistp && (instl_res_flistp=PIN_FLIST_ELEM_GET(ret_get_instl_flistp, PIN_FLD_RESULTS,
					PIN_ELEMID_ANY, 1, ebufp)) != NULL)

	{
		PIN_FLIST_FLD_COPY(instl_res_flistp, PIN_FLD_TOTAL_AMOUNT, ret_flistp, PIN_FLD_TOTAL_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(instl_res_flistp, PIN_FLD_CHARGE_AMT, ret_flistp, PIN_FLD_CHARGE_AMT, ebufp);
		PIN_FLIST_FLD_COPY(instl_res_flistp, PIN_FLD_TERM, ret_flistp, PIN_FLD_TERM, ebufp);

		start_t=PIN_FLIST_FLD_GET(instl_res_flistp,PIN_FLD_START_T,1,ebufp);
		if(start_t != NULL )
		{
			/*Convert date in string format to unix timestamp*/
			start_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp, start_t, ebufp);

		}
		PIN_FLIST_FLD_SET(ret_flistp,TAB_FLD_START_T_STR, start_t_str, ebufp);
		free(start_t_str);

		end_t=PIN_FLIST_FLD_GET(instl_res_flistp,PIN_FLD_END_T,1,ebufp);
		if(end_t != NULL )
		{
			/*Convert date in string format to unix timestamp*/
			end_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp,end_t, ebufp);

		}
		PIN_FLIST_FLD_SET(ret_flistp,TAB_FLD_END_T_STR, end_t_str, ebufp);
		free(end_t_str);

		PIN_FLIST_FLD_COPY(instl_res_flistp, PIN_FLD_STATUS, ret_flistp, PIN_FLD_STATUS, ebufp);  //END_T
		PIN_FLIST_FLD_COPY(instl_res_flistp, PIN_FLD_INVOICE_DATA, ret_flistp, PIN_FLD_INVOICE_DATA, ebufp);  //END_T
		instl_in_flistp=PIN_FLIST_ELEM_GET(instl_res_flistp, PIN_FLD_INSTALLMENTS,PIN_ELEMID_ANY, 0, ebufp);

		instl_flist  = PIN_FLIST_ELEM_ADD(ret_flistp, PIN_FLD_INSTALLMENTS , 0, ebufp);
		PIN_FLIST_FLD_COPY(instl_in_flistp, PIN_FLD_AMOUNT, instl_flist, PIN_FLD_AMOUNT, ebufp); //AMOUNT

		effective_t=PIN_FLIST_FLD_GET(instl_in_flistp,PIN_FLD_EFFECTIVE_T,1,ebufp);
		if(effective_t != NULL )
		{
			/*Convert date in string format to unix timestamp*/
			effective_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp,effective_t, ebufp);

		}
		PIN_FLIST_FLD_SET(instl_flist,TAB_FLD_EFFECTIVE_T_STR, effective_t_str, ebufp);
		free(effective_t_str);

		PIN_FLIST_FLD_COPY(instl_in_flistp, PIN_FLD_STATUS, instl_flist, PIN_FLD_STATUS, ebufp); //EFFECTIVE_T
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_PAYMENT_INSTALLMENTS, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_get_installment:"
				" input flist ", get_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_get_installment:"
				" Error in PCM_OP_INSTALLMENT_GET_INSTALLMENT , Error in getting  result status.", ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_installment:"
			"output flist :", ret_flistp);


	*out_flistpp = PIN_FLIST_COPY(ret_flistp, ebufp);
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&update_service_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_get_instl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&i_install_sche_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&o_install_sche_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_get_instl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&get_instl_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_get_installment output flist : ", *out_flistpp);

	return;
}
