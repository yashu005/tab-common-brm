/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 26-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"



/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_create_promise_to_pay(
		cm_nap_connection_t     *connp,
		int                     opcode,
		int                     flags,
		pin_flist_t             *in_flistp,
		pin_flist_t             **out_flistpp,
		pin_errbuf_t            *ebufp);

void fm_tab_collections_create_promise_to_pay(
		pcm_context_t       	*ctxp,
		pin_flist_t         	*in_flistp,
		pin_flist_t         	**out_flistpp,
		int64                   db_no,
		pin_errbuf_t        	*ebufp);



/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 1
 0 PIN_FLD_MSISDN    STR [0] "6091001011"
 0 PIN_FLD_ACCOUNT_NO    STR [0] "6091001011"
 0 PIN_FLD_DAYS   INT [0]    2
 0 PIN_FLD_DATE   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_ORDER_DATE   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_AMOUNT        DECIMAL [0] 150
 0 PIN_FLD_CORRELATION_ID    STR [0] "er2345XR"
 0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"


 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY operation.
 *************************************************************************/
void op_tab_collections_create_promise_to_pay(
		cm_nap_connection_t      *connp,
		int                       opcode,
		int                       flags,
		pin_flist_t               *in_flistp,
		pin_flist_t               **ret_flistpp,
		pin_errbuf_t              *ebufp)
{
	pcm_context_t            *ctxp = connp->dm_ctx;
	pin_flist_t              *r_flistp = NULL;
	int32                    tab_order_flag = 0;
	int32                    error_clear_flag = 1;
	int32                    cerror_code = 0;
	char                     log_msg[512]= "";
	int64                    db_no = 0;
	poid_t                   *account_pdp = NULL;
	int32                    status = PIN_BOOLEAN_TRUE;
	pin_flist_t              *enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_create_promise_to_pay error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_create_promise_to_pay opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_promise_to_pay input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}


	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_PROMISE_TO_PAY, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_promise_to_pay: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_promise_to_pay:"
					" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_promise_to_pay:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/*	 call main function */
		fm_tab_collections_create_promise_to_pay(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_create_promise_to_pay error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_promise_to_pay:"
					" fm_tab_collections_create_promise_to_pay input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_promise_to_pay:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_create_promise_to_pay: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_COLLECTIONS_CREATE_PROMISE_TO_PAY", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_promise_to_pay:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_create_promise_to_pay:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_PROMISE_TO_PAY, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_create_promise_to_pay output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_create_promise_to_pay(
		pcm_context_t       *ctxp,
		pin_flist_t         *in_flistp,
		pin_flist_t         **out_flistpp,
		int64               db_no,
		pin_errbuf_t        *ebufp)
{
	pin_flist_t                     *billinfo_flistp= NULL;
	pin_flist_t                     *ret_get_ptp_flistp = NULL;
	pin_flist_t                     *ret_flistp = NULL;
	pin_flist_t                     *get_ptp_flistp = NULL;
	pin_flist_t                     *ptp_res_flistp = NULL;
	pin_flist_t                     *scenario_readobj_iflistp = NULL;
	pin_flist_t                     *scenario_readobj_rflistp = NULL;
	pin_flist_t                     *freeze_PTP_flistp = NULL;
	pin_flist_t                     *ptp_freeze_collections = NULL;
	pin_flist_t     		*context_flistp=NULL;
	pin_flist_t     		*ptp_info_flistp=NULL;
	poid_t                          *account_pdp = NULL;
	char                            log_msg[256]="";
	int32                           active_flag = 0;
	int32                           paytype_i = 0;
	int32                           num_milestone = 1;
	poid_t  			*scenario_obj  = NULL;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;
	int32                           agreedDays= 0;
	char                            *agreedDate_strp= NULL;
	int32                   	error_code = 0;
	void                            *vp = NULL;
	time_t                          convrt_agreedDate_t= 0;
	time_t                          convrt_requestDate_t = 0;
    char                            *requestDate_strp= NULL;
	time_t  						current_date = pin_virtual_time((time_t *)NULL);
	int32 							*agreed_days = NULL;

	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
				" input flist", in_flistp);
		return;
	}


	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}


        agreedDate_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_AGREED_DATE_T_STR, 1, ebufp);
        vp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_DAYS, 1, ebufp);

        if((agreedDate_strp == NULL || strlen(agreedDate_strp ) == 0) && (vp == NULL || strlen(vp) == 0))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_AGREED_DAYS_DATE_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_DAYS and PIN_FLD_DATE", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_DAYS and PIN_FLD_DATE", in_flistp);
                goto cleanup;

	}
	if(vp)
    {
          agreedDays = *(int32*) vp;
    }
	if(agreedDate_strp)
	{
		convrt_agreedDate_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, agreedDate_strp, ebufp);
        sprintf(log_msg, "%ld",convrt_agreedDate_t);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if((convrt_agreedDate_t - current_date) < 0)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_create_promise_to_pay:"
					"input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INCORRECT_AGREED_DATE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
					"Given AgreedDate is in PastDate or sameDame as PVT", ebufp);
			goto cleanup;
		}
	}



	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_create_promise_to_pay:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_create_promise_to_pay:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_SCENARIO_OBJ, in_flistp, PIN_FLD_SCENARIO_OBJ, ebufp);

	vp=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp != NULL)
	{
		paytype_i = *(int32 *)vp;
	}

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
	{
		if(account_no != NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
                               "Error Subord Paytype found for the given account", ebufp);
                	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                	goto cleanup;
		}
		else
		{
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
                               "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
	}

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			"Validated to be postpaid account");


	/*Read_Obj of scenario_obj*/
	scenario_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SCENARIO_OBJ,1,ebufp);
	if (PIN_POID_IS_NULL(scenario_obj))
                        {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_obj:"
                                        "Account not in collections,Error while getting  SCENARIO obj_id", ebufp);
                        goto cleanup;
                        }
	scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(scenario_readobj_iflistp,PIN_FLD_POID, scenario_obj, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj input flist",
			scenario_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, scenario_readobj_iflistp,&scenario_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Account not in collections,Error while doing SCENARIO  read_obj", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj return flist:",
			scenario_readobj_rflistp);

	if(scenario_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Error while doing SCENARIO  read_obj,Account not in collections,scenario obj not found.", ebufp);
		goto cleanup;
	}


	/*********************************************************
	 * Flist creation of PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY
	 *********************************************************/
	/*
	 *Sample Input Flist to call the opcode:
	 0 PIN_FLD_POID           POID  [0] 0.0.0.1 /account 12345 1
	 0 PIN_FLD_BILLINFO_OBJ               POID [0] 0.0.0.1 /billinfo 67779166 0
	 0 PIN_FLD_SCENARIO_OBJ               POID [0] 0.0.0.1 /collections_scenario 43780269 0
	 0 PIN_FLD_PROGRAM_NAME                STR [0] "er2345|CRM"
	 0 PIN_FLD_PROMISE_TO_PAY_INFO SUBSTRUCT  [0]
	 1 PIN_FLD_DAYS   INT [0] 0
	 1 PIN_FLD_DATE   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
	 1 PIN_FLD_ORDER_DATE   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
	 1 PIN_FLD_AMOUNT        DECIMAL [0] 150
	 0 PIN_FLD_CONTEXT_INFO SUBSTRUCT [0]
	 1   PIN_FLD_CORRELATION_ID            STR [0] "er2345"
	 1   PIN_FLD_EXTERNAL_USER             STR [0] "CRM"

	 *
	 **/

	get_ptp_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, get_ptp_flistp, PIN_FLD_POID, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILLINFO_OBJ, get_ptp_flistp, PIN_FLD_BILLINFO_OBJ, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_SET(get_ptp_flistp,PIN_FLD_SCENARIO_OBJ, scenario_obj, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, get_ptp_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	ptp_info_flistp=PIN_FLIST_SUBSTR_ADD(get_ptp_flistp,PIN_FLD_PROMISE_TO_PAY_INFO,ebufp);
	requestDate_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_REQUEST_DATE_T_STR, 1, ebufp);
    if(requestDate_strp != NULL)
    {
    	convrt_requestDate_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, requestDate_strp, ebufp);
        sprintf(log_msg, "%ld",convrt_requestDate_t);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

        PIN_FLIST_FLD_SET(ptp_info_flistp, PIN_FLD_INVOKE_T, &convrt_requestDate_t, ebufp);
    }
    else
    {
    	convrt_requestDate_t = current_date;

        sprintf(log_msg, "%ld",convrt_requestDate_t);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

        PIN_FLIST_FLD_SET(ptp_info_flistp, PIN_FLD_INVOKE_T, &current_date, ebufp);
    }
	if(agreedDays != NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DAYS,ptp_info_flistp,PIN_FLD_DAYS,ebufp);
	}
	else
	{
		agreed_days = ((convrt_agreedDate_t - convrt_requestDate_t)/86400);
		sprintf(log_msg, "%ld",agreed_days);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		PIN_FLIST_FLD_SET(ptp_info_flistp, PIN_FLD_DAYS, &agreed_days, ebufp);
	}

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AMOUNT,ptp_info_flistp,PIN_FLD_AMOUNT,ebufp);
	PIN_FLIST_FLD_SET(ptp_info_flistp,PIN_FLD_NUM_MILESTONES, &num_milestone, ebufp);

	context_flistp=PIN_FLIST_SUBSTR_ADD(get_ptp_flistp,PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_flistp,PIN_FLD_EXTERNAL_USER,ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			" PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY input flist ", get_ptp_flistp);



	/***************************************
	 * PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY  Opcode Call
	 ***************************************/
	PCM_OP(ctxp,PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY, 0, get_ptp_flistp, &ret_get_ptp_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp) || ret_get_ptp_flistp ==(pin_flist_t *)NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_promise_to_pay:"
				" input flist ", get_ptp_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_promise_to_pay:"
				" Error in PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY", ebufp);
		goto cleanup;
	}        

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			" PCM_OP_COLLECTIONS_INVOKE_PROMISE_TO_PAY output flist ", ret_get_ptp_flistp);

	ptp_freeze_collections=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(ptp_freeze_collections, get_ptp_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_create_promise_to_pay: TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY "
			"input flist", ptp_freeze_collections);


	PIN_ERR_CLEAR_ERR(ebufp);

	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY, 0, ptp_freeze_collections, &freeze_PTP_flistp, ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error in TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay : TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY:"
				"Enrich input flist", ptp_freeze_collections);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(freeze_PTP_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (freeze_PTP_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_create_promise_to_pay: Error in TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY enrich_iflistp is NULL.", ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_create_promise_to_pay:"
				"Enrich input flist : TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY : ", get_ptp_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			"TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY : After Enrich output flist :", freeze_PTP_flistp);


	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN,ret_flistp, PIN_FLD_MSISDN, ebufp);

	if (freeze_PTP_flistp && (ptp_res_flistp=PIN_FLIST_ELEM_GET(freeze_PTP_flistp, PIN_FLD_RESULTS,
					PIN_ELEMID_ANY, 1, ebufp)) != NULL)

	{
		PIN_FLIST_FLD_COPY(ptp_res_flistp, TAB_FLD_REQUEST_STATUS, ret_flistp, PIN_FLD_STATUS, ebufp);  //END_T
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_PROMISE_TO_PAY, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_promise_to_pay:"
				" input flist ", get_ptp_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_create_promise_to_pay:"
				" Error in TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY , Error in getting  result status.", ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_create_promise_to_pay:"
			"output flist :", ret_flistp);


	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&freeze_PTP_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_get_ptp_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&get_ptp_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ptp_freeze_collections, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_create_promise_to_pay output flist : ", *out_flistpp);

	return;
}
