/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 3-Feb-2022    | Akshay Gund 	|               | New opcode TAB_OP_COLLECTIONS_UPDATE_EXEMPTION.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_UPDATE_EXEMPTION operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/collections.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_collections_update_exemption(
	cm_nap_connection_t	 *connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

//static functions 
static void
fm_tab_collections_update_exemption(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_UPDATE_EXEMPTION operation.
 *************************************************************************/
void
op_tab_collections_update_exemption(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_update_exemption function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_COLLECTIONS_UPDATE_EXEMPTION) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_update_exemption bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_update_exemption input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_COLLECTION_EXEMPTION, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* call main function */
		fm_tab_collections_update_exemption(ctxp, in_flistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_update_exemption error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption :input flist ", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_update_exemption:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_update_exemption: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_COLLECTIONS_UPDATE_EXEMPTION", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_update_exemption:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_COLLECTION_EXEMPTION, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_update_exemption output flist", *ret_flistpp);
	return;
}

/********************************************
 * We use this function update collection exemption
 * for given account
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/
 
static void fm_tab_collections_update_exemption(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*update_exemption_pol_flistp = NULL;
	pin_flist_t	*enrich_iflistp=NULL;
	pin_flist_t	*hook_update_exemption_pol_flistp = NULL;
	pin_flist_t	*update_coll_exempt_oflistp=NULL;
	pin_flist_t	*billinfo_flistp=NULL;
	pin_flist_t	*temp_pol_input_flistp=NULL;
	pin_flist_t	*exemption_flistp=NULL;
	pin_flist_t	*context_flistp=NULL;
	pin_flist_t	*update_exemption_action_flistp=NULL;
	pin_flist_t	*hook_update_exemption_action_flistp=NULL;
		
	poid_t		*account_pdp = NULL;
	poid_t		*scenario_pdp=NULL;
	char		db_no_str[10];
	int32		active_flag = 0;
	int32		*paytype_i =NULL;
	int32		*exempt_flag = 0;
	int32		*exempt_iflag = 0;
	int32		exemption = 0;
	char		log_msg[256]="";
	char		*account_no=NULL;
	char		*msisdn=NULL;
	pin_flist_t	*update_coll_exempt_iflistp = NULL;
	pin_flist_t *r_flistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_update_exemption in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_update_exemption input flist", in_flistp);

	/*********************************************************
	* Getting billinfo details for account
	*********************************************************/
        /*Check for account number or MSISDN*/
        account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
        msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);

        if((account_no == NULL || strlen(account_no ) == 0)
                        && (msisdn == NULL || strlen(msisdn) == 0))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment_reversal:input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
				"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}
	/* Validate the input arguments */
	else
	{
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
				" input flist", in_flistp);
		goto cleanup;
	}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_update_exemption:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);


	exempt_iflag=(int *)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS, 1, ebufp);


        if (exempt_iflag != NULL)
        {
                if(( *exempt_iflag== TAB_COLL_EXEMPT_FLAG_TRUE) ||(*exempt_iflag== TAB_COLL_EXEMPT_FLAG_FALSE))
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_update_exemption input flist", in_flistp);
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_INVALID_EXEMPTION_FLAG, 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                        "fm_tab_collections_update_exemption :Error PIN_FLD_EXEMPT_FROM_COLLECTIONS value invalid", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_update_exemption input flist", in_flistp);
			goto cleanup;
                }
        }
        else
        {
                pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_EXEMPTION_FLAG_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_collections_update_exemption : Error PIN_FLD_EXEMPT_FROM_COLLECTIONS is missing ", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_update_exemption input flist", in_flistp);
		goto cleanup;
        }


	account_pdp = PIN_FLIST_FLD_GET(enrich_iflistp, PIN_FLD_POID, 1 , ebufp);
	fm_tab_utils_common_get_billinfo(ctxp,account_pdp, active_flag,&billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption input flist", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp);

	/*********************************************************
	 * Validation if the account is prepaid
	 *********************************************************/
	if ((PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp)) != NULL);
	{
		paytype_i = (int *)PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	}

	if (paytype_i && *paytype_i == PIN_BILL_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption input flist", billinfo_flistp);
		goto cleanup;
	}
        if (*paytype_i == PIN_BILL_TYPE_SUBORD)
        {
                if(account_no != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption:"
                                        "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemptions:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }


	if ((PIN_FLIST_FLD_GET(billinfo_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS, 1, ebufp)) != NULL)
	{
		exempt_flag=(int *)PIN_FLIST_FLD_GET(billinfo_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS, 1, ebufp);
	}

	sprintf(log_msg,"paytype_i ,  exempt_flag , exempt_iflag %d %d %d" ,*paytype_i, *exempt_flag ,*exempt_iflag );
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	if(*exempt_iflag == *exempt_flag)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SAME_EXEMPTION_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption input flist", billinfo_flistp);
		goto cleanup;
	}

	/*Create input flist for policy opcode*/
	update_exemption_pol_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(enrich_iflistp,PIN_FLD_POID,update_exemption_pol_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO,update_exemption_pol_flistp,PIN_FLD_ACCOUNT_NO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MSISDN,update_exemption_pol_flistp,PIN_FLD_MSISDN,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,update_exemption_pol_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,update_exemption_pol_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,update_exemption_pol_flistp,PIN_FLD_EXTERNAL_USER,ebufp);

	temp_pol_input_flistp=PIN_FLIST_SUBSTR_ADD(update_exemption_pol_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_FLD_COPY(enrich_iflistp,PIN_FLD_POID,temp_pol_input_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp,PIN_FLD_POID,temp_pol_input_flistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	scenario_pdp=PIN_FLIST_FLD_GET(billinfo_flistp,PIN_FLD_SCENARIO_OBJ,1,ebufp);
	if (!PIN_POID_IS_NULL(scenario_pdp))
	{
		PIN_FLIST_FLD_COPY(billinfo_flistp,PIN_FLD_SCENARIO_OBJ,temp_pol_input_flistp,PIN_FLD_SCENARIO_OBJ,ebufp);
	}
	PIN_FLIST_FLD_COPY(billinfo_flistp,PIN_FLD_PROGRAM_NAME,temp_pol_input_flistp,PIN_FLD_PROGRAM_NAME,ebufp);

	exemption_flistp=PIN_FLIST_ELEM_ADD(temp_pol_input_flistp,PIN_FLD_EXEMPTIONS,1,ebufp);
	//PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,exemption_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,ebufp);
	if (*exempt_iflag == PIN_BOOLEAN_TRUE)
	{
		exemption = PIN_COLLECTIONS_EXEMPTED;
		PIN_FLIST_FLD_SET(exemption_flistp, PIN_FLD_EXEMPT_STATUS, (void *) &exemption, ebufp);
	}
	else
	{
		exemption = PIN_COLLECTIONS_REMOVE_BILLINFO_EXEMPTION;
		PIN_FLIST_FLD_SET(exemption_flistp, PIN_FLD_EXEMPT_STATUS, (void *) &exemption, ebufp);
	}

	context_flistp=PIN_FLIST_SUBSTR_ADD(temp_pol_input_flistp,PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_flistp,PIN_FLD_EXTERNAL_USER,ebufp);


	/*Add source database*/
	memset(db_no_str, '\0', sizeof(db_no_str));
	snprintf(db_no_str, sizeof(db_no_str), "%d", db_no);

	{
		PIN_FLIST_FLD_SET(update_exemption_pol_flistp, PIN_FLD_SRC_DATABASE, db_no_str, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION"
				"input flist", update_exemption_pol_flistp);

	PCM_OP(ctxp,TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION,0,update_exemption_pol_flistp,&hook_update_exemption_pol_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&update_exemption_pol_flistp, NULL);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION"
					"Hook opcode prepare Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION"
					"Hook opcode prepare input flist error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION "
			       "output flist", hook_update_exemption_pol_flistp);

	if(hook_update_exemption_pol_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_update_exemption: PCM_OP_COLLECTIONS_EXEMPT_BILLINFO"
			       	"input flist ", hook_update_exemption_pol_flistp);
		update_coll_exempt_iflistp = PIN_FLIST_COPY(hook_update_exemption_pol_flistp, ebufp);
		PIN_FLIST_DESTROY_EX(&hook_update_exemption_pol_flistp, NULL);
		PCM_OP(ctxp, PCM_OP_COLLECTIONS_EXEMPT_BILLINFO, 0, update_coll_exempt_iflistp, &update_coll_exempt_oflistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption:"
					" input flist ", update_coll_exempt_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_update_exemption:"
					" Error in update customer", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_update_exemption: PCM_OP_COLLECTIONS_EXEMPT_BILLINFO"
					" output flist ", update_coll_exempt_oflistp);

		update_exemption_action_flistp = PIN_FLIST_COPY(update_coll_exempt_oflistp,ebufp);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS"
			       	"input flist", update_exemption_action_flistp);

		PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS,0,update_exemption_action_flistp,&hook_update_exemption_action_flistp,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_UPDATE_COLLECTION_EXEMPTION, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS"
				      	"Hook opcode prepare Input flist", update_exemption_action_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS"
					"Hook opcode prepare input flist error", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_collections_update_exemption: TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS "
				"output flist", hook_update_exemption_action_flistp);
	}
	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	*out_flistpp = r_flistp ;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_update_exemption output flist", *out_flistpp);

cleanup:
	PIN_FLIST_DESTROY_EX(&update_exemption_action_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&hook_update_exemption_action_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_coll_exempt_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_coll_exempt_iflistp, NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_update_exemption output flist", *out_flistpp);
	return;
}


