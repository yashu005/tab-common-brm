/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 3-Feb-2022    | Akshay Gund 	|               | New opcode TAB_OP_COLLECTIONS_REPLACE_SCENARIO.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_REPLACE_SCENARIO operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/collections.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "cm_cache.h"
#include "tab_utils_common.h"

extern cm_cache_t *fm_collections_config_scenario_cache_ptr;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_collections_replace_scenario(
	cm_nap_connection_t	 *connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

//static functions 
static void
fm_tab_collections_replace_scenario(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_REPLACE_SCENARIO operation.
 *************************************************************************/
void
op_tab_collections_replace_scenario(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)

{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp=NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_replace_scenario function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_COLLECTIONS_REPLACE_SCENARIO) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_replace_scenario bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_replace_scenario input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_COLLECTIONS_REPLACE_SCENARIO;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_COLLECTIONS_REPLACE_SCENARIO)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_COLLECTIONS_REPLACE_SCENARIO, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
					" input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_replace_scenario:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_collections_replace_scenario(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_replace_scenario error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario : enrich_iflistp", enrich_iflistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_replace_scenario:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_replace_scenario: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_COLLECTIONS_REPLACE_SCENARIO", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_replace_scenario:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_COLLECTIONS_REPLACE_SCENARIO;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_COLLECTIONS_REPLACE_SCENARIO )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_COLLECTIONS_REPLACE_SCENARIO, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_replace_scenario output flist", *ret_flistpp);
	return;
}

/********************************************
 * We use this function replace scneario for
 * account which is in collection.
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/
 
static void fm_tab_collections_replace_scenario(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*replace_secnario_pol_iflistp = NULL;
	pin_flist_t	*hook_replace_secnario_pol_oflistp = NULL;
	pin_flist_t	*billinfo_flistp=NULL;
	pin_flist_t	*replace_scenario_info_flistp=NULL;
	pin_flist_t	*get_scenario_iflistp=NULL;
	pin_flist_t	*context_flistp=NULL;
	pin_flist_t	*res_flistp=NULL;
	pin_flist_t	*action_flistp=NULL;
	pin_flist_t	*scenario_info_flistp=NULL;

	poid_t		*account_pdp = NULL;
	poid_t		*from_obj_pdp=NULL;
	poid_t		*to_obj_pdp=NULL;
	int32		active_flag = 0;
	int		*paytype_i =NULL;
	int32		*fld_mode= 0;
	char		log_msg[256]="";
	int32		coll_scenario_elemid= 0;
	time_t		current_time=0;
	pin_cookie_t	coll_scenario_cookie = NULL;
	char		*effective_date= NULL;
	time_t		schedule_t=0;	
	char		*scenario_name_inp=NULL;
	char		*scenario_new_value=NULL;
	char		*scenario_name=NULL;
	char		*accountno = NULL;

	cm_cache_key_poid_t     cache_key;
	int32		err = 0;
	int32		error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_replace_scenario input flist", in_flistp);

	accountno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if ((accountno == NULL || strlen(accountno) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario : Error PIN_FLD_ACCOUNT_NO - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario  input flist", in_flistp);
		goto cleanup;
	}

	scenario_name_inp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SCENARIO_NAME, 1, ebufp);
	scenario_new_value=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_NEW_VALUE,1, ebufp);

	if ((scenario_name_inp== NULL || strlen(scenario_name_inp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SCENARIO_NAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario : Error PIN_FLD_SCENARIO_NAME- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;
	}

	if ((scenario_new_value== NULL || strlen(scenario_new_value) == 0))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_NEW_SCENARIO_VALUE_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_collections_replace_scenario : Error PIN_FLD_NEW_VALUE- Input is missing", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario input flist", in_flistp);
                goto cleanup;
        }

	if (strcmp(scenario_name_inp,scenario_new_value) == 0 )
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SAME_SCENARIO_VALUES, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;

	}

	fld_mode= (int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MODE, 1, ebufp);

	if (fld_mode != NULL)
	{
		if(( *fld_mode == TAB_SUCCESS ) ||(*fld_mode == TAB_FAIL))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_collections_replace_scenario input flist", in_flistp);
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_SCHEDULE_MODE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_replace_scenario:Error PIN_FLD_MODE value invalid", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario input flist", in_flistp);
			goto cleanup;
		}
	}
	else
	{
        pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_SCHEDULE_MODE_MISSING, 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_collections_replace_scenario:Error PIN_FLD_MODE is missing", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_collections_replace_scenario input flist", in_flistp);
        goto cleanup;
    }


	 /********************************************************
	*If PIN_FLD_MODE from input is 1, check TAB_FLD_EFFECTIVE_DATE is passed or not
	*If date is not passed use current date.
	*********************************************************/

	effective_date = PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_EFFECTIVE_DATE,1, ebufp);

	if ((*fld_mode == TAB_SUCCESS) && ((effective_date==NULL) || ( strlen(effective_date) == 0)))
	{
			current_time = pin_virtual_time(NULL);
			sprintf(log_msg,"%ld",current_time);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			schedule_t=current_time;
	}
	else 
	{
		schedule_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp,effective_date, ebufp);
	}

	sprintf(log_msg,"effective_date schedule_t %s %ld",effective_date,schedule_t);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/*********************************************************
	* Getting billinfo details for account
	*********************************************************/

	account_pdp = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID, 1 , ebufp);
	fm_tab_utils_common_get_billinfo(ctxp,account_pdp, active_flag,&billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp);

	/*********************************************************
	 * Validation if the account is prepaid
	 *********************************************************/
	paytype_i = (int *)PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if (*paytype_i == PIN_BILL_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", billinfo_flistp);
		goto cleanup;
	}
	if (*paytype_i == PIN_BILL_TYPE_SUBORD)
        {
                if(accountno != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_replace_scenario:"
                                        "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }



        /***********************************************************************************************
         * Call Init to get the /config/collections/scenario  poid
         ***********************************************************************************************/

        cache_key.id = 1;
        cache_key.db = 0;

        action_flistp= cm_cache_find_entry (fm_collections_config_scenario_cache_ptr,
                        (void *)&cache_key, &err);

        if ( action_flistp != (pin_flist_t *)NULL )
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"action_flistp flist", action_flistp);
        }
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Base search opcode error", get_scenario_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Base search opcode error", ebufp);
		goto cleanup;
	}
	coll_scenario_elemid= 0;
	coll_scenario_cookie = NULL;
	while((res_flistp= PIN_FLIST_ELEM_GET_NEXT(action_flistp, PIN_FLD_RESULTS,
					&coll_scenario_elemid, 1, &coll_scenario_cookie, ebufp)) != (pin_flist_t *)NULL)
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "res_flistp to get PIN_FLD_RESULTS",res_flistp );
		scenario_info_flistp=PIN_FLIST_SUBSTR_GET(res_flistp, PIN_FLD_SCENARIO_INFO,1,ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "scenario_info_flistp to PIN_FLD_SCENARIO_INFO ",scenario_info_flistp);

		scenario_name=PIN_FLIST_FLD_GET(scenario_info_flistp,PIN_FLD_SCENARIO_NAME,1, ebufp);
		sprintf(log_msg,"scenario_name , scenario_name_inp %s %s ",scenario_name,scenario_name_inp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);


		if (strcmp(scenario_name,scenario_name_inp)== 0)
		{
			from_obj_pdp=PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_POID,1,ebufp);
		}
		else if (strcmp(scenario_name,scenario_new_value)== 0)
		{	
			to_obj_pdp=PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_POID,1,ebufp);
		}

		if(!(PIN_POID_IS_NULL(from_obj_pdp))  && !(PIN_POID_IS_NULL(to_obj_pdp)))	
		{
			break;
		}
	}

	if (PIN_POID_IS_NULL(from_obj_pdp))  
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SCENARIO_NOT_EXISTS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: Error current scenario name dose not exists ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;
	}
	if (PIN_POID_IS_NULL(to_obj_pdp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NEW_SCENARIO_NOT_EXISTS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario:Error new scenario name does not exists ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario input flist", in_flistp);
		goto cleanup;
	}

	/*Create input flist for policy opcode*/
	replace_secnario_pol_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,replace_secnario_pol_iflistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO,replace_secnario_pol_iflistp,PIN_FLD_ACCOUNT_NO,ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp,PIN_FLD_POID,replace_secnario_pol_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME,replace_secnario_pol_iflistp,PIN_FLD_PROGRAM_NAME,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,replace_secnario_pol_iflistp,PIN_FLD_EXEMPT_FROM_COLLECTIONS,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,replace_secnario_pol_iflistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,replace_secnario_pol_iflistp,PIN_FLD_EXTERNAL_USER,ebufp);

	replace_scenario_info_flistp=PIN_FLIST_SUBSTR_ADD(replace_secnario_pol_iflistp,PIN_FLD_REPLACE_SCENARIO_INFO ,ebufp);
	PIN_FLIST_FLD_SET(replace_scenario_info_flistp,PIN_FLD_FROM_OBJ,from_obj_pdp,ebufp);
	PIN_FLIST_FLD_SET(replace_scenario_info_flistp,PIN_FLD_TO_OBJ,to_obj_pdp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MODE,replace_scenario_info_flistp,PIN_FLD_SCHEDULE_MODE,ebufp);
	if( *fld_mode == TAB_SUCCESS )
	{
		PIN_FLIST_FLD_SET(replace_scenario_info_flistp,PIN_FLD_SCHEDULE_T,&schedule_t,ebufp);
	}
	context_flistp=PIN_FLIST_SUBSTR_ADD(replace_secnario_pol_iflistp,PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_flistp,PIN_FLD_EXTERNAL_USER,ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_replace_scenario: TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO"
				"input flist", replace_secnario_pol_iflistp);

	PCM_OP(ctxp,TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO,0,replace_secnario_pol_iflistp,&hook_replace_secnario_pol_oflistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO "
					"Hook opcode prepare Input flist", replace_secnario_pol_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_replace_scenario: TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO"
					"Hook opcode prepare input flist error", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
        *out_flistpp= PIN_FLIST_COPY(hook_replace_secnario_pol_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_replace_scenario: TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO"
				"output flist", hook_replace_secnario_pol_oflistp);

cleanup:
	PIN_FLIST_DESTROY_EX(&replace_secnario_pol_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_replace_secnario_pol_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp,NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_replace_scenario output flist", *out_flistpp);
	return;
}


