/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 26-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_GET_ACTIONS operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"

//extern cm_cache_t *tab_get_collections_action_config_cache_ptr;
extern cm_cache_t *fm_collections_config_scenario_cache_ptr;
extern pin_flist_t *config_collection_actions_flistp;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_get_actions(
		cm_nap_connection_t     *connp,
		int                     opcode,
		int                     flags,
		pin_flist_t             *in_flistp,
		pin_flist_t             **out_flistpp,
		pin_errbuf_t            *ebufp);

void fm_tab_collections_get_actions(
		pcm_context_t       	*ctxp,
		pin_flist_t         	*in_flistp,
		pin_flist_t         	**out_flistpp,
		int64                   db_no,
		pin_errbuf_t        	*ebufp);



/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_GET_ACTIONS is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 1
 0 PIN_FLD_MSISDN    STR [0] "6091001011"
 0 PIN_FLD_ACCOUNT_NO    STR [0] "6091001011"
 0 PIN_FLD_ACTION_NAME STR [0] "collection action”
 0 PIN_FLD_DAYS   INT [0]    2
 0 PIN_FLD_DUE_T   TSTAMP [0] (1649228429) Wed Apr  6 00:00:29 2022
 0 PIN_FLD_USER_NAME    STR [0] "123456"
 0 TAB_FLD_ADDITIONAL_INFO    STR [0] " reason for rescheduling the action "
 0 PIN_FLD_CORRELATION_ID    STR [0] "er2345XR"
 0 PIN_FLD_EXTERNAL_USER    STR [0] " CRM "


 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_GET_ACTIONS operation.
 *************************************************************************/
void op_tab_collections_get_actions(
		cm_nap_connection_t      *connp,
		int                       opcode,
		int                       flags,
		pin_flist_t               *in_flistp,
		pin_flist_t               **ret_flistpp,
		pin_errbuf_t              *ebufp)
{
	pcm_context_t            *ctxp = connp->dm_ctx;
	pin_flist_t              *r_flistp = NULL;
	int32                    error_clear_flag = 1;
	int32                    cerror_code = 0;
	char                     log_msg[512]= "";
	int64                    db_no = 0;
	int32                    status = PIN_BOOLEAN_TRUE;
	pin_flist_t              *enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_actions error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_GET_ACTIONS) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_get_actions opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_actions input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}


	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_loan_details: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_loan_details:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/*	 call main function */
	fm_tab_collections_get_actions(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_get_actions error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_actions:"
				" fm_tab_collections_get_actions input flist", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_actions:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_get_actions:"
				" Error while getting collections actions details ", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_COLLECTION_ACTIONS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_get_actions output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_get_actions(
		pcm_context_t       *ctxp,
		pin_flist_t         *in_flistp,
		pin_flist_t         **out_flistpp,
		int64               db_no,
		pin_errbuf_t        *ebufp)
{
	pin_flist_t                     *billinfo_flistp= NULL;
	pin_flist_t                     *ret_flistp = NULL;
	pin_flist_t                     *scenario_readobj_iflistp = NULL;
	pin_flist_t                     *scenario_readobj_rflistp = NULL;
	pin_flist_t                     *enrich_PTP_flistp = NULL;
	pin_flist_t     		*i_coll_action_flistp=NULL;
	pin_flist_t     		*o_coll_action_flistp=NULL;
	pin_flist_t     		*args_flistp=NULL;
	int32                 		 coll_action_elemid = 0;
	pin_cookie_t           		 coll_action_cookie = NULL;
	pin_flist_t                     *res_flistp=NULL;
	pin_flist_t                     *res_action_flistp=NULL;
	pin_flist_t                     *config_action_readobj_rflistp=NULL;
	pin_flist_t                     *config_action_flistp=NULL;
	pin_flist_t                     *temp_flistp=NULL;
	pin_flist_t                     *action_ret_flistp=NULL;
	pin_flist_t                     *conf_action_res_flistp=NULL;
	pin_flist_t                     *config_scenario_info_flist=NULL;
	pin_flist_t                     *config_scenario_flistp=NULL;
	pin_flist_t                     *temp_scenario_flistp=NULL;
	pin_flist_t                     *config_action_info_flist=NULL;
	pin_flist_t                     *conf_scenario_res_flistp=NULL;
	pin_flist_t                     *ptp_flist=NULL;
	poid_t                          *account_pdp = NULL;
	poid_t                          *config_action_obj = NULL;
	poid_t                          *config_scenario_obj = NULL;
	poid_t                          *config_scenario_cache_obj = NULL;
	char                            log_msg[256]="";
	int32                           active_flag = 0;
	int32                           status = 0;
	int32                           *req_type = NULL;
	int32                           paytype_i = 0;
	poid_t  			*scenario_obj  = NULL;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;
	char                            *action_name = NULL;
	char                            *valid_to = NULL;
	time_t                            valid_to_epoch = 0;
	char                            *valid_from = NULL;
	time_t                            valid_from_epoch = 0;
	int32                           s_flags = 256;
	poid_t                          *srchp  = NULL;
	poid_t                          *config_action_cache_obj  = NULL;
	void                            *vp = NULL;
	cm_cache_key_poid_t             cache_key;
	int32                   	res_elemid = 0;
	pin_cookie_t            	res_cookie = NULL;
	int32                           err = 0;
	char                            *due_t_str = NULL;
	char                            *complete_t_str = NULL;
	time_t                          *due_t = NULL;
	time_t                          *complete_t = NULL;





	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
				" input flist", in_flistp);
		return;
	}


	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_actions:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_get_actions:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_get_actions:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_SCENARIO_OBJ, in_flistp, PIN_FLD_SCENARIO_OBJ, ebufp);

	vp=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp != NULL)
	{
		paytype_i = *(int32 *)vp;
	}

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
        {
                if(account_no != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_get_actions:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }


	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_actions:"
			"Validated to be postpaid account");

	req_type = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ARG_TYPE, 1, ebufp);
	if (req_type != NULL)
	{
		if (*req_type == 0)
		{
			status = 2;
		}
		else if (*req_type == 1)
		{
			status = 0;
		}
		else if (*req_type == 2)
		{
			status = 1;
		}
	}
	else
	{
		status = 2;
	}

	valid_to=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_VALID_TO_STR,1,ebufp);
	if(valid_to != NULL )
	{
		/*Convert date in string format to unix timestamp*/
		valid_to_epoch = fm_tab_utils_common_convert_date_to_timestamp(ctxp, valid_to, ebufp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_actions:"
				"valid_to_epoch");


	}

	valid_from=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_VALID_FROM_STR ,0,ebufp);
	if(valid_from != NULL)
	{
		/*Convert date in string format to unix timestamp*/
		valid_from_epoch = fm_tab_utils_common_convert_date_to_timestamp(ctxp, valid_from, ebufp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_actions:"
				"valid_from_epoch");

	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_VALID_FROM_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Error in getting  PIN_FLD_VALID_FROM_STR ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Missing PIN_FLD_VALID_FROM_STR ", in_flistp);
		goto cleanup;

	}
	if(valid_to == NULL )
	{
		if(valid_from_epoch)
		{
			valid_to_epoch = valid_from_epoch + 7776000;
		}

	}

                scenario_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SCENARIO_OBJ,1,ebufp);
        if (PIN_POID_IS_NULL(scenario_obj))
                        {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_obj:"
                                        "Account not in collections,Error while getting  SCENARIO obj_id", ebufp);
                        goto cleanup;
                        }

	/*Read_Obj of scenario_obj*/
	scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(scenario_readobj_iflistp,PIN_FLD_POID, scenario_obj, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj input flist",
			scenario_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, scenario_readobj_iflistp,&scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_iflistp, NULL);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Account not in collections,scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Error while doing SCENARIO  read_obj", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj return flist",
			scenario_readobj_rflistp);

	if(scenario_readobj_rflistp ==NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
				scenario_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
				"Account not in collections,Error while doing SCENARIO  read_obj", ebufp);
		goto cleanup;
	}


	/***********************************************************************************************
	 * Call Init to get the /config/collections/actions  poid
	 ***********************************************************************************************/


	/*	config_action_flistp = cm_cache_find_entry (tab_get_collections_action_config_cache_ptr,
		(void *)&cache_key, &err);  */
	config_action_flistp=PIN_FLIST_COPY(config_collection_actions_flistp, ebufp);
	if ( config_action_flistp != (pin_flist_t *)NULL )
	{

		res_flistp = PIN_FLIST_ELEM_GET(config_action_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

		if ( res_flistp != (pin_flist_t *)NULL )
		{

			while ((temp_flistp = PIN_FLIST_ELEM_GET_NEXT(config_action_flistp,
							PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"action flistp flist", temp_flistp);

			}
		}       

	}

	res_elemid = 0;
	res_cookie = NULL;


	/***********************************************************************************************
	 * Call Init to get the /config/collections/scenario  poid
	 ***********************************************************************************************/

	cache_key.id = 1;
	cache_key.db = 0;

	config_scenario_flistp = cm_cache_find_entry (fm_collections_config_scenario_cache_ptr,
			(void *)&cache_key, &err);

	if ( config_scenario_flistp != (pin_flist_t *)NULL )
	{

		res_flistp = PIN_FLIST_ELEM_GET(config_scenario_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

		if ( res_flistp != (pin_flist_t *)NULL )
		{

			while ((temp_flistp = PIN_FLIST_ELEM_GET_NEXT(config_scenario_flistp,
							PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"scenario flistp flist", temp_flistp);

			}
		}

	}

	res_elemid = 0;
	res_cookie = NULL;


	/***********************************************************************************************
	 * Search  the /collection_action 
	 ***********************************************************************************************/
	i_coll_action_flistp  = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(i_coll_action_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(i_coll_action_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	if (status == 1)
	{
		vp =(void *)"select X from /collections_action  where  F1 = V1 and F2 >= V2 and F3 <= V3 order by collections_action_t.due_t desc ";
	}
	else
	{
		vp =(void *)"select X from /collections_action  where  F1 = V1 and F2 >= V2 and F3 <= V3 and F4 = V4 order by collections_action_t.due_t desc ";
		args_flistp = PIN_FLIST_ELEM_ADD(i_coll_action_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &status, ebufp);
	}

	PIN_FLIST_FLD_SET(i_coll_action_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_coll_action_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_coll_action_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_DUE_T, &valid_from_epoch, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_coll_action_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_DUE_T, &valid_to_epoch, ebufp);

	PIN_FLIST_ELEM_SET(i_coll_action_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to get collections_action  : "
			"input flist", i_coll_action_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0,i_coll_action_flistp, &o_coll_action_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Base search opcode error in finding actions", i_coll_action_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_get_actions: Base search opcode error in finding collection actions.", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_get_actions: Base search opcode output for colection action :", o_coll_action_flistp);


	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	//action_ret_flistp = PIN_FLIST_ELEM_ADD(ret_flistp, PIN_FLD_ACTION_INFO, PIN_ELEMID_ANY, ebufp);

	if (o_coll_action_flistp != (pin_flist_t *)NULL )
	{

		res_flistp = PIN_FLIST_ELEM_GET(o_coll_action_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"res_flistp", res_flistp);

		if (res_flistp != (pin_flist_t *)NULL )
		{
			while((res_action_flistp= PIN_FLIST_ELEM_GET_NEXT(o_coll_action_flistp, PIN_FLD_RESULTS,
							&coll_action_elemid, 1, &coll_action_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				action_ret_flistp = PIN_FLIST_ELEM_ADD(ret_flistp, PIN_FLD_ACTION_INFO, coll_action_elemid, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"res_action_flistp", res_action_flistp);


				/*Read_Obj of config_action_obj*/
				config_action_obj = PIN_FLIST_FLD_GET(res_action_flistp,PIN_FLD_CONFIG_ACTION_OBJ,0,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"config_action_flistp", config_action_flistp);

				if ( config_action_flistp != (pin_flist_t *)NULL )
				{

					conf_action_res_flistp = PIN_FLIST_ELEM_GET(config_action_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

					if ( conf_action_res_flistp != (pin_flist_t *)NULL )
					{

						while ((temp_flistp = PIN_FLIST_ELEM_GET_NEXT(config_action_flistp,
										PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							config_action_cache_obj=PIN_FLIST_FLD_GET(temp_flistp,PIN_FLD_POID,0,ebufp);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
									"flistp flist", temp_flistp);
							if(!PIN_POID_COMPARE(config_action_obj, config_action_cache_obj, 0, ebufp))	
							{


								config_action_info_flist=PIN_FLIST_ELEM_GET(temp_flistp, PIN_FLD_CONFIG_ACTION_INFO, PIN_ELEMID_ANY, 1, ebufp);
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
										"config_action_info_flist", config_action_info_flist);

								PIN_FLIST_FLD_COPY(config_action_info_flist,PIN_FLD_ACTION_NAME,action_ret_flistp,PIN_FLD_ACTION_NAME,ebufp);
								PIN_FLIST_FLD_COPY(config_action_info_flist,PIN_FLD_ACTION_TYPE,action_ret_flistp,PIN_FLD_ACTION_TYPE,ebufp);
								action_name=PIN_FLIST_FLD_GET(config_action_info_flist,PIN_FLD_ACTION_NAME,0, ebufp);
								if(strcmp(action_name,"Promise to Pay") == 0)
								{

									ptp_flist = PIN_FLIST_ELEM_GET(res_action_flistp, PIN_FLD_PROMISE_TO_PAY_INFO, PIN_ELEMID_ANY, 1, ebufp);
									if ( ptp_flist != (pin_flist_t *)NULL )
									{
										PIN_FLIST_FLD_COPY(ptp_flist,PIN_FLD_AMOUNT,action_ret_flistp,PIN_FLD_AMOUNT,ebufp);
									}


								}
							}

						}
						res_elemid = 0;
						res_cookie = NULL;
					}

				}

				due_t=PIN_FLIST_FLD_GET(res_action_flistp,PIN_FLD_DUE_T,1,ebufp);
				if(due_t != NULL )
				{
					/*Convert date in string format to unix timestamp*/
					due_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp, due_t, ebufp);

				}
				PIN_FLIST_FLD_SET(action_ret_flistp,TAB_FLD_DUE_T_STR, due_t_str, ebufp);
				free(due_t_str);
					
				complete_t=PIN_FLIST_FLD_GET(res_action_flistp,PIN_FLD_COMPLETED_T,1,ebufp);
				if(complete_t != NULL )
				{
					/*Convert date in string format to unix timestamp*/
					complete_t_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp, complete_t, ebufp);

				}
				PIN_FLIST_FLD_SET(action_ret_flistp,TAB_FLD_COMPLETED_T_STR, complete_t_str, ebufp);
				free(complete_t_str);

				PIN_FLIST_FLD_COPY(res_action_flistp,PIN_FLD_STATUS,action_ret_flistp,PIN_FLD_STATUS,ebufp);

				/*Read_Obj of scenario_obj*/
				scenario_obj = PIN_FLIST_FLD_GET(res_action_flistp,PIN_FLD_SCENARIO_OBJ,0,ebufp);
				scenario_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(scenario_readobj_iflistp,PIN_FLD_POID, scenario_obj, ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj input flist",
						scenario_readobj_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, scenario_readobj_iflistp,&scenario_readobj_rflistp, ebufp);
				PIN_FLIST_DESTROY_EX(&scenario_readobj_iflistp, NULL);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
							scenario_readobj_iflistp);
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
							"Error while doing SCENARIO  read_obj", ebufp);
					goto cleanup;
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SCENARIO  Read_Obj return flist",
						scenario_readobj_rflistp);

				if(scenario_readobj_rflistp ==NULL)
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"scenario_read_obj input flist",
							scenario_readobj_iflistp);
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_GET_COLLECTION_ACTIONS, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"scenario_read_obj:"
							"Error while doing SCENARIO  read_obj for an action", ebufp);
					goto cleanup;
				}

				PIN_FLIST_FLD_COPY(scenario_readobj_rflistp,PIN_FLD_OVERDUE_AMOUNT,action_ret_flistp,PIN_FLD_OVERDUE_AMOUNT,ebufp);

				config_scenario_obj=PIN_FLIST_FLD_GET(scenario_readobj_rflistp,PIN_FLD_CONFIG_SCENARIO_OBJ,0,ebufp);
				if ( config_scenario_flistp != (pin_flist_t *)NULL )
				{

					conf_scenario_res_flistp = PIN_FLIST_ELEM_GET(config_scenario_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

					if ( conf_scenario_res_flistp != (pin_flist_t *)NULL )
					{

						while ((temp_scenario_flistp = PIN_FLIST_ELEM_GET_NEXT(config_scenario_flistp,
										PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							config_scenario_cache_obj=PIN_FLIST_FLD_GET(temp_scenario_flistp,PIN_FLD_POID,0,ebufp);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
									"flistp flist", temp_scenario_flistp);
							//if( strcmp(config_scenario_obj,config_scenario_cache_obj)== 0 )
							if(!PIN_POID_COMPARE(config_scenario_obj, config_scenario_cache_obj, 0, ebufp))
							{

								config_scenario_info_flist=PIN_FLIST_ELEM_GET(temp_scenario_flistp, PIN_FLD_SCENARIO_INFO, PIN_ELEMID_ANY, 1, ebufp);
								PIN_FLIST_FLD_COPY(config_scenario_info_flist,PIN_FLD_SCENARIO_NAME,action_ret_flistp,PIN_FLD_SCENARIO_NAME,ebufp);
								PIN_FLIST_FLD_COPY(config_scenario_info_flist,PIN_FLD_SCENARIO_DESCR,action_ret_flistp,PIN_FLD_SCENARIO_DESCR,ebufp);
							}

						}
						res_elemid = 0;
						res_cookie = NULL;
					}

				}



			}
		}
	}


	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_get_actions:"
			"output flist :", ret_flistp);


	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_PTP_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&scenario_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&o_coll_action_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&conf_action_res_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&config_action_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&i_coll_action_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_get_actions output flist : ", *out_flistpp);

	return;
}
