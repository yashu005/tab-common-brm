/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 04-04-2022    | Rashmi Shete      |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "ops/collections.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "cm_cache.h"
#include "ops/installment.h"

extern cm_cache_t *tab_get_collections_status_config_cache_ptr;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/


EXPORT_OP void
op_tab_collections_cancel_installment(
		cm_nap_connection_t     		*connp,
		int                              	opcode,
		int                              	flags,
		pin_flist_t                     	*in_flistp,
		pin_flist_t                     	**out_flistpp,
		pin_errbuf_t            		*ebufp);

void fm_tab_collections_cancel_installment(
		pcm_context_t       			*ctxp,
		pin_flist_t         			*in_flistp,
		pin_flist_t         			**out_flistpp,
		int64                           	db_no,
		pin_errbuf_t        			*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern int32	*cfg_tab_system_currency;

/**************************************************************************
 *
 * New opcode TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 0
 * 0		PIN_FLD_ACCOUNT_NO	STR[0] "0.0.0.1-14422173"
 0 		PIN_FLD_MSISDN      STR [0] "60020211229 "
 0	        PIN_FLD_EXTERNAL_USER              STR [0] "CRM"
 0 		PIN_FLD_CORRELATION_ID             STR [0] "820345239"

 *************************************************************************/


/**************************************************************************
 * Main routine for the TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT operation.
 *************************************************************************/

	void
op_tab_collections_cancel_installment(
		cm_nap_connection_t             *connp,
		int                              opcode,
		int                              flags,
		pin_flist_t                      *in_flistp,
		pin_flist_t                      **ret_flistpp,
		pin_errbuf_t                     *ebufp)
{
	pcm_context_t                   		*ctxp = connp->dm_ctx;
	pin_flist_t                             *r_flistp = NULL;
	int32                                   tab_order_flag = 0;
	int32                                   error_clear_flag = 1;
	int32                                   cerror_code = 0;
	char                                    log_msg[512]= "";
	int64                                   db_no = 0;
	poid_t                                  *account_pdp = NULL;
	int32                                   status = PIN_BOOLEAN_TRUE;
	pin_flist_t                             *enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_cancel_installment error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_cancel_installment opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_cancel_installment input flist", in_flistp);



	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	//r_flistp = PIN_FLIST_CREATE(ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_PAYMENT_INSTALLMENT, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_cancel_installment: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_cancel_installment:"
					" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_cancel_installment:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/*	 call main function */
		fm_tab_collections_cancel_installment(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_collections_cancel_installment error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_cancel_installment:"
					" fm_tab_collections_cancel_installment input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_collections_cancel_installment:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_cancel_installment: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_COLLECTIONS_CANCEL_INSTALLMENT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_collections_cancel_installment:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_collections_cancel_installment:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_PAYMENT_INSTALLMENT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_collections_cancel_installment output flist", *ret_flistpp);
	return;
}

void fm_tab_collections_cancel_installment(
		pcm_context_t       *ctxp,
		pin_flist_t         *in_flistp,
		pin_flist_t         **out_flistpp,
		int64				db_no,
		pin_errbuf_t        *ebufp)
{
	pin_flist_t			*billinfo_flistp= NULL;
	pin_flist_t			*enrich_iflistp = NULL;
	pin_flist_t			*ret_cancel_instl_flistp = NULL;
	pin_flist_t			*ret_flistp = NULL;
	pin_flist_t			*cancel_instl_flistp = NULL;
	pin_flist_t			*in_unfreeze_collections = NULL;
	pin_flist_t			*out_unfreeze_collections = NULL;
	pin_flist_t			*update_service_flistp = NULL;
	pin_flist_t             	*i_install_sche_flistp = NULL;
	pin_flist_t             	*o_install_sche_flistp = NULL;
	pin_flist_t             	*res_flistp = NULL;
	pin_flist_t             	*args_flistp = NULL;
	poid_t				*account_pdp = NULL;
	char				log_msg[256]="";
	int32				active_flag = 0;
	int32				paytype_i = 0;
	void                            *vp = NULL;
	poid_t                          *instl_spec_obj = NULL;
	poid_t          		*srchp  = NULL;
	int32           		s_flags = 256;
	char                            *account_no= NULL;
	char                            *msisdn_strp = NULL;



	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment:"
				" input flist", in_flistp);
		return;
	}

	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			" input flist", in_flistp);


	/***********************************************************
	 * Mandatory Validation
	 ***********************************************************/

	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_no == NULL || strlen(account_no ) == 0) && (msisdn_strp == NULL || strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Error in getting  PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mandatory_field_validation: Missing PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO", in_flistp);
		goto cleanup;

	}



	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);

	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_collections_cancel_installment:"
			" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment input flist", in_flistp);
		goto cleanup;
	}

	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment input flist", in_flistp);
		goto cleanup;
	}

	sprintf(log_msg,"fm_tab_collections_cancel_installment:"
			" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)

		/*********************************************************
		 * Validation if the account is postpaid.
		 *********************************************************/
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	paytype_i = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if (paytype_i == PIN_PAY_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_POSTPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error Paytype is not postpaid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error Paytype is not postpaid input flist", billinfo_flistp);
		goto cleanup;
	}
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
        {
                if(account_no != NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment:"
                               "Error Subord Paytype found for the given account", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
                else
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_MSISDN_NOT_PR , 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment:"
                               "Error Subord Paytype found for the given MSISDN", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment:"
                               "Error SubordPaytype  input flist", billinfo_flistp);
                        goto cleanup;
                }
        }

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			"Validated to be postpaid account");



	/***********************************************************************************************
	 * Search  the /installment_schedule poid
	 ***********************************************************************************************/
	i_install_sche_flistp  = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(i_install_sche_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(i_install_sche_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =(void *)"select X from /installment_schedule where  F1 = V1";
	PIN_FLIST_FLD_SET(i_install_sche_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(i_install_sche_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);

	PIN_FLIST_ELEM_SET(i_install_sche_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to get installment_schedule : "
			"input flist", i_install_sche_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0,i_install_sche_flistp, &o_install_sche_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Base search opcode error", i_install_sche_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Base search opcode error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_cancel_installment: Base search opcode output", o_install_sche_flistp);
	if (o_install_sche_flistp && (o_install_sche_flistp != NULL ))
	{

		res_flistp = PIN_FLIST_ELEM_GET(o_install_sche_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0, ebufp);

		if (res_flistp != (pin_flist_t *)NULL )
		{
			vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_POID, 0, ebufp); 
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_cancel_installment: No installment_schedule found  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment : No installment_schedule found:"
					"input flist",i_install_sche_flistp);
			goto cleanup;

		}

		if(vp)
		{
			instl_spec_obj=(poid_t *)vp;

		}
		else 
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_collections_cancel_installment: No installment_schedule found  ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment : No installment_schedule found :"
					"input flist",i_install_sche_flistp);
			goto cleanup;

		}

	}
	else
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error in installment_schedule search  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment : installment_schedule search:"
				"input flist",i_install_sche_flistp);
		goto cleanup;
	}


	/*********************************************************
	  fm_tab_collections_cancel_installment.c         * Flist creation of PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT
	 *********************************************************/
	/*
	 *Sample Input Flist to call the opcode:
	 0      PIN_FLD_POID           POID [0] 0.0.0.1 /installment_schedule 23546 1
	 0     PIN_FLD_ACCOUNT_OBJ	STR[0] "0.0.0.1-2636100 "
	 0     PIN_FLD_PROGRAM_NAME    STR [0] "CRM"
	 *
	 **/

	cancel_instl_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(cancel_instl_flistp,PIN_FLD_POID, instl_spec_obj, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, cancel_instl_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, cancel_instl_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			" PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT input flist ", cancel_instl_flistp);



	/***************************************
	 * PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT  Opcode Call
	 ***************************************/
	PCM_OP(ctxp,PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT, 0, cancel_instl_flistp, &ret_cancel_instl_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_cancel_installment:"
				" input flist ", cancel_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_cancel_installment:"
				" Error in PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT", ebufp);
		goto cleanup;
	}        

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			" PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT output flist ", ret_cancel_instl_flistp);


	if (PIN_ERR_IS_ERR(ebufp) || (ret_cancel_instl_flistp == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_collections_cancel_installment:"
				" input flist ", cancel_instl_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_collections_cancel_installment:"
				" Error in PCM_OP_INSTALLMENT_CANCEL_INSTALLMENT , Error in getting  result status.", ebufp);
		goto cleanup;
	}

	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,ret_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	in_unfreeze_collections=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(in_unfreeze_collections, cancel_instl_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_cancel_installment: TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT "
			"input flist", in_unfreeze_collections);


	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT , 0,in_unfreeze_collections, &out_unfreeze_collections, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		vp = PIN_FLIST_FLD_GET(out_unfreeze_collections, PIN_FLD_ERROR_CODE, 0, ebufp);
		if(vp)
		{	
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					*(int32 *)vp, 0, 0, 0);
		}
		else
		{

			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
		}
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error in TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment : TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT:"
				"input flist", in_unfreeze_collections);
		*out_flistpp = out_unfreeze_collections;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			"TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT : output flist :", out_unfreeze_collections);

	/***************************************************************************************
	 * Update service status 
	 ***************************************************************************************/


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_cancel_installment: TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS "
			"input flist", in_unfreeze_collections);

	PCM_OP(ctxp, TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS , 0, in_unfreeze_collections, &update_service_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		vp = PIN_FLIST_FLD_GET(update_service_flistp, PIN_FLD_ERROR_CODE, 0, ebufp);
		if(vp)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					*(int32 *)vp, 0, 0, 0);
		}
		else
		{

			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_CANCEL_PAYMENT_INSTALLMENT, 0, 0, 0);
		}
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_cancel_installment: Error in TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_cancel_installment : TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS:"
				"input flist", in_unfreeze_collections);
		*out_flistpp = update_service_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_cancel_installment:"
			"TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS : output flist :", update_service_flistp);


	*out_flistpp =ret_flistp;
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&i_install_sche_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&o_install_sche_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&cancel_instl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&in_unfreeze_collections, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&update_service_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_cancel_instl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&out_unfreeze_collections, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_cancel_installment output flist : ", *out_flistpp);

	return;
}
