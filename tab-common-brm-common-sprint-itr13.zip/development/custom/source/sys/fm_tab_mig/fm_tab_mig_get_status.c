/******************************************************************************
 * 
 *	Copyright (c) 1999, 2019, Oracle and/or its affiliates. All rights reserved.
 *    
 *	This material is the confidential property of Oracle Corporation
 * 	or its licensors and may be used, reproduced, stored or transmitted
 *	only in accordance with a valid Oracle license or sublicense agreement.
 *
 ********************************************************************************/


/*******************************************************************
 *	Contains the TAB_OP_GET_MIG_STATUS operation. 
 ********************************************************************/

#include <stdio.h> 
#include <string.h> 
#include <fcntl.h> 

#include "pcm.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_cust.h"
#include "cm_cache.h"
#include "tab_ops_flds.h"
#include "tab_common.h"


extern cm_cache_t *tab_get_mig_status_config_cache_ptr;

/*******************************************************************
 *	Routines contained within.
 ********************************************************************/
EXPORT_OP void
op_tab_mig_get_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*i_flistp,
	pin_flist_t		**o_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_mig_get_status(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_mig_get_status_val_mand_flds(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

int
fm_tab_get_port_out_flag(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	

void
fm_tab_mig_multi_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_mig_prim_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	
extern char *
fm_tab_utils_common_convert_timestamp_to_date(
        pcm_context_t           *ctxp,
        time_t                  *input_time_t,
        pin_errbuf_t            *ebufp);
	
/*******************************************************************
 *	Main routine for the fm_tab_mig_get_status operation.
 ********************************************************************/
void
op_tab_mig_get_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*i_flistp,
	pin_flist_t		**o_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_mig_get_status opcode error", ebufp);
		return;
	}
	PIN_ERR_CLEAR_ERR(ebufp);

	/***********************************************************
	 * Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_MIG_GET_STATUS) {
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_mig_get_status opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_mig_get_status: input flist", i_flistp);

	/***********************************************************
	 * Call main function to do it
	***********************************************************/
     
	fm_tab_mig_get_status(ctxp, i_flistp, &r_flistp, ebufp);

	/***********************************************************
	 * Results.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_mig_get_status error", ebufp);
		goto cleanup;
	}

	/***************************************************
	 * Point the real return flist to the right thing.
	 ***************************************************/
	*o_flistpp = r_flistp;

	/***************************************************
	 * Debug: What we're sending back.
	 ***************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_mig_get_status return flist", r_flistp);

	return;
cleanup:
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	*o_flistpp = NULL;
	return;
}

static void
fm_tab_mig_get_status(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*out_flistp = NULL;
	pin_flist_t		*srch_out_flistp = NULL;
	pin_flist_t		*flistp = NULL;
	pin_flist_t		*port_search_flistp = NULL;
	pin_flist_t		*read_out_flistp = NULL;
	pin_flist_t		*read_mig_in_flistp = NULL;
	pin_flist_t		*read_mig_out_flistp = NULL;
	pin_flist_t		*refresh_flistp = NULL;
	pin_flist_t		*tab_mig_status_in_flistp = NULL;
	pin_flist_t		*tab_mig_status_out_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	pin_flist_t		*serv_res_flistp=NULL;
	pin_flist_t		*alias_flistp=NULL;
	pin_flist_t		*serv_flistp=NULL;
	pin_flist_t		*service_flistp=NULL;
	pin_flist_t		*service_res_flistp=NULL;
	pin_flist_t		*res_flistp=NULL;
	pin_flist_t		*read_service_in_flistp=NULL;
	pin_flist_t		*read_service_out_flistp=NULL;
	pin_flist_t		*prim_srch_out_flistp=NULL;
	pin_flist_t		*multi_srch_out_flistp=NULL;
	pin_flist_t		*service_out_flistp=NULL;
	pin_flist_t		*results_flistp=NULL;
	pin_flist_t		*result_copy_flistp=NULL;
	int32			res_elemid = 0;
	pin_cookie_t	res_cookie = NULL;
	int32			serv_res_elemid = 0;
	pin_cookie_t	serv_res_cookie = NULL;
	int32			alias_elemid = 0;
	pin_cookie_t	alias_cookie = NULL;
	char			*msidn = NULL;
	char			*name = NULL;
	char			*input_msisdn = NULL;
	char			*pre_msisdn = NULL;
	int32			status = PIN_BOOLEAN_FALSE;
	int32			*srvc_status = NULL;
	int32			is_found_flag = PIN_BOOLEAN_FALSE;
	char			err_code[255] = { '\0' };
	char			err_descr[255] = { '\0' };
	void			*aac_vendor = NULL;
	cm_cache_key_iddbstr_t	cache_key;
	pin_flist_t		*r_flistp = NULL;
	int32			err = 0;
	time_t			*mod_t = NULL;
	time_t			*cache_mod_t = NULL;
	time_t			*effective_t = NULL;
	time_t			*migration_t = NULL;
	char            *effective_t_strp = NULL;
    char            *migration_t_strp = NULL;
	int64           errorCode = 0;
	int32			is_portout_flag = PIN_BOOLEAN_FALSE;
	int32			set_date_flag = PIN_BOOLEAN_FALSE;
	int32			set_status =PIN_BOOLEAN_FALSE;
	int32			ret_status = PIN_BOOLEAN_TRUE;
	int32			match_flag = PIN_BOOLEAN_FALSE;
	int32                   no_msisdn_flag = PIN_BOOLEAN_FALSE;
	

        if (PIN_ERR_IS_ERR(ebufp))
                return;
        PIN_ERR_CLEAR_ERR(ebufp);

	/*****************************************
	 * Validation of Mandatory Fields routine
	 ****************************************/
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		goto cleanup;
	}

	fm_tab_mig_get_status_val_mand_flds(ctxp, in_flistp, &out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		goto cleanup;
	}
	
	input_msisdn=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1, ebufp);

	// In case of mutli_db environment - SEARCH from UNINQNESS_T
	if(cm_fm_is_multi_db())
	{
		fm_tab_mig_multi_search(ctxp, in_flistp, &multi_srch_out_flistp, ebufp);
		
		
		if (PIN_ERR_IS_ERR(ebufp))
			{
				goto cleanup;
			}

		while ((results_flistp = PIN_FLIST_ELEM_GET_NEXT(multi_srch_out_flistp,
					PIN_FLD_RESULTS, &serv_res_elemid, 1, &serv_res_cookie, ebufp)) != (pin_flist_t *)NULL)			
		{

			name=PIN_FLIST_FLD_GET(results_flistp,PIN_FLD_LOGIN,1, ebufp);
						
			if ( strcmp(name, input_msisdn) == 0 ){
				
				match_flag = PIN_BOOLEAN_TRUE;
				result_copy_flistp = PIN_FLIST_COPY(results_flistp, ebufp);
				break;
			}		
		}
		if ( !match_flag ){
		
			service_res_flistp = PIN_FLIST_ELEM_GET(multi_srch_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
			if (service_res_flistp == NULL){
				pin_set_err(ebufp, PIN_ERRLOC_FM,
                        PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        PIN_ERR_NOT_FOUND, 0, 0, 0);
				no_msisdn_flag = PIN_BOOLEAN_TRUE;

			goto cleanup;
			}	
			
			//for closed service perform a read fld of the service object.
			read_service_in_flistp  = PIN_FLIST_CREATE(ebufp);
			
			PIN_FLIST_FLD_COPY(service_res_flistp, PIN_FLD_SERVICE_OBJ, read_service_in_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_STATUS, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_LIFECYCLE_STATE, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_EFFECTIVE_T, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_LOGIN, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_AAC_VENDOR, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_ACCOUNT_OBJ, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_CREATED_T, NULL,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"read_service_in_flistp flist", read_service_in_flistp);
			PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_service_in_flistp, &service_out_flistp, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"read_service_out_flistp flist", service_out_flistp);
		}
		else
		{
			//for active service perform a read fld of the service object.
			
			read_service_in_flistp  = PIN_FLIST_CREATE(ebufp);
			
			PIN_FLIST_FLD_COPY(result_copy_flistp, PIN_FLD_SERVICE_OBJ, read_service_in_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_STATUS, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_LIFECYCLE_STATE, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_EFFECTIVE_T, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_LOGIN, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_AAC_VENDOR, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_ACCOUNT_OBJ, NULL,ebufp);
			PIN_FLIST_FLD_SET(read_service_in_flistp, PIN_FLD_CREATED_T, NULL,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"read_service_in_flistp flist", read_service_in_flistp);
			PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_service_in_flistp, &service_out_flistp, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"read_service_out_flistp flist", service_out_flistp);
		}
	}
	else 
	{
		fm_tab_mig_prim_search(ctxp, in_flistp, &prim_srch_out_flistp, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			goto cleanup;
		}

		while ((results_flistp = PIN_FLIST_ELEM_GET_NEXT(prim_srch_out_flistp,
					PIN_FLD_RESULTS, &serv_res_elemid, 1, &serv_res_cookie, ebufp)) != (pin_flist_t *)NULL)			
		{

			while (!alias_flistp && (alias_flistp = PIN_FLIST_ELEM_GET_NEXT(results_flistp,
					PIN_FLD_ALIAS_LIST, &alias_elemid, 1, &alias_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
						name=PIN_FLIST_FLD_GET(alias_flistp,PIN_FLD_NAME,1, ebufp);
						
						if ( strcmp(name, input_msisdn) == 0 ){
							
							match_flag = PIN_BOOLEAN_TRUE;
							
							service_out_flistp = PIN_FLIST_COPY(results_flistp, ebufp);
							
							break;
						}		
			}
		}
		if ( !match_flag ){
			
			service_out_flistp = PIN_FLIST_ELEM_GET(prim_srch_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
			if (service_out_flistp == NULL){
				pin_set_err(ebufp, PIN_ERRLOC_FM,
                        PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        PIN_ERR_NOT_FOUND, 0, 0, 0);
				no_msisdn_flag = PIN_BOOLEAN_TRUE;

				goto cleanup;
			}
		}
	}

	
	/************** Prepare Return Flist ********************
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
	0 PIN_FLD_MSISDN          STR [0] "66990207308"
	0 PIN_FLD_STATUS_MSG      STR [0] "Success"
	0 PIN_FLD_SERVICE_STATUS  STR [0] "active"

	0 PIN_FLD_STATUS         ENUM [0] 1
	0 200068                  STR [0] "10-Apr-2022 07:00:00"
	0 200002                 ENUM [0] 1
	**********************************************************/
		
	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, ret_flistp, PIN_FLD_POID, ebufp);
	msidn = PIN_FLIST_FLD_GET( in_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if ( service_out_flistp != (pin_flist_t *)NULL )
	{
		srvc_status = (int32 *)PIN_FLIST_FLD_GET(service_out_flistp, PIN_FLD_STATUS, 1, ebufp);
		aac_vendor =  PIN_FLIST_FLD_GET( service_out_flistp, PIN_FLD_AAC_VENDOR, 1, ebufp);
			
	}

	if ( service_out_flistp == NULL ||  srvc_status != NULL  )
	{
		cache_key.id = 1;
		cache_key.db = 0;
		cache_key.str = "/config/tab_migration_status";
							
		r_flistp = cm_cache_find_entry (tab_get_mig_status_config_cache_ptr,
				(void *)&cache_key, &err);

		if ( r_flistp != (pin_flist_t *)NULL )
		{
			res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);

			read_mig_in_flistp = PIN_FLIST_CREATE(ebufp);
			
			PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID, read_mig_in_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_SET(read_mig_in_flistp, PIN_FLD_MOD_T, NULL, ebufp);
			PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_mig_in_flistp, &read_mig_out_flistp, ebufp);

			PIN_FLIST_DESTROY_EX(&read_mig_in_flistp, NULL);

			res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
			mod_t = PIN_FLIST_FLD_GET( read_mig_out_flistp, PIN_FLD_MOD_T, 1, ebufp);
			cache_mod_t  = PIN_FLIST_FLD_GET( res_flistp, PIN_FLD_MOD_T, 0, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"r_flistp flist", r_flistp);

			if ( *mod_t > *cache_mod_t )
			{
				//Read the latest /tab_migration_status object.
				tab_mig_status_in_flistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID, tab_mig_status_in_flistp, PIN_FLD_POID, ebufp);
				PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, tab_mig_status_in_flistp, &tab_mig_status_out_flistp, ebufp);
				
				PIN_FLIST_DESTROY_EX(&tab_mig_status_in_flistp, NULL);
				
				
				//Refresh the tab_get_mig_status_config_cache_ptr
				refresh_flistp = PIN_FLIST_CREATE(ebufp);
	
				PIN_FLIST_ELEM_SET(refresh_flistp,tab_mig_status_out_flistp,PIN_FLD_RESULTS,0,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"refresh_flistp flist", refresh_flistp);
				cm_cache_update_entry (tab_get_mig_status_config_cache_ptr, 
					(void *)&cache_key,
					refresh_flistp,
					&err);

				r_flistp = NULL;
				res_flistp = NULL;

				r_flistp = cm_cache_find_entry (tab_get_mig_status_config_cache_ptr,
					(void *)&cache_key, &err);

				res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
			}	
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"r_flistp flist 2", r_flistp);
			if ( res_flistp != (pin_flist_t *)NULL ){
				while ((flistp = PIN_FLIST_ELEM_GET_NEXT(res_flistp,
					PIN_FLD_VALUE_RANGES, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL) 
				{
					pre_msisdn = PIN_FLIST_FLD_GET( flistp, PIN_FLD_RANGE_START, 1, ebufp);
					if (strncmp(pre_msisdn, msidn, strlen(pre_msisdn)) == 0)
					{
						is_found_flag = 1;
						break;
					}
				}
			}
		}
		if(is_found_flag == 1)
		{
			if ( srvc_status != NULL)
			{
				if (( *srvc_status == PIN_STATUS_CLOSED ))
				{
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);
					status = PIN_BOOLEAN_TRUE;
					PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS_MSG, "Success", ebufp);
					is_portout_flag = fm_tab_get_port_out_flag(ctxp,service_out_flistp, &port_search_flistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						goto cleanup;
					}

					/*Pre to post conversion
					*returning the migration status as 0 in case of Prepaid to postpaid conversion (PortOutFlag =2 )
					*/
					if(is_portout_flag == 2){
						status = PIN_BOOLEAN_FALSE;
						set_date_flag = PIN_BOOLEAN_TRUE;
						set_status = PIN_BOOLEAN_TRUE;
					}
					else if (is_portout_flag == 1){
						status = PIN_BOOLEAN_TRUE;
						set_date_flag = PIN_BOOLEAN_TRUE;
						set_status = PIN_BOOLEAN_TRUE;
					}
					else{
						status = PIN_BOOLEAN_TRUE;
						PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
						set_date_flag = PIN_BOOLEAN_TRUE;
					}
				}
				else{
						set_date_flag = PIN_BOOLEAN_TRUE;
						status = PIN_BOOLEAN_TRUE;
						PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
																					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"checking  1flist", read_service_in_flistp);
						
				}
				
				
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"checking  2flist", read_service_in_flistp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);
				PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
				PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS_MSG, "Success", ebufp);



			}
		}
		else
		{

			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);
			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS_MSG, "Success", ebufp);

		}
	}


	/* Performing read_fld to get the effective_t of the service */

	if ( set_date_flag )
	{

		set_date_flag = PIN_BOOLEAN_TRUE;

		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);

		if (set_status)
		{
			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
		}
		else 
		{
			srvc_status = (int32 *)PIN_FLIST_FLD_GET(service_out_flistp, PIN_FLD_STATUS, 1, ebufp);
		}

		if (*srvc_status == PIN_STATUS_ACTIVE)
		{

			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_SERVICE_STATUS, "active", ebufp);
		}
		else if (*srvc_status == PIN_STATUS_INACTIVE)
		{

			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_SERVICE_STATUS, "inactive", ebufp);
		}
		else 
		{

			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_SERVICE_STATUS, "closed", ebufp);
		}

		PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS_MSG, "Success", ebufp);
		
		effective_t = PIN_FLIST_FLD_GET( service_out_flistp, PIN_FLD_CREATED_T, 1, ebufp);
		aac_vendor =  PIN_FLIST_FLD_GET( service_out_flistp, PIN_FLD_AAC_VENDOR, 1, ebufp);
		migration_t = PIN_FLIST_FLD_GET( flistp, PIN_FLD_DATE, 1, ebufp);

		if ( (strlen((char *)aac_vendor) > 0 ) )
		{
			migration_t_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,migration_t, ebufp);
			PIN_FLIST_FLD_PUT(ret_flistp, TAB_FLD_LAST_STATUS_STR, migration_t_strp, ebufp);


		
		}
		else
		{

			effective_t_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,effective_t, ebufp);
			PIN_FLIST_FLD_PUT(ret_flistp, TAB_FLD_LAST_STATUS_STR, effective_t_strp, ebufp);
			

		}
	}
	PIN_FLIST_FLD_SET(ret_flistp, TAB_FLD_REQUEST_STATUS, &ret_status, ebufp);
cleanup:
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERRBUF_CLEAR(ebufp);

		if(no_msisdn_flag){

			ret_flistp = PIN_FLIST_CREATE(ebufp);
                        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, ret_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);

            PIN_FLIST_FLD_SET(ret_flistp,TAB_FLD_REQUEST_STATUS, &ret_status, ebufp);
			PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS, &status, ebufp);
						PIN_FLIST_FLD_SET( ret_flistp, PIN_FLD_STATUS_MSG, "Success", ebufp);

			*out_flistpp = ret_flistp;
			return;
		}

		if (out_flistp == (pin_flist_t *)NULL)
		{
			ret_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, ret_flistp, PIN_FLD_POID, ebufp);
			sprintf(err_descr ,"Error while getting migration status") ;
			errorCode = TAB_ERR_CODE_API_GET_MIGRATION_STATUS;
			sprintf(err_code,"%d",errorCode);
			PIN_FLIST_FLD_SET(ret_flistp,PIN_FLD_ERROR_DESCR,&err_descr,ebufp);
			PIN_FLIST_FLD_SET(ret_flistp,PIN_FLD_ERROR_CODE,err_code,ebufp);
			PIN_FLIST_FLD_SET( flistp, TAB_FLD_REQUEST_STATUS, PIN_BOOLEAN_FALSE, ebufp);

			*out_flistpp = ret_flistp;
		}
		else
		{
			*out_flistpp = out_flistp;
			return;
		}
	}
	else
	{

		*out_flistpp = ret_flistp;
	}
	PIN_FLIST_DESTROY_EX(&out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&srch_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&port_search_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_mig_get_status return flist", *out_flistpp);

	return;
}

void
fm_tab_mig_get_status_val_mand_flds(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*flistp = NULL;
	void			*vp = NULL;
	poid_t			*err_pdp = NULL;
	int64			database = 1;
	char			err_code[255] = { '\0' };
	char			err_descr[255] = { '\0' };
	int32			errorCode = 0;
	pin_errbuf_t		err_buf;

	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERR_CLEAR_ERR(ebufp);

	PIN_ERR_CLEAR_ERR(&err_buf);

	vp =  PIN_FLIST_FLD_GET( in_flistp, PIN_FLD_MSISDN, 0, ebufp);

	if(vp == NULL )
	{
		errorCode = TAB_ERR_CODE_MSISDN_MISSING;
		sprintf(err_code,"%d",errorCode);
		sprintf(err_descr ,"Subscriber MSISDN is Missing in request") ;
		goto cleanup;
	}

	if( (strlen(vp) == 0 ))
	{
		pin_set_err(ebufp, PIN_ERRLOC_APP,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_NULL_PTR, PIN_FLD_POID, 0, 0);

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"is_valid_msisdn error not a valid msisdn",ebufp);

		errorCode = TAB_ERR_CODE_INVALID_INPUT_MSISDN;
		sprintf(err_code,"%d",errorCode);
		sprintf(err_descr ,"Subscriber MSISDN is not associated with input resource sharing group") ;
		goto cleanup;
	}

cleanup:
	flistp = PIN_FLIST_CREATE(&err_buf);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		err_pdp = PIN_POID_CREATE(database, "/error", (int64)-1, &err_buf);
		PIN_FLIST_FLD_PUT(flistp, PIN_FLD_POID, (void *)err_pdp, &err_buf);
		PIN_FLIST_FLD_SET(flistp,PIN_FLD_ERROR_CODE,err_code,&err_buf);
		PIN_FLIST_FLD_SET(flistp,PIN_FLD_ERROR_DESCR,&err_descr,&err_buf);
		PIN_FLIST_FLD_SET( flistp, TAB_FLD_REQUEST_STATUS, PIN_BOOLEAN_FALSE, &err_buf);
	}

	*out_flistpp = flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_mig_get_status_val_mand_flds return flist", *out_flistpp);

	return;
}

int
fm_tab_get_port_out_flag(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*s_flistp = NULL;
	pin_flist_t		*arg1_flistp = NULL;
	pin_flist_t		*arg2_flistp = NULL;
	pin_flist_t		*arg3_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*sub_pref_flistp = NULL;
	pin_flist_t		*flistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	int32			count = 0;
	int32			s_flags = 0;
	poid_t			*s_pdp = NULL;
	poid_t			*prof_pdp = NULL;
	int32			port_flag = PIN_BOOLEAN_FALSE;
	int64			database = 1;
	int32			res_elemid = 0;
	pin_cookie_t		res_cookie = NULL;
	char			*value = NULL;
	char			*name = NULL;
	poid_t			*act_pdp = NULL;
	char			template[1024] = "select X from /profile/subscriber_preferences where F1 = V1 and F2.type = V2 and F3 = V3";

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_get_port_out_flag", ebufp);
		goto cleanup;
	}

	act_pdp = PIN_FLIST_FLD_GET( in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	database= PIN_POID_GET_DB(act_pdp);

	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID , (void *)s_pdp   , ebufp);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, ebufp);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, template, ebufp);

	arg1_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, arg1_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	arg2_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 2, ebufp);
	prof_pdp = PIN_POID_CREATE(database, "/profile/subscriber_preferences", -1, ebufp);

	PIN_FLIST_FLD_PUT(arg2_flistp, PIN_FLD_POID , (void *)prof_pdp   , ebufp);
	arg3_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 3, ebufp);
	sub_pref_flistp = PIN_FLIST_ELEM_ADD(arg3_flistp, PIN_FLD_SUBSCRIBER_PREFERENCES, 0, ebufp);
	PIN_FLIST_FLD_SET(sub_pref_flistp, PIN_FLD_NAME, "PortOutFlag", ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	/***********************************************************
	 * 	 * call search opcode
	 ************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_get_port_out_flag : Search input flist", s_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &ret_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "Error loading Config Object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_get_port_out_flag : Search output flist ", ret_flistp);
	count = PIN_FLIST_ELEM_COUNT(ret_flistp, PIN_FLD_RESULTS, ebufp);
	if (count == 0) 
	{
		goto cleanup;

	} else 
	{
		result_flistp = PIN_FLIST_ELEM_GET(ret_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
		while ((flistp = PIN_FLIST_ELEM_GET_NEXT(result_flistp,
			PIN_FLD_SUBSCRIBER_PREFERENCES, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL) 
		{
			name = PIN_FLIST_FLD_GET( flistp, PIN_FLD_NAME, 1, ebufp);

			if ( strcmp(name,"PortOutFlag") == 0 )
			{
				value = PIN_FLIST_FLD_GET( flistp, PIN_FLD_VALUE, 1, ebufp);

				if ( strcmp(value,"1") == 0 )
				{
					port_flag = 1;
					break;
				}else if( strcmp(value,"2") == 0 )
				{
					port_flag = 2;
					break;
				}
			}
		}
	}
cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);

	return port_flag;
}



void
fm_tab_mig_multi_search
 (
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	
	pin_flist_t		*srch_out_flistp = NULL;
	pin_flist_t		*srch_in_flistp = NULL;
	pin_flist_t		*srch_args1_flistp;
	pin_flist_t		*srch_args2_flistp = NULL;
	pin_flist_t		*srch_args3_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	poid_t			*serv_pdp = NULL;
	int32			srch_flag = 512;
	int64			database = 1;
	char			*input_msisdn = NULL;
	char			tempNum[1024] = "";
	char			template[1024] = "select X from /uniqueness where (F1 = V1 or F2 like V2) order by F3 desc";
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "Error fm_tab_mig_multi_search", ebufp);
		goto cleanup;
	}
	/*
		0 PIN_FLD_POID POID [0] 0.0.0.1 /search -1 0
		0 PIN_FLD_FLAGS INT [0] 0
		0 PIN_FLD_TEMPLATE STR [0] "select X from /uniqueness where (F1 = V1 or F2 like V2) order by F3 desc"
		0 PIN_FLD_RESULTS ARRAY [*]
		1     PIN_FLD_SERVICE_OBJ         POID [0]
		1     PIN_FLD_ACCOUNT_OBJ    POID [0] 
		0 PIN_FLD_ARGS ARRAY [1] allocated 20, used 1
		1    PIN_FLD_LOGIN            STR [0] "6682413080"
		0 PIN_FLD_ARGS ARRAY [2] allocated 20, used 1
		1     PIN_FLD_LOGIN            STR [0] "DTAC0808001
		0 PIN_FLD_ARGS ARRAY [3] allocated 20, used 1
		1     PIN_FLD_EFFECTIVE_T  TSTAMP [0] (0)
	*/
	
	srch_in_flistp = PIN_FLIST_CREATE(ebufp);

	serv_pdp = PIN_POID_CREATE(database, "/search", (int64)-1, ebufp);
	
	PIN_FLIST_FLD_PUT(srch_in_flistp, PIN_FLD_POID, (void *)serv_pdp, ebufp);
	
	PIN_FLIST_FLD_SET(srch_in_flistp, PIN_FLD_FLAGS, &srch_flag, ebufp);
	
	PIN_FLIST_FLD_SET(srch_in_flistp, PIN_FLD_TEMPLATE, template, ebufp);
	
	srch_args1_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, srch_args1_flistp, PIN_FLD_LOGIN, ebufp);
	
	srch_args2_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	input_msisdn=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1, ebufp);
	strcpy(tempNum,input_msisdn);
	strcat(tempNum,"_%");
	PIN_FLIST_FLD_SET(srch_args2_flistp, PIN_FLD_LOGIN, tempNum, ebufp);
	
	srch_args3_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(srch_args3_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	
	srch_res_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_SERVICE_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_LOGIN, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_mig_multi_search search input flist", srch_in_flistp);
					
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, srch_in_flistp, &srch_out_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_mig_multi_search: search_output flist", srch_out_flistp);

cleanup:

	PIN_FLIST_DESTROY_EX(&srch_in_flistp, NULL);
		
	*out_flistpp = srch_out_flistp;
	return;
}


void
fm_tab_mig_prim_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*srch_out_flistp = NULL;
	pin_flist_t		*srch_in_flistp = NULL;
	pin_flist_t		*srch_args1_flistp;
	pin_flist_t		*srch_args2_flistp = NULL;
	pin_flist_t		*srch_args3_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*alias1_flistp = NULL;
	pin_flist_t		*alias2_flistp = NULL;
	pin_flist_t		*alias1_res_flistp = NULL;
	poid_t			*serv_pdp = NULL;
	int32			srch_flag = 512;
	int64			database = 1;
	char			*input_msisdn = NULL;
	char			tempNum[1024] = "";
	char			template[1024] = "select X from /service where (F1 = V1 or F2 like V2) order by F3 desc";
	
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "Error fm_tab_mig_prim_search ", ebufp);
		goto cleanup;
	}
	srch_in_flistp = PIN_FLIST_CREATE(ebufp);

	serv_pdp = PIN_POID_CREATE(database, "/search", (int64)-1, ebufp);
	
	PIN_FLIST_FLD_PUT(srch_in_flistp, PIN_FLD_POID, (void *)serv_pdp, ebufp);
	
	PIN_FLIST_FLD_SET(srch_in_flistp, PIN_FLD_FLAGS, &srch_flag, ebufp);
	
	PIN_FLIST_FLD_SET(srch_in_flistp, PIN_FLD_TEMPLATE, template, ebufp);
	
	srch_args1_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	alias1_flistp=PIN_FLIST_ELEM_ADD(srch_args1_flistp, PIN_FLD_ALIAS_LIST, 0, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, alias1_flistp, PIN_FLD_NAME, ebufp);
	
	srch_args2_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	alias2_flistp=PIN_FLIST_ELEM_ADD(srch_args2_flistp, PIN_FLD_ALIAS_LIST, 0, ebufp);
	input_msisdn=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1, ebufp);
	//srch_msisdn=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1, ebufp);
	strcpy(tempNum,input_msisdn);
	strcat(tempNum,"_%");
		PIN_FLIST_FLD_SET(alias2_flistp, PIN_FLD_NAME, tempNum, ebufp);


	srch_args3_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(srch_args3_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	

	srch_res_flistp=PIN_FLIST_ELEM_ADD(srch_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	alias1_res_flistp=PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_ALIAS_LIST, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_LIFECYCLE_STATE, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_CREATED_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_AAC_VENDOR, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_mig_prim_search :Search input flist", srch_in_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, srch_in_flistp, &srch_out_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_mig_prim_search :Search outtput flist", srch_out_flistp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "Error fm_tab_mig_prim_search ", ebufp);
		goto cleanup;
	}
	
cleanup:

	PIN_FLIST_DESTROY_EX(&srch_in_flistp, NULL);
		
	*out_flistpp = srch_out_flistp;
	return;
}
