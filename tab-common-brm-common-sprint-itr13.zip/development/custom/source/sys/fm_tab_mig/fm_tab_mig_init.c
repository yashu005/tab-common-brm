/*******************************************************************************
 *
 * Copyright (c) 2000, 2016, Oracle and/or its affiliates. All rights reserved.
 *
 *      This material is the confidential property of Oracle Corporation
 *      or its licensors and may be used, reproduced, stored or transmitted
 *      only in accordance with a valid Oracle license or sublicense agreement.
 *
 ********************************************************************************/



/********************************************************************************
 * This file contains the fm_tab_mig_init() function which is called
 * during CM initialization.  This function caches the 
 * /tab_migration_status object poids in a cm_cache for later
 * (faster) retrieval
 ********************************************************************************/

#include <stdio.h> 
#include <string.h> 
#include <stdlib.h>

 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_cust.h"
#include "cm_cache.h"


#define FILE_SOURCE_ID          "fm_tab_mig_init.c"

/***********************************************************************
 *Forward declaration
 ***********************************************************************/
 
EXPORT_OP void fm_tab_mig_init(int32 *errp);

PIN_EXPORT cm_cache_t *tab_get_mig_status_config_cache_ptr = (cm_cache_t *)0;

		   
void fm_tab_mig_init(int32 *errp)
{
	pcm_context_t   	*ctxp = NULL;
	pin_errbuf_t    	ebuf;
	int64			database;
	poid_t			*pdp = NULL;
	poid_t			*s_pdp = NULL;
	char 			s_template[BUFSIZ];
	int32			err = 0;
	pin_flist_t		*s_flistp = NULL;
	pin_flist_t		*arg_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*value_flistp = NULL;
	int32			s_flags = SRCH_DISTINCT;
	cm_cache_key_iddbstr_t	cache_key;
	int32			nconfig;


	/***********************************************************
	 * open the context and get the database number.
	 ***********************************************************/
	PIN_ERR_CLEAR_ERR(&ebuf);
	PCM_CONTEXT_OPEN(&ctxp, (pin_flist_t *)0, &ebuf);
	if(PIN_ERR_IS_ERR(&ebuf)) {
		pin_set_err(&ebuf, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_DM_CONNECT_FAILED, 0, 0, ebuf.pin_err);
		PIN_FLIST_LOG_ERR("fm_tab_mig_init pcm_context_open err", &ebuf);
		if (errp) {
			*errp = PIN_ERR_DM_CONNECT_FAILED;
		}
		return;
	}

	pdp = PCM_GET_USERID(ctxp);
	database = PIN_POID_GET_DB(pdp);
	PIN_POID_DESTROY(pdp, NULL);

	/***********************************************************
	 * Get all /config/tab_migration_status objects
	 ***********************************************************/

	s_flistp = PIN_FLIST_CREATE(&ebuf);

	s_pdp = PIN_POID_CREATE(database, "/search", -1, &ebuf);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, &ebuf);

	/* setup arguments */ 
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, &ebuf);

	s_pdp = PIN_POID_CREATE(database, "/config/tab_migration_status", -1, &ebuf);
	PIN_FLIST_FLD_PUT(arg_flistp, PIN_FLD_POID, (void *)s_pdp, &ebuf);

	sprintf(s_template, "select X from /config "
			"where F1.type = V1 ");
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, &ebuf);

	res_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_RESULTS, 
			PCM_RECID_ALL, &ebuf);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_mig_init search flist", s_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &r_flistp, &ebuf);

	if (PIN_ERR_IS_ERR(&ebuf)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_mig_init: error loading "
			"/migration_status object", &ebuf);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_mig_init: Return migration_status ", r_flistp);

	/* Housekeeping..  Free un-needed memory allocated so far */
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);


	value_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 0, 1, &ebuf);
	if ( value_flistp != NULL)
	{
		nconfig = PIN_FLIST_ELEM_COUNT( value_flistp, PIN_FLD_VALUE_RANGES, &ebuf );
	}

	if (nconfig == 0) {
		tab_get_mig_status_config_cache_ptr = NULL;
		goto cleanup;

	} else {
		/*
		 * This cache doesn't need configuration because its size
		 * is computed
		 */
		tab_get_mig_status_config_cache_ptr =
			cm_cache_init("tab_get_mig_status_cache",
					nconfig,
					nconfig * 3056 ,
					10, CM_CACHE_KEY_POID, &err);

		if (err != PIN_ERR_NONE) {
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_mig_init: error initing cm_cache", &ebuf);
			goto cleanup;
		}
	}

	cache_key.db = 0;
	cache_key.id = 1;
	cache_key.str = "/config/tab_migration_status";
	
	cm_cache_add_entry (tab_get_mig_status_config_cache_ptr, 
		(void *)&cache_key, r_flistp, &err);
	switch (err) {
		case PIN_ERR_NONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_DEBUG
					,
					"Added fm_tab_mig_init  cache entry: "
					"cache key [%" I64_PRINTF_PATTERN "d.%" 
					I64_PRINTF_PATTERN "d] : ",
					cache_key.db, cache_key.id);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"cache value :", r_flistp);
			break;
		case PIN_ERR_OP_ALREADY_DONE:
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_WARNING
					,
					"add fm_tab_mig_init  cache entry already done: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN 
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
		default:
			pin_set_err(&ebuf, PIN_ERRLOC_FM,
					PIN_ERRCLASS_SYSTEM_DETERMINATE,
					PIN_ERR_NO_MEM, 0, 0, err);
			pinlog(FILE_SOURCE_ID, __LINE__, LOG_FLAG_ERROR,
					"bad fm_tab_mig_init  cache add entry: "
					"err [%d] ; cache key [%" I64_PRINTF_PATTERN 
					"d.%" I64_PRINTF_PATTERN "d]",err,
					cache_key.db, cache_key.id);
			break;
	}

	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	PCM_CONTEXT_CLOSE(ctxp, 0, &ebuf);
	*errp = ebuf.pin_err;
	return;
cleanup: 
	PIN_FLIST_DESTROY_EX (&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	tab_get_mig_status_config_cache_ptr = NULL;
	PCM_CONTEXT_CLOSE(ctxp, 0, &ebuf);
	*errp = ebuf.pin_err;
	return;
}