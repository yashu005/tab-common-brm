/*******************************************************************************
*
*	This material is the confidential property of Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date       | Programmer  | Req/bug/Gap   			| Change details
*
* 1  | 22/04/2022 | Alok     |					        | Opcode TAB_OP_CUST_POL_GET_POLICY_LABEL 
*                                                              introduced.
*																 
**************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_POL_GET_POLICY_LABEL operation. 
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_cust_pol_get_policy_label(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_pol_get_policy_label(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
	
extern pin_flist_t	*cfg_tab_policy_label_map_flistp;

/**********************************************************************************
 * The policy opcode TAB_OP_CUST_POL_GET_POLICY_LABEL 
 * copies the input flist to output flist
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp the input flist 
 * @param ret_flistpp the output flist 
 * @param ebufp The error buffer.
 * @return nothing.
 ***********************************************************************************/   
void
op_tab_cust_pol_get_policy_label(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_policy_label: function entry error", ebufp);
		return;
	}

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_CUST_POL_GET_POLICY_LABEL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_policy_label: opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_get_policy_label: input flist", in_flistp);

	/***********************************************************
	 * Prep the return flist.
	 ***********************************************************/
	fm_tab_cust_pol_get_policy_label(ctxp, flags, in_flistp, ret_flistpp, ebufp);

	/***********************************************************
	 * Results.
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_policy_label: error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_get_policy_label: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
 * fm_tab_cust_pol_get_policy_label() 
 * copies input flist to output flist
 * @param ctxp The context pointer.
 * @param flags The opcode flags.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The output flist .
 * @param ebufp The error buffer.
 * @return nothing.
 *
**********************************************************************/
static void
fm_tab_cust_pol_get_policy_label(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	int32			bundle_elemid = 0;
	int32			products_elemid = 0;
	int32			pkg_elemid = 0;
	int32			policy_label_elemid = 0;
	pin_cookie_t		policy_label_cookie = NULL;
	pin_cookie_t		pkg_cookie = NULL;
	pin_cookie_t		bundle_cookie = NULL;
	pin_cookie_t		products_cookie = NULL;
	pin_flist_t		*package_flistp = NULL;
	pin_flist_t		*bundleinfo_flistp = NULL;
	pin_flist_t		*products_flistp = NULL;
	pin_flist_t		*prod_offerings_flistp = NULL;
	pin_flist_t		*policy_label_flistp = NULL;
	char			*product_name_labelp = NULL;
	char			*in_prod_name = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_pol_get_policy_label: function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_pol_get_policy_label "
		"cfg_tab_policy_label_map_flistp", cfg_tab_policy_label_map_flistp);
	prod_offerings_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	
	while ((package_flistp = PIN_FLIST_ELEM_GET_NEXT(prod_offerings_flistp, PIN_FLD_PACKAGE_INFO, 
					&pkg_elemid, 1, &pkg_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		bundle_elemid = 0;
		bundle_cookie = NULL;
		while ((bundleinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(package_flistp, PIN_FLD_BUNDLE_INFO, 
					&bundle_elemid, 1, &bundle_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			products_elemid = 0;
			products_cookie = NULL;
			while ((products_flistp = PIN_FLIST_ELEM_GET_NEXT(bundleinfo_flistp, PIN_FLD_PRODUCTS, 
					&products_elemid, 1, &products_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				if(products_flistp != NULL)
				{
					in_prod_name = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_NAME, 1, ebufp);	
					if(cfg_tab_policy_label_map_flistp != NULL)
					{
						policy_label_elemid = 0;
						policy_label_cookie = NULL;
						while ((policy_label_flistp = PIN_FLIST_ELEM_GET_NEXT(
							cfg_tab_policy_label_map_flistp, PIN_FLD_DATA_ARRAY, 
							&policy_label_elemid, 1, &policy_label_cookie, 
							ebufp)) != (pin_flist_t *)NULL)
						{
							product_name_labelp = PIN_FLIST_FLD_GET(policy_label_flistp, PIN_FLD_NAME, 1, ebufp);					
							if (in_prod_name && product_name_labelp && strcmp(in_prod_name, product_name_labelp)== 0)
							{
								PIN_FLIST_FLD_COPY(policy_label_flistp, PIN_FLD_LABEL, products_flistp, PIN_FLD_LABEL, ebufp);
							}
						}
					}
				}
			}
		}
	}
	*ret_flistpp = prod_offerings_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_pol_get_policy_label: return flist", *ret_flistpp);

	return;
}
