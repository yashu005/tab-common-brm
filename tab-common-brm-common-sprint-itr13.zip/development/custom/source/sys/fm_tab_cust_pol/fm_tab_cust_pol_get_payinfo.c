/*******************************************************************************
*
*	This material is the confidential property of Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date       | Programmer  | Req/bug/Gap   			| Change details
*
* 1  | 03/01/2022 | Darshan     |					        | Opcode TAB_OP_CUST_POL_GET_PAYINFO 
*                                                              introduced.
*																 
**************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_POL_GET_PAYINFO operation. 
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_cust_pol_get_payinfo(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_pol_get_payinfo(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

/**********************************************************************************
 * The policy opcode TAB_OP_CUST_POL_GET_PAYINFO 
 * copies the input flist to output flist
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp the input flist 
 * @param ret_flistpp the output flist 
 * @param ebufp The error buffer.
 * @return nothing.
 ***********************************************************************************/   
void
op_tab_cust_pol_get_payinfo(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_payinfo: function entry error", ebufp);
		return;
	}

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_CUST_POL_GET_PAYINFO)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_payinfo: opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_get_payinfo: input flist", in_flistp);

	/***********************************************************
	 * Prep the return flist.
	 ***********************************************************/
	fm_tab_cust_pol_get_payinfo(ctxp, flags, in_flistp, ret_flistpp, ebufp);

	/***********************************************************
	 * Results.
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_get_payinfo: error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_get_payinfo: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
 * fm_tab_cust_pol_get_payinfo() 
 * copies input flist to output flist
 * @param ctxp The context pointer.
 * @param flags The opcode flags.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The output flist .
 * @param ebufp The error buffer.
 * @return nothing.
 *
**********************************************************************/
static void
fm_tab_cust_pol_get_payinfo(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_pol_get_payinfo: function entry error", ebufp);
		return;
	}

	*ret_flistpp = PIN_FLIST_COPY(in_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_pol_get_payinfo: return flist", *ret_flistpp);

	return;
}
