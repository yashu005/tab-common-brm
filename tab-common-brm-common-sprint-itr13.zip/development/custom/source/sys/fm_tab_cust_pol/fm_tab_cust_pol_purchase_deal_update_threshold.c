/*******************************************************************************
*
*	This material is the confidential property of Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date		  | Programmer	| Req/bug/Gap				| Change details
*
* 1  | 07/12/2021 	  | Darshan	|					| Opcode TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD 
*										   introduced.
*																 
**************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD operation. 
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "ops/bill.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_cust_pol_purchase_deal_update_threshold(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_pol_purchase_deal_update_threshold(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

extern pin_flist_t *cfg_tab_package_descr_flistp;

/**********************************************************************************
 * The policy opcode TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD 
 * copies the input flist to output flist
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp the input flist 
 * @param ret_flistpp the output flist 
 * @param ebufp The error buffer.
 * @return nothing.
 ***********************************************************************************/	
void
op_tab_cust_pol_purchase_deal_update_threshold(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_purchase_deal_update_threshold: function entry error", ebufp);
		return;
	}

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_purchase_deal_update_threshold: opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_purchase_deal_update_threshold: input flist", in_flistp);

	/***********************************************************
	 * Prep the return flist.
	 ***********************************************************/
	fm_tab_cust_pol_purchase_deal_update_threshold(ctxp, flags, in_flistp, ret_flistpp, ebufp);

	/***********************************************************
	 * Results.
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_pol_purchase_deal_update_threshold: error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_pol_purchase_deal_update_threshold: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
 * fm_tab_cust_pol_purchase_deal_update_threshold() 
 * copies input flist to output flist
 * @param ctxp The context pointer.
 * @param flags The opcode flags.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The output flist .
 * @param ebufp The error buffer.
 * @return nothing.
 *
**********************************************************************/
static void
fm_tab_cust_pol_purchase_deal_update_threshold(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	int32			data_array_elemid = 0;
	pin_cookie_t		data_array_cookie = NULL;
	pin_cookie_t		limit_cookie = NULL;
	int32			limit_elemid = 0;
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*limit_array_flistp = NULL;
	char			*in_package_namep = NULL;
	char			*data_array_namep = NULL;
	pin_flist_t		*limit_flistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*set_limit_cr_iflistp = NULL;
	pin_flist_t		*set_limit_cr_oflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_pol_purchase_deal_update_threshold: function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_pol_purchase_deal_update_threshold cfg_tab_package_descr_flistp", cfg_tab_package_descr_flistp);

	in_package_namep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);

	if(cfg_tab_package_descr_flistp != NULL)
	{
		while ((data_array_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_package_descr_flistp, 
			PIN_FLD_DATA_ARRAY, &data_array_elemid, 1, &data_array_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_cust_pol_purchase_deal_update_threshold: data_array_flistp", data_array_flistp);

			data_array_namep = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_NAME, 1, ebufp);

			if (in_package_namep && data_array_namep && !strncmp(in_package_namep, data_array_namep,
				strlen(in_package_namep)))
			{
				limit_elemid = 0;
				limit_cookie = NULL;
				while ((limit_array_flistp = PIN_FLIST_ELEM_GET_NEXT(data_array_flistp, 
				PIN_FLD_LIMIT, &limit_elemid, 1, &limit_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
						"fm_tab_cust_pol_purchase_deal_update_threshold: limit_array_flistp", limit_array_flistp);
					set_limit_cr_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, set_limit_cr_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, set_limit_cr_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, set_limit_cr_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, set_limit_cr_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

					limit_flistp = PIN_FLIST_ELEM_ADD(set_limit_cr_iflistp, PIN_FLD_LIMIT, limit_elemid, ebufp);
					PIN_FLIST_FLD_COPY(limit_array_flistp, PIN_FLD_CREDIT_LIMIT, limit_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
					PIN_FLIST_FLD_COPY(limit_array_flistp, PIN_FLD_CREDIT_FLOOR, limit_flistp, PIN_FLD_CREDIT_FLOOR, ebufp);
					PIN_FLIST_FLD_COPY(limit_array_flistp, PIN_FLD_CREDIT_THRESHOLDS, limit_flistp, PIN_FLD_CREDIT_THRESHOLDS, ebufp);
					context_info_flistp = PIN_FLIST_SUBSTR_ADD(set_limit_cr_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
						"fm_tab_cust_pol_purchase_deal_update_threshold: PCM_OP_BILL_SET_LIMIT_AND_CR input flist", 
						set_limit_cr_iflistp);

					PCM_OP(ctxp, PCM_OP_BILL_SET_LIMIT_AND_CR, 0, set_limit_cr_iflistp, &set_limit_cr_oflistp, ebufp);

					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_cust_pol_purchase_deal_update_threshold: PCM_OP_BILL_SET_LIMIT_AND_CR Opcode Input flist", 
							set_limit_cr_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_cust_pol_purchase_deal_update_threshold: PCM_OP_BILL_SET_LIMIT_AND_CR Opcode error", ebufp);
						goto cleanup;
					}

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
							"fm_tab_cust_pol_purchase_deal_update_threshold: PCM_OP_BILL_SET_LIMIT_AND_CR output flist", 
							set_limit_cr_oflistp);

					PIN_FLIST_DESTROY_EX(&set_limit_cr_iflistp, NULL);
					PIN_FLIST_DESTROY_EX(&set_limit_cr_oflistp, NULL);
				}
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	******************************************************************/
	*ret_flistpp = PIN_FLIST_COPY(set_limit_cr_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&set_limit_cr_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&set_limit_cr_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_pol_purchase_deal_update_threshold: return flist", *ret_flistpp);

	return;
}
