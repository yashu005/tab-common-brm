/*******************************************************************************
 *
 *      This material is the confidential property of Oracle Corporation or its
 *      licensors and may be used, reproduced, stored or transmitted only in
 *      accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 * Change History
 *
 * No | Date       | Programmer  | Req/bug/Gap                          | Change details
 *
 * 1  | 06/01/2022 | Rahul Honnaiah |                                   | Opcode TAB_OP_CUST_POL_SET_SUBSCRIBER_PREFERENCES_PREPARE_PAYLOAD introduced.
 *
 **************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_POL_SET_SUBSCRIBER_PREFERENCES_PREPARE_PAYLOAD operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_cust_pol_set_subscriber_preferences_prepare_payload(
        cm_nap_connection_t     *connp,
        int                     opcode,
        int                     flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        pin_errbuf_t            *ebufp);

static void
fm_tab_cust_pol_set_subscriber_preferences_prepare_payload(
        pcm_context_t           *ctxp,
        int32                   flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        pin_errbuf_t            *ebufp);

void
op_tab_cust_pol_set_subscriber_preferences_prepare_payload(
        cm_nap_connection_t     *connp,
        int                     opcode,
        int                     flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        pin_errbuf_t            *ebufp)
{
        pcm_context_t           *ctxp = connp->dm_ctx;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "op_tab_cust_pol_set_subscriber_preferences_prepare_payload: function entry error", ebufp);
                return;
        }

        /***********************************************************
         * Insanity check.
         ***********************************************************/
        if (opcode != TAB_OP_CUST_POL_SET_SUBSCRIBER_PREFERENCES_PREPARE_PAYLOAD)
        {
                pin_set_err(ebufp, PIN_ERRLOC_FM,
                        PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        PIN_ERR_BAD_OPCODE, 0, 0, opcode);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "op_tab_cust_pol_set_subscriber_preferences_prepare_payload: opcode error", ebufp);
                return;
        }

        /***********************************************************
         * Debug: What we got.
         ***********************************************************/
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "op_tab_cust_pol_set_subscriber_preferences_prepare_payload: input flist", in_flistp);

        /***********************************************************
         * Prep the return flist.
         ***********************************************************/
        fm_tab_cust_pol_set_subscriber_preferences_prepare_payload(ctxp, flags, in_flistp, ret_flistpp, ebufp);

        /***********************************************************
         * Results.
         ***********************************************************/
        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "op_tab_cust_pol_set_subscriber_preferences_prepare_payload: error", ebufp);
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "op_tab_cust_pol_set_subscriber_preferences_prepare_payload: output flist", *ret_flistpp);
        return;
}

static void
fm_tab_cust_pol_set_subscriber_preferences_prepare_payload(
        pcm_context_t           *ctxp,
        int32                   flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        pin_errbuf_t            *ebufp)
{

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "fm_tab_cust_pol_set_subscriber_preferences_prepare_payload: function entry error", ebufp);
                return;
        }


        *ret_flistpp = PIN_FLIST_COPY(in_flistp, ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
        "fm_tab_cust_pol_set_subscriber_preferences_prepare_payload: return flist", *ret_flistpp);

        return;
}
