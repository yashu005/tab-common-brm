/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_cust_pol_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_cust_pol_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_CUST_POL_ENRICH_CREATE_SUBSCRIBER, "op_tab_cust_pol_enrich_create_subscriber", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_CREATE_SUBSCR_VALIDATE_INPUT, "op_tab_cust_pol_create_subscr_validate_input", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL, "op_tab_cust_pol_enrich_purchase_deal", CM_FM_OP_OVERRIDABLE },
        { TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD, "op_tab_cust_pol_purchase_deal_update_threshold", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_PROFILE, "op_tab_cust_pol_get_profile", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_PAYINFO, "op_tab_cust_pol_get_payinfo", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_UPDATE_ACCOUNT_STATUS, "op_tab_cust_pol_update_account_status", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE, "op_tab_cust_pol_update_account_profile", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_VALIDATE_FNF, "op_tab_cust_pol_validate_fnf", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_GET_FNF, "op_tab_cust_pol_enrich_get_fnf", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_MARKETING_NAME, "op_tab_cust_pol_get_marketing_name", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_GET_SERVICES, "op_tab_cust_pol_enrich_get_services", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_CREATE_ACCT_VALIDATE_INPUT, "op_tab_cust_pol_create_acct_validate_input", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_CREATE_ACCOUNT, "op_tab_cust_pol_enrich_create_account", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_SET_SUBSCRIBER_PREFERENCES_PREPARE_PAYLOAD, "op_tab_cust_pol_set_subscriber_preferences_prepare_payload", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_CANCEL_BUDGET_LIMIT, "op_tab_cust_pol_cancel_budget_limit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_PRE_MODIFY_CL, "op_tab_cust_pol_pre_modify_cl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL, "op_tab_cust_pol_pre_ncr_modify_cl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_POST_MODIFY_CL, "op_tab_cust_pol_post_modify_cl", CM_FM_OP_OVERRIDABLE },	
	{ TAB_OP_CUST_POL_PRE_GET_CL, "op_tab_cust_pol_pre_get_cl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_POST_GET_CL, "op_tab_cust_pol_post_get_cl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_PRE_SET_BDGT_CTRL, "op_tab_cust_pol_pre_set_bdgt_ctrl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_EXTRACT_CL_HIST, "op_tab_cust_pol_extract_cl_hist", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_VALIDATE_UPDATE_ADDRESSES, "op_tab_cust_pol_validate_update_addresses", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_MULTI_SIM, "op_tab_cust_pol_get_multi_sim", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_MANAGE_MULTI_SIM, "op_tab_cust_pol_manage_multi_sim", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_ACCOUNT_FROM_ID, "op_tab_cust_pol_get_account_from_id", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_GET_BUNDLE, "op_tab_cust_pol_enrich_get_bundle", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_POLICY_LABEL, "op_tab_cust_pol_get_policy_label", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_WRITEOFF_STATUS, "op_tab_cust_pol_get_writeoff_status",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_UPDATE_WRITEOFF_STATUS, "op_cust_pol_update_writeoff_status" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_CANCEL_OFFER, "op_tab_cust_pol_enrich_cancel_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL, "op_tab_cust_pol_enrich_resp_modify_cl", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_MANAGE_FNF_ADD, "op_tab_cust_pol_post_manage_fnf_add", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_CREATE_SUBSCR_GET_DB_NO, "op_tab_cust_pol_create_subscr_get_db_no" ,CM_FM_OP_OVERRIDABLE },
    { TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO, "op_tab_cust_pol_create_acct_get_db_no" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_GET_NOTIFICATION_HISTORY, "op_tab_cust_pol_get_notification_history", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_PRE_PURCHASE_OFFER, "op_tab_cust_pol_pre_purchase_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_POST_CREATE_SUBSCRIBER, "op_tab_cust_pol_post_create_subscriber", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_POST_CANCEL_OFFER, "op_tab_cust_pol_post_cancel_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_VALIDATE_CUG, "op_tab_cust_pol_validate_cug", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_MOVE_GROUP_MEMBER, "op_tab_cust_pol_enrich_move_group_member", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_ENRICH_DELETE_GROUP_MEMBER, "op_tab_cust_pol_enrich_delete_group_member", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL, "op_tab_cust_pol_bal_grp_modify_cl", CM_FM_OP_OVERRIDABLE },
    { 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_cust_pol_config_func()
{
  return ((void *) (fm_tab_cust_pol_config));
}
#endif
