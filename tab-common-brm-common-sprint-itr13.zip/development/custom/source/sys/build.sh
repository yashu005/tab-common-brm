#!/bin/bash
set -e
trap 'catch $?' EXIT

catch() {
    echo
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
    echo "Verifying for Errors"

    if [ "$1" != "0" ]; then
        test -t 1 && tput bold; tput setf 4
        echo "Error $1 occurred - build aborted"
        test -t 1 && tput sgr0 # Reset terminal
    else
        echo "No errors identified"
    fi
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
}

if [ -z "$error_flag" ];then
  error_flag=0
fi

echo ""
echo "**********************************************"
echo "* building all sub folders under custom/source/sys"
echo "**********************************************"

for x in `ls -d */`; do
  if [ -f "$x/Makefile" ]; then

    cd $x

    #TODO: Having to do this because the makefile also calls clean after all, refactor makefile required?
    make clean
    error_flag=$(($error_flag|$?))
    make all
    error_flag=$(($error_flag|$?))

    cd ..

    if [ $error_flag != 0 ];then
        echo ""
        echo "Build Aborted - Last command returned $error_flag"
        echo ""
        exit $error_flag
    fi

  fi
done

