/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_ar_pol_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_ar_pol_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_AR_POL_GET_PAYMENT , "op_tab_ar_pol_get_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_PAYMENT ,	"op_tab_ar_pol_post_payment",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_PAYMENT ,	"op_tab_ar_pol_validate_payment",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT , "op_tab_ar_pol_validate_make_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT , "op_tab_ar_pol_post_make_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_CREATE_PAYTYPE , "op_tab_ar_pol_create_paytype", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL , "op_tab_ar_pol_post_make_payment_reversal", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL , "op_tab_ar_pol_validate_make_payment_reversal", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT , "op_tab_ar_pol_validate_corp_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_CORP_PAYMENT , "op_tab_ar_pol_post_corp_payment", CM_FM_OP_OVERRIDABLE },	
	{ TAB_OP_AR_POL_POST_MAKE_REFUND, "op_tab_ar_pol_post_make_refund", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_MAKE_REFUND, "op_tab_ar_pol_validate_make_refund", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_GET_REFUND, "op_tab_ar_pol_post_get_refund", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE , "op_tab_ar_pol_validate_make_dispute", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_ENRICH_RESP_RELEASE_DEPOSIT , "op_tab_ar_pol_enrich_resp_release_deposit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT , "op_tab_ar_pol_enrich_resp_make_deposit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT , "op_tab_ar_pol_enrich_resp_make_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_ENRICH_RES_MAKE_PAYMENT_REV , "op_tab_ar_pol_enrich_resp_make_payment_rev", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_ENRICH_RESP_MAKE_ADJUSTMENT , "op_tab_ar_pol_enrich_resp_make_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_MAKE_DISPUTE , "op_tab_ar_pol_post_make_dispute", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_POL_POST_MAKE_SETTLEMENT , "op_tab_ar_pol_post_make_settlement", CM_FM_OP_OVERRIDABLE },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_ar_pol_config_func()
{
  return ((void *) (fm_tab_ar_pol_config));
}
#endif
