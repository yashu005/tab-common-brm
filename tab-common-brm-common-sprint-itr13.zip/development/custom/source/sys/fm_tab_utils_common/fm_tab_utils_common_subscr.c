/*********************************************************************
 * * This Utility finds wheather the given acct_no is there
 * * in the DB or not.
 * * It will take acct_no as an input argument and it will give
 * * the result in PIN_FLD_POID field.
 *********************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_subscr.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <pin_subscription.h>
#include "pin_cust.h"
#include "pin_bal.h"
#include "ops/cust.h"
#include "ops/ece.h"
#include "pbo_decimal.h"
#include "tab_utils_common.h"
#include "tab_ops_flds.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_subscr.c(2)"

/*************************************************
 *	*  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_subscr_get_discount_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_subscr_get_chargeshare_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_subscr_get_group_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_subscr_get_all_groups(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void fm_tab_utils_common_subscr_get_ordered_bg_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void fm_tab_utils_common_subscr_get_current_main_balance(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void fm_tab_utils_common_subscr_get_balances_array(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/*******************************************************************
 *  fm_tab_utils_common_subscr_get_discount_offer()
 *  
 *  This function will be used to retrieve the purchased discount
 *  details based on input discount name and account poid
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param db_no Database number.
 *  @param ebufp The error buffer.
 *  @return flistp.
 *  
 *********************************************************************/

void
fm_tab_utils_common_subscr_get_discount_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	int32			status = PIN_DISCOUNT_STATUS_ACTIVE;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_discount_offer input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /purchased_discount 1, /discount 2 where  1.F1 = 2.F2 and 1.F3 = V3 and 2.F4 = V4 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_DISCOUNT_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_FLAGS, &status, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_DISCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_discount_offer input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_discount_offer output flist", r_flistp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_subscr_get_discount_offer input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_discount_offer: Error in getting group object", ebufp);
	}
	else
	{
		*r_flistpp = r_flistp;
	}

	return;
}

/*******************************************************************
 *  fm_tab_utils_common_subscr_get_chargeshare_offer()
 * 
 *  This function will be used to retrieve sponsorship object
 *  based on chargeshare offer name
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param db_no Database number.
 *  @param ebufp The error buffer.
 *  @return flistp.
 * 
 **********************************************************************/

void
fm_tab_utils_common_subscr_get_chargeshare_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_chargeshare_offer input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /sponsorship  where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_chargeshare_offer input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_chargeshare_offer output flist", r_flistp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_subscr_get_chargeshare_offer input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_chargeshare_offer: Error in getting sponsorship object", ebufp);
	}
	else
	{
		*r_flistpp = r_flistp;
	}

	return;
}

/*******************************************************************
 *   fm_tab_utils_common_subscr_get_group_details()
 *  
 *   This function will be used to retrieve group sharing objects
 *   based on group name and account poid
 *   
 *   @param ctxp The context pointer.
 *   @param i_flistp input flist.
 *   @param r_flistpp The return flist.
 *   @param db_no Database number.
 *   @param ebufp The error buffer.
 *   @return flistp.
 *   
 ***********************************************************************/

void
fm_tab_utils_common_subscr_get_group_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_group_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_group_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_group_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /group/sharing where  F1 = V1 and F2 = V2 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_group_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_subscr_get_group_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_group_details: Error in getting resource sharing object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_subscr_get_group_details output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/*******************************************************************
 *  fm_tab_utils_common_subscr_get_ordered_bg_details()
 * 
 *  This function will be used to retrieve ordered balance group
 *  based on service poid.
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param db_no Database number.
 *  @param ebufp The error buffer.
 *  @return flistp.
 *  
 ************************************************************************/


void fm_tab_utils_common_subscr_get_ordered_bg_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchpp	= NULL;
	int32			s_flags	= 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_ordered_bg_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_ordered_bg_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_ordered_bg_details input", i_flistp);

	srchpp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchpp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /ordered_balgrp where F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_SERVICE_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_ordered_bg_details search input flist: ", search_flistp);

	/***********************************************************
	 *	* Perform the search.
	 *		***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_subscr_get_ordered_bg_details search output flist: ", r_flistp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_ordered_bg_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_ordered_bg_details: no service associated with the ordered_balgrp", ebufp);
	}
	else
	{
		*out_flistp = r_flistp;
	}

	return;
}

/*******************************************************************
 *  fm_tab_utils_common_subscr_get_all_groups()
 *  
 *  This function will be used to retrieve all the group names
 *  associated with the account.
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param db_no Database number.
 *  @param ebufp The error buffer.
 *  @return flistp.
 *  
 *************************************************************************/

void
fm_tab_utils_common_subscr_get_all_groups(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_all_groups error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_all_groups:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_all_groups input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /group where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_all_groups input flist", search_flistp);

	/***********************************************************
	 *			* Perform the search.
	 *					 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_all_groups input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_all_groups: Error in getting resource sharing objects", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_subscr_get_all_groups output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}


/*******************************************************************
 *  fm_tab_utils_common_get_service_from_msisdn()
 *  
 *  This function will be used to get service information
 *  from the MSISDN
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param db_no Database number.
 *  @param ebufp The error buffer.
 *  
 *************************************************************************/

void
fm_tab_utils_common_get_service_from_msisdn(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	poid_t			*srch_pdp = NULL;
	int32			s_flags = 0;
	pin_flist_t		*result_flistp = NULL;
	void			*template_str = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32                   count = 0;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_service_from_msisdn error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_service_from_msisdn:"
			" input flist", in_flistp);
		return;
	}
	
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /service where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_ALIAS_LIST, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, args_flistp, PIN_FLD_NAME, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_get_service_from_msisdn:"
		"search input flist", search_in_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_get_service_from_msisdn: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_service_from_msisdn:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_get_service_from_msisdn:"
                "search output flist", search_out_flistp);
	
	count = PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp);
	if(count > 0)
	{
		result_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_get_service_from_msisdn:"
			"search result flist", result_flistp);
		if(result_flistp)
			*out_flistpp = PIN_FLIST_ELEM_TAKE(search_out_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);

	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_get_service_from_msisdn:"
		"output flist", *out_flistpp);
cleanup:
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	return;
}

/*************************************************************************
 *  fm_tab_utils_common_update_service()
 *  
 *  This function will process the update common services
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param ebufp The error buffer.
 *  
 *************************************************************************/
void
fm_tab_utils_common_update_service(
	pcm_context_t		*ctxp,
	pin_flist_t     	*in_flistp,
	pin_flist_t       	**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t 		*updatesrvs_in_flistp = NULL;
	pin_flist_t			*updatesrvs_out_flistp = NULL;
	pin_flist_t			*services_flistp = NULL;
	poid_t				*account_pdp = NULL;

	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_service error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_service:"
			" input flist", in_flistp);
		return;
	}
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	
	/**********************************************
	*0 PIN_FLD_POID            POID [0] 0.0.0.1 /account 123 0
	*0 PIN_FLD_PROGRAM_NAME          STR [0] "981999999"
	*0 PIN_FLD_SERVICES      ARRAY [0] 
	*1 PIN_FLD_POID            POID [0] 0.0.0.1 /service 456 0
	*1 PIN_FLD_SERVICE_STATE_EXPIRATION_T TSTAMP [0] (1633075519)
	*0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
	*0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
	***********************************************/
	
	updatesrvs_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(updatesrvs_in_flistp, PIN_FLD_POID, account_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, updatesrvs_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	services_flistp =  PIN_FLIST_ELEM_ADD(updatesrvs_in_flistp, PIN_FLD_SERVICES, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, services_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, services_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LIFECYCLE_STATE, services_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	services_flistp = PIN_FLIST_SUBSTR_ADD (updatesrvs_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, services_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, services_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" PCM_OP_CUST_UPDATE_SERVICES input flist", updatesrvs_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_CUST_UPDATE_SERVICES, 0, updatesrvs_in_flistp, &updatesrvs_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_service error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_service:"
			" input flist", in_flistp);
		PIN_FLIST_DESTROY_EX(&updatesrvs_in_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&updatesrvs_out_flistp, NULL);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" PCM_OP_CUST_UPDATE_SERVICES output flist", updatesrvs_out_flistp);
		
	*out_flistpp = updatesrvs_out_flistp;
	PIN_FLIST_DESTROY_EX(&updatesrvs_in_flistp, NULL);
	return;
}

/*************************************************************************
 *  fm_tab_utils_common_subscr_bill_debit()
 *  
 *  This function will be used to process billdebit to the account
 *  associated with the account.
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param curr The Currency.
 *  @param ebufp The error buffer.
 *  
 *************************************************************************/
void
fm_tab_utils_common_subscr_bill_debit(
	pcm_context_t       *ctxp,
    pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int32				curr,
    pin_errbuf_t        *ebufp)
{
	pin_flist_t			*billdebit_in_flistp = NULL;
	pin_flist_t			*billdebit_out_flistp = NULL;
	pin_flist_t			*debit_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_bill_debit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_bill_debit:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_subscr_bill_debit:"
		" input flist", in_flistp);
	
	billdebit_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, billdebit_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, billdebit_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_REASON_CODE, billdebit_in_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FLAGS, billdebit_in_flistp, PIN_FLD_FLAGS, ebufp);
	debit_flistp =  PIN_FLIST_ELEM_ADD(billdebit_in_flistp, PIN_FLD_DEBIT, curr, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, debit_flistp, PIN_FLD_BAL_OPERAND, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_subscr_bill_debit:"
		" PCM_OP_BILL_DEBIT input flist", billdebit_in_flistp);

	PCM_OP(ctxp, PCM_OP_BILL_DEBIT , 0, billdebit_in_flistp, &billdebit_out_flistp, ebufp);
	

	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_bill_debit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_bill_debit:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_subscr_bill_debit:"
		"PCM_OP_BILL_DEBIT output flist", billdebit_out_flistp);
	
	*out_flistpp = billdebit_out_flistp;
	
	PIN_FLIST_DESTROY_EX(&billdebit_in_flistp, NULL);
	return;
}


/*************************************************************************
 *  fm_tab_utils_common_get_ece_balances()
 *  
 *  This function will be used to retrieve the ece balances of the service
 *  associated with the account.
 *  
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param ebufp The error buffer.
 *  
 *************************************************************************/

void
fm_tab_utils_common_get_ece_balances(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64		    db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*ecebalances_in_flistp = NULL;
	pin_flist_t			*ecebalances_ret_flistp = NULL;
	pin_flist_t			*contextinfo_flistp = NULL;
	int32				mode = 1;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_ece_balances error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_ece_balances:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
					"fm_tab_utils_common_get_ece_balances:"
					"input flist for ece balance function", in_flistp);
	
	ecebalances_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, ecebalances_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ecebalances_in_flistp, PIN_FLD_LOGIN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_START_T, ecebalances_in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_SET (ecebalances_in_flistp, PIN_FLD_MODE, &mode, ebufp);
	
	contextinfo_flistp = PIN_FLIST_SUBSTR_ADD (ecebalances_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, contextinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, contextinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_ece_balances:"
											"input flist for PCM_OP_BAL_GET_ECE_BALANCES", ecebalances_in_flistp);

	PCM_OP(ctxp, PCM_OP_BAL_GET_ECE_BALANCES, 0, ecebalances_in_flistp, &ecebalances_ret_flistp, ebufp);
	
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_common_get_ece_balances: output flist for PCM_OP_BAL_GET_ECE_BALANCES", in_flistp);
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
        	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_ece_balances: input flist for PCM_OP_BAL_GET_ECE_BALANCES", ecebalances_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"ecebalances_in_flistp: Error in getting ece balances object", ebufp);
		PIN_FLIST_DESTROY_EX(&ecebalances_in_flistp, NULL);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_common_get_ece_balances: output flist for PCM_OP_BAL_GET_ECE_BALANCES", ecebalances_ret_flistp);
	
	*out_flistpp = PIN_FLIST_COPY(ecebalances_ret_flistp, ebufp);
	
	cleanup:
	PIN_FLIST_DESTROY_EX(&ecebalances_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ecebalances_ret_flistp, ebufp);

	
	return;
}

void
fm_tab_utils_common_subscr_get_current_main_balance(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*read_iflistp = NULL;
	pin_flist_t		*read_oflistp = NULL;
	pin_flist_t		*sub_bal_flistp = NULL;
	pin_flist_t		*bal_flistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	pin_decimal_t		*total_bal = pbo_decimal_from_str("0.0",ebufp);
	pin_decimal_t		*curr_bal = NULL; 
	time_t			valid_to = 0;
	time_t			valid_from = 0;
	time_t			now_t = pin_virtual_time((time_t *)NULL);
	int32			bal_type = 0;
	int32			resource_id = 0;
	int32			elemid = 0;
	pin_cookie_t		cookie = NULL;
	void			*vp = NULL;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_common_subscr_get_current_main_balance: input flist ", i_flistp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_current_main_balance entry error", ebufp);
		return;
	}

	resource_id = *(int32 *)PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_RESOURCE_ID, 0, ebufp);
	read_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID ,read_iflistp, PIN_FLD_POID, ebufp);
	t_flistp = PIN_FLIST_ELEM_ADD(read_iflistp, PIN_FLD_BALANCES, resource_id, ebufp);
	PIN_FLIST_FLD_SET(read_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_current_main_balance:"
		" Read flds input flist", read_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, PCM_OPFLG_CACHEABLE, read_iflistp, &read_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" input flist ", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" Error while reading Balance flds", ebufp);
		goto cleanup;
	}

	if (read_oflistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PCM_OP_READ_FLDS, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_current_main_balance:"
			" input flist", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_current_main_balance return error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_current_main_balance:"
		" Read flds Output flist", read_oflistp);

	bal_flistp = PIN_FLIST_ELEM_GET(read_oflistp, PIN_FLD_BALANCES, resource_id, 1, ebufp);

	if (bal_flistp != NULL)
	{
		elemid = 0;
		cookie = NULL;
		while ((sub_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(bal_flistp,
			PIN_FLD_SUB_BALANCES, &elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			valid_from = *(time_t*)PIN_FLIST_FLD_GET(sub_bal_flistp,PIN_FLD_VALID_FROM,0, ebufp);
			valid_to = *(time_t*)PIN_FLIST_FLD_GET(sub_bal_flistp,PIN_FLD_VALID_TO,0, ebufp);

			if (((valid_from<=now_t ) && (valid_to>=now_t ||valid_to==0 )))
			{
				vp = NULL;
				vp = PIN_FLIST_FLD_GET(sub_bal_flistp, PIN_FLD_SUBTYPE, 1, ebufp);
				if ( vp != NULL)
				{
					bal_type = *(int32 *)vp;
				}

				if (bal_type == PIN_SUB_BAL_TYPE_DEFAULT)
				{
					curr_bal = PIN_FLIST_FLD_GET(sub_bal_flistp,PIN_FLD_CURRENT_BAL,0, ebufp);
					pbo_decimal_add_assign(total_bal, curr_bal, ebufp);
				}
			}
		}
	}

	*out_flistp = PIN_FLIST_COPY(i_flistp, ebufp);
	PIN_FLIST_FLD_SET(*out_flistp, PIN_FLD_CURRENT_BAL, total_bal, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_common_subscr_get_current_main_balance: output flist ", *out_flistp);

cleanup:
	if(total_bal)
	{
		pbo_decimal_destroy(&total_bal);
	}
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
	return;
}
/*************************************************************************
 *  fm_tab_utils_common_resume_service()
 *
 *  This function will process the update common services
 *
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param ebufp The error buffer.
 *
 *************************************************************************/
void
fm_tab_utils_common_resume_service(
		pcm_context_t           *ctxp,
		pin_flist_t             *in_flistp,
		pin_flist_t             **out_flistpp,
		int64                   db_no,
		pin_errbuf_t            *ebufp)
{
	pin_flist_t             *updatesrvs_in_flistp = NULL;
	pin_flist_t             *updatesrvs2_in_flistp = NULL;
	pin_flist_t             *updatesrvs_out_flistp = NULL;
	pin_flist_t             *services_flistp = NULL;
	pin_flist_t             *out_service_flistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service:"
			" input flist", in_flistp);
		return;
	}



	/**********************************************
	 *0 PIN_FLD_POID            POID [0] 0.0.0.1 /account 123 0
	 *0 PIN_FLD_PROGRAM_NAME          STR [0] "981999999"
	 *0 PIN_FLD_SERVICES      ARRAY [0]
	 *1 PIN_FLD_POID            POID [0] 0.0.0.1 /service 456 0
	 *1 PIN_FLD_SERVICE_STATE_EXPIRATION_T TSTAMP [0] (1633075519)
	 *0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
	 *0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
	 ***********************************************/
	updatesrvs_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, updatesrvs_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, updatesrvs_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	services_flistp =  PIN_FLIST_ELEM_ADD(updatesrvs_in_flistp, PIN_FLD_SERVICES, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, services_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, services_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LIFECYCLE_STATE, services_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	services_flistp = PIN_FLIST_SUBSTR_ADD (updatesrvs_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, services_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, services_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" TAB_OP_SUBSCRIPTION_POL_PRE_UPDATE_SERVICE input flist", updatesrvs_in_flistp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_PRE_UPDATE_SERVICE, 0, updatesrvs_in_flistp, &updatesrvs_out_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" TAB_OP_SUBSCRIPTION_POL_PRE_UPDATE_SERVICE out flist", updatesrvs_out_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service:"
			" input flist", updatesrvs_in_flistp);
		return;
	}

	updatesrvs2_in_flistp = PIN_FLIST_COPY(updatesrvs_out_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&updatesrvs_out_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" PCM_OP_CUST_UPDATE_SERVICES input flist", updatesrvs2_in_flistp);

	PCM_OP(ctxp, PCM_OP_CUST_UPDATE_SERVICES, 0, updatesrvs2_in_flistp, &out_service_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_resume_service:"
			" input flist", updatesrvs2_in_flistp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_update_service:"
		" PCM_OP_CUST_UPDATE_SERVICES out flist", out_service_flistp);

	*out_flistpp = PIN_FLIST_COPY(out_service_flistp, ebufp); 

	PIN_FLIST_DESTROY_EX(&updatesrvs_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&updatesrvs2_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&out_service_flistp, ebufp);

	return;
}
/*************************************************************************
 *  fm_tab_utils_common_subscr_get_balances_array()
 *
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param r_flistpp The return flist.
 *  @param ebufp The error buffer.
 *
 *************************************************************************/
void
fm_tab_utils_common_subscr_get_balances_array(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*read_iflistp = NULL;
	pin_flist_t		*read_oflistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	int32			resource_id = 0;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_subscr_get_balances_array: input flist ", i_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_subscr_get_balances_array entry error", ebufp);
		return;
	}

	resource_id = *(int32 *)PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_RESOURCE_ID, 0, ebufp);
	read_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID ,read_iflistp, PIN_FLD_POID, ebufp);
	t_flistp = PIN_FLIST_ELEM_ADD(read_iflistp, PIN_FLD_BALANCES, resource_id, ebufp);
	PIN_FLIST_FLD_SET(read_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_subscr_get_balances_array:"
		" Read flds input flist", read_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, PCM_OPFLG_CACHEABLE, read_iflistp, &read_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading Balance flds", ebufp);
		goto cleanup;
	}

	if (read_oflistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PCM_OP_READ_FLDS, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_balances_array:"
			" input flist", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_subscr_get_balances_array return error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_subscr_get_balances_array:"
		" Read flds Output flist", read_oflistp);


	*out_flistp = PIN_FLIST_COPY(read_oflistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_subscr_get_balances_array: output flist ", *out_flistp);

cleanup:
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
	return;
}

