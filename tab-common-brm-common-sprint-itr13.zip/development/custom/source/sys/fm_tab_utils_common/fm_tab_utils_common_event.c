/*********************************************************************
 * * This Utility finds wheather the given acct_no is there
 * * in the DB or not.
 * * It will take acct_no as an input argument and it will give
 * * the result in PIN_FLD_POID field.
 *********************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_get_event_adjustment_details.c:2022-Feb-16%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <pin_rate.h>
#include <pin_subscription.h>
#include "tab_ops_flds.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_get_event_adjustment_details.c(2)"

/*************************************************
 *	*  *Global routines contained within
 ************************************************/

void
fm_tab_utils_common_get_event_adjustment_details(
        pcm_context_t           *ctxp,
        int32                   flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);
		

void
fm_tab_utils_common_get_evt_payment_details(
        pcm_context_t           *ctxp,
        char                    *trans_id,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_get_payment_reversal_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_refund_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_utils_common_create_limit_event(
    pcm_context_t        *ctxp,
    int64            db_no,
    poid_t            *event_pdp,
    pin_flist_t        *in_flistp,
    pin_flist_t        **out_flistpp,
    pin_errbuf_t        *ebufp);
/********************************************
 * We use this function to get product
 * object using product name.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************/
void
fm_tab_utils_common_get_event_adjustment_details (
        pcm_context_t           *ctxp,
        int32                   flags,
        pin_flist_t             *in_flistp,
        pin_flist_t             **ret_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp)
{
	pin_flist_t             *transid_srch_iflistp = NULL;
        pin_flist_t             *trans_id_srch_rflistp = NULL;
        pin_flist_t             *args_flistp = NULL;
        pin_flist_t             *bal_impacts_iflistp = NULL;
        pin_flist_t             *adjust_info_flistp = NULL;
        pin_flist_t             *event_misc_iflistp = NULL;
        pin_flist_t             *adjustment_info_iflistp = NULL;
        pin_flist_t             *srch_res_flistp = NULL;

        char                    *trans_id =NULL;
        poid_t                  *srchp  = NULL;
        int32                   s_flags = 0;
        void                    *vp = NULL;


        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details: "
                                " input flist",in_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details "
                                " function entry error", ebufp);
                return;
        }

        /* Creating Search flist */
        trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

        transid_srch_iflistp = PIN_FLIST_CREATE(ebufp);
        srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(transid_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
        PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

        if ((trans_id != NULL) && (strlen(trans_id) != 0))
        {
                vp =  (void *)"select X from /event/billing/adjustment where F1 = V1 and "
                                        " F2 like V2 and F3 = V3";
                PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
        }

        else
        {
                vp =  (void *)"select X from /event/billing/adjustment where F1 = V1 and "
                                        " F2 like V2 and F3 >= V3 and F4 <= V4";
                PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
        }

        args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

        args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 2, ebufp);
        srchp = PIN_POID_CREATE(db_no, "/event/billing/adjustment/%", -1, ebufp);
        PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
        
	if ((trans_id != NULL) && (strlen(trans_id) != 0))
	{
                args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 3, ebufp);
                adjust_info_flistp = PIN_FLIST_ELEM_ADD(args_flistp, TAB_FLD_ADJUSTMENT_INFO, 0, ebufp);
                PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, adjust_info_flistp, PIN_FLD_TRANS_ID, ebufp);
        }

	else
	{
		args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 3, ebufp);
	        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VALID_FROM, args_flistp, PIN_FLD_START_T, ebufp);

	        args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 4, ebufp);
	        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VALID_TO, args_flistp, PIN_FLD_END_T, ebufp);
	}

        srch_res_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_CREATED_T, NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_START_T, NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_END_T, NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_DESCR, NULL, ebufp);

        bal_impacts_iflistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_BAL_IMPACTS, 0, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_RESOURCE_ID, NULL, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_AMOUNT, NULL, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_DISCOUNT, NULL, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_GL_ID, NULL, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_IMPACT_TYPE, NULL, ebufp);
        PIN_FLIST_FLD_SET(bal_impacts_iflistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);

        event_misc_iflistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_EVENT_MISC_DETAILS, 0, ebufp);
        PIN_FLIST_FLD_SET(event_misc_iflistp, PIN_FLD_REASON_DOMAIN_ID, NULL, ebufp);
        PIN_FLIST_FLD_SET(event_misc_iflistp, PIN_FLD_REASON_ID, NULL, ebufp);

        adjustment_info_iflistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, TAB_FLD_ADJUSTMENT_INFO, 0, ebufp);
        PIN_FLIST_FLD_SET(adjustment_info_iflistp, PIN_FLD_USER_NAME, NULL, ebufp);
        PIN_FLIST_FLD_SET(adjustment_info_iflistp, PIN_FLD_LOCATION, NULL, ebufp);
        PIN_FLIST_FLD_SET(adjustment_info_iflistp, PIN_FLD_TRANS_ID, NULL, ebufp);
        PIN_FLIST_FLD_SET(adjustment_info_iflistp, PIN_FLD_GLACCOUNT, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_event_adjustment_details Search: "
                        " input flist", transid_srch_iflistp);

        /***************Perform the search*************************/

        PCM_OP(ctxp, PCM_OP_SEARCH, 0, transid_srch_iflistp, &trans_id_srch_rflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details:"
                        " input flist ", transid_srch_iflistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details:"
                        " Error while doing search: ", ebufp);
                goto cleanup;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_event_adjustment_details Search: "
                        " return flist", trans_id_srch_rflistp);

        *ret_flistpp = trans_id_srch_rflistp;

cleanup:
        /******************************************************************
        *            * Clean up.
        ******************************************************************/
        PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
        return;
}

/********************************************
 * We use this function to get payment reversal 
 * information on basis of input.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************/

	void
fm_tab_utils_common_get_payment_reversal_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_iflistp=NULL;
	pin_flist_t		*search_rflistp=NULL;
	pin_flist_t		*args_flistp=NULL;
	pin_flist_t		*bal_impacts_rflistp=NULL;
	pin_flist_t		*reversal_iflistp=NULL;
	pin_flist_t		*bal_impact_inp_flistp=NULL;
	pin_flist_t		*reversal_res_flistp=NULL;
	pin_flist_t		*srch_res_flistp=NULL;
	char			*trans_id=NULL;
	poid_t			*srchp=NULL;
	int32			s_flags=0;
	int32			prerated_impact_type=0;
	void			*vp=NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_payment_reversal_details: "
				" input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_payment_reversal_details "
			" function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_payment_reversal_details input flist",in_flistp);

	/* Creating Search flist */
	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	search_iflistp = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	/* Sample input flist for search 
	 0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	 0 PIN_FLD_FLAGS           INT [0] 0
	 0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/reversal where F1 like V1 and F2 = V2 and F3 = V3 "
	 0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	 1     PIN_FLD_POID           POID [0] 0.0.0.1 /event/billing/reversal/% -1 0
	 0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	 1     PIN_FLD_BAL_IMPACTS   ARRAY [0] allocated 20, used 1
	 2         PIN_FLD_IMPACT_TYPE    ENUM [0] 2
	 0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	 1     PIN_FLD_PAYMENT      SUBSTRUCT [0] allocated 20, used 1
	 2         PIN_FLD_TRANS_ID        STR [0] "T1,5,0"
	 0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 4
	 1     PIN_FLD_CREATED_T    TSTAMP [0] (0) <null>
	 1     PIN_FLD_DESCR           STR [0] ""
	 1     PIN_FLD_BAL_IMPACTS   ARRAY [0] allocated 20, used 2
	 2         PIN_FLD_AMOUNT       DECIMAL [0] NULL
	 2         PIN_FLD_IMPACT_TYPE    ENUM [0] 0
	 1     PIN_FLD_PAYMENT      SUBSTRUCT [0] allocated 20, used 2
	 2         PIN_FLD_PAYMENT_TRANS_ID    STR [0] ""
	 2         PIN_FLD_TRANS_ID        STR [0] ""
	 2         PIN_FLD_USER_NAME        STR [0] ""
	 2         PIN_FLD_LOCATION        STR [0] ""
	 */

	if((trans_id != NULL) && (strlen(trans_id) != 0))
	{
		vp=(void *)"select X from /event/billing/reversal where F1 like V1 and F2 = V2 and F3 = V3";
		PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	else
	{
		vp=(void *)"select X from /event/billing/reversal where F1 like V1 and F2 = V2 and "
			"F3 = V3 and F4 >= V4 and F5 <= V5 ";
		 PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 1, ebufp);
	srchp = PIN_POID_CREATE(db_no, "/event/billing/reversal/%", -1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)srchp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 2, ebufp);
	bal_impact_inp_flistp=PIN_FLIST_ELEM_ADD(args_flistp,PIN_FLD_BAL_IMPACTS, 0, ebufp);
	prerated_impact_type=PIN_IMPACT_TYPE_PRERATED;
	PIN_FLIST_FLD_SET(bal_impact_inp_flistp,PIN_FLD_IMPACT_TYPE,(void *)&prerated_impact_type,ebufp);

	if((trans_id != NULL) && (strlen(trans_id) != 0))
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 3, ebufp);
		reversal_iflistp=PIN_FLIST_ELEM_ADD(args_flistp,TAB_FLD_REVERSAL_INFO,0,ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, reversal_iflistp, PIN_FLD_TRANS_ID, ebufp);
	}
	else
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_START_T , args_flistp, PIN_FLD_CREATED_T, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_END_T, args_flistp, PIN_FLD_CREATED_T, ebufp);
	}
	srch_res_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_CREATED_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_START_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_END_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_DESCR, NULL, ebufp);

	bal_impacts_rflistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_BAL_IMPACTS, 0, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_rflistp, PIN_FLD_AMOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_rflistp, PIN_FLD_IMPACT_TYPE, NULL, ebufp);

	reversal_res_flistp= PIN_FLIST_ELEM_ADD(srch_res_flistp, TAB_FLD_REVERSAL_INFO,PIN_ELEMID_ANY,ebufp);
	PIN_FLIST_FLD_SET(reversal_res_flistp, PIN_FLD_USER_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(reversal_res_flistp, PIN_FLD_LOCATION, NULL, ebufp);
	PIN_FLIST_FLD_SET(reversal_res_flistp, PIN_FLD_PAYMENT_TRANS_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(reversal_res_flistp, PIN_FLD_LOCATION, NULL, ebufp);
	PIN_FLIST_FLD_SET(reversal_res_flistp, PIN_FLD_TRANS_ID, NULL, ebufp);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Akshay");

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_payment_reversal_details Search: "
			" input flist", search_iflistp);

	/***************Perform the search*************************/

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_iflistp, &search_rflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_payment_reversal_details:"
				" input flist ", search_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_payment_reversal_details:"
				" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_payment_reversal_details Search: "
			" return flist", search_rflistp);

	*ret_flistpp = search_rflistp;

cleanup:
	/******************************************************************
	 *                        * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_iflistp, NULL);
	return;
}


/******************************************
 * We use this function to get event
 * payment object using trans id.
 * @param ctxp The context pointer.
 * @param trans_id Payment Trans ID.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void
fm_tab_utils_common_get_evt_payment_details(
        pcm_context_t           *ctxp,
        char                    *trans_id,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *search_flistp = NULL;
        pin_flist_t             *res_flistp = NULL;
        pin_flist_t             *args_flistp = NULL;
        pin_flist_t             *r_flistp = NULL;
        pin_flist_t             *payment_flistp = NULL;
        void                    *vp = NULL;
        poid_t                  *srchp = NULL;
        poid_t                  *event_payment_pdp = NULL;
        int32                   s_flags = 0;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_utils_common_get_evt_payment_details error", ebufp);
                return;
        }

        PIN_ERRBUF_RESET(ebufp);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_evt_payment_details:"
                "Payment Transaction ID");
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, trans_id);

        srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
        search_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
        PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
        vp =  (void *)"select X from /event/billing/payment where F1 like V1 and F2 = V2 ";
        PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

        args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
        event_payment_pdp = PIN_POID_CREATE(db_no, "/event/billing/payment/%", -1, ebufp);
        PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, event_payment_pdp, ebufp);

        args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
        payment_flistp = PIN_FLIST_SUBSTR_ADD(args_flistp, PIN_FLD_PAYMENT, ebufp);
        PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_TRANS_ID, trans_id, ebufp);

        res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
        PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
        payment_flistp = PIN_FLIST_SUBSTR_ADD(res_flistp, PIN_FLD_PAYMENT, ebufp);
        PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_TRANS_ID, NULL, ebufp);
        PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_get_evt_payment_details input flist", search_flistp);

        /***********************************************************
         *                                * Perform the search.
         ************************************************************/
        PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_utils_common_get_evt_payment_details input flist", search_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_evt_payment_details: "
                        "Error in getting event payment object", ebufp);
        }
        else
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_utils_common_get_evt_payment_details output flist", r_flistp);
                *r_flistpp = r_flistp;
        }

        PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
        return;
}

/********************************************
 * We use this function to get refund
 * information on basis of input.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************/
void
fm_tab_utils_common_get_refund_details(
	pcm_context_t           *ctxp,
	int32                   flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **ret_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *search_iflistp = NULL;
	pin_flist_t             *search_rflistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *bal_impacts_rflistp = NULL;
	pin_flist_t             *refund_iflistp = NULL;
	pin_flist_t             *bal_impact_inp_flistp = NULL;
	pin_flist_t             *refund_res_flistp = NULL;
	pin_flist_t             *srch_res_flistp = NULL;
	char                    *trans_id = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;
	int32                   prerated_impact_type = PIN_IMPACT_TYPE_PRERATED;
	void                    *vp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_refund_details: "
			" input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_refund_details "
			" function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_refund_details input flist", in_flistp);

	/* Creating Search flist */
	search_iflistp = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(search_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	/* Sample input flist for search
	   0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	   0 PIN_FLD_FLAGS           INT [0] 0
	   0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/refund where F1 like V1 and F2 = V2 and F3 = V3 "
	   0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	   1     PIN_FLD_POID           POID [0] 0.0.0.1 /event/billing/refund/% -1 0
	   0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	   1     PIN_FLD_BAL_IMPACTS   ARRAY [0] allocated 20, used 1
	   2         PIN_FLD_IMPACT_TYPE    ENUM [0] 2
	   0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	   1     PIN_FLD_PAYMENT      SUBSTRUCT [0] allocated 20, used 1
	   2         PIN_FLD_TRANS_ID        STR [0] "T1,5,0"
	   0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 4
	   1     PIN_FLD_CREATED_T    TSTAMP [0] (0) <null>
	   1     PIN_FLD_DESCR           STR [0] ""
	   1     PIN_FLD_BAL_IMPACTS   ARRAY [0] allocated 20, used 2
	   2         PIN_FLD_AMOUNT       DECIMAL [0] NULL
	   2         PIN_FLD_IMPACT_TYPE    ENUM [0] 0
	   1     PIN_FLD_PAYMENT      SUBSTRUCT [0] allocated 20, used 2
	   2         PIN_FLD_PAYMENT_TRANS_ID    STR [0] ""
	   2         PIN_FLD_TRANS_ID        STR [0] ""
	   2         PIN_FLD_USER_NAME        STR [0] ""
	   2         PIN_FLD_LOCATION        STR [0] ""
	   */

	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	if((trans_id != NULL) && (strlen(trans_id) != 0))
	{
		vp=(void *)"select X from /event/billing/refund where F1 like V1 and F2 = V2 and F3 = V3";
		PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	else
	{
		vp=(void *)"select X from /event/billing/refund where F1 like V1 and F2 = V2 and "
			"F3 = V3 and F4 >= V4 and F5 <= V5 ";
		PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 1, ebufp);
	srchp = PIN_POID_CREATE(db_no, "/event/billing/refund/%", -1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)srchp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 2, ebufp);
	bal_impact_inp_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_BAL_IMPACTS, 0, ebufp);
	PIN_FLIST_FLD_SET(bal_impact_inp_flistp, PIN_FLD_IMPACT_TYPE, (void *)&prerated_impact_type, ebufp);

	if((trans_id != NULL) && (strlen(trans_id) != 0))
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 3, ebufp);
		refund_iflistp = PIN_FLIST_ELEM_ADD(args_flistp, TAB_FLD_REFUND_INFO, 0, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, refund_iflistp, PIN_FLD_TRANS_ID, ebufp);
	}
	else
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_START_T , args_flistp, PIN_FLD_CREATED_T, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_END_T, args_flistp, PIN_FLD_CREATED_T, ebufp);
	}
	srch_res_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_CREATED_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_START_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_END_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_DESCR, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);


	bal_impacts_rflistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_BAL_IMPACTS, 0, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_rflistp, PIN_FLD_AMOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_rflistp, PIN_FLD_IMPACT_TYPE, NULL, ebufp);

	refund_res_flistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, TAB_FLD_REFUND_INFO, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_USER_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_LOCATION, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_PAYMENT_TRANS_ID, NULL, ebufp);
    PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_TRANS_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_LOCATION, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_BANK_ACCOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_BANK_CODE, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_BRANCH_NO, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_CHECK_NO, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_DEALER_CODE, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, PIN_FLD_DEALER_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_BANK_BRNCH_CODE, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_CHANNEL_ID_STR, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_CHECK_AMOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_CHECK_ISSUE_T_STR, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_CHECK_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(refund_res_flistp, TAB_FLD_GL_GRP_CODE, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_refund_details Search: "
		" input flist", search_iflistp);

	/***************Perform the search*************************/

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_iflistp, &search_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_refund_details:"
			" input flist ", search_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_refund_details:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_refund_details Search: "
		" return flist", search_rflistp);

	*ret_flistpp = search_rflistp;

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_iflistp, NULL);
	return;
}
/*******************************************************************
 *This function will be used to create the event for setBudgetLimit,
 * CancelBudgetLimit and ModifyCreditLimit.
 *
 * @param ctxp The context pointer.
 * @param i_flistp the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_create_limit_event(
    pcm_context_t        *ctxp,
    int64            db_no,
    poid_t            *event_pdp,
    pin_flist_t        *in_flistp,
    pin_flist_t        **out_flistpp,
    pin_errbuf_t        *ebufp)
{

    pin_flist_t        *create_event_input_flistp = PIN_FLIST_CREATE(ebufp);
    pin_flist_t        *create_event_out_flistp=NULL;
    pin_flist_t        *read_object_flistp = NULL;
    char            *created_datep=NULL;
    time_t            created_t=0;
    poid_t            *event_poidp = NULL;
    int            elem_limit=0;
    pin_cookie_t        cookie_limit= NULL;
    pin_flist_t        *result_limit_flistp=NULL;
    pin_flist_t        *limit_array_flistp=NULL;

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_common_create_limit_event input flistp", in_flistp);

    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event error", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event:"
            " in_flistp", in_flistp);
        return;
    }

    fm_tab_utils_common_read_object(ctxp,event_pdp,&read_object_flistp,ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object error", ebufp);
        PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object:",event_pdp);
        goto cleanup;
    }

    created_t=*(time_t*)PIN_FLIST_FLD_GET(read_object_flistp, PIN_FLD_CREATED_T,0,ebufp);
    created_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&created_t,ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_convert_timestamp_to_date error", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_convert_timestamp_to_date:",read_object_flistp);
        goto cleanup;
    }
    PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_CREATED_T_STR,created_datep, ebufp);
    free(created_datep);


    event_poidp = PIN_POID_CREATE(db_no, "/tab_event_modify_credit_limit", -1, ebufp);
    PIN_FLIST_FLD_PUT(create_event_input_flistp, PIN_FLD_POID, event_poidp, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_OBJ ,create_event_input_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DESCR ,create_event_input_flistp, PIN_FLD_DESCR, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MSISDN ,create_event_input_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO ,create_event_input_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_RESOURCE_ID ,create_event_input_flistp, PIN_FLD_RESOURCE_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CREDIT_LIMIT ,create_event_input_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME ,create_event_input_flistp, PIN_FLD_USER_NAME, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CL_TYPE ,create_event_input_flistp, TAB_FLD_CL_TYPE, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_SERV_DETAILS ,create_event_input_flistp, TAB_FLD_SERV_DETAILS, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_WAIVER_CODE ,create_event_input_flistp, TAB_FLD_WAIVER_CODE, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CHANNEL ,create_event_input_flistp, PIN_FLD_CHANNEL, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_ABSOLUTE_FLAG ,create_event_input_flistp, TAB_FLD_ABSOLUTE_FLAG, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_OLD_CREDIT_LIMIT ,create_event_input_flistp, TAB_FLD_OLD_CREDIT_LIMIT, ebufp);
    PIN_FLIST_FLD_COPY(read_object_flistp,PIN_FLD_POID ,create_event_input_flistp, PIN_FLD_EVENT_OBJ, ebufp);
    PIN_FLIST_FLD_COPY(read_object_flistp,PIN_FLD_SERVICE_OBJ ,create_event_input_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_EXPIRY_T_STR ,create_event_input_flistp, TAB_FLD_EXPIRY_T_STR, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_TEMP_CL_FLAG ,create_event_input_flistp, TAB_FLD_TEMP_CL_FLAG, ebufp);


    while ((result_limit_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_THRESHOLDS,
                    &elem_limit, 1, &cookie_limit, ebufp)) !=    (pin_flist_t*)NULL)
    {
        PIN_FLIST_ELEM_COPY(in_flistp,PIN_FLD_THRESHOLDS,elem_limit,create_event_input_flistp,
            PIN_FLD_THRESHOLDS,elem_limit,ebufp);
    }
    elem_limit=0;
    cookie_limit=NULL;
    while ((limit_array_flistp = PIN_FLIST_ELEM_GET_NEXT(read_object_flistp,
				    PIN_FLD_LIMIT, &elem_limit, 1, &cookie_limit, ebufp)) != (pin_flist_t *)NULL)
    {
	    if (elem_limit ==1)    
	    {
		    PIN_FLIST_FLD_COPY(limit_array_flistp, PIN_FLD_CREDIT_LIMIT, create_event_input_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
	    }
    }

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_create_limit_event:"
        "Read_Obj input Flist", create_event_input_flistp);
    PCM_OP( ctxp,PCM_OP_CREATE_OBJ,0, create_event_input_flistp, &create_event_out_flistp, ebufp );
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_create_limit_event:"
        "Read_Obj output Flist", create_event_out_flistp);

    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event error", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event:"
            " in_flistp", create_event_input_flistp);
        goto cleanup;
    }


cleanup:
    /******************************************************************
     * Clean up.
     ******************************************************************/
    PIN_FLIST_DESTROY_EX(&create_event_input_flistp, NULL);
    PIN_FLIST_DESTROY_EX(&create_event_out_flistp, NULL);
    PIN_FLIST_DESTROY_EX(&read_object_flistp, NULL);
    return;
}
