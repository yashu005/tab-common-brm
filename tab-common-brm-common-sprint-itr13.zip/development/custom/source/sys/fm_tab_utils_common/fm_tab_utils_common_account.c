/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah            |                       | Account DB Search
 *
 *********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_account.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <limits.h>
#include "tab_ops_flds.h"
#include "tab_common.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_account.c(2)"

/*************************************************
 *  *  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_get_poid_from_accountno(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_poid_from_msisdn_sim(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_service_from_accountno(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_utils_common_get_profile_customer_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_account_details(
	pcm_context_t		*ctxp,
	char			*account_no,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_service(
	pcm_context_t		*ctxp,
	poid_t			*svc_pdp,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_service_from_account(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_service_from_accountpdp(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern pin_flist_t*
fm_tab_utils_common_prep_simple_search_flist(
	char			*template,
	field_t			args_struct[],
	int			n_args,
	field_t			result_struct[],
	int			n_results,
	int64			db_no,
	int			flags,
	pin_errbuf_t		*ebufp);

extern int
fm_tab_utils_common_call_opcode(
	pcm_context_t		*ctxp,
	u_int			opcode,
	u_int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	char			*log_info,
	int			set_error,
	pin_errbuf_t		*ebufp);

/********************************************************
 *  This function will find the strings details with the
 *  given strings value.
 *  If the string is available then it will return
 *  the returned value in the return flist
 ***********************************************/
void
fm_tab_utils_common_get_poid_from_accountno(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*srv_result_flistp = NULL;
	pin_flist_t		*get_srv_oflistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_accountno error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_accountno:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_poid_from_accountno input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /account where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, args_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_GROUP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_poid_from_accountno input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
		"fm_tab_utils_common_get_poid_from_accountno input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_utils_common_get_poid_from_accountno: Error in getting account object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_poid_from_accountno output flist", r_flistp);

		if (r_flistp && (result_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, 
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			fm_tab_utils_common_get_service_from_accountno(ctxp, i_flistp, &get_srv_oflistp, db_no, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_utils_common_get_service_from_accountno input flist", search_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_service_from_accountno: Error in getting service object", ebufp);
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_get_service_from_accountno output flist", get_srv_oflistp);

				if (get_srv_oflistp && (srv_result_flistp = PIN_FLIST_ELEM_GET(get_srv_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(srv_result_flistp, PIN_FLD_POID, 
						result_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(srv_result_flistp, PIN_FLD_ACCOUNT_OBJ,
                                                result_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(srv_result_flistp, PIN_FLD_BAL_GRP_OBJ,
                                                result_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID,
							result_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				}
			}
			*r_flistpp = PIN_FLIST_COPY(r_flistp,ebufp);
		}
	}
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_srv_oflistp, NULL);
	return;
}

void
fm_tab_utils_common_get_service_from_accountno(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_service_from_accountno error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_service_from_accountno:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_service_from_accountno input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /service 1, /account 2 where 1.F2 = 2.F1 and 2.F3 = V3 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, args_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SERVICE_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_service_from_accountno input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_get_service_from_accountno input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_service_from_accountno: Error in getting service object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_service_from_accountno output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

void
fm_tab_utils_common_get_poid_from_msisdn_sim(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*alias_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_msisdn_sim error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_msisdn_sim:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_poid_from_msisdn_sim input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /service where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	alias_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_ALIAS_LIST, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, alias_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_poid_from_msisdn_sim input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_get_poid_from_msisdn_sim input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_poid_from_msisdn_sim: Error in getting service object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_poid_from_msisdn_sim output flist", r_flistp);
		*r_flistpp = r_flistp;	
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

void
fm_tab_utils_common_get_profile_customer_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	poid_t			*profile_poidp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_customer_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_customer_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_customer_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	profile_poidp = PIN_POID_CREATE(db_no, "/profile/tab_customer_details", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /profile where  F1 = V1 and F2 = V2 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, profile_poidp, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_SUBSTR_SET(res_flistp, NULL, PIN_FLD_CUSTOMER_CARE_INFO, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_profile_customer_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_utils_common_get_profile_customer_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_profile_customer_details: Error in getting profile customer details object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_profile_customer_details output flist", r_flistp);
		*r_flistpp = r_flistp;	
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

void 
fm_tab_utils_common_get_account_details(
	pcm_context_t		*ctxp,
	char			*account_no,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*arg_flistp = NULL;
	pin_flist_t		*s_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*result_flistp = NULL;

	int32			flags = SRCH_DISTINCT;
	poid_t			*s_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERR_CLEAR_ERR(ebufp);

	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, s_pdp, ebufp);

	/***********************************************************************
	 * Create Search FLIST to get account details
	 ***********************************************************************/
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, " select X from /account where F1 = V1 ", ebufp);
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, &flags, ebufp);

	/**************************************************
	 * Account No
	 **************************************************/
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_ACCOUNT_NO, account_no, ebufp);

	/**************************************************
	 * Results
	 **************************************************/
	result_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	// Added below to fetch only those fields which are required.
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_CURRENCY, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_account_details search in flist: s_flistp", s_flistp);

	/**************************************************
	 * Perform Search
	 **************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &r_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_account_details: PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_account_details: r_flistp", r_flistp);

	*r_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_account_details: r_flistpp", *r_flistpp);

cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
}

/*******************************************************************
 *  fm_tab_utils_common_get_service()
 *  
 *  This function will be used to retrieve the service 
 * 
 *  @param ctxp The context pointer.
 *  @param svc_pdp the account poid.
 *  @param active_flag  10100 or 10102 or 10103
 *  @param r_flistpp The return flist.
 *  @param ebufp The error buffer.
 *  @return flistp.
 * 
 ********************************************************************/
void
fm_tab_utils_common_get_service(
	pcm_context_t		*ctxp,
	poid_t			*svc_pdp,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp)

{
	if( PIN_ERR_IS_ERR(ebufp) )
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
		"fm_tab_utils_common_get_service error", ebufp);
		return;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_service :Function starts");

	/*******************************************************************
 * 	Intialize variables
 * 		*******************************************************************/
	poid_t		*s_pdp = NULL;
	int32		s_flags = 256;
	int32		count = 0;
	char		s_template[2*BUFSIZ] = {""};
	pin_flist_t		*s_flistp =NULL;
	pin_flist_t		*arg_flistp =NULL;
	pin_flist_t		*ret_flistp =NULL;

	/*******************************************************************
 * 	construct search flist
 * 		*******************************************************************/
	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	if(s_pdp) 
	{
		PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp,ebufp);
	}
	
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, ebufp);
	if(active_flag != 0)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching Active service Details");
		strcpy ( s_template, "select X from /service where F1 = V1 and F2 = V2 ");
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching  service details");
		strcpy ( s_template, "select X from /service where F1 = V1 ");
	}

	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_POID, svc_pdp, ebufp);
	if(active_flag != 0)
	{
		arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 2, ebufp);
		PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_STATUS, &active_flag, ebufp);
	}

	PIN_FLIST_ELEM_SET(s_flistp, NULL, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	/*******************************************************************
 * 	call search opcode
 * 		*******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_service: PCM_OP_SEARCH Input Flist", s_flistp);

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &ret_flistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_services: PCM_OP_SEARCH Input Flist", s_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_service: PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_service: PCM_OP_SEARCH Output Flist", ret_flistp);

	count=PIN_FLIST_ELEM_COUNT(ret_flistp, PIN_FLD_RESULTS, ebufp);

	if(count > 0) 
	{
		*r_flistpp = PIN_FLIST_COPY(ret_flistp,ebufp);
	}

	cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	return;
}


void
fm_tab_utils_common_get_service_from_account(
		pcm_context_t  	*ctxp,
		poid_t		*poid_pdp,
		int64  		db_no,
		pin_flist_t    	**ret_flistpp,
		pin_errbuf_t   	*ebufp)
{
	field_t		args_struct[1];
	field_t		result_struct[0];
	int		n_args = 1;
	int		n_results = 0;
	char		*template= "select X from /service where F1 = V1";;
	int 		flags=0;
	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;

	/******************************************************************
	 * Search template for msisdn's bill
	 ******************************************************************/			

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[0].fld_value = poid_pdp;			

	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp, 
			&search_out_flistp, "fm_tab_utils_common_get_service_from_account search", 1, ebufp);

	if (opcode_result != 0 ) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_service_from_account" 
				"error search failed", ebufp);												
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_service_from_account output flist", search_out_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);	

	*ret_flistpp=search_out_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_service_from_account output flist", *ret_flistpp);
	return;	
}

void
fm_tab_utils_common_get_service_from_accountpdp(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*search_flist_arg1 = NULL;
	pin_flist_t		*result_flist_arg = NULL;
	poid_t			*srch_msisdn_pdp = NULL;
	int32			s_flags = 0;
	char			*svc_template="select X from /service where F1 = V1";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_service_from_accountpdp error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_service_from_accountpdp:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_service_from_accountpdp input", i_flistp);

	search_flistp = PIN_FLIST_CREATE(ebufp);
	srch_msisdn_pdp = PIN_POID_CREATE(db_no, "/search", -1,ebufp);
	PIN_FLIST_FLD_PUT(search_flistp,PIN_FLD_POID,(void *)srch_msisdn_pdp,ebufp);
	PIN_FLIST_FLD_SET(search_flistp,PIN_FLD_FLAGS,&s_flags,ebufp);
	PIN_FLIST_FLD_SET(search_flistp,PIN_FLD_TEMPLATE,svc_template,ebufp);

	search_flist_arg1 = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp,PIN_FLD_POID,search_flist_arg1,PIN_FLD_ACCOUNT_OBJ,ebufp);

	result_flist_arg = PIN_FLIST_ELEM_ADD(search_flistp,PIN_FLD_RESULTS,0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_SEARCH:" "result arg flist", result_flist_arg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_SEARCH:" "input flist",search_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &res_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_service_from_accountpdp input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_service_from_accountpdp: Error in getting service object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_service_from_accountpdp output flist", res_flistp);

		*r_flistpp = res_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}
