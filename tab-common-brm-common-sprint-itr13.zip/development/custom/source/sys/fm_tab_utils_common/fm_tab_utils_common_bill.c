/*******************************************************************************
 *
 *	This material is the confidential property of Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date	   | Programmer					| Req/bug/Gap			| Change details
 *
 * 1  | 09/Feb/2021 | Darshan		|						| Bill DB Search
 *
 *********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_bill.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include "tab_common.h"
#include "tab_ops_flds.h"
#define FILE_SOURCE_ID "fm_tab_utils_common_bill.c(2)"

/*************************************************
 *	*  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_get_bill_details(
    pcm_context_t       *ctxp,
    pin_flist_t         *i_flistp,
    pin_flist_t         **r_flistpp,
    int64               db_no,
    pin_errbuf_t        *ebufp);

void
fm_tab_utils_common_search_bill_no(
        pcm_context_t   *ctxp,
        pin_flist_t     *in_flistp,
        pin_flist_t     **out_flistpp,
        int64           db_no,
        pin_errbuf_t    *ebufp);

void
fm_tab_utils_common_search_item_bill_pdp(
        pcm_context_t   *ctxp,
        pin_flist_t     *in_flistp,
        pin_flist_t     **out_flistpp,
        int64           db_no,
        pin_errbuf_t    *ebufp);

void
fm_tab_utils_common_search_item_account_pdp(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);	

extern pin_flist_t*
fm_tab_utils_common_prep_simple_search_flist(
	char		*template,
	field_t		args_struct[],
	int		n_args,
	field_t		result_struct[],
	int		n_results,
	int64		db_no,
	int		flags,
	pin_errbuf_t	*ebufp);

extern int
fm_tab_utils_common_call_opcode(
	pcm_context_t	*ctxp,
	u_int		opcode,
	u_int		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	char		*log_info,
	int		set_error,
	pin_errbuf_t	*ebufp);

void
fm_tab_utils_common_search_bill_no_with_account(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t   	*ebufp);

/*******************************************************************
 * fm_tab_utils_common_get_bill_details()
 *
 * This function will be used to retrieve the ar bill object
 * details based on bill no.
 *
 * @param ctxp The context pointer.
 * @param in_flistp input flist
 * @param out_flistp The return flist.
 * @param db_no Database number
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************************************/

void
fm_tab_utils_common_get_bill_details(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	void                    *vp = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
				" input flist", i_flistp);
		return;
	}
	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_bill_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /bill where F1 = V1 and F2 = V2 and bill_t.BILLINFO_OBJ_ID0 = bill_t.AR_BILLINFO_OBJ_ID0 and bill_t.end_t != 0 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BILL_NO, args_flistp, PIN_FLD_BILL_NO, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	
	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILLINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILL_NO, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_START_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_END_T, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_bill_details input flist", search_flistp);
	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_bill_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_bill_details: Error in getting ar bill object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_get_bill_details output flist", r_flistp);
	}
	
	*r_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

void 
fm_tab_utils_common_search_bill_no(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t   	*ebufp)
{	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_bill_no input flistp", in_flistp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;	
	char		*bill_nop= NULL;
	field_t		args_struct[2];
	field_t		result_struct[0];
	int		n_args = 2;
	int		n_results = 0;
	char		*template= "select X from /bill where F1 = V1 and F2 = V2 ";
	int 		flags=0;

	bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_BILL_NO;
	args_struct[0].fld_value = bill_nop;		

	poid_t 	*parent_pdp = PIN_POID_CREATE(0, "", 0, ebufp);

	args_struct[1].fld_name = PIN_FLD_PARENT;
	args_struct[1].fld_value = parent_pdp;	

	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp, 
			&search_out_flistp, "fm_tab_utils_common_search_bill_no bill search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_search_bill_no" 
				"error search bill failed", ebufp);												
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);		



cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	

	*out_flistpp= search_out_flistp;
	PIN_POID_DESTROY(parent_pdp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_bill_no output flist", *out_flistpp);
	return;	
}


void 
fm_tab_utils_common_search_item_bill_pdp(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_item_bill_pdp input flistp", in_flistp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_bill_pdp error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_bill_pdp:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;	
	poid_t		*bill_pdp= NULL;
	field_t		args_struct[3];
	field_t		result_struct[0];
	int		n_args = 3;
	int		n_results = 0;
	char		*template= "select X from /item where F1 = V1 and F2 = V2 and F3 > V3 ";
	int 		flags=0;
	int 		status=2;
	pin_decimal_t 	*zero=pbo_decimal_from_str("0",ebufp);		

	bill_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_AR_BILL_OBJ;
	args_struct[0].fld_value = bill_pdp;		

	args_struct[1].fld_name = PIN_FLD_STATUS;
	args_struct[1].fld_value = &status;	

	args_struct[2].fld_name = PIN_FLD_DUE;
	args_struct[2].fld_value = zero;		


	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp, 
			&search_out_flistp, "fm_tab_utils_common_search_item_bill_pdp search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ITEM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_search_item_bill_pdp" 
				"error search item failed", ebufp);												
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);		



cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	

	*out_flistpp= search_out_flistp;
	pbo_decimal_destroy(&zero);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_item_bill_pdp output flist", *out_flistpp);
	return;	
}


void
fm_tab_utils_common_search_item_account_pdp(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_item_account_pdp input flistp", in_flistp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_account_pdp error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_account_pdp:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;	
	poid_t		*account_pdp= NULL;
	field_t		args_struct[3];
	field_t		result_struct[0];
	int		n_args = 3;
	int		n_results = 0;
	char		*template= "select X from /item where F1 = V1 and F2 = V2 and F3 > V3 ";
	int 		flags=0;
	int 		status=2;
	pin_decimal_t 	*zero=pbo_decimal_from_str("0",ebufp);	

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[0].fld_value = account_pdp;		

	args_struct[1].fld_name = PIN_FLD_STATUS;
	args_struct[1].fld_value = &status;	

	args_struct[2].fld_name = PIN_FLD_DUE;
	args_struct[2].fld_value = zero;		

	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp, 
			&search_out_flistp, "fm_tab_utils_common_search_item_account_pdp search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ITEM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_search_item_account_pdp" 
				"error search item failed", ebufp);												
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);		



cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	

	*out_flistpp= search_out_flistp;
	pbo_decimal_destroy(&zero);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_item_account_pdp output flist", *out_flistpp);
	return;	
}

void
fm_tab_utils_common_search_bill_no_with_account(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t   	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_bill_no input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	char		*bill_nop= NULL;
	field_t		args_struct[2];
	field_t		result_struct[0];
	int		n_args = 2;
	int		n_results = 0;
	char		*template= "select X from /bill where F1 = V1 and F2 = V2 ";
	int 		flags=0;
	poid_t 		*account_pdp=NULL;

	bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_INVOICE_DATA, 1, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 0, ebufp);

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_BILL_NO;
	args_struct[0].fld_value = bill_nop;

	args_struct[1].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[1].fld_value = account_pdp;

	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_utils_common_search_bill_no bill search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_search_bill_no"
				"error search bill failed", ebufp);
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);



cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*out_flistpp= search_out_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_search_bill_no output flist", *out_flistpp);
	return;
}
