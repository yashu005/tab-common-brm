/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 18-OCT-2021   | Darshan           |               | New file.
 *                  | 2     | 10/Nov/2021   | Rahul Honnaiah    |               | Modified file and udpated
 *                  								| validate_and_normalize_input().

 *************************************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_validate_and_normalize_input.c:2021-Oct-10%";
#endif

#include "pcm.h"
#include "cm_fm.h"
#include "ops/cust.h"
#include "tab_common.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_validate_and_normalize_input.c"

/*************************************************
 *  *  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern Functions */
extern void
fm_tab_utils_common_get_poid_from_accountno(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_poid_from_msisdn_sim(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/********************************************************
 *  This function will validate the input fields
 *  and return flist based on the input passed.
 ***********************************************/
void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_poid_acctno_oflistp = NULL;
	pin_flist_t		*msisdn_sim_oflistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*enrich_flistp = NULL;

	char			*corr_id = NULL;
	char			*extern_user = NULL;
	char			*prog_name_intr = TAB_PROGRAM_NAME_INTERNAL;
	char			prog_name[255];

	char			*acct_nop = NULL;
	char			*msisdnp = NULL;
	void			*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_validate_and_normalize_input input", i_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);
	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);

	enrich_flistp = PIN_FLIST_COPY(i_flistp, ebufp);
	
	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(enrich_flistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(enrich_flistp, PIN_FLD_PROGRAM_NAME, prog_name_intr, ebufp);
	}

	if(msisdnp && strlen(msisdnp) != 0 )
	{
		fm_tab_utils_common_get_poid_from_msisdn_sim(ctxp, i_flistp, &msisdn_sim_oflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_validate_and_normalize_input: "
				"fm_tab_utils_common_get_poid_from_msisdn_sim error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
				" input flist", i_flistp);
			//PIN_FLIST_DESTROY_EX(&msisdn_sim_oflistp, NULL);
			goto cleanup;
			//return;
		}
		else
		{
			if (msisdn_sim_oflistp && (result_flistp = PIN_FLIST_ELEM_GET(msisdn_sim_oflistp,
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_utils_common_validate_and_normalize_input: "
					"result flist", result_flistp);

				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID,
					enrich_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_ACCOUNT_OBJ,
					enrich_flistp, PIN_FLD_POID, ebufp);

				vp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID, 1, ebufp);
				if (vp)
				{
					PIN_FLIST_FLD_DROP(result_flistp, PIN_FLD_POID, ebufp);
				}
				PIN_FLIST_CONCAT(enrich_flistp, result_flistp, ebufp);
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_MSISDN_NOT_FOUND, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_validate_and_normalize_input: "
					"Subscriber MSISDN not found", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_validate_and_normalize_input:"
					" input flist", i_flistp);
				//PIN_FLIST_DESTROY_EX(&msisdn_sim_oflistp, NULL);
				goto cleanup;
				//return;
			}
			goto cleanup;
		}
	}	
	if(acct_nop && strlen(acct_nop) != 0) 
	{
		/* Get owner account and group billing object */
		fm_tab_utils_common_get_poid_from_accountno(ctxp, i_flistp, 
			&get_poid_acctno_oflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_utils_common_validate_and_normalize_input: "
				"fm_tab_utils_common_get_poid_from_accountno error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_accountno:"
				" input flist", i_flistp);
			//PIN_FLIST_DESTROY_EX(&get_poid_acctno_oflistp, NULL);
			goto cleanup;
			//return;
		}
		else
		{
			if (get_poid_acctno_oflistp && (result_flistp = PIN_FLIST_ELEM_GET(get_poid_acctno_oflistp, 
				PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_utils_common_validate_and_normalize_input: "
					"fm_tab_utils_common_get_poid_from_accountno result flist", result_flistp);

				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID,
					enrich_flistp, PIN_FLD_POID, ebufp);

				if(PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
					PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID,
						enrich_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

				vp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID, 1, ebufp);
				if (vp)
				{
					PIN_FLIST_FLD_DROP(result_flistp, PIN_FLD_POID, ebufp);
				}
				PIN_FLIST_CONCAT(enrich_flistp, result_flistp, ebufp);
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ACCT_NOT_FOUND, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_validate_and_normalize_input:"
					"account number is not found in DB", ebufp);
				//PIN_FLIST_DESTROY_EX(&get_poid_acctno_oflistp, NULL);
				goto cleanup;
				//return;
			}
			goto cleanup;
		}
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*r_flistpp = PIN_FLIST_COPY(enrich_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&get_poid_acctno_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&msisdn_sim_oflistp, NULL);
	return;
}
