/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah		| 			| New opcode implementation to
 *                                               			| manage orders.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_UTILS_COMMON_MANAGE_ORDER operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_utils_common_manage_order(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_utils_common_manage_order(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_manage_order_update(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			exception_flag,
	poid_t			*tab_order_pdp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_manage_order_create(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/* Extern functions */
extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_tab_order_after(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_UTILS_COMMON_MANAGE_ORDER is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, TAB_FLD_NEW_MSISDN, TAB_FLD_OLD_IMSI
 *                  TAB_FLD_NEW_IMSI and PIN_FLD_ACTION.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID               POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN             STR [0] "981999999"
 * 0 TAB_FLD_NEW_MSISDN          STR [0] "81999900"
 * 0 TAB_FLD_OLD_IMSI                STR [0] "666666"
 * 0 TAB_FLD_NEW_IMSI               STR [0] "777777"
 * 0 PIN_FLD_ACTION             STR [0] "msisdn"
 * 0 PIN_FLD_CORRELATION_ID     STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 *
 */

void
op_tab_utils_common_manage_order(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			error_clear_flag = 1;
	int32                   cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_utils_common_manage_order function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_UTILS_COMMON_MANAGE_ORDER) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_utils_common_manage_order bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_utils_common_manage_order input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* call main function */
	fm_tab_utils_common_manage_order(ctxp, flags, in_flistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_utils_common_manage_order error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_utils_common_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_utils_common_manage_order:"
			" Error while creating/Updating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_COMMON_MANAGE_ORDER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_COMMON_MANAGE_ORDER)
                {
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_COMMON_MANAGE_ORDER, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_utils_common_manage_order output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to update the service information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_utils_common_manage_order(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*tab_order_oflistp = NULL;
	pin_flist_t		*results_tab_order_flistp = NULL;
	pin_flist_t		*manage_tab_order_oflistp = NULL;
	char                    log_msg[512]="";
	poid_t                  *tab_order_pdp = NULL;
        int32                   *statusp = NULL;
        int32                   *exception_flagp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_manage_order function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_manage_order: input flist", in_flistp);

	/*Search for /tab_order object*/
	fm_tab_utils_common_get_tab_order_after(ctxp, in_flistp, &tab_order_oflistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
			" Error while searching /tab_order object", ebufp);
		goto cleanup;
	}

	if ( tab_order_oflistp != NULL && (results_tab_order_flistp = PIN_FLIST_ELEM_GET(tab_order_oflistp,
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_manage_order:"
				" results_tab_order_flistp flist", results_tab_order_flistp);

		tab_order_pdp = PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_POID, 1, ebufp);
		statusp = (int32 *) PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_STATUS, 1, ebufp);
		exception_flagp = (int32 *) PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_FLAGS, 1, ebufp);

		sprintf(log_msg,"*statusp, *exception_flagp, %d %d", *statusp, *exception_flagp );
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(statusp && *statusp == TAB_ORDER_FAILURE && exception_flagp)
		{
			/*Update tab order in case of failure*/
			fm_tab_utils_common_manage_order_update(ctxp, in_flistp, ++*exception_flagp,
				tab_order_pdp, &manage_tab_order_oflistp, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
					" create tab_order input flist ", in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
					" Error while creating /tab_order object", ebufp);
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_ORDER_UPDATION, 0, 0, 0);
			}
		}
		if(statusp && *statusp == TAB_ORDER_SUCCESS)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_DUPLICATE_ORDER, 0, 0, 0);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
                                " create tab_order input flist ", in_flistp);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
                                " Duplicate tab_order ", ebufp);
		}
	}
	else
	{
		/*Tab order creation in case of failure*/
		fm_tab_utils_common_manage_order_create(ctxp, in_flistp, &manage_tab_order_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
				" create tab_order input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order:"
				" Error while creating /tab_order object", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_FAILED_ORDER_CREATION, 0, 0, 0);
		}
	}
cleanup:
	PIN_FLIST_DESTROY_EX(&tab_order_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&manage_tab_order_oflistp, NULL);
	return;
}

void
fm_tab_utils_common_manage_order_update(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   exception_flag,
        poid_t                  *tab_order_pdp,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *tab_order_iflistp = NULL;
        pin_flist_t             *create_tab_order_oflistp = NULL;
        pin_flist_t             *opcode_info_flistp = NULL;
        time_t                  current_time;
        int32                   *status = NULL;
        char                    *strp = NULL;
        int32                   len = 0;
        pin_buf_t               *bufp = NULL;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_update error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_update:"
                        " input flist", i_flistp);
                return;
        }
        PIN_ERRBUF_RESET(ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_manage_order_update input", i_flistp);

        tab_order_iflistp = PIN_FLIST_CREATE(ebufp);

        current_time = pin_virtual_time(NULL);

        if(!PIN_POID_IS_NULL(tab_order_pdp))
        {
                PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_POID, tab_order_pdp, ebufp);
		status = (int32 *) PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_STATUS, 1, ebufp);
        	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STATUS, tab_order_iflistp, PIN_FLD_STATUS, ebufp);

                PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_FLAGS, &exception_flag, ebufp);
                if(status && *status == TAB_SUCCESS)
                {
                        PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, &current_time, ebufp);
                }
                else
                {
                        PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, NULL, ebufp);
                }

		opcode_info_flistp = PIN_FLIST_SUBSTR_GET(i_flistp, PIN_FLD_OPCODE_INFO, 1, ebufp);

		/* Turn the flist into a string */
		len = 0;
		if (opcode_info_flistp == NULL)
		{
			strp = (char *)NULL;
		}
		else
		{
			PIN_FLIST_TO_STR(opcode_info_flistp, &strp, &len, ebufp);
		}

		bufp = (pin_buf_t *)calloc(1, sizeof(pin_buf_t));

		if(bufp != (pin_buf_t *)NULL)
		{
			/* Memory allocated successfully! */
			if (strp != NULL)
			{
				bufp->data = (caddr_t)strp;
				bufp->size = len + 1;           /* Include NULL termination */
			}
			else
			{
				bufp->data = (char *)NULL;
				bufp->size = 0;
			}

			bufp->flag = 0;
			bufp->offset = 0;
			bufp->xbuf_file = (char *)NULL;

			/* Plob buf into flist */
			PIN_FLIST_FLD_PUT(tab_order_iflistp, TAB_FLD_INPUT_FLIST,
					(void *)bufp, ebufp);
		}
		else
		{
			/* Memory not being able to allocated. Error. */
			pin_set_err(ebufp, PIN_ERRLOC_FM,
					PIN_ERRCLASS_APPLICATION,
					PIN_ERR_NO_MEM,
					TAB_FLD_INPUT_FLIST, 0, 0);

			if (strp)
			{
				free(strp);
			}
		}

		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ERROR_CODE, tab_order_iflistp, PIN_FLD_ERROR_CODE, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ERROR_DESCR, tab_order_iflistp, PIN_FLD_ERROR_DESCR, ebufp);

                /* Turn the flist into a string */
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_utils_common_manage_order_update : Write flds /tab_order "
                        "object input flist", tab_order_iflistp);

                PCM_OP(ctxp, PCM_OP_WRITE_FLDS, PCM_OPFLG_LOCK_NONE, tab_order_iflistp, &create_tab_order_oflistp, ebufp);

                if (PIN_ERR_IS_ERR(ebufp))
                {
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_utils_common_manage_order_update : Error in writing /tab_order object", ebufp);
                        goto cleanup;
                }
                else
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                                "fm_tab_utils_common_manage_order_update: Write Flds /tab_order "
                                "object output flist", create_tab_order_oflistp);
                        *r_flistpp = create_tab_order_oflistp;
                }
        }
cleanup:
        /******************************************************************
         * Clean up.
         ******************************************************************/
        PIN_FLIST_DESTROY_EX(&tab_order_iflistp, NULL);
        return;
}


void
fm_tab_utils_common_manage_order_create(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
	int64			db_no,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *tab_order_iflistp = NULL;
        pin_flist_t             *create_tab_order_oflistp = NULL;
        pin_flist_t             *hook_iflistp = NULL;
        pin_flist_t             *opcode_info_flistp = NULL;
        time_t                  current_time;
        poid_t                  *tab_orderp = NULL;
        poid_t                  *account_pdp = NULL;
        int32                   *status = NULL;
        char                    *name = NULL;
        char                    *strp = NULL;
        int32                   len = 0;
        pin_buf_t               *bufp = NULL;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_create error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_create:"
                        " input flist", i_flistp);
                return;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_manage_order_create input", i_flistp);

        tab_order_iflistp = PIN_FLIST_CREATE(ebufp);

        current_time = pin_virtual_time(NULL);

	status = (int32 *) PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_STATUS, 1, ebufp);
	name = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_NAME, 1, ebufp);
	if(name && strlen(name) != 0)
	{
		if(strcmp(name, "TAB_OP_CUST_CREATE_SUBSCRIBER") == 0)
		{
			PCM_OP(ctxp, TAB_OP_CUST_POL_CREATE_SUBSCR_GET_DB_NO, 0, i_flistp, &hook_iflistp, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_manage_order_create: "
					"TAB_OP_CUST_POL_CREATE_SUBSCR_GET_DB_NO input flist", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_create: "
					"TAB_OP_CUST_POL_CREATE_SUBSCR_GET_DB_NO error", ebufp);
				*r_flistpp = hook_iflistp;
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_manage_order_create: "
				"TAB_OP_CUST_POL_CREATE_SUBSCR_GET_DB_NO hook output flist", hook_iflistp);
			account_pdp = PIN_FLIST_FLD_GET(hook_iflistp, PIN_FLD_POID, 1, ebufp);
			db_no = PIN_POID_GET_DB(account_pdp);
			PIN_FLIST_DESTROY_EX(&hook_iflistp, ebufp);
		}
		if(strcmp(name, "TAB_OP_CUST_CREATE_ACCOUNT") == 0)
		{
			PCM_OP(ctxp, TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO, 0, i_flistp, &hook_iflistp, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_manage_order_create: "
					"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO input flist", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_manage_order_create: "
					"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO error", ebufp);
				*r_flistpp = hook_iflistp;
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_manage_order_create: "
				"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO hook output flist", hook_iflistp);
			account_pdp = PIN_FLIST_FLD_GET(hook_iflistp, PIN_FLD_POID, 1, ebufp);
			db_no = PIN_POID_GET_DB(account_pdp);
			PIN_FLIST_DESTROY_EX(&hook_iflistp, ebufp);
		}
	}
	tab_orderp = PIN_POID_CREATE(db_no, "/tab_order", -1, ebufp);

        PIN_FLIST_FLD_PUT(tab_order_iflistp, PIN_FLD_POID, (void *)tab_orderp, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, tab_order_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, tab_order_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, tab_order_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, tab_order_iflistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STATUS, tab_order_iflistp, PIN_FLD_STATUS, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_FLAGS, tab_order_iflistp, PIN_FLD_FLAGS, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, tab_order_iflistp, PIN_FLD_NAME, ebufp);

	opcode_info_flistp = PIN_FLIST_SUBSTR_GET(i_flistp, PIN_FLD_OPCODE_INFO, 1, ebufp);

	/* Turn the flist into a string */
	len = 0;
	if (opcode_info_flistp == NULL)
	{
		strp = (char *)NULL;
	}
	else
	{
		PIN_FLIST_TO_STR(opcode_info_flistp, &strp, &len, ebufp);
	}

	bufp = (pin_buf_t *)calloc(1, sizeof(pin_buf_t));

	if(bufp != (pin_buf_t *)NULL)
	{
		/* Memory allocated successfully! */
		if (strp != NULL)
		{
			bufp->data = (caddr_t)strp;
			bufp->size = len + 1;           /* Include NULL termination */
		}
		else
		{
			bufp->data = (char *)NULL;
			bufp->size = 0;
		}

		bufp->flag = 0;
		bufp->offset = 0;
		bufp->xbuf_file = (char *)NULL;

		/* Plob buf into flist */
		PIN_FLIST_FLD_PUT(tab_order_iflistp, TAB_FLD_INPUT_FLIST,
				(void *)bufp, ebufp);
	}
	else
	{
		/* Memory not being able to allocated. Error. */
		pin_set_err(ebufp, PIN_ERRLOC_FM,
				PIN_ERRCLASS_APPLICATION,
				PIN_ERR_NO_MEM,
				TAB_FLD_INPUT_FLIST, 0, 0);

		if (strp)
		{
			free(strp);
		}
	}

        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ERROR_CODE, tab_order_iflistp, PIN_FLD_ERROR_CODE, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ERROR_DESCR, tab_order_iflistp, PIN_FLD_ERROR_DESCR, ebufp);

        if(status && *status == TAB_SUCCESS)
        {
                PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, &current_time, ebufp);
        }
        else
        {
                PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, NULL, ebufp);
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_manage_order_create : create /tab_order "
                "object input flist", tab_order_iflistp);

        PCM_OP(ctxp, PCM_OP_CREATE_OBJ, PCM_OPFLG_LOCK_NONE, tab_order_iflistp, &create_tab_order_oflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "fm_tab_utils_common_manage_order_create: Error in creating /tab_order object", ebufp);
                goto cleanup;
        }
        else
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_manage_order_create: create /tab_order "
                "object output flist", create_tab_order_oflistp);
                *r_flistpp = create_tab_order_oflistp;
        }
cleanup:
        /******************************************************************
         * Clean up.
         ******************************************************************/
        PIN_FLIST_DESTROY_EX(&tab_order_iflistp, NULL);
        return;
}
