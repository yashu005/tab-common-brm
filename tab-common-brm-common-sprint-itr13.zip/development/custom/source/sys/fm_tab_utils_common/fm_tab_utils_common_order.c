/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/
/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah            |                       | Manage tab order process 
 *
 *********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_order.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <pin_subscription.h>
#include "tab_ops_flds.h"
#include "tab_common.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_order.c(2)"

/*************************************************
 *  *  *Global routines contained within
 ************************************************/
int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_tab_order_after(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp); 

void
fm_tab_utils_common_update_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	poid_t			*tab_order_pdp,
	int32			*errorCode,
	char			*errorMsg,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_create_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	int32			*errorCode,
	char			*errorMsg,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/********************************************************
 * This function will find the strings details with the
 * given strings value.
 * If the string is available then it will return
 * the returned value in the return flist
 ***********************************************/
int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*results_tab_order_flistp = NULL;

	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	int32			return_val = 0;
	int32			*statusp = NULL;
	int32			*exception_flagp = NULL;
	char			*corr_id = NULL;
	char			*extern_user = NULL;


	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before:"
			" input flist", i_flistp);
		return_val = 99;
		return return_val;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_tab_order_before input", i_flistp);

	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);

	if(corr_id == NULL && extern_user == NULL)
	{
		return_val = 0;
		return return_val;
	}

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /tab_order where  F1 = V1 and F2 = V2 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, args_flistp, PIN_FLD_CORRELATION_ID, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, args_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_FLAGS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_tab_order_before input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_tab_order_before: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before:"
			" input flist", search_flistp);
		return_val = 99;
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_tab_order_before output flist", r_flistp);
		if (r_flistp && (results_tab_order_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			statusp = PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_STATUS, 1, ebufp);
			exception_flagp = PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_FLAGS, 1, ebufp);

			if(statusp && *statusp == TAB_ORDER_SUCCESS )
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_DUPLICATE_ORDER, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_manage_msisdn_sim:"
					"Duplicate Order", ebufp);
				goto cleanup;
			}
			if(statusp && exception_flagp &&
				*statusp == TAB_ORDER_FAILURE && *exception_flagp >= TAB_ORDER_EXCEPTION )
			{
				return_val = *exception_flagp;
			}
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return return_val;
}

/********************************************************
 * This function will find the strings details with the
 * given strings value.
 * If the string is available then it will return
 * the returned value in the return flist
 ***********************************************/
void
fm_tab_utils_common_get_tab_order_after(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	char			*corr_id = NULL;
	char			*extern_user = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_after error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_after:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_tab_order_after input", i_flistp);

	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);

	if(corr_id == NULL && extern_user == NULL)
	{
		*r_flistpp = r_flistp;
		return;
	}

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /tab_order where  F1 = V1 and F2 = V2 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, args_flistp, PIN_FLD_CORRELATION_ID, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, args_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_FLAGS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_get_tab_order_after input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_tab_order_after: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_after:"
			" input flist", search_flistp);
		PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_utils_common_get_tab_order_after output flist", r_flistp);
		*r_flistpp = r_flistp;
		goto cleanup;
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

void
fm_tab_utils_common_update_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	poid_t			*tab_order_pdp,
	int32			*errorCode,
	char			*errorMsg,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*tab_order_iflistp = NULL;
	pin_flist_t		*create_tab_order_oflistp = NULL;
	time_t			current_time;
	char			*strp = NULL;
	int32			len = 0;
	pin_buf_t		*bufp = NULL;
	void			*vp = NULL;
	//struct  tm              *info;
	//time_t                  current_pvt_t = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_update_tab_order error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_update_tab_order:"
			" input flist", i_flistp);
		return;
	}
	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_update_tab_order input", i_flistp);

	vp = PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_EXCEPTION_FLAG, 1, ebufp);
	if (vp)
	{
		PIN_FLIST_FLD_DROP(i_flistp, TAB_FLD_EXCEPTION_FLAG, ebufp);
	}

        tab_order_iflistp = PIN_FLIST_CREATE(ebufp);

        current_time = pin_virtual_time(NULL);
        /*time(&current_time);
        info = localtime(&current_time);
        info->tm_isdst = -1;
        current_pvt_t = mktime(info); */

	if(!PIN_POID_IS_NULL(tab_order_pdp))
	{
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_POID, tab_order_pdp, ebufp);
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_STATUS, &status, ebufp);
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_FLAGS, &exception_flag, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_ADD_INFO,  tab_order_iflistp, TAB_FLD_HEADER_ADD_INFO, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_REMARK,  tab_order_iflistp, TAB_FLD_HEADER_REMARK, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_REQUEST_ID,  tab_order_iflistp, TAB_FLD_HEADER_REQUEST_ID, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_CHANNEL,  tab_order_iflistp, TAB_FLD_HEADER_CHANNEL, ebufp);

		if(status == TAB_SUCCESS)
		{
			PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, &current_time, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, NULL, ebufp);
		}
		
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_update_tab_order: errorMsg");
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, errorMsg);
		
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_ERROR_CODE, errorCode, ebufp);
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_ERROR_DESCR, errorMsg, ebufp);

		/* Turn the flist into a string */
		len = 0;
		if (i_flistp == NULL) 
		{
			strp = (char *)NULL;
		}
		else 
		{
			PIN_FLIST_TO_STR(i_flistp, &strp, &len, ebufp);
		}
		
		bufp = (pin_buf_t *)calloc(1, sizeof(pin_buf_t));
		
		if(bufp != (pin_buf_t *)NULL) 
		{
			/* Memory allocated successfully! */
			if (strp != NULL) 
			{
				bufp->data = (caddr_t)strp;
				bufp->size = len + 1;           /* Include NULL termination */
			}
			else 
			{
				bufp->data = (char *)NULL;
				bufp->size = 0;
			}

			bufp->flag = 0;
			bufp->offset = 0;
			bufp->xbuf_file = (char *)NULL;

			/* Plob buf into flist */
			PIN_FLIST_FLD_PUT(tab_order_iflistp, TAB_FLD_INPUT_FLIST,
				(void *)bufp, ebufp);
		}
		else 
		{
			/* Memory not being able to allocated. Error. */
			pin_set_err(ebufp, PIN_ERRLOC_FM,
				PIN_ERRCLASS_APPLICATION,
				PIN_ERR_NO_MEM,
				TAB_FLD_INPUT_FLIST, 0, 0);

			if (strp) 
			{
				free(strp);
			}
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_update_tab_order : Write flds /tab_order "
			"object input flist", tab_order_iflistp);
		PCM_OP(ctxp, PCM_OP_WRITE_FLDS, PCM_OPFLG_LOCK_NONE, tab_order_iflistp, &create_tab_order_oflistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_update_tab_order : Error in writing /tab_order object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_update_tab_order: Write Flds /tab_order "
				"object output flist", create_tab_order_oflistp);
			*r_flistpp = create_tab_order_oflistp;
		}
	}
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&tab_order_iflistp, NULL);
	return;
}

void
fm_tab_utils_common_create_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	int32			*errorCode,
	char			*errorMsg,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*tab_order_iflistp = NULL;
	pin_flist_t		*create_tab_order_oflistp = NULL;
	time_t			current_time;
	//struct	tm		*info;
	//time_t			current_pvt_t = 0;
	poid_t			*tab_orderp = NULL;
	void			*vp = NULL;
	char			*strp = NULL;
	int32			len = 0;
	pin_buf_t		*bufp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_tab_order error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_tab_order:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_create_tab_order input", i_flistp);

	vp = PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_EXCEPTION_FLAG, 1, ebufp);
	if (vp)
	{
		PIN_FLIST_FLD_DROP(i_flistp, TAB_FLD_EXCEPTION_FLAG, ebufp);
	}

	tab_order_iflistp = PIN_FLIST_CREATE(ebufp);

	current_time = pin_virtual_time(NULL);
	/*time(&current_time);
	info = localtime(&current_time);
	info->tm_isdst = -1;
	current_pvt_t = mktime(info); */

	tab_orderp = PIN_POID_CREATE(db_no, "/tab_order", -1, ebufp);

	PIN_FLIST_FLD_PUT(tab_order_iflistp, PIN_FLD_POID, (void *)tab_orderp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, tab_order_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, tab_order_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, tab_order_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, tab_order_iflistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_STATUS, &status, ebufp);
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_FLAGS, &exception_flag, ebufp);
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_NAME, opcode_name, ebufp);
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_ERROR_CODE, errorCode, ebufp);
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_ERROR_DESCR, errorMsg, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_ADD_INFO,  tab_order_iflistp, TAB_FLD_HEADER_ADD_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_REMARK,  tab_order_iflistp, TAB_FLD_HEADER_REMARK, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_REQUEST_ID,  tab_order_iflistp, TAB_FLD_HEADER_REQUEST_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_HEADER_CHANNEL,  tab_order_iflistp, TAB_FLD_HEADER_CHANNEL, ebufp);

	if(status == TAB_SUCCESS)
	{
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, &current_time, ebufp);		
	}
	else
	{
		PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_COMPLETED_T, NULL, ebufp);		
	}
	PIN_FLIST_FLD_SET(tab_order_iflistp, PIN_FLD_CREATED_T, &current_time, ebufp);
	
	/* Turn the flist into a string */
	len = 0;
	if (i_flistp == NULL) 
	{
			strp = (char *)NULL;
	}
	else 
	{
		PIN_FLIST_TO_STR(i_flistp, &strp, &len, ebufp);
	}
	
	bufp = (pin_buf_t *)calloc(1, sizeof(pin_buf_t));
	
	if(bufp != (pin_buf_t *)NULL) 
	{
		/* Memory allocated successfully! */
		if (strp != NULL) 
		{
			bufp->data = (caddr_t)strp;
			bufp->size = len + 1;           /* Include NULL termination */
		}
		else 
		{
			bufp->data = (char *)NULL;
			bufp->size = 0;
		}

		bufp->flag = 0;
		bufp->offset = 0;
		bufp->xbuf_file = (char *)NULL;

		/* Plob buf into flist */
		PIN_FLIST_FLD_PUT(tab_order_iflistp, TAB_FLD_INPUT_FLIST,
				(void *)bufp, ebufp);
	}
	else 
	{
		/* Memory not being able to allocated. Error. */
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_APPLICATION,
			PIN_ERR_NO_MEM,
			TAB_FLD_INPUT_FLIST, 0, 0);

		if (strp) 
		{
			free(strp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_create_tab_order : create /tab_order "
		"object input flist", tab_order_iflistp);

	PCM_OP(ctxp, PCM_OP_CREATE_OBJ, PCM_OPFLG_LOCK_NONE, tab_order_iflistp, &create_tab_order_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_utils_common_create_tab_order: Error in creating /tab_order object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_create_tab_order: create /tab_order "
		"object output flist", create_tab_order_oflistp);
		*r_flistpp = create_tab_order_oflistp;
	}
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&tab_order_iflistp, NULL);
	return;
}
