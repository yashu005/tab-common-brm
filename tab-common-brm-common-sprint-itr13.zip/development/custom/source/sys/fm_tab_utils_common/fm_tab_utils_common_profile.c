/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 22/Nov/2021 | Rahul Honnaiah		|                       | Profile DB Search
 *
 *********************************************************************************/
#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>

#define FILE_SOURCE_ID "fm_tab_utils_common_profile.c(2)"

/*************************************************
 *  *  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_get_profile_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	char			*profile_type,
	char			*profile_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_profile_sub_preferences(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_get_profile_multisim_map(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_get_profile_by_poid(
        pcm_context_t           *ctxp,
        poid_t                  *acc_pdp,
        poid_t                  *svc_pdp,
        char                    *profile_type,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);


/********************************************************
 *  This function will find the strings details with the
 *  given strings value.
 *  If the string is available then it will return
 *  the returned value in the return flist
 ***********************************************/

void
fm_tab_utils_common_get_profile_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	char			*profile_type,
	char			*profile_name,
	pin_flist_t*		*r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	poid_t			*srchp = NULL;
	poid_t			*profile_pdp = NULL;
	int32			s_flags = SRCH_DISTINCT;
	char			s_template[1023] = {""};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_details input", i_flistp);

	search_flistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	strcpy (s_template, "select X from /profile where F1.type = V1 and F2 = V2 and F3 = V3 ");

	profile_pdp = PIN_POID_CREATE (db_no, profile_type, -1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)profile_pdp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, args_flistp, PIN_FLD_SERVICE_OBJ, ebufp);

	if (profile_name && (strlen(profile_name) > 0))
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_NAME, profile_name, ebufp);
		strcat (s_template, "and (UPPER(F4) like V4) ");
	}

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);
	srch_res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_NAME, NULL, ebufp);
	data_array_flistp = PIN_FLIST_ELEM_ADD(srch_res_flistp, PIN_FLD_DATA_ARRAY, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(data_array_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(data_array_flistp, PIN_FLD_VALID_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(data_array_flistp, PIN_FLD_VALID_TO, NULL, ebufp);
	PIN_FLIST_FLD_SET(data_array_flistp, PIN_FLD_VALUE, NULL, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_profile_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_profile_details: Error in getting profile object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_profile_details output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/**
 *	We use this function to get account's
 *	profile subscriber preferences.
 *	@param ctxp The context pointer.
 *	@param in_flistp in the input flist.
 *	@param ebufp The error buffer.
 *	@return flistp.
 *     
 **/

void
fm_tab_utils_common_get_profile_sub_preferences(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*srchp = NULL;
	poid_t			*profilep = NULL;
	poid_t                  *svc_pdp = NULL;
	int32			s_flags = 0;
	char                    s_template[2*BUFSIZ] = {""};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_sub_preferences error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_sub_preferences:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_sub_preferences input", i_flistp);
	svc_pdp = (poid_t *)PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);

	search_flistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	profilep = PIN_POID_CREATE(db_no, "/profile/subscriber_preferences", -1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)profilep, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	if(svc_pdp){
                args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
                PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_SERVICE_OBJ, svc_pdp, ebufp);
                strcpy ( s_template, "select X from /profile where F1.type like V1 and F2 = V2 and F3 = V3 ");
        }else{
                strcpy ( s_template, "select X from /profile where F1.type like V1 and F2 = V2 ");
        }

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);
	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PCM_RECID_ALL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_ELEM_SET(res_flistp, NULL, PIN_FLD_SUBSCRIBER_PREFERENCES, PCM_RECID_ALL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_sub_preferences input flist", search_flistp);

	/***********************************************************
	 ** Perform the search.
	 ************************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
		"fm_tab_utils_common_get_profile_sub_preferences input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_utils_common_get_profile_sub_preferences: Error in getting profile "
		"subscriber preferences object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_profile_sub_preferences output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}


/**
 ** We use this function to get account's
 ** profile multi sim map object.
 ** @param ctxp The context pointer.
 ** @param in_flistp in the input flist.
 ** @param ebufp The error buffer.
 ** @return flistp.
 **
 **/

void
fm_tab_utils_common_get_profile_multisim_map(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	void                    *vp = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_multisim_map error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_multisim_map:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_profile_multisim_map input", i_flistp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /profile/tab_multisim_map where F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	data_array_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_DATA_ARRAY, PCM_RECID_ALL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, data_array_flistp, PIN_FLD_SERVICE_OBJ, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PCM_RECID_ALL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SERVICE_OBJ, NULL, ebufp);
	PIN_FLIST_ELEM_SET(res_flistp, NULL, PIN_FLD_DATA_ARRAY, PCM_RECID_ALL, ebufp);	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_profile_multisim_map input flist", search_flistp);

	/***********************************************************
	 ** Perform the search.
	 ************************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_profile_multisim_map input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_utils_common_get_profile_multisim_map: Error in getting profile subscriber preferences object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_get_profile_multisim_map output flist", r_flistp);

		*r_flistpp = r_flistp;
	}
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_profile_by_poid()
 *
 *  This function will be used to retrieve the profile details of  
 *  the subscriber 
 *
 * @param ctxp The context pointer.
 * @param acc_pdp the account poid.
 * @param svc_pdp the service poid.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_get_profile_by_poid(
	pcm_context_t		*ctxp,
	poid_t			*acc_pdp,
	poid_t			*svc_pdp,
	char			*profile_type,
	pin_flist_t		**r_flistpp,
	int64                   db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t        		*s_pdp = NULL;
	poid_t        		*profile_pdp = NULL;
	int32	        	s_flags = 0;
	int32		        count=0;
	char		        s_template[2*BUFSIZ] = {""};
	pin_flist_t		*s_flistp =NULL;
	pin_flist_t		*arg_flistp =NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*ret_flistp =NULL;

	if( PIN_ERR_IS_ERR(ebufp) ){
		return;
	}

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_profile_by_poid :Function starts");

	/*******************************************************************
	  construct search flist
	 *******************************************************************/
	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	if( s_pdp ) {
		PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp,ebufp);
	}
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_ACCOUNT_OBJ, acc_pdp, ebufp);

	profile_pdp = PIN_POID_CREATE (db_no, profile_type, -1, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD(s_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(arg_flistp, PIN_FLD_POID, (void *)profile_pdp, ebufp);

	if(svc_pdp){
		arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_SERVICE_OBJ, svc_pdp, ebufp);
		strcpy ( s_template, "select X from /profile where F1 = V1 and F2.type like V2 and F3 = V3");
	}else{
		strcpy ( s_template, "select X from /profile where F1 = V1 and F2.type like V2");
	}

	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD (s_flistp,  PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	/*******************************************************************
	  call search opcode
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_profile_by_poid: PCM_OP_SEARCH Input Flist", s_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &ret_flistp, ebufp);
	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_by_poid: PCM_OP_SEARCH Input Flist", s_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_by_poid: PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_profile_by_poid: PCM_OP_SEARCH Output Flist", ret_flistp);
	count=PIN_FLIST_ELEM_COUNT(ret_flistp,PIN_FLD_RESULTS,ebufp);
	if(count > 0) {
		res_flistp  = PIN_FLIST_ELEM_GET(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
		if(res_flistp)
			*r_flistpp = PIN_FLIST_ELEM_TAKE(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
	}
cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	return;
}
