
/*******************************************************************************
 *
 *	This material is the confidential property of Oracle corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 * Change History
 *
 * No | Date       | Programmer  | Req/bug/Gap   			| Change details
 *
 * 1  | 22/11/2021 | Oracle   	| 							| 
 *																 
 **************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "pcm.h"
#include "pinlog.h"
#include "pin_errs.h"
#include "cm_fm.h"
#include "cm_cache.h"
#include "pin_cust.h"

/*******************************************************************
 * Global Variable declaration
 *******************************************************************/
PIN_EXPORT pin_flist_t	*cfg_tab_policy_label_map_flistp;
PIN_EXPORT pin_flist_t 	*config_beid_out_flistp;
PIN_EXPORT pin_flist_t	*cfg_tab_package_descr_flistp;
PIN_EXPORT pin_flist_t	*cfg_tab_prepaid_sub_states_flistp;
PIN_EXPORT pin_flist_t	*cfg_tab_system_prod_flistp;
PIN_EXPORT int32 	*cfg_tab_system_currency;
PIN_EXPORT pin_flist_t	*cfg_tab_system_get_deal_flistp = NULL;

void
fm_tab_utils_common_init_load_config_policy_label_map_flist(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_init_load_config_tab_package_descr_flist(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_init_load_beid(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_init_load_product(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_init_load_recharge_valid_states(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_utils_common_init_get_deals(
        pcm_context_t           *ctxp,
        int64                   database,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_init_system_currency();

/***********************************************************************
 *Forward declaration
 ***********************************************************************/
EXPORT_OP void fm_tab_utils_common_init(int32 *errp);

void
fm_tab_utils_common_init_load_config_flist( 
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_init(int32 *errp)
{
	pcm_context_t		*ctxp = NULL;
	poid_t			*pdp = NULL;
	pin_errbuf_t		ebuf;
	int64			database;

	PIN_ERR_CLEAR_ERR(&ebuf);
	/***********************************************************
	 * open the context and get the database number. Don't do this
	 * first, otherwise we don't cleanup.
	 ***********************************************************/
	PCM_CONTEXT_OPEN(&ctxp, (pin_flist_t *)0, &ebuf);

	if(PIN_ERR_IS_ERR(&ebuf)) 
	{
		pin_set_err(&ebuf, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_DM_CONNECT_FAILED, 0, 0, ebuf.pin_err);

		PIN_FLIST_LOG_ERR("fm_tab_utils_common_init pcm_context_open err", 
				&ebuf);

		*errp = PIN_ERR_NAP_CONNECT_FAILED;
		return;
	}

	pdp = PCM_GET_USERID(ctxp);
	database = PIN_POID_GET_DB(pdp);
	PIN_POID_DESTROY(pdp, NULL);

	/***********************************************************
	 * Load custom beid mapping information
	 ***********************************************************/
	fm_tab_utils_common_init_load_config_policy_label_map_flist( ctxp, database, &ebuf );

	fm_tab_utils_common_init_load_config_tab_package_descr_flist( ctxp, database, &ebuf );
	fm_tab_utils_common_init_load_beid( ctxp, database, &ebuf );
	fm_tab_utils_common_init_load_recharge_valid_states( ctxp, database, &ebuf );

	fm_tab_utils_common_init_system_currency();
	fm_tab_utils_common_init_load_product(ctxp,database,&ebuf);
	fm_tab_utils_common_init_get_deals(ctxp,database,&ebuf);

	PCM_CONTEXT_CLOSE(ctxp, 0, &ebuf);
	*errp = ebuf.pin_err;
	return;
}

/***********************************************************************
 * fm_tab_utils_common_init_load_config_tab_package_descr_flist
 *
 * Frame the global flist with custom config package descr details
 ***********************************************************************/
	void
fm_tab_utils_common_init_load_config_tab_package_descr_flist(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{
	poid_t			*search_poidp = NULL;
	poid_t			*prod_lang_poidp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	int32			flags = SRCH_EXACT;
	char			search_template[PCM_FLIST_HEAP_SIZE] =
	{"select X from /config where F1 = V1 "};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	/* Create Search flist */
	search_in_flistp = PIN_FLIST_CREATE(ebufp);

	search_poidp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, 
			search_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, 
			search_template, ebufp);

	prod_lang_poidp = PIN_POID_CREATE(database, 
			"/config/tab_package_descr", -1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, 
			PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, prod_lang_poidp, ebufp);
	PIN_FLIST_ELEM_SET(search_in_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_config_tab_package_descr_flist() "
			"error loading /config/tab_package_descr object",
			ebufp);
		goto cleanup;
	}

	res_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, 
			PIN_ELEMID_ANY, 1, ebufp);

	if(res_flistp != NULL) {
		//cfg_tab_package_descr_flistp = PIN_FLIST_CREATE(ebufp);
		cfg_tab_package_descr_flistp = PIN_FLIST_COPY(res_flistp, ebufp);
	}

	/* cleanup activity  */
	cleanup:
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	/***************************************************
	 * Debug: cfg_tab_package_descr_flistp.
	 ***************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_config_tab_package_descr_flist() "
		"config package descr global flist", cfg_tab_package_descr_flistp);
	return;
}


/***********************************************************************
 * fm_tab_utils_common_init_load_config_policy_label_map_flist
 *
 * Frame the global flist with custom config policy label map details
 ***********************************************************************/
void
fm_tab_utils_common_init_load_config_policy_label_map_flist(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{
	poid_t			*search_poidp = NULL;
	poid_t			*policy_label_poidp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	int32			flags = SRCH_EXACT;
	char			search_template[PCM_FLIST_HEAP_SIZE] =
	{"select X from /config where F1 = V1 "};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	/* Create Search flist */
	search_in_flistp = PIN_FLIST_CREATE(ebufp);

	search_poidp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, 
			search_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, 
			search_template, ebufp);

	policy_label_poidp = PIN_POID_CREATE(database, 
			"/config/tab_offer_policy_label_map", -1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, 
			PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, policy_label_poidp, ebufp);
	PIN_FLIST_ELEM_SET(search_in_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_config_policy_label_map_flist() "
			"error loading /config/tab_offer_policy_label_map object",
			ebufp);
		goto cleanup;
	}

	res_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, 
			PIN_ELEMID_ANY, 1, ebufp);

	if(res_flistp != NULL) {
		//cfg_tab_policy_label_map_flistp = PIN_FLIST_CREATE(ebufp);
		cfg_tab_policy_label_map_flistp = PIN_FLIST_COPY(res_flistp, ebufp);
	}

	/* cleanup activity  */
	cleanup:
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	/***************************************************
	 * Debug: cfg_tab_policy_label_map_flistp.
	 ***************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_config_policy_label_map_flist() "
		"config policy label mapping global flist", cfg_tab_policy_label_map_flistp);
	return;
}


/***********************************************************************
* fm_tab_utils_common_init_load_beid
*
* Frame the global flist with custom config policy label map details
***********************************************************************/
void
fm_tab_utils_common_init_load_beid(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	/* Create beid flist list */
	config_beid_out_flistp=pin_conf_beid(ctxp,ebufp);
	/***************************************************
	* Debug: cfg_tab_policy_label_map_flistp.
	***************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_beid() "
		"fm_tab_utils_common_init_load_beid", config_beid_out_flistp);
	return;
}



/***********************************************************************
* fm_tab_utils_common_init_load_product
*
* Frame the global flist with system level products, discount and sponsership
***********************************************************************/
void
fm_tab_utils_common_init_load_product(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{

	poid_t			*search_poidp = NULL;
	poid_t			*account_poidp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	int32			flags = SRCH_EXACT;
	int 			type=602;
	char			*search_template="select X from /product where F1 != V1 ";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_product() "
		"return flist", cfg_tab_system_prod_flistp);
	/* Create Search flist */
	search_in_flistp = PIN_FLIST_CREATE(ebufp);

	search_poidp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID,search_poidp, ebufp);
	account_poidp = PIN_POID_CREATE(database,"/account",1, ebufp);

	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE,(void *)search_template, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp,PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_TYPE,&type,ebufp);

	results_flistp=PIN_FLIST_ELEM_ADD(search_in_flistp,PIN_FLD_RESULTS,0,ebufp);
	PIN_FLIST_FLD_SET(results_flistp, PIN_FLD_POID,NULL,ebufp);
	PIN_FLIST_FLD_SET(results_flistp, PIN_FLD_NAME,NULL,ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_product: "
			"error in loading the product",
			ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_RENAME(search_out_flistp,PIN_FLD_RESULTS, PIN_FLD_PRODUCTS,ebufp);
	cfg_tab_system_prod_flistp=PIN_FLIST_COPY(search_out_flistp,ebufp);

	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	search_template ="select X from /discount where F1 != V1 ";

	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE,
			search_template, ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_product: "
			"error in loading the discount",
			ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_RENAME(search_out_flistp,PIN_FLD_RESULTS, PIN_FLD_DISCOUNTS,ebufp);
	PIN_FLIST_CONCAT(cfg_tab_system_prod_flistp,search_out_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	search_template ="select X from /sponsorship where F1 = V1 ";

	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE,
			search_template, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE,search_template, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp,PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp,PIN_FLD_ACCOUNT_OBJ,account_poidp,ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH,0,search_in_flistp,&search_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_product: "
			"error in loading the search",
			ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_RENAME(search_out_flistp,PIN_FLD_RESULTS, PIN_FLD_SPONSORS,ebufp);
	PIN_FLIST_CONCAT(cfg_tab_system_prod_flistp,search_out_flistp,ebufp);


	/* cleanup activity  */
	cleanup:

	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_product() "
		"return flist", cfg_tab_system_prod_flistp);
	return;
}

/***********************************************************************
 * fm_tab_utils_common_init_load_recharge_valid_states
 *
 * Frame the global flist with custom config recharge valid states
 ***********************************************************************/
void
fm_tab_utils_common_init_load_recharge_valid_states(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{
	poid_t			*search_poidp = NULL;
	poid_t			*cfg_poidp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	int32			flags = SRCH_EXACT;
	char			search_template[PCM_FLIST_HEAP_SIZE] =
				{"select X from /config where F1 = V1 "};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	/* Create Search flist */
	search_in_flistp = PIN_FLIST_CREATE(ebufp);

	search_poidp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID,
		search_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE,
		search_template, ebufp);

	cfg_poidp = PIN_POID_CREATE(database,
		"/config/tab_prepaid_subscriber_recharge_states", -1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp,
		PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, cfg_poidp, ebufp);
	PIN_FLIST_ELEM_SET(search_in_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_load_recharge_valid_states: "
			"error loading /config/tab_prepaid_subscriber_recharge_states object",
			ebufp);
		goto cleanup;
	}

	res_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS,
	PIN_ELEMID_ANY, 1, ebufp);

	if(res_flistp != NULL) {

		cfg_tab_prepaid_sub_states_flistp = PIN_FLIST_COPY(res_flistp, ebufp);
	}

	/* cleanup activity  */
	cleanup:
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	/***************************************************
	 * Debug: cfg_tab_prepaid_sub_states_flistp.
	 ***************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_load_recharge_valid_states: "
		"config prepaid recharge subscriber status flist", cfg_tab_prepaid_sub_states_flistp);
	return;
}


/***********************************************************************
 * fm_tab_utils_common_init_system_currency
 *
 * Fetch the system level currency
 ***********************************************************************/
void
fm_tab_utils_common_init_system_currency()
{
	int32		err = PIN_ERR_NONE;
	int32		*sys_currency = NULL;

	/***************************************************************
	 * read entry from pin.conf
	 ***************************************************************/
	pin_conf( FM_CUST_POL, "currency", PIN_FLDT_INT, (caddr_t *)&sys_currency, &err );

	if( err != PIN_ERR_NONE || sys_currency == NULL )
	{
		/***************************************************************
		 * FM_COUNTRY_TOKEN not well defined
		 ***************************************************************/
		PIN_ERR_LOG_MSG( PIN_ERR_LEVEL_DEBUG, " fm_tab_utils_common_init_system_currency "
				"System Currency Not Found" );
	}
	else
	{
		PIN_ERR_LOG_MSG( PIN_ERR_LEVEL_DEBUG, " fm_tab_utils_common_init_system_currency "
				"System Currency Found" );
		cfg_tab_system_currency = sys_currency;
	}

	return;
}

/***********************************************************************
* fm_tab_utils_common_init_get_deals
*
* Frame the global flist to get bundles
***********************************************************************/
void
fm_tab_utils_common_init_get_deals(
	pcm_context_t		*ctxp,
	int64			database,
	pin_errbuf_t		*ebufp)
{
	poid_t		*search_poidp = NULL;
	poid_t			*deal_pdp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	int32			flags = SRCH_DISTINCT;
	char			*search_template="select X from /deal where F1 = V1 ";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_get_deals return flist", cfg_tab_system_get_deal_flistp);

	/* Create Search flist */
	search_in_flistp = PIN_FLIST_CREATE(ebufp);

	search_poidp = PIN_POID_CREATE(database, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID,search_poidp, ebufp);

	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, (void *)search_template, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	deal_pdp = PIN_POID_CREATE(database, "/deal", -1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, deal_pdp, ebufp);

	results_flistp=PIN_FLIST_ELEM_ADD(search_in_flistp,PIN_FLD_RESULTS,0,ebufp);
	PIN_FLIST_FLD_SET(results_flistp, PIN_FLD_POID,NULL,ebufp);
	PIN_FLIST_FLD_SET(results_flistp, PIN_FLD_NAME,NULL,ebufp);
	PIN_FLIST_FLD_SET(results_flistp, PIN_FLD_DESCR,NULL,ebufp);

	/***********************************************************
	 * Do the database search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_init_get_deals:error in loading bundles", ebufp);
		goto cleanup;
	}
	if(PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp) != NULL)
    {
        cfg_tab_system_get_deal_flistp = PIN_FLIST_COPY(search_out_flistp,ebufp);
    }

cleanup:
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_init_get_deals return flist", cfg_tab_system_get_deal_flistp);
	return;
}
