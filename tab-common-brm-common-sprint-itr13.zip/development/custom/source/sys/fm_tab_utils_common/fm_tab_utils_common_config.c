/*******************************************************************************
*
*	This material is the confidential property of Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date       | Programmer  | Req/bug/Gap   | Change details
*
* 1  | 18-OCT-2021 | Oracle   | 		| New File.
*													
**************************************************************************************************/

#include <stdio.h>      /* for FILE * in pcm.h */
#include "ops/cust.h"
#include "pcm.h"
#include "cm_fm.h"
#include "pcm_ops.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_utils_common_config_func();
#endif

/*******************************************************************
 * NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 * AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 * OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 *******************************************************************/

struct cm_fm_config fm_tab_utils_common_config[] = {
	/* opcode as a u_int, function name (as a string) */
	{ TAB_OP_UTILS_COMMON_MANAGE_ORDER,       "op_tab_utils_common_manage_order", CM_FM_OP_OVERRIDABLE },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_utils_common_config()
{
  return ((void *) (fm_tab_utils_common_config));
}
#endif
