/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *					| 1		| 18-OCT-2021	| Darshan			|				| New file.
 *					| 2		| 10/Nov/2021	| Rahul Honnaiah	|				| Modified the file to handle
 *													| for order creation/Update.

 *************************************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_error.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include "tab_common.h"
#include "tab_ops_flds.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_error.c"

/*************************************************
 *	*  *Global routines contained within
 ************************************************/
void fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			error_clear_flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/************************************************************
 * fm_tlc_utils_common_request_set_error()
 * This function will be used to retrieve the error message
 * for default and custom error codes
 * @param ctxp The context pointer.
 * @param err_flistpp The input flist.
 * @param ebufp The error buffer.
 *
 *********************************************************/ 
void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			error_clear_flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*errorField = NULL;
	char			errorMsg[1024] = "";
	char			log_msg[512]="";
	int			status = TAB_FAIL;
	int32			errorCode = 0;
	int32			errorLoc = 0;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*r_poidp = NULL;
	pin_errbuf_t		local_ebuf = {0} ;
	pin_errbuf_t		*local_ebufp = &local_ebuf;
	char			*error_msg = NULL;
	char			*description = NULL;
	int32			i = 0;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_request_set_error input flist", i_flistp);
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_utils_common_request_set_error Error flist", *err_flistpp);

	memset(errorMsg, '\0', sizeof(errorMsg));

	errorField = (char *)PIN_FIELD_GET_NAME(ebufp->field);
	errorCode = ebufp->pin_err;
	errorLoc = ebufp->location;

	if(error_clear_flag)
	{
		PIN_ERR_CLEAR_ERR(ebufp);
	}

	sprintf(log_msg,"%d",errorCode);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	r_flistp = PIN_FLIST_CREATE(local_ebufp);
	r_poidp = PIN_POID_CREATE(db_no, "/account", -1, local_ebufp);
	PIN_FLIST_FLD_PUT(r_flistp, PIN_FLD_POID, r_poidp, local_ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, local_ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, local_ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, local_ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, local_ebufp);
	PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, local_ebufp);


	if(errorCode < 1000 && customErrorCode == 0)
	{

		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, local_ebufp);
		switch(errorLoc)
		{
			case PIN_ERRLOC_CM:
				strncpy(errorMsg, TAB_ERR_MSG_CM_ERROR, strlen(TAB_ERR_MSG_CM_ERROR));
				break;

			case PIN_ERRLOC_DM:

				switch (errorCode)
				{
					case PIN_ERR_NOT_FOUND:
						strncpy(errorMsg, TAB_ERR_MSG_BAD_VALUE, strlen(TAB_ERR_MSG_BAD_VALUE));
						errorField = (char *)PIN_FIELD_GET_NAME(PIN_FLD_POID);
						strncat(errorMsg, errorField, strlen(errorField));
						break;


					default:
						strncpy(errorMsg, TAB_ERR_MSG_DM_ERROR, strlen(TAB_ERR_MSG_DM_ERROR));
						strncat(errorMsg, errorField, strlen(errorField));
						break;
				}

				break;

			case PIN_ERRLOC_FM:

				switch (errorCode)
				{

					case PIN_ERR_BAD_VALUE:
						strncpy(errorMsg, TAB_ERR_MSG_BAD_VALUE, strlen(TAB_ERR_MSG_BAD_VALUE));
						strncat(errorMsg, errorField, strlen(errorField));
						break;
					case PIN_ERR_BAD_OPCODE:
						strncpy(errorMsg, TAB_ERR_MSG_BAD_VALUE, strlen(TAB_ERR_MSG_BAD_VALUE));
						strncat(errorMsg, errorField, strlen(errorField));
						break;
					case PIN_ERR_DUPLICATE:
						strncpy(errorMsg, TAB_ERR_DUPLICATE, strlen(TAB_ERR_DUPLICATE));
						strncat(errorMsg, errorField, strlen(errorField));
						break;

					default:
						strncpy(errorMsg, TAB_ERR_MSG_UNKNOWN_ERR, strlen(TAB_ERR_MSG_UNKNOWN_ERR));
						strncat(errorMsg, errorField, strlen(errorField));
						break;
				}

				break;

			case PIN_ERRLOC_FLIST:

				switch (errorCode)
				{
					case PIN_ERR_NONE:
					case PIN_ERR_MISSING_ARG:
					case PIN_ERR_NOT_FOUND:
						strncpy(errorMsg, TAB_ERR_MSG_MISSING_ARG, strlen(TAB_ERR_MSG_MISSING_ARG));
						strncat(errorMsg, errorField, strlen(errorField));
						break;

					default:
						strncpy(errorMsg, TAB_ERR_MSG_UNKNOWN_ERR, strlen(TAB_ERR_MSG_UNKNOWN_ERR));
						break;
				}
				break;

			default:
				strncpy(errorMsg, TAB_ERR_MSG_UNKNOWN_ERR, strlen(TAB_ERR_MSG_UNKNOWN_ERR));
				break;
		}
	}else{
		
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, local_ebufp);
		for (i=0;; i++)
		{
			if (tab_err_codes_list[i].error_code == 0) 
			{
				description = "Unknown Error Description";
				break;
			} else if (errorCode == tab_err_codes_list[i].error_code) 
			{
				description = tab_err_codes_list[i].error_desc;
				break;
			}
		}
	}
	if(*err_flistpp)
	{
		error_msg = PIN_FLIST_FLD_GET(*err_flistpp, PIN_FLD_ERROR_DESCR, 1, local_ebufp);
	}
	if(error_msg && !(strlen(error_msg) == 0))
	{
		if(r_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(*err_flistpp, PIN_FLD_ERROR_DESCR, r_flistp,
				PIN_FLD_ERROR_DESCR, ebufp);
		}
	}	
	else
	{
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, description, local_ebufp);
	}
	PIN_FLIST_DESTROY_EX(err_flistpp, NULL);
    *err_flistpp = PIN_FLIST_COPY(r_flistp, local_ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_request_set_error return flist", *err_flistpp);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;
}
