/*******************************************************************************************************

 *
 *      This material is the confidential property of Oracle Corporation or its
 *      licensors and may be used, reproduced, stored or transmitted only in
 *      accordance with a valid Oracle license or sublicense agreement.
 *
 ******************************************************************************************************/
/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah            |                       | To manage transaction and orders 
 *
 *********************************************************************************/

#include <stdio.h>
#include <time.h>
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained herein.
 *******************************************************************/
int32
fm_tab_utils_common_trans_abort(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

int32
fm_tab_utils_common_trans_commit(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

int32
fm_tab_utils_common_global_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern Functions */
extern void
fm_tab_utils_common_get_tab_order_after(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_update_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	poid_t			*tab_order_pdp,
	int32			*errorCode,
	char			*errorMsg,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_create_tab_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	int32			exception_flag,
	int32			*errorCode,
	char			*errorMsg,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,	
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/***********************************************************
 * fm_tab_utils_common_trans_open ()
 * This function will open a transaction and return 
 * 0 if successfull or 1 if failed.
 *
 * @param ctxp The context pointer.
 * @param pdp.
 * @param ebufp The error buffer.
 * @return int value 0 or 1.
***********************************************************/
int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*o_trans_flistp  = NULL;
	pin_flist_t		*i_trans_flistp = NULL;
	int32			return_val = 0;
	int32			cerror_code = 0;
	char			log_msg[512] = "";

	i_trans_flistp = PIN_FLIST_CREATE( ebufp );
	PIN_FLIST_FLD_SET(i_trans_flistp, PIN_FLD_POID, pdp, ebufp);

	PCM_OP(ctxp, PCM_OP_TRANS_OPEN, PCM_TRANS_OPEN_READWRITE, i_trans_flistp, &o_trans_flistp, ebufp );
	if (PIN_ERRBUF_IS_ERR(ebufp))
	{
		cerror_code = ebufp->pin_err;
		if(cerror_code == PIN_ERR_TRANS_ALREADY_OPEN )
		{
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_ERR_CLEAR_ERR(ebufp);
			return_val = 0;
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST( PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_trans_open : "
				"Error while openning a transaction", i_trans_flistp);
			PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_trans_open : "
				"Error while openning a transaction", ebufp);
			return_val = 1;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_open: Transaction Opened!!!");
		return_val = 0;
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&i_trans_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&o_trans_flistp, NULL);
	return return_val;
}

/***********************************************************
 * fm_tab_utils_common_trans_commit ()
 * This function will commit a transaction and return 
 * 0 if successfull or 1 if failed.
 *
 * @param ctxp The context pointer.
 * @param pdp.
 * @param ebufp The error buffer.
 * @return int value 0 or 1.
***********************************************************/
int32
fm_tab_utils_common_trans_commit(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*o_trans_flistp  = NULL;
	pin_flist_t		*i_trans_flistp = NULL;
	int32			return_val = 0;

	i_trans_flistp = PIN_FLIST_CREATE( ebufp );
	PIN_FLIST_FLD_SET(i_trans_flistp, PIN_FLD_POID, pdp, ebufp);

	PCM_OP(ctxp, PCM_OP_TRANS_COMMIT, PCM_TRANS_OPEN_READWRITE, i_trans_flistp, &o_trans_flistp, ebufp );
	if (PIN_ERRBUF_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_commit : "
			"Error while commiting a transaction", i_trans_flistp);
		PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_commit : "
			"Error while commiting a transaction", ebufp);
		return_val = 1;
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_commit: Transaction Commited!!!");
		return_val = 0;
	}

	PIN_FLIST_DESTROY_EX(&i_trans_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&o_trans_flistp, NULL);
	return return_val;
}


/***********************************************************
 * fm_tab_utils_common_trans_abort ()
 * This function will abort a transaction and return 
 * 0 if successfull or 1 if failed.
 *
 * @param ctxp The context pointer.
 * @param pdp.
 * @param ebufp The error buffer.
 * @return int value 0 or 1.
***********************************************************/
int32
fm_tab_utils_common_trans_abort(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*o_trans_flistp  = NULL;
	pin_flist_t		*i_trans_flistp = NULL;
	int32			return_val = 0;
	pin_errbuf_t		local_ebuf;
	pin_errbuf_t		*local_ebufp = &local_ebuf;


	PIN_ERR_CLEAR_ERR(local_ebufp);

	i_trans_flistp = PIN_FLIST_CREATE( local_ebufp);
	PIN_FLIST_FLD_SET(i_trans_flistp, PIN_FLD_POID, pdp, local_ebufp);

	if(pcm_trans_state(ctxp)){
		PCM_OP(ctxp, PCM_OP_TRANS_ABORT, PCM_TRANS_OPEN_READWRITE, i_trans_flistp, 
			&o_trans_flistp, local_ebufp );
	}
	if (PIN_ERRBUF_IS_ERR(local_ebufp))
	{
		PIN_ERR_LOG_FLIST( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_abort : "
			"Error while aborting a transaction", i_trans_flistp);
		PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_abort : "
			"Error while aborting a transaction", local_ebufp);
		return_val = 1;
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_abort: Transaction Aborted!!!");
		return_val = 0;
	}

	/*PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_abort :"
		" Error buffer is set from the parent opcode. Preserving the parent error buffer error.", ebufp); */

	PIN_FLIST_DESTROY_EX(&i_trans_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&o_trans_flistp, NULL);
	return return_val;
}

void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*tab_order_oflistp = NULL;
	pin_flist_t		*manage_tab_order_oflistp = NULL;
	pin_flist_t		*results_tab_order_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	poid_t			*tab_order_pdp = NULL;
	int32			*statusp = NULL;
	int32			*exception_flagp = NULL;
	int32			*tab_order_flag = NULL;
	int			abort_flag = 0;
	int			commit_flag = 0;
	int			create_order_flag = 0;
	int			update_order_flag = 0;
	int			duplicate_order_flag = 0;
	pin_errbuf_t		local_ebuf = {0} ;
	pin_errbuf_t		*local_ebufp = &local_ebuf;

	char			*corr_id = NULL;
	char			*extern_user = NULL;
	char			log_msg[512]="";
	int32			*errorCode = NULL;
	char			*errorMsg = NULL;
	int32			error_clear_flag = 0;
	int32			customErrorCode = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order error", ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_trans_manage_order input", i_flistp);

	tab_order_flag = (int32 *) PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_EXCEPTION_FLAG, 1, local_ebufp);
	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, local_ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, local_ebufp);

	sprintf(log_msg, "tab_order_flag is %d", *tab_order_flag);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/*Search for /tab_order object*/
	fm_tab_utils_common_get_tab_order_after(ctxp, i_flistp, &tab_order_oflistp, db_no, local_ebufp);
	if(PIN_ERR_IS_ERR(local_ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" Error while searching /tab_order object", local_ebufp);
		abort_flag = 1;
		create_order_flag = 0;
		update_order_flag = 0;
		if(!PIN_ERR_IS_ERR(ebufp))
		{
			ebufp = &local_ebuf;
		}
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_manage_order:"
			" tab_order_flistp flist", tab_order_oflistp);
	
	if ( tab_order_oflistp != NULL && (results_tab_order_flistp = PIN_FLIST_ELEM_GET(tab_order_oflistp, 
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, local_ebufp)) != NULL)
	{
	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_manage_order:"
			" results_tab_order_flistp flist", results_tab_order_flistp);

		tab_order_pdp = PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_POID, 1, local_ebufp);
		statusp = (int32 *) PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_STATUS, 1, local_ebufp);
		exception_flagp = (int32 *) PIN_FLIST_FLD_GET(results_tab_order_flistp, PIN_FLD_FLAGS, 1, local_ebufp);

		sprintf(log_msg,"*statusp, *exception_flagp, *tab_order_flag, status %d %d %d %d", 
			*statusp, *exception_flagp, *tab_order_flag, status);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(statusp && *statusp == TAB_ORDER_FAILURE && exception_flagp && 
		*tab_order_flag != *exception_flagp && status == 1)
		{
			//abort_transaction
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 1: Abort");
			abort_flag = 1;
			commit_flag = 0;
			create_order_flag = 0;
			update_order_flag = 0;
			duplicate_order_flag = 0;
			goto cleanup;
		}
		else if(statusp && *statusp == TAB_ORDER_FAILURE && exception_flagp && 
		*tab_order_flag != *exception_flagp && status == 0)
		{
			//abort_transaction
			//update order with new error code and descr
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 2: Abort and Update Order");
			abort_flag = 1;
			commit_flag = 0;
			create_order_flag = 0;
			update_order_flag = 1;
			duplicate_order_flag = 0;
			goto cleanup;
		}
		else if(statusp && *statusp == TAB_ORDER_FAILURE && exception_flagp && 
		*tab_order_flag == *exception_flagp && status == 1)
		{
			//update order 
			//commit_transaction
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 3:Update Order and Commit");
			abort_flag = 0;
			commit_flag = 1;
			create_order_flag = 0;
			update_order_flag = 1;
			duplicate_order_flag = 0;
			goto cleanup;
		}
		else if(statusp && *statusp == TAB_ORDER_FAILURE && exception_flagp && 
		*tab_order_flag == *exception_flagp && status == 0)
		{
			//abort_transaction
			//update order with new error code and descr
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 4: Abort and Update Order");
			abort_flag = 1;
			commit_flag = 0;
			create_order_flag = 0;
			update_order_flag = 1;
			duplicate_order_flag = 0;
			goto cleanup;
		}
		else if(statusp && *statusp == TAB_ORDER_SUCCESS && (status == 1 || status == 0))
		{
			//abort_transaction
			//send duplicate order
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 5:Abort and Duplicate Order");
			abort_flag = 1;
			commit_flag = 0;
			create_order_flag = 0;
			update_order_flag = 0;
			duplicate_order_flag = 2;
			goto cleanup;
		}
	}
	else
	{

		if(corr_id && extern_user)
		{
			create_order_flag = 1;
			update_order_flag = 0;
			duplicate_order_flag = 0;
		}
		else
		{
			create_order_flag = 0;
			update_order_flag = 0;
			duplicate_order_flag = 0;
		}

		if(status)
		{
			//create_order
			//commit_transaction
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 6: Create Order and Commit");
			abort_flag = 0;
			commit_flag = 1;
			goto cleanup;
		}
		else
		{
			//commit_transaction
			//create_order
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Enter Condition 7: Commit and Create Order");
			abort_flag = 1;
			commit_flag = 0;
			goto cleanup;
		}
	}

cleanup:
	if( abort_flag )
	{
		// Added correrlation id to handle transaction during MTA/external calls
		if(corr_id && fm_tab_utils_common_trans_abort(ctxp, account_pdp, ebufp))
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				"Aborting transaction failed") ;
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ABORT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_trans_manage_order:"
				" Error while aborting the transaction", ebufp);
		}
		sprintf(log_msg,"error_clear_flag is %d",error_clear_flag);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		fm_tab_utils_common_request_set_error(ctxp, i_flistp, error_clear_flag, customErrorCode, 
			&r_flistp, db_no, ebufp);
		if(r_flistp)
		{
			errorCode = (int32 *) PIN_FLIST_FLD_GET(r_flistp, PIN_FLD_ERROR_CODE, 1, local_ebufp);
			errorMsg = (char *) PIN_FLIST_FLD_GET(r_flistp, PIN_FLD_ERROR_DESCR, 1, local_ebufp);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "errorMsg");
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, errorMsg);
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" fm_tab_utils_common_request_set_error output flist ", r_flistp);
		if(create_order_flag)
		{
			/*Tab order creation in case of failure*/
			fm_tab_utils_common_create_tab_order(ctxp, i_flistp, TAB_ORDER_FAILURE, *tab_order_flag,
				errorCode, errorMsg, opcode_name, &manage_tab_order_oflistp, db_no, local_ebufp);
			if(PIN_ERR_IS_ERR(local_ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
						" create tab_order input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
						" Error while creating /tab_order object", local_ebufp);
				if(!PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_FAILED_ORDER_CREATION, 0, 0, 0);
				}
			}
		}
		if(update_order_flag)
		{
			/*Update tab order in case of failure*/
			fm_tab_utils_common_update_tab_order(ctxp, i_flistp, TAB_ORDER_FAILURE, *exception_flagp,
				tab_order_pdp, errorCode, errorMsg, &manage_tab_order_oflistp, local_ebufp);

			if(PIN_ERR_IS_ERR(local_ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" create tab_order input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" Error while creating /tab_order object", local_ebufp);
				if(!PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_FAILED_ORDER_UPDATION, 0, 0, 0);
				}
			}
		}
		if(duplicate_order_flag == 2)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUPLICATE_ORDER, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" create tab_order input flist ", i_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" Duplicate tab_order ", ebufp);
		}
	}
	if( commit_flag )
	{
		if(update_order_flag)
		{
			/*Update tab order in case of failure*/
			fm_tab_utils_common_update_tab_order(ctxp, i_flistp, TAB_ORDER_SUCCESS, *exception_flagp,
				tab_order_pdp, errorCode, errorMsg, &manage_tab_order_oflistp, local_ebufp);

			if(PIN_ERR_IS_ERR(local_ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" create tab_order input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" Error while creating /tab_order object", local_ebufp);
				abort_flag = 2;
				commit_flag = 0;
				if(!PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_ORDER_UPDATION, 0, 0, 0);
				}
			}
		}
		if(create_order_flag)
		{
			/*Tab order creation*/
			fm_tab_utils_common_create_tab_order(ctxp, i_flistp, TAB_ORDER_SUCCESS, *tab_order_flag,
				errorCode, errorMsg, opcode_name, &manage_tab_order_oflistp, db_no, local_ebufp);
			if(PIN_ERR_IS_ERR(local_ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" Error while creating /tab_order object", local_ebufp);
				abort_flag = 2;
				commit_flag = 0;
				if(!PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_ORDER_CREATION, 0, 0, 0);
				}
			}
		}

		// Publish Notification 
		if (*r_flistpp)
		{
			notify_flistp = PIN_FLIST_ELEM_GET(*r_flistpp, TAB_FLD_NOTIFICATION,
								PIN_ELEMID_ANY, 1, local_ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_trans_manage_order:"
				" Notification flist ", notify_flistp);
		}
		if (notify_flistp )
		{
			PCM_OP(ctxp, PCM_OP_PUBLISH_GEN_PAYLOAD, 0, notify_flistp, &notify_oflistp, local_ebufp);
			if(PIN_ERR_IS_ERR(local_ebufp))
			{
				PIN_ERR_LOG_FLIST( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_manage_order: : "
					"Error while PCM_OP_PUBLISH_GEN_PAYLOAD transaction", notify_flistp);
				PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, " fm_tab_utils_common_trans_manage_order: : "
					"Error while notify_flistp transaction", local_ebufp);
				abort_flag = 2;
				commit_flag = 0;
				if(!PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_PUBLISH_NOTIFICATION, 0, 0, 0);
				}
			}
		}

		if(commit_flag)
		{
			if(corr_id && fm_tab_utils_common_trans_commit( ctxp, account_pdp, ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_TRANS_COMMIT, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_trans_manage_order:"
					"Error while commiting the transaction", ebufp);
					
				fm_tab_utils_common_request_set_error(ctxp, i_flistp, error_clear_flag, customErrorCode,
					&r_flistp, db_no, ebufp);
				
				*r_flistpp=PIN_FLIST_COPY(r_flistp,local_ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
						" fm_tab_utils_common_request_set_error output flist ", *r_flistpp);
			} 
		}
		if(abort_flag == 2)
		{
			if(corr_id && fm_tab_utils_common_trans_abort(ctxp, account_pdp, ebufp))
			{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					"Aborting transaction failed") ;
				pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_TRANS_ABORT, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_trans_manage_order:"
					" Error while aborting the transaction", ebufp);
			}

		}
	}

	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&manage_tab_order_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&tab_order_oflistp, NULL);
	return;
}


/***********************************************************
 * fm_tab_utils_common_global_trans_open ()
 * This function will open a transaction and return 
 * 0 if successfull or 1 if failed.
 *
 * @param ctxp The context pointer.
 * @param pdp.
 * @param ebufp The error buffer.
 * @return int value 0 or 1.
***********************************************************/
int32
fm_tab_utils_common_global_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*o_trans_flistp  = NULL;
	pin_flist_t		*i_trans_flistp = NULL;
	int32			return_val = 0;
	int32			cerror_code = 0;
	char			log_msg[512] = "";
	int32			s_flags = PCM_TRANS_OPEN_READWRITE|PCM_TRANS_OPEN_GLOBALTRANSACTION;

	i_trans_flistp = PIN_FLIST_CREATE( ebufp );
	PIN_FLIST_FLD_SET(i_trans_flistp, PIN_FLD_POID, pdp, ebufp);

	PCM_OP(ctxp, PCM_OP_TRANS_OPEN, s_flags, i_trans_flistp, &o_trans_flistp, ebufp );
	if (PIN_ERRBUF_IS_ERR(ebufp))
	{
		cerror_code = ebufp->pin_err;
		if(cerror_code == PIN_ERR_TRANS_ALREADY_OPEN )
		{
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_ERR_CLEAR_ERR(ebufp);
			return_val = 0;
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST( PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_global_trans_open : "
				"Error while openning a Global transaction", i_trans_flistp);
			PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_global_trans_open : "
				"Error while openning a Global transaction", ebufp);
			return_val = 1;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_global_trans_open: Global Transaction Opened!!!");
		return_val = 0;
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&i_trans_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&o_trans_flistp, NULL);
	return return_val;
}
