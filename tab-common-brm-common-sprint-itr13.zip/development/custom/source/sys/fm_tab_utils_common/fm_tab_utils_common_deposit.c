/*******************************************************************************
 *
 *	This material is the confidential property of Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date	   | Programmer					| Req/bug/Gap			| Change details
 *
 * 1  | 22/Nov/2021 | Rahul Honnaiah		|						| Billinfo DB Search
 *
 *********************************************************************************/
#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>

#define FILE_SOURCE_ID "fm_tab_utils_common_deposit.c(2)"

/*************************************************
 **	Global routines contained within
 ************************************************/
void
fm_tab_utils_common_get_depositspec_name(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_purchased_deposit_pd(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

/*******************************************************************
 * fm_tab_utils_common_get_depositspec_name()
 *
 *This function will be used to retrieve the deposit spec details 
 * based on spec name
 * @param ctxp The context pointer.
 * @param i_flistp the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_get_depositspec_name (
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *sflist_arg = NULL;
	pin_flist_t             *rflist_arg = NULL;
	poid_t                  *srch_pdp = NULL;
	int32                   s_flags = 256;
	char                    *svc_template="select X from /deposit_specification where F1 = V1";
	char                    *dep_spec_name = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_depositspec_name error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_depositspec_name:"
			"input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_depositspec_name input", i_flistp);
	dep_spec_name = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_NAME, 1, ebufp);

	search_flistp = PIN_FLIST_CREATE(ebufp);
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1,ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, svc_template, ebufp);

	sflist_arg = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(sflist_arg, PIN_FLD_NAME, dep_spec_name, ebufp);

	rflist_arg = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_SEARCH:input flist", search_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &res_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_depositspec_name input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_depositspec_name: Error in getting deposit specification poid", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_depositspec_name output flist", res_flistp);
		*r_flistpp = res_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}


void
fm_tab_utils_common_get_purchased_deposit_pd(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*sflist_arg = NULL;
	pin_flist_t		*rflist_arg = NULL;
	poid_t			*srch_pdp = NULL;
	int32			s_flags = 256;
	char			*svc_template="select X from /purchased_deposit where F1 = V1 and F2=V2";
		poid_t			*dep_spec_pd = NULL;
		pin_flist_t		*acct_obj = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_deposit_pd error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_deposit_pd:"
			"input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_purchased_deposit_pd input", i_flistp);

	dep_spec_pd = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);
	acct_obj = PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

	search_flistp = PIN_FLIST_CREATE(ebufp);
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1,ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, svc_template, ebufp);

	sflist_arg = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(sflist_arg, PIN_FLD_DEPOSIT_SPEC_OBJ, dep_spec_pd, ebufp);

	sflist_arg = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(sflist_arg, PIN_FLD_ACCOUNT_OBJ,acct_obj, ebufp);

	rflist_arg = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_SEARCH:input flist", search_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &res_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchased_deposit_pd input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchased_deposit_pd: Error in getting purchased deposit poid", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_purchased_deposit_pd output flist", res_flistp);
		*r_flistpp = res_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}
