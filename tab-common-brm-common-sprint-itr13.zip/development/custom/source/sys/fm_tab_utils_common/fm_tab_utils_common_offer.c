/*********************************************************************
 * * This Utility finds wheather the given acct_no is there
 * * in the DB or not.
 * * It will take acct_no as an input argument and it will give
 * * the result in PIN_FLD_POID field.
 *********************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_subscr.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <pin_subscription.h>
#include "ops/subscription.h"
#include "ops/rate.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "tab_utils_common.h"

#define FILE_SOURCE_ID "fm_tab_utils_common_subscr.c(2)"
extern pin_flist_t  *cfg_tab_system_get_deal_flistp;

/*************************************************
 *	*  *Global routines contained within
 ************************************************/

void
fm_tab_utils_common_get_discount_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_product_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_deal_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_plan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_bundle_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_offering_details(
		pcm_context_t 	*ctxp,
		poid_t         	*account_pdp,
		pin_flist_t     **out_flistpp,
		int64		db_no,
		pin_errbuf_t    *ebufp);

extern void
fm_tab_utils_common_read_object(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
	
	
void
fm_tab_utils_common_get_rate_plan_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_get_purchase_bundle_dtls(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_read_product_cache(
        pcm_context_t           *ctxp,
        poid_t                  *product_pdp,
        pin_flist_t             **ret_flistpp,
	int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_read_discount_cache(
        pcm_context_t           *ctxp,
        poid_t                  *discount_pdp,
        pin_flist_t             **ret_flistpp,
	int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_read_deal_cache(
        pcm_context_t           *ctxp,
        poid_t                  *deal_pdp,
        pin_flist_t             **ret_flistpp,
	int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_read_plan_cache(
        pcm_context_t           *ctxp,
        poid_t                  *plan_pdp,
        pin_flist_t             *bundle_rflistp,
        pin_flist_t             **ret_flistpp,
	int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_get_purchased_bundle_details(
        pcm_context_t           *ctxp,
        poid_t                  *acct_pdp,
        pin_flist_t             **r_flistpp,
	int64           	db_no,
        pin_errbuf_t            *ebufp);

/********************************************
 * We use this function to get product
 * object using product name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************/

void
fm_tab_utils_common_get_product_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_product_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_product_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_product_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /product where F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_product_details input flist", search_flistp);

	/***********************************************************
	 *		   * Perform the search.
	 *					***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_product_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_product_details: Error in getting product object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_product_details output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/******************************************
 * We use this function to get discount
 * object using discount name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void
fm_tab_utils_common_get_discount_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_discount_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_discount_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_discount_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /discount where F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_discount_details input flist", search_flistp);

	/***********************************************************
	 *		   * Perform the search.
	 *					***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_discount_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_discount_details: Error in getting discount object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_discount_details output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/******************************************
 * We use this function to get deal
 * object using deal name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 * 
 ********************************************/

void
fm_tab_utils_common_get_deal_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	poid_t			*deal_pdp = NULL;
	char			*name = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_deal_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /deal where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	name = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_NAME, 1, ebufp);
	if (name != NULL)
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_NAME, name, ebufp);
	}
	else
	{
		deal_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);
		if(!PIN_POID_IS_NULL(deal_pdp))
		{
			args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	                PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, deal_pdp, ebufp);
		}
	}

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_DESCR, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PERMITTED, NULL, ebufp);
	PIN_FLIST_ELEM_SET(res_flistp, NULL, PIN_FLD_PRODUCTS, PCM_RECID_ALL, ebufp);
	PIN_FLIST_ELEM_SET(res_flistp, NULL, PIN_FLD_DISCOUNTS, PCM_RECID_ALL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_deal_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_deal_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_deal_details: Error in getting deal object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_deal_details output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/*****************************************
 * We use this function to get plan
 * object using plan name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 * 
 *********************************************/

void
fm_tab_utils_common_get_plan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_plan_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_plan_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_plan_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /plan where F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_plan_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_plan_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_plan_details: Error in getting plan object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_plan_details output flist", r_flistp);
		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}


/*****************************************
 * We use this function to get bundle
 * object using bundle name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 * 
 *********************************************/

void
fm_tab_utils_common_get_bundle_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	int			bundle_status = PIN_BUNDLE_STATUS_CANCELLED;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bundle_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bundle_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_bundle_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &bundle_status, ebufp);
	
	if ((PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_FROM, 1, ebufp) != NULL)
			&& (PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_TO, 1, ebufp) != NULL))
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 != V3 and F4 = V4 and F5 = V5 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_FROM, args_flistp, PIN_FLD_VALID_FROM, ebufp);
		
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_TO, args_flistp, PIN_FLD_VALID_TO, ebufp);
	}
	else
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 != V3 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_TO, NULL, ebufp);
	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_bundle_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_bundle_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_bundle_details: Error in getting purchased bundle object", ebufp);
	}
	
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	*r_flistpp = r_flistp;
	
	return;
}


void 
fm_tab_utils_common_get_offering_details(
	pcm_context_t 	*ctxp,
	poid_t         	*account_pdp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{	

	PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_offering_details input flistp", account_pdp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details:"
				" in_flistp", account_pdp);
		return;
	}

	int 		result_elemid = 0 ;
	pin_cookie_t 	result_cookie= NULL;

	poid_t 		*plan_objp = NULL;
	poid_t 		*product_objp = NULL;
	poid_t 		*discount_objp=NULL;
	poid_t 		*deal_objp = NULL;

	char   		*bundle_namep=NULL;
	pin_flist_t	*read_grantor_oflistp= NULL;
	pin_flist_t	*product_flistp= NULL;
	pin_flist_t 	*result_product_flistp = NULL;
	pin_flist_t	*discount_flistp=NULL;
	pin_flist_t	*result_discount_flistp=NULL;
	char 		*plan_desr=NULL;
	char 		*plan_name=NULL;
	char 		*product_descr=NULL;
	pin_flist_t	*bundle_resflistp = NULL;

	pin_flist_t *search_input_flistp=PIN_FLIST_CREATE(ebufp);;
	pin_flist_t *search_out_flistp=NULL;	
	pin_flist_t *return_flistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_POID, account_pdp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_offering_details input flist", search_input_flistp);	
	PCM_OP(ctxp,PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS,0,search_input_flistp,&search_out_flistp,ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_offering_details out flist", search_out_flistp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details:"
				" in_flistp", search_input_flistp);
		return;
	}

	fm_tab_utils_common_get_purchased_bundle_details(ctxp, account_pdp, &bundle_resflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details error", ebufp);
                PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details:"
                                " account poid", account_pdp);
                goto cleanup;
        }

	while ((result_product_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp, PIN_FLD_PRODUCTS,&result_elemid, 1, &result_cookie, ebufp)) != (pin_flist_t *)NULL)
	{	
		product_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_PRODUCTS,result_elemid,ebufp);				
		PIN_FLIST_FLD_COPY(result_product_flistp, PIN_FLD_OFFERING_OBJ, product_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(result_product_flistp, PIN_FLD_DESCR, product_flistp, TAB_FLD_OFFER_ID, ebufp);

		if ((deal_objp = PIN_FLIST_FLD_GET(result_product_flistp,PIN_FLD_DEAL_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(deal_objp))
		{		
			fm_tab_utils_common_read_deal_cache(ctxp, deal_objp, &read_grantor_oflistp, db_no, ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read deal input", deal_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read plan output", ebufp);
				goto cleanup;						
			}			
			if ((bundle_namep = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(product_flistp,TAB_FLD_BUNDLE_NAME,bundle_namep,ebufp);
			}
			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
		}
		if ((plan_objp = PIN_FLIST_FLD_GET(result_product_flistp,PIN_FLD_PLAN_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(plan_objp) )
		{
			fm_tab_utils_common_read_plan_cache(ctxp, plan_objp, bundle_resflistp, &read_grantor_oflistp, db_no, ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read product input", plan_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read plan output", ebufp);
				goto cleanup;						
			}	

			if ((plan_desr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DESCR,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(product_flistp,TAB_FLD_OFFER_TYPE,plan_desr,ebufp);
			}

			if ((plan_name = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(product_flistp,TAB_FLD_PACKAGE_NAME,plan_name,ebufp);
			}
			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
		}

		if ((product_objp = PIN_FLIST_FLD_GET(result_product_flistp,PIN_FLD_PRODUCT_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(product_objp))
		{
			fm_tab_utils_common_read_product_cache(ctxp, product_objp, &read_grantor_oflistp, db_no, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read product input", product_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read product output", ebufp);
				goto cleanup;						
			}		

			if ((product_descr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(product_flistp,TAB_FLD_OFFER_NAME,product_descr,ebufp);
			}
			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);			
		}
	}
	result_elemid=0;
	result_cookie=NULL;
	while ((result_discount_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp, PIN_FLD_DISCOUNTS,&result_elemid, 1, &result_cookie, ebufp)) != (pin_flist_t *)NULL)
	{	

		discount_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_DISCOUNTS,result_elemid,ebufp);				
		PIN_FLIST_FLD_COPY(result_discount_flistp, PIN_FLD_OFFERING_OBJ, discount_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(result_discount_flistp, PIN_FLD_DESCR, discount_flistp, TAB_FLD_OFFER_ID, ebufp);

		if ((deal_objp = PIN_FLIST_FLD_GET(result_discount_flistp,PIN_FLD_DEAL_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(deal_objp))
		{			
			 fm_tab_utils_common_read_deal_cache(ctxp, deal_objp, &read_grantor_oflistp, db_no, ebufp);
		
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read deal input", deal_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read plan output", ebufp);
				goto cleanup;						
			}			

			if ((bundle_namep = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(discount_flistp,TAB_FLD_BUNDLE_NAME,bundle_namep,ebufp);
			}
			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
		}

		if ((plan_objp = PIN_FLIST_FLD_GET(result_discount_flistp,PIN_FLD_PLAN_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(plan_objp) )
		{
			fm_tab_utils_common_read_plan_cache(ctxp, plan_objp, bundle_resflistp, &read_grantor_oflistp, db_no, ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read product input", plan_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read plan output", ebufp);
				goto cleanup;						
			}	

			if ((plan_desr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DESCR,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(discount_flistp,TAB_FLD_OFFER_TYPE,plan_desr,ebufp);
			}

			if ((plan_name = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(discount_flistp,TAB_FLD_PACKAGE_NAME,plan_name,ebufp);
			}
			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
		}

		if ((discount_objp = PIN_FLIST_FLD_GET(result_discount_flistp,PIN_FLD_DISCOUNT_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(product_objp))
		{
			fm_tab_utils_common_read_discount_cache(ctxp, discount_objp, &read_grantor_oflistp, db_no, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details read product input", product_objp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_utils_common_get_offering_details: read product output", ebufp);
				goto cleanup;						
			}		

			if ((product_descr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_SET(discount_flistp,TAB_FLD_OFFER_NAME,product_descr,ebufp);
			}

			PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
		}
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	 
	*out_flistpp = PIN_FLIST_COPY(return_flistp,ebufp);
	
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);	
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_grantor_oflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_offering_details output flist", *out_flistpp);
	return;	
}

/********************************************
 * We use this function to get rate_plan 
 * object using product poid.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************/

void
fm_tab_utils_common_get_rate_plan_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
        pin_flist_t             *args_flistp = NULL;
        pin_flist_t             *r_flistp = NULL;
        void                    *vp = NULL;
        poid_t                  *srchp = NULL;
        int32                   s_flags = 0;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_rate_plan_details error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_rate_plan_details :"
                        " input flist", i_flistp);
                return;
        }

        PIN_ERRBUF_RESET(ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_get_rate_plan_details input", i_flistp);

        srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
        search_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
        PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
        vp =  (void *)"select X from /rate_plan where F1 = V1 ";
        PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

        args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);

        res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_get_rate_plan_details input flist", search_flistp);

        /***********************************************************
         *                 * Perform the search.
	***********************************************************/
        PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_utils_common_get_rate_plan_details input flist", search_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_utils_common_get_rate_plan_details : Error in getting product object", ebufp);
        }
        else
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_utils_common_get_rate_plan_details output flist", r_flistp);
                *r_flistpp = r_flistp;
        }

        PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
        return;
}

/*****************************************
 * We use this function to get bundle
 * object using bundle name.
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *********************************************/

void
fm_tab_utils_common_get_purchase_bundle_dtls(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	void                    *vp = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;
	int                     bundle_status = PIN_BUNDLE_STATUS_CANCELLED;
	int                     bundle_value = PIN_BUNDLE_STATUS_ACTIVE;
	time_t                  now_t = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchase_bundle_dtls error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchase_bundle_dtls:"
			" input flist", i_flistp);
		return;
	}
	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_purchase_bundle_dtls input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);


	if ((PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_FROM, 1, ebufp) != NULL)
		&& (PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_TO, 1, ebufp) != NULL))
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 != V3 and F4 = V4 and F5 = V5 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &bundle_status, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_FROM, args_flistp, PIN_FLD_VALID_FROM, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_TO, args_flistp, PIN_FLD_VALID_TO, ebufp);
	}
	else
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and (F3 = V3 or (F4 < V4 and F5 >= V5)) ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
		now_t = pin_virtual_time(NULL);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &bundle_value, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_VALID_FROM, (void *)&now_t, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_VALID_TO, (void *)&now_t, ebufp);
	}

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_TO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_purchase_bundle_dtls input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchase_bundle_dtls input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchase_bundle_dtls: Error in getting purchased bundle object", ebufp);
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	*r_flistpp = r_flistp;

	return;
}

/*****************************************
 * We use this function to get product
 * details using PCM_OP_RATE_GET_PRODUCT
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *********************************************/
void
fm_tab_utils_common_read_product_cache(
	pcm_context_t		*ctxp,
	poid_t			*product_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*search_prdct_iflistp = NULL;
	pin_flist_t		*search_prdct_rflistp = NULL;



	search_prdct_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(search_prdct_iflistp,PIN_FLD_POID, product_pdp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_product_cache"
			"input flist", search_prdct_iflistp);

	PCM_OP(ctxp, PCM_OP_RATE_GET_PRODUCT, 0, search_prdct_iflistp, &search_prdct_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"ifm_tab_utils_common_read_product_cache input flist", search_prdct_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_read_product_cache: Error in getting product object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_read_product_cache output flist", search_prdct_rflistp);

		*ret_flistpp = PIN_FLIST_COPY(search_prdct_rflistp, ebufp);
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&search_prdct_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_prdct_rflistp, NULL);
	return;
}

/*****************************************
 * We use this function to get discount
 * details using PCM_OP_RATE_GET_DISCOUNT
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *********************************************/
void
fm_tab_utils_common_read_discount_cache(
	pcm_context_t		*ctxp,
	poid_t			*discount_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*search_discount_iflistp = NULL;
	pin_flist_t		*search_discount_rflistp = NULL;

	search_discount_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(search_discount_iflistp,PIN_FLD_POID, discount_pdp, ebufp);

	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_discount_cache"
		"input flist", search_discount_iflistp);

	PCM_OP(ctxp, PCM_OP_RATE_GET_DISCOUNT, 0, search_discount_iflistp, &search_discount_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_read_discount_cache input flist", search_discount_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_read_discount_cache: Error in getting discount object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_read_discount_cache output flist", search_discount_rflistp);
		*ret_flistpp = PIN_FLIST_COPY(search_discount_rflistp, ebufp);
		}

cleanup:
	PIN_FLIST_DESTROY_EX(&search_discount_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_discount_rflistp, NULL);
	return;
}
/***************************************************
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ***************************************************/
void
fm_tab_utils_common_read_deal_cache(
	pcm_context_t		*ctxp,
	poid_t			*deal_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*deal_res_flistp = NULL;
	int32			res_elemid = 0;
	pin_cookie_t		res_cookie = NULL;
	poid_t			*cache_deal_obj = NULL;
	pin_flist_t		*r_flistp =  NULL;
	unsigned long		results_array_max = 0;
	pin_flist_t		*deal_details_iflistp = NULL;
	pin_flist_t		*deal_details_oflistp = NULL;
	int32			deal_found = 0;
	pin_flist_t		*res_flistp = NULL;



	/* Call Init to get the /deal details*/

	if ( cfg_tab_system_get_deal_flistp != (pin_flist_t *)NULL )
	{
		deal_found = 0;
		res_elemid = 0;
		res_cookie = NULL;
		while ((deal_res_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_get_deal_flistp,
			PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			cache_deal_obj = PIN_FLIST_FLD_GET(deal_res_flistp, PIN_FLD_POID, 0, ebufp);
			if(PIN_POID_COMPARE(deal_pdp, cache_deal_obj, 0, ebufp) == 0)
			{
				*ret_flistpp = PIN_FLIST_COPY(deal_res_flistp,ebufp);
			//	*ret_flistpp = deal_res_flistp;
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_deal_cache"
						" return flist", *ret_flistpp);
				deal_found = 1;
				break;
			}

		}

		if (deal_found ==  0)
		{
			//Manual DB Search
			deal_details_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(deal_details_iflistp, PIN_FLD_POID, deal_pdp, ebufp);

			fm_tab_utils_common_get_deal_details(ctxp, deal_details_iflistp, &deal_details_oflistp, db_no, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
						" input flist ", deal_details_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
						" Error while getting deal object", ebufp);
				goto cleanup;
			}
			if (deal_details_oflistp && (res_flistp = PIN_FLIST_ELEM_GET(deal_details_oflistp,
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				/* Get max array elem */
				if(res_flistp != NULL)
				{
					results_array_max = fm_tab_utils_common_get_max_elemid(ctxp, cfg_tab_system_get_deal_flistp,
							PIN_FLD_RESULTS, ebufp);
				}

				r_flistp = PIN_FLIST_ELEM_ADD(cfg_tab_system_get_deal_flistp,PIN_FLD_RESULTS, ++results_array_max, ebufp);
				PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_NAME, r_flistp, PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_DESCR, r_flistp, PIN_FLD_DESCR, ebufp);
				
				*ret_flistpp=r_flistp;
			}
		}
	}
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
				" input flist ", deal_details_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
				" Error while getting deal object", ebufp);
		goto cleanup;
	}	
	
cleanup:
	PIN_FLIST_DESTROY_EX (&deal_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&deal_details_oflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_deal_cache"
		" return flist", *ret_flistpp);	
	return;
}

/***************************************************
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ***************************************************/
void
fm_tab_utils_common_read_plan_cache(
	pcm_context_t		*ctxp,
	poid_t			*plan_pdp,
	pin_flist_t		*bundle_rflistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*plan_res_flistp = NULL;
	int32			res_elemid = 0;
	pin_cookie_t		res_cookie = NULL;
	poid_t			*cache_plan_obj = NULL;



	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_plan_cache"
			"plan flist", bundle_rflistp);

	if ( bundle_rflistp != (pin_flist_t *)NULL )
	{
		res_elemid = 0;
		res_cookie = NULL;
		while ((plan_res_flistp = PIN_FLIST_ELEM_GET_NEXT(bundle_rflistp,
			PIN_FLD_RESULTS, &res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			cache_plan_obj = PIN_FLIST_FLD_GET(plan_res_flistp, PIN_FLD_POID, 0, ebufp);
			if( PIN_POID_COMPARE(plan_pdp, cache_plan_obj, 0, ebufp) == 0 )
			{
				*ret_flistpp = PIN_FLIST_COPY(plan_res_flistp,ebufp) ;
			//	*ret_flistpp = plan_res_flistp;
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_plan_cache"
					"return flist", plan_res_flistp);
				break;
			}
		}
	}
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_purchased_bundle_details()
 *
 * This function will be used to retrieve the purchased
 * bundle details for input account poid
 *
 * @param ctxp The context pointer.
 * @param in_flistp input flist.
 * @param out_flistp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************************************/

void
fm_tab_utils_common_get_purchased_bundle_details(
	pcm_context_t		*ctxp,
	poid_t			*acct_pdp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details:"
			" input Poid", acct_pdp);
		return;
	}
	PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_purchased_bundle_details input", acct_pdp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /purchased_bundle where F1 = V1";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_pdp, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_DESCR, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_TO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_purchased_bundle_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchased_bundle_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_purchased_bundle_details: Error in getting billinfo object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_purchased_bundle_details output flist", r_flistp);

		*r_flistpp = PIN_FLIST_COPY(r_flistp,ebufp);
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;
}
