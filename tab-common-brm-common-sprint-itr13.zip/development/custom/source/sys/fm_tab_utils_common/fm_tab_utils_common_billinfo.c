/*******************************************************************************
 *
 *	This material is the confidential property of Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date	   | Programmer					| Req/bug/Gap			| Change details
 *
 * 1  | 22/Nov/2021 | Rahul Honnaiah		|						| Billinfo DB Search
 *
 *********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_billinfo.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>

#define FILE_SOURCE_ID "fm_tab_utils_common_billinfo.c(2)"

/*************************************************
 *	*  *Global routines contained within
 ************************************************/
void
fm_tab_utils_common_get_billinfo_by_acctno (
	pcm_context_t		*ctxp,
	char			*acc_no,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_billinfo (
	pcm_context_t		*ctxp,
	poid_t			*acc_pdp,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_billinfo_dtls(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_paytype_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

int
fm_tab_utils_common_get_credit_thresholds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_utils_common_get_paytype_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/*******************************************************************
 * fm_tab_utils_common_get_billinfo()
 *
 *This function will be used to retrieve the billinfo details of
 *the subscriber based on status flag.
 * @param ctxp The context pointer.
 * @param acc_pdp the account poid.
 * @param active_flag 0 or 1 .
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_get_billinfo_by_acctno (
	pcm_context_t		*ctxp,
	char			*acc_no,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*s_pdp = NULL;
	int32			s_flags = 0;
	int32			count = 0;
	char			s_template[2*BUFSIZ] = {""};
	pin_flist_t		*s_flistp =NULL;
	pin_flist_t		*arg_flistp =NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*ret_flistp =NULL;

	if( PIN_ERR_IS_ERR(ebufp) ){
		return;
	}
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo_by_acctno :Function starts");

	/*******************************************************************
	  construct search flist
	 *******************************************************************/
	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	if( s_pdp ) {
		PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp,ebufp);
	}
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, ebufp);
	if(active_flag == 1){
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching Active billinfo Details");
		strcpy ( s_template, "select X from /billinfo 1, /account 2	 where 2.F1 = V1 and 2.F2 = 1.F3 and billinfo_t.status = 10100 order by billinfo_t.mod_t desc ");
	}
	else{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching All billinfo Details");
		strcpy ( s_template, "select X from /billinfo 1, /account 2 where 2.F1 = V1 and 2.F2 = 1.F3 order by billinfo_t.mod_t desc ");
	}

	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_ACCOUNT_NO, acc_no, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_POID, NULL, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD (s_flistp,	PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAYINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_NEXT_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_LAST_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_FUTURE_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_CYCLE_DOM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILLINFO_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_CURRENCY, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SCENARIO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_MOD_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILL_WHEN, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PARENT_BILLINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);


	/*******************************************************************
	  call search opcode
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo_by_acctno: "
		"PCM_OP_SEARCH Input Flist", s_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &ret_flistp, ebufp);
	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_by_acctno: "
			"PCM_OP_SEARCH Input Flist", s_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_by_acctno: "
			"PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo_by_acctno: "
		"PCM_OP_SEARCH Output Flist", ret_flistp);
	count=PIN_FLIST_ELEM_COUNT(ret_flistp,PIN_FLD_RESULTS,ebufp);
	if(count > 0) {
		res_flistp	= PIN_FLIST_ELEM_GET(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
		if(res_flistp)
			*r_flistpp = PIN_FLIST_ELEM_TAKE(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
	}
cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_billinfo()
 *
 *	This function will be used to retrieve the billinfo details of	.
 *	the subscriber based on status flag.
 *
 * @param ctxp The context pointer.
 * @param acc_pdp the account poid.
 * @param active_flag 0 or 1 .
 * @param r_flistpp The return flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_get_billinfo (
	pcm_context_t		*ctxp,
	poid_t			*acc_pdp,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*s_pdp = NULL;
	int32			s_flags = 0;
	int32			count = 0;
	char			s_template[2*BUFSIZ] = {""};
	pin_flist_t		*s_flistp =NULL;
	pin_flist_t		*arg_flistp =NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*ret_flistp =NULL;

	if( PIN_ERR_IS_ERR(ebufp) ){
		return;
	}
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo :Function starts");

	/*******************************************************************
	  construct search flist
	 *******************************************************************/
	s_flistp = PIN_FLIST_CREATE(ebufp);
	s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	if( s_pdp ) {
		PIN_FLIST_FLD_PUT(s_flistp, PIN_FLD_POID, (void *)s_pdp,ebufp);
	}
	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_FLAGS, (void *)&s_flags, ebufp);
	if(active_flag == 1){
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching Active billinfo Details");
		strcpy ( s_template, 
				"select X from /billinfo where F1 = V1 and status = 10100 order by billinfo_t.mod_t desc ");
	}
	else{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"Fetching All billinfo Details");
		strcpy ( s_template, "select X from /billinfo where F1 = V1 order by billinfo_t.mod_t desc ");
	}

	PIN_FLIST_FLD_SET(s_flistp, PIN_FLD_TEMPLATE, (void *)s_template, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_ACCOUNT_OBJ, acc_pdp, ebufp);
	arg_flistp = PIN_FLIST_ELEM_ADD (s_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(arg_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD (s_flistp,	PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAYINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_NEXT_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_LAST_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_FUTURE_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_CYCLE_DOM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILLINFO_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_CURRENCY, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SCENARIO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_MOD_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILL_WHEN, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_EXEMPT_FROM_COLLECTIONS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PARENT_BILLINFO_OBJ, NULL, ebufp);
        PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);



	/*******************************************************************
	  call search opcode
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo: PCM_OP_SEARCH Input Flist", s_flistp);
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, s_flistp, &ret_flistp, ebufp);
	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo: "
			"PCM_OP_SEARCH Input Flist", s_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tlc_utils_db_get_account: PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_get_billinfo: "
		"PCM_OP_SEARCH Output Flist", ret_flistp);
	count=PIN_FLIST_ELEM_COUNT(ret_flistp,PIN_FLD_RESULTS,ebufp);
	if(count > 0) {
		res_flistp	= PIN_FLIST_ELEM_GET(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
		if(res_flistp)
			*r_flistpp = PIN_FLIST_ELEM_TAKE(ret_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
	}
	cleanup:
	PIN_FLIST_DESTROY_EX(&s_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	return;
}


/*******************************************************************
 * fm_tab_utils_common_get_billinfo_dtls()
 *
 *	This function will be used to retrieve the billinfo
 *	details for input bal_grp poid
 *
 * @param ctxp The context pointer.
 * @param in_flistp input flist
 * @param out_flistp The return flist.
 * @param db_no Database number
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************************************/
void
fm_tab_utils_common_get_billinfo_dtls(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchpp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}
	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo_dtls input", i_flistp);

	srchpp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchpp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /billinfo 1, /balance_group 2, /account 3	where 3.F1 = V1 and 2.F2 = 3.F3 and 1.F4 = 2.F5 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_POID, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILLINFO_OBJ, NULL, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD (search_flistp,	 PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAYINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_NEXT_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_LAST_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_FUTURE_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_CYCLE_DOM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILLINFO_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_CURRENCY, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTUAL_LAST_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SCENARIO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_MOD_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILL_WHEN, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo_dtls search input flist",	 search_flistp);
	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_billinfo_dtls: Error in getting the billinfo object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_billinfo_dtls search input flist",	 search_flistp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo_dtls search output flist",  r_flistp);

	*out_flistp = PIN_FLIST_COPY(r_flistp,ebufp);

	cleanup:
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_owner_billinfo_details()
 * 
 * This function will be used to retrieve the billinfo
 * details for input bal_grp and account poid
 *	
 * @param ctxp The context pointer.
 * @param in_flistp input flist.
 * @param out_flistp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *	
 ********************************************************************/

void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_owner_billinfo_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /billinfo where F1 = V1 and F2 = V2  ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BAL_GRP_OBJ, args_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAYINFO_OBJ, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACTG_CYCLE_DOM, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BILL_WHEN, 0, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_owner_billinfo_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_owner_billinfo_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_owner_billinfo_details: Error in getting billinfo object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_owner_billinfo_details output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_billinfo_details()
 * 
 * This function will be used to retrieve the billinfo
 * details for MSISDN
 *
 * @param ctxp The context pointer.
 * @param in_flistp input flist
 * @param out_flistp The return flist.
 * @param db_no Database number
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************************************/

void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*alias_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	char			*msisdn = NULL;
	char			*acct_no = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);
	msisdn =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);
	acct_no = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /billinfo 1, /service 2 where 1.F1 = 2.F2 and 2.F3 = V3 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ,args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_billinfo_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_billinfo_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_billinfo_details: Error in getting billinfo object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo_details output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

/*******************************************************************
 * fm_tab_utils_common_get_paytype_details()
 *
 * This function will be used to retrieve the billinfo
 * details for input MSISDN
 *
 * @param ctxp The context pointer.
 * @param in_flistp input flist
 * @param out_flistp The return flist.
 * @param db_no Database number
 * @param ebufp The error buffer.
 * @return flistp.
 *
 ********************************************************************/

void
fm_tab_utils_common_get_paytype_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_paytype_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_paytype_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_paytype_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /billinfo 1, /service 2 where 1.F1 = 2.F2 and 2.F3 = V3";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_BAL_GRP_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_paytype_details input flist", search_flistp);

	/***********************************************************
	 *			* Perform the search.
	 ************************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_paytype_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_paytype_details: Error in getting billinfo object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_paytype_details output flist", r_flistp);

		*r_flistpp = r_flistp;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	return;
}

int
fm_tab_utils_common_get_credit_thresholds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	int			t_credit_percent = 0;
	int			thres_rec_id = 0;
	pin_cookie_t		thres_cookie = NULL;
	pin_flist_t		*thres_flistp = NULL;
	int32			credit_thresholds = 0;
	int			credit_percent = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_credit_thresholds error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_credit_thresholds:"
			" input flist", i_flistp);
		return t_credit_percent;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_credit_thresholds input", i_flistp);

	thres_rec_id = 0;
	thres_cookie = NULL;
	while( NULL != (thres_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_THRESHOLDS,
		&thres_rec_id, 1, &thres_cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_subscriber_prep_billinfo threshold flist ", thres_flistp);

		credit_thresholds = *(int32*) PIN_FLIST_FLD_GET(thres_flistp,
				PIN_FLD_CREDIT_THRESHOLDS, 1, ebufp);
		switch (credit_thresholds) {
			case 0:
				credit_percent = 0;
				break;
			case 5:
				credit_percent = 1;
				break;
			case 10:
				credit_percent = 2;
				break;
			case 15:
				credit_percent = 4;
				break;
			case 20:
				credit_percent = 8;
				break;
			case 25:
				credit_percent = 16;
				break;
			case 30:
				credit_percent = 32;
				break;
			case 35:
				credit_percent = 64;
				break;
			case 40:
				credit_percent = 128;
				break;
			case 45:
				credit_percent = 256;
				break;
			case 50:
				credit_percent = 512;
				break;
			case 55:
				credit_percent = 1024;
				break;
			case 60:
				credit_percent = 2048;
				break;
			case 65:
				credit_percent = 4096;
				break;
			case 70:
				credit_percent = 8192;
				break;
			case 75:
				credit_percent = 16384;
				break;
			case 80:
				credit_percent = 32768;
				break;
			case 85:
				credit_percent = 65536;
				break;
			case 90:
				credit_percent = 131072;
				break;
			case 95:
				credit_percent = 262144;
				break;
			case 100:
				credit_percent = 524288;
				break;
			default:
				break;
		}
		t_credit_percent = credit_percent + t_credit_percent;
	}
	return t_credit_percent;
}
