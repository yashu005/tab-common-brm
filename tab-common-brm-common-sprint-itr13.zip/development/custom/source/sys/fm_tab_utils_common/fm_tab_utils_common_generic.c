/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah            |                       | Generic DB Search
 *
 *********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_utils_common_generic.c:2021-Oct-10%";
#endif

#include <stdio.h>
#include <string.h>
#include <pcm.h>
#include <pinlog.h>
#include <cm_fm.h>
#include <limits.h>
#include "tab_common.h"
#include "ops/subscription.h"
#include "tab_ops_flds.h"
#define FILE_SOURCE_ID "fm_tab_utils_common_generic.c(2)"
typedef char  SUBVAL_STR[128];

/*************************************************
 *  *  *Global routines contained within
 ************************************************/
int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

unsigned long
fm_tab_utils_common_get_max_elemid(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			fld_no,
	pin_errbuf_t		*ebufp);

int32
fm_tab_utils_common_get_top_ancestor_flist(
	cm_op_info_t		*ancestor_ptr,
	int32			in_opcode,
	pin_flist_t		**out_top_ancestor_flistp,
	pin_errbuf_t		*ebufp);

char *fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

time_t fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

pin_flist_t* fm_tab_utils_common_prep_simple_search_flist(
	char                   *template,
	field_t                 args_struct[],
	int                 	n_args,
	field_t                 result_struct[],
	int                 	n_results,
	int64			db_no,
	int			flags,
	pin_errbuf_t            *ebufp) ;

int fm_tab_utils_common_call_opcode(
	pcm_context_t     	*ctxp,
	u_int               	opcode,
	u_int               	flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**ret_flistpp,
	char			*log_info,
	int			set_error,
	pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_read_object(
	pcm_context_t     	*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t         	**ret_flistpp,
	pin_errbuf_t        	*ebufp);

int64
fm_tab_utils_common_order_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

int64
fm_tab_utils_common_compare_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

int
fm_tab_utils_calculate_number_of_days(
	int months,
	time_t *effective_tp);

int
fm_tab_utils_calculate_days_in_month(
	int year,
	int month);

/***********************************************************
 *  fm_tab_utils_common_get_db_no()
 *  This function will return the db number based on
 *  input poid.
 *
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param ebufp The error buffer.
 *  @return int64.
 ************************************************************/

int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp)
{
	poid_t			*account_pdp = NULL;
	poid_t			*s_pdp = NULL;
	poid_t			*poidp = NULL;
	int64			primary_db_no = 1;
        int64			ctx_db_no = 1;
	char                    *acct_nop = NULL;
        char                    *msisdnp = NULL;
        void                    *vp = NULL;
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*l_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*unique_flistp = NULL;
	int32                   search_flag = SRCH_DISTINCT;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			" input flist", i_flistp);
		return primary_db_no;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_get_db_no input", i_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);
	poidp =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);


	ctx_db_no = cm_fm_get_current_db_no(ctxp);
	if(cm_fm_is_multi_db())
	{
		if(((msisdnp && strlen(msisdnp) != 0) || (acct_nop && strlen(acct_nop) != 0)) 
			&& (!PIN_POID_IS_NULL(poidp) && PIN_POID_GET_ID(poidp) < 1))
		{
			/*********************************************************
			 * Create the search flist
			 ********************************************************/
			search_flistp = PIN_FLIST_CREATE(ebufp);
			cm_fm_get_primary_db_no(&ctx_db_no, ebufp);
			s_pdp = PIN_POID_CREATE(ctx_db_no, "/search", -1, ebufp);
			PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)s_pdp, ebufp);

			/******************************************************************
			 * Set the search template.
			 ******************************************************************/
			PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &search_flag, ebufp);

			/* Add the search criteria. */
			//Commmented If condition for UAT bug
			/*if((msisdnp && strlen(msisdnp) != 0) && (acct_nop && strlen(acct_nop) != 0))
			{
				vp = (void *)"select X from /uniqueness where F1 = V1 and F2 = V2 ";
				PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

				l_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
				PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_LOGIN, (void *)msisdnp, ebufp);

				l_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
				PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_ACCOUNT_NO, (void *)acct_nop, ebufp);
			}
			else if(msisdnp && strlen(msisdnp) != 0 && acct_nop == NULL)*/
			if(msisdnp && strlen(msisdnp) != 0)
			{
				vp = (void *)"select X from /uniqueness where F1 = V1 ";
				PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

				l_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
				PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_LOGIN, (void *)msisdnp, ebufp);
			}
			else if(acct_nop && strlen(acct_nop) != 0 && msisdnp == NULL)
			{
				vp = (void *)"select X from /unique_account_no where F1 = V1 ";
				PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

				l_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
				PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_ACCOUNT_NO, (void *)acct_nop, ebufp);
			}

			res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
			PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
			PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_get_db_no input flist", search_flistp);

			/***********************************************************
			 * Perform the search.
			 ***********************************************************/
			PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_get_db_no input flist", search_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_get_db_no: Error in getting service object", ebufp);
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_utils_common_get_db_no output flist", r_flistp);
				if (r_flistp && (unique_flistp = PIN_FLIST_ELEM_GET(r_flistp,
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(unique_flistp, PIN_FLD_ACCOUNT_OBJ,
						i_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
					account_pdp = PIN_FLIST_FLD_GET(unique_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
					if(!PIN_POID_IS_NULL(account_pdp))
					{
						primary_db_no = PIN_POID_GET_DB(account_pdp);
					}
				}
				else
				{
					primary_db_no = ctx_db_no;
				}
			}
		}
		else
		{
			primary_db_no = ctx_db_no;
		}
	}
	else 
	{
		primary_db_no = ctx_db_no;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return primary_db_no;
}

/***********************************************************
 *  fm_tab_utils_common_get_max_elemid()
 *  This function will return the maximum array elemid
 *
 * @param ctxp The context pointer.
 * @param i_flistp input flist.
 * @param fld_no Array field.
 * @param ebufp The error buffer.
 * @return unsigned long.
 ************************************************************/


unsigned long fm_tab_utils_common_get_max_elemid(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			fld_no,
	pin_errbuf_t		*ebufp)
{
	int32			elemid = 0;
	pin_cookie_t		cookie = NULL;
	int32			max = INT_MIN;
	pin_flist_t		*flds_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_max_elemid error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_max_elemid:"
			" input flist", i_flistp);
		return 0;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_max_elemid input flist", i_flistp);

	while ((flds_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, fld_no,
					&elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_get_max_elemid flds_flistp", flds_flistp);

		if (max <= elemid)
		{
			max = elemid;
		}
	}

	return (max == INT_MIN ? 0 : max);
}

/***********************************************************
 * fm_tab_utils_common_get_top_ancestor_flist()
 * This function will return the int value based on ancestor flist information
 *
 * @param ancestor_ptr The context pointer.
 * @param in_opcode The opcode number.
 * @param out_top_ancestor_flistp
 * @param ebufp The error buffer.
 * @return int value.
 *
 ***********************************************************/
int32
fm_tab_utils_common_get_top_ancestor_flist(
	cm_op_info_t		*ancestor_ptr,
	int32			in_opcode ,
	pin_flist_t		**out_top_ancestor_flistp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*ancestor_flistp = NULL ;
	pin_flist_t		*cur_ans_flistp = NULL ;
	cm_op_info_t		*top_ancestor_ptr = NULL ;
	int32			ret_val = 0 ;
	char			opcode_name[256] ;

	if (PIN_ERR_IS_ERR(ebufp))
		return  ret_val;

	while ( ancestor_ptr )
	{
		opcode_name[0] = '\0' ;
		sprintf(opcode_name,"Opcode Name: %d",ancestor_ptr->opcode) ;
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,opcode_name) ;
		ancestor_flistp = NULL ;
		ancestor_flistp = ancestor_ptr->in_flistp;
		cur_ans_flistp = ancestor_ptr->in_flistp;
		if ( ancestor_flistp )
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "NotifY ancestor_flistp", ancestor_flistp);
		}
		top_ancestor_ptr = ancestor_ptr ;
		ancestor_ptr = ancestor_ptr->next;
	}
	if ( top_ancestor_ptr->opcode == in_opcode )
	{
		ret_val = 1 ;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_top_ancestor_flist: ", cur_ans_flistp);
	if ( cur_ans_flistp )
	{
		*out_top_ancestor_flistp = cur_ans_flistp;
	}
	return ret_val ;
}

/************************************************
 *  * We use this function to convert unix
 * timestamp to date in string format.
 * @param ctxp The context pointer.
 * @param str_timestamp input timestamp.
 * @param ebufp The error buffer.
 * @return time_t.
 *
 ************************************************/

char *fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp)
{
	char			converted_date[MAX]={""};
	char			*converted_date_str;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_convert_timestamp_to_date");

	memset(converted_date, '\0', MAX);

	if(input_time_t != NULL)
	{
		strftime(converted_date, MAX, "%d-%b-%Y %H:%M:%S", localtime(input_time_t));
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, converted_date);
		if(converted_date)
		{
			converted_date_str = (char *)calloc(strlen(converted_date)+1, sizeof(char));
			strncpy(converted_date_str, converted_date, strlen(converted_date));
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_utils_common_convert_timestamp_to_date: converted date");

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, converted_date_str);
		}
	}

	return converted_date_str;
}

/*******************************************
 * We use this function to convert date
 * in string format to unix timestamp.
 * @param ctxp The context pointer.
 * @param str_timestamp input timestamp.
 * @param ebufp The error buffer.
 * @return time_t.
 *
 ********************************************/

time_t fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp)
{
	time_t			ret_time_t = 0;
	struct			tm converted_time = {0};

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_convert_date_to_timestamp");

	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, str_timestamp);

	if(str_timestamp != NULL)
	{
		strptime(str_timestamp, "%d-%b-%Y %H:%M:%S", &converted_time);
		converted_time.tm_isdst = 0;
		ret_time_t = mktime(&converted_time);
	}

	return ret_time_t;
}


/***********************************************************
 * fm_tab_utils_common_prep_simple_search_flist()
 * This function to prepare the search flist
 * @param template, provide the search criteria.
 * @param args_struct, search flist argument.
 * @param n_args, count of argument fields be passed
 * @param result_struct, result structure with field name
 * @param n_results, count of results fields to be present in output
 * @param ebufp The error buffer.
 * @returns a frameed pin_flist_t value.
 ***********************************************************/

pin_flist_t* fm_tab_utils_common_prep_simple_search_flist(
	char                   *template,
	field_t                 args_struct[],
	int                 	n_args,
	field_t                 result_struct[],
	int                 	n_results,
	int64			db_no,
	int 			flags,
	pin_errbuf_t            *ebufp)
{

	poid_t          	*srch_poidp = NULL;
	pin_flist_t     	*args_flistp = NULL;
	pin_flist_t     	*result_flistp = NULL;
	pin_flist_t		*search_flistp = NULL;
	int			i = 0;

	search_flistp = PIN_FLIST_CREATE(ebufp);
	srch_poidp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_flistp,PIN_FLD_POID, srch_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp,PIN_FLD_FLAGS, &flags, ebufp);
	PIN_FLIST_FLD_SET(search_flistp,PIN_FLD_TEMPLATE, template, ebufp);

	//Setting Arguments
	for(i=0; i<n_args; i++) {
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, i+1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, args_struct[i].fld_name, (void*)args_struct[i].fld_value, ebufp);
	}

	//Setting Results
	if (n_results > 0) {
		result_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
		for(i=0; i<n_results; i++) {
			PIN_FLIST_FLD_SET(result_flistp, result_struct[i].fld_name, (void*)result_struct[i].fld_value, ebufp);
		}
	}
	else {
		result_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_prep_simple_search_flist output", search_flistp);

	return search_flistp;
}


/***********************************************************
 * fm_tab_utils_common_call_opcode()
 * This function to execute the given opcode and
 * logs the input and output flist.
 * @param opcode, opcode name/number.
 * @param opcode, Flags for the execution.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param log_info, Function loggin information.
 * @param ebufp The error buffer.
 * @returns a integer value with success or failure response.
 ***********************************************************/

int fm_tab_utils_common_call_opcode(
	pcm_context_t  	*ctxp,
	u_int           opcode,
	u_int           flags,
	pin_flist_t     *in_flistp,
	pin_flist_t     **ret_flistpp,
	char		*log_info,
	int		set_error,
	pin_errbuf_t    *ebufp)
{

	pin_flist_t	*r_flistp = NULL;
	int		len = 0, status = 0;
	char		*log_msg = NULL;

	len = strlen (log_info);
	log_msg = (char*) malloc (len+20);

	sprintf(log_msg, "%s input flist", log_info);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, log_msg, in_flistp);

	PCM_OP( ctxp, opcode, flags, in_flistp, &r_flistp, ebufp );

	sprintf(log_msg, "%s return flist", log_info);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, log_msg, r_flistp);

	*ret_flistpp = r_flistp;
	if (PIN_ERR_IS_ERR(ebufp)) {
		sprintf(log_msg, "%s error flist", log_info);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, log_msg, r_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, log_msg, ebufp);
		if (set_error != 1) {
			PIN_ERR_CLEAR_ERR(ebufp);
		}
		status = 1;
		goto cleanup;
	}

cleanup:
	free(log_msg);
	return status;
}


void
fm_tab_utils_common_read_object(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{

	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*input_flistp = NULL;
		
	input_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(input_flistp, PIN_FLD_POID, poid_pdp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_object input flist", input_flistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, input_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)){

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object: "
				"Input Flist", input_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object: "
				"error", ebufp);
		PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&input_flistp, NULL);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_read_object out flist", r_flistp);

cleanup:

	PIN_FLIST_DESTROY_EX(&input_flistp, NULL);
	*ret_flistpp = r_flistp;
	return ;
}

int64
fm_tab_utils_common_order_get_db_no(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp)
{
	int64                   primary_db_no = 0;
	int64                   ctx_db_no = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_order_get_db_no error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_order_get_db_no:"
			" input flist", i_flistp);
		return primary_db_no;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_order_get_db_no input", i_flistp);

	ctx_db_no = cm_fm_get_current_db_no(ctxp);
	if(cm_fm_is_multi_db())
	{
		cm_fm_get_primary_db_no(&primary_db_no, ebufp);
	}
	else {
		primary_db_no = ctx_db_no;
	}

	return primary_db_no;
}

/***********************************************************
 *  fm_tab_utils_common_compare_db_no()
 *  This function will return the value based on
 *  comparison of DB number.
 *
 *  @param ctxp The context pointer.
 *  @param i_flistp input flist.
 *  @param ebufp The error buffer.
 *  @return int64.
 ************************************************************/

int64
fm_tab_utils_common_compare_db_no(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	poid_t                  *account_pdp = NULL;
	poid_t                  *s_pdp = NULL;
	int64                   primary_db_no = 1;
	int64                   value = 0;
	int64                   flag = 0;
	char                    *acct_nop = NULL;
	char                    *msisdnp = NULL;
	void                    *vp = NULL;
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *l_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t             *unique_flistp = NULL;
	int32                   search_flag = SRCH_DISTINCT;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_compare_db_no error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_compare_db_no:"
			" input flist", i_flistp);
		return value;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_utils_common_compare_db_no input", i_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if((msisdnp && strlen(msisdnp) != 0) || (acct_nop && strlen(acct_nop) != 0))
	{

		/*********************************************************
		 * Create the search flist
		 ********************************************************/
		search_flistp = PIN_FLIST_CREATE(ebufp);
		s_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
		PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)s_pdp, ebufp);

		/******************************************************************
		 * Set the search template.
		 ******************************************************************/
		vp = (void *)"select X from /uniqueness where F1 = V1 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &search_flag, ebufp);

		/* Add the search criteria. */
		l_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		if(msisdnp && strlen(msisdnp) != 0 )
		{
			PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_LOGIN, (void *)msisdnp, ebufp);
		}
		if(acct_nop && strlen(acct_nop) != 0 && msisdnp == NULL)
		{
			PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_ACCOUNT_NO, (void *)acct_nop, ebufp);
		}
		res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_SERVICE_OBJ, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_compare_db_no input flist", search_flistp);

		/***********************************************************
		 * Perform the search.
		 ***********************************************************/
		PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_compare_db_no input flist", search_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_compare_db_no: Error in getting service object", ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_utils_common_compare_db_no output flist", r_flistp);
			if (r_flistp && (unique_flistp = PIN_FLIST_ELEM_GET(r_flistp,
				PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				PIN_FLIST_FLD_COPY(unique_flistp, PIN_FLD_ACCOUNT_OBJ,
					i_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				account_pdp = PIN_FLIST_FLD_GET(unique_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
				if(!PIN_POID_IS_NULL(account_pdp))
				{
					primary_db_no = PIN_POID_GET_DB(account_pdp);
					flag = 1;
				}
			}
		}
	}

	if(db_no != primary_db_no && flag == 1)
	{
		value = 1;
	}

	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return value;
}

/*****************************************************************
 * common utils function to populate the ebuf in the response
 * using the errorCode coming from Return flist
 *****************************************************************/

void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *in_flistp,
        pin_errbuf_t            *ebufp)
{
        char                   *err_code = NULL;
        char                  log_msg[512]= "";

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_error_ebuf error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_error_ebuf input flist:"
                        " input flist", in_flistp);
                return;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_utils_common_error_ebuf input", in_flistp);

        err_code = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ERROR_CODE, 1, ebufp);

        sprintf(log_msg,"errorCode::%s",err_code);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
        if(err_code && strlen(err_code) != 0)
        {
                int errorCode=0;
                sscanf(err_code, "%d", &errorCode);
                pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE, errorCode, 0, 0, 0);
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_utils_common_error_ebuf",in_flistp);
        return ;
}

int
fm_tab_utils_calculate_number_of_days(
	int months,
	time_t *effective_tp)
{
	char	  str[60];
	char   	  year_str[128];
	char   	  month_str[128];
	char   	  day_str[128];
	char	  msgbuf[256];
	char	  msgbuf1[256];
	SUBVAL_STR sub_value[5];
	int32 iYear=0;
	int32 iMonths=0;
	int32 iDays=0;

	int  days=0;
	struct tm *ptr;
	time_t tm;
	int loop=0;
	int totaldays=0;

	tm = time(NULL);
	tm = pin_virtual_time(NULL);
	ptr = localtime(&tm);

	year_str[0] = 0;
	month_str[0] = 0;

	pin_strftimet(year_str, sizeof(year_str), "%y", *(time_t *)effective_tp);
	pin_strftimet(month_str, sizeof(month_str), "%m", *(time_t *)effective_tp);
	pin_strftimet(day_str, sizeof(day_str), "%d", *(time_t *)effective_tp);

    strcpy(sub_value[2], year_str);
	iYear = atoi(sub_value[2]);
	strcpy(sub_value[2], month_str);
	iMonths = atoi(sub_value[2]);
	strcpy(sub_value[2], day_str);
	iDays = atoi(sub_value[2]);

	for(loop=1;loop <= months; loop++)
	{
		if(iMonths==13)
		{
			iYear=iYear+1;
			iMonths=1;
		}
		days = days + fm_tab_utils_calculate_days_in_month(iYear,iMonths);
		iMonths++;
	}
	totaldays=days;
	return totaldays;
}

/************************
* Function to check number of days in month
************************/

int
fm_tab_utils_calculate_days_in_month(
	int year,
	int month)
{
   int days = 0;
   if ((month < 1) || (month >12))
      {
         fprintf (stderr, "fm_tab_utils_calculate_days_in_month(): invalid month value\n");
         exit (EXIT_FAILURE);
      }
   switch (month)
      {
         case 1:
         case 3:
         case 5:
         case 7:
         case 8:
         case 10:
         case 12:
            days = 31;
            break;
         case 4:
         case 6:
         case 9:
         case 11:
            days = 30;
            break;
         case 2:
            if ( ((year % 4 == 0) && !(year % 100 == 0))
               || (year % 400 == 0) )
               days = 29;
            else
               days = 28;
            break;
      }
   return days;
}