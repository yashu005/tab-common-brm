/*******************************************************************************
*
*	This material is the confidential property of Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date       | Programmer  		| Req/bug/Gap   			| Change details
*
* 1  | 07/03/2023 | Piyush Suryavanshi |							| Opcode TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS introduced.
*
**************************************************************************************************/

/*******************************************************************
* Contains the TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS operation.
*******************************************************************/
#include "pcm.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

/*******************************************************************
* Routines contained within.
*******************************************************************/
EXPORT_OP void
op_tab_bill_pol_post_get_event_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_pol_post_get_event_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);


/**********************************************************************************
* The policy opcode TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS
* formats the output recived from the prepare output opcode
* @param connp The connection pointer.
* @param opcode This opcode.
* @param flags The opcode flags.
* @param in_flistp the input flist
* @param ret_flistpp the output flist
* @param ebufp The error buffer.
* @return nothing.
***********************************************************************************/
void
op_tab_bill_pol_post_get_event_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t           *ctxp = connp->dm_ctx;
	int64					db_no = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"op_tab_bill_pol_post_get_event_details: function entry error", ebufp);
		return;
	}

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
		PIN_ERRCLASS_SYSTEM_DETERMINATE,
		PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"op_tab_bill_pol_post_get_event_details: opcode error", ebufp);
		return;
	}

	/***********************************************************
	* Debug: What we got.
	***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
	"op_tab_bill_pol_post_get_event_details: input flist", in_flistp);

	/***********************************************************
	* Prep the return flist.
	***********************************************************/
	fm_tab_bill_pol_post_get_event_details(ctxp,in_flistp,ret_flistpp, ebufp);

	/***********************************************************
	* Results.
	***********************************************************/

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_pol_post_get_event_details error", ebufp);
		goto cleanup;
	}

cleanup:

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
	"op_tab_bill_pol_post_get_event_details: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
* fm_tab_bill_pol_post_get_event_details()
* copies input flist to output flist
* @param ctxp The context pointer.
* @param flags The opcode flags.
* @param in_flistp in the input flist.
* @param ret_flistpp The output flist .
* @param ebufp The error buffer.
* @return nothing.
*
***********************************************************************/

static void
fm_tab_bill_pol_post_get_event_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_bill_pol_post_get_event_details: function entry error", ebufp);
		return;
	}

	*ret_flistpp=PIN_FLIST_COPY(in_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_pol_post_get_event_details error", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
	"fm_tab_bill_pol_post_get_event_details output flist", *ret_flistpp);
	return;
}
