
/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date		| Programmer		| Req/bug/Gap   | Change details
*
* 1  | 19-JAN-2022 	| Venu Padala		| 	        | New File.
**************************************************************************************************/

#include <stdio.h>      /* for FILE * in pcm.h */
#include "ops/pymt.h"
#include "pcm.h"
#include "cm_fm.h"
#include "pcm_ops.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_notify_pol_config_func();
#endif

/*******************************************************************
 * NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 * AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 * OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 *******************************************************************/

struct cm_fm_config fm_tab_notify_pol_config[] = {
	/* opcode as a u_int, function name (as a string) */
	{ TAB_OP_NOTIFY_POL_ENRICH_RECHARGE_NOTIFICATION ,	"op_tab_notify_pol_enrich_recharge_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_REVERSE_RECHARGE_NOTIFICATION ,	"op_tab_notify_pol_enrich_reverse_recharge_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_EXTEND_VALIDTY_NOTIFICATION ,	"op_tab_notify_pol_extend_prepaid_validity_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CHANGE_OFFER ,      "op_tab_notify_pol_enrich_change_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_UPDATE_ADDRESSES_NOTIFICATION ,      "op_tab_notify_pol_update_addresses_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CANCEL_OFFER ,      "op_tab_notify_pol_enrich_cancel_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_PURCHASE_OFFER ,      "op_tab_notify_pol_enrich_purchase_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CREATE_SUBSCRIBER ,      "op_tab_notify_pol_enrich_create_subscriber", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CREATE_ACCOUNT ,      "op_tab_notify_pol_enrich_create_account", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_MANAGE_MSISDN_SIM_NOTIFICATION ,      "op_tab_notify_pol_manage_msisdn_sim_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MANAGE_CUG ,      "op_tab_notify_pol_enrich_manage_cug", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MANAGE_FNF ,      "op_tab_notify_pol_enrich_manage_fnf", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_UPDATE_SERVICE_NOTIFICATION ,      "op_tab_notify_pol_enrich_update_service_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_UPDATE_INVOICE_PREFERENCE,      "op_tab_notify_pol_enrich_update_invoice_preference", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION ,	"op_tab_notify_pol_enrich_payment_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_ADJUSTMENT,      "op_tab_notify_pol_enrich_make_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_ADJUST_BALANCE_VALIDITY_NOTIFICATION ,      "op_tab_notify_pol_enrich_adjust_balance_validity_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_NOTIFICATION ,      "op_tab_notify_pol_enrich_adjust_ncr_balance_validity_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_UPDATE_SUBSCRIBER_PREFERENCES_NOTIFICATION, "op_tab_notify_pol_update_subscriber_preferences_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CANCEL_BUDGET_LIMIT,  "op_tab_notify_pol_enrich_cancel_budget_limit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MODIFY_CL_NOTIFICATION ,     "op_tab_notify_pol_enrich_modify_cl_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_SET_BUDGET_LIMIT,  "op_tab_notify_pol_enrich_set_budget_limit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CHANGE_BDOM,  "op_tab_notify_pol_enrich_change_bdom", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_PAYMENT_REVERSAL,      "op_tab_notify_pol_enrich_make_payment_reversal", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_REQUEST_LOAN_NOTIFICATION ,      "op_tab_op_notify_pol_enrich_request_loan_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_BALANCE_TRANSFER_NOTIFICATION ,      "op_tab_notify_pol_enrich_balance_transfer_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CHANGE_BDOM,  "op_tab_notify_pol_enrich_change_bdom", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_UPDATE_PAYTYPE,      "op_tab_notify_pol_enrich_update_paytype", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_DELETE_SHARING_GROUP,  "op_tab_notify_pol_enrich_delete_sharing_group", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_ADD_SHARING_GROUP_MEMBERS,  "op_tab_notify_pol_enrich_add_sharing_group_members", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_DELETE_SHARING_GROUP_MEMBERS,  "op_tab_notify_pol_enrich_delete_sharing_group_members", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_ADD_GROUP_MEMBER,  "op_tab_notify_pol_enrich_add_group_member", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_DELETE_GROUP_MEMBER,  "op_tab_notify_pol_enrich_delete_group_member", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_CORP_PAYMENT_NOTIFICATION ,	"op_tab_notify_pol_enrich_corp_payment_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_SETTLEMENT, "op_tab_notify_pol_enrich_make_settlement",  CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_UPDATE_ACCOUNT_STATUS, "op_tab_notify_pol_enrich_update_account_status",  CM_FM_OP_OVERRIDABLE },
  { TAB_OP_NOTIFY_POL_UPDATE_ACCOUNT_PROFILE_NOTIFICATION, "op_tab_notify_pol_update_account_profile_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_DEPOSIT, "op_tab_notify_pol_enrich_make_deposit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_RELEASE_DEPOSIT_NOTIFICATION ,	"op_tab_notify_pol_enrich_release_deposit_notification", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_DISPUTE, "op_tab_notify_pol_enrich_make_dispute", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_WRITEOFF, "op_tab_notify_pol_enrich_make_writeoff", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_COLLECTIONS_CREATE_INSTALLMENT,  "op_tab_op_notify_pol_enrich_collections_create_installment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MAKE_REFUND, "op_tab_notify_pol_enrich_make_refund", CM_FM_OP_OVERRIDABLE },
    { TAB_OP_NOTIFY_POL_ENRICH_CREATE_SHARING_GROUP, "op_tab_notify_pol_enrich_create_sharing_group", CM_FM_OP_OVERRIDABLE },
    { TAB_OP_NOTIFY_POL_ENRICH_ADD_REMOVE_SHARING_GROUP, "op_tab_notify_pol_enrich_add_remove_sharing_group",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_NOTIFY_POL_ENRICH_MOVE_GROUP_MEMBER,  "op_tab_notify_pol_enrich_move_group_member", CM_FM_OP_OVERRIDABLE },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_notify_pol_config_func()
{
  return ((void *) (fm_tab_notify_pol_config));
}
#endif
