/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 10-FEB-2022   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_NOTIFY_POL_ENRICH_ADJUST_BALANCE_VALIDITY_NOTIFICATION operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#define FILE_SOURCE_ID "fm_tab_notify_pol_adjust_balance_validity_notify.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_notify_pol_enrich_adjust_balance_validity_notification(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_notify_pol_enrich_adjust_balance_validity_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t		*ebufp);

 /**************************************************************************
 *
 * New opcode TAB_OP_NOTIFY_POL_ENRICH_ADJUST_BALANCE_VALIDITY_NOTIFICATION is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_NOTIFY_POL_ENRICH_ADJUST_BALANCE_VALIDITY_NOTIFICATION operation.
 *************************************************************************/
void
op_tab_notify_pol_enrich_adjust_balance_validity_notification(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_notify_pol_enrich_adjust_balance_validity_notification error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_NOTIFY_POL_ENRICH_ADJUST_BALANCE_VALIDITY_NOTIFICATION) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_notify_pol_enrich_adjust_balance_validity_notification opcode error",ebufp);
		return;
	}
	
	/***********************************************************
  	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_notify_pol_enrich_adjust_balance_validity_notification :"
			" input flist", in_flistp);
			
	/***********************************************************
  	 * Main Function Call
	 ***********************************************************/
	fm_tab_notify_pol_enrich_adjust_balance_validity_notification(ctxp, in_flistp, &r_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_notify_pol_enrich_adjust_balance_validity_notification error",ebufp);
		return ;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_notify_pol_enrich_adjust_balance_validity_notification :"
			" output flist", r_flistp);
	
	*ret_flistpp = r_flistp;
	
	return;
}


void
fm_tab_notify_pol_enrich_adjust_balance_validity_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_pol_enrich_adjust_balance_validity_notification error",ebufp);
		return ;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_pol_enrich_adjust_balance_validity_notification :"
			" input flist", in_flistp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_pol_enrich_adjust_balance_validity_notification :"
		" Return flist", *ret_flistpp);
	
	return;	
}
