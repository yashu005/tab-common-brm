/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_cust_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_cust_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_CUST_GET_FNF,                 "op_tab_cust_get_fnf", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_CUG,                 "op_tab_cust_get_cug", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_MANAGE_MSISDN_SIM,       "op_tab_cust_manage_msisdn_sim", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_MANAGE_FNF,              "op_tab_cust_manage_fnf", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_MANAGE_CUG,              "op_tab_cust_manage_cug", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_PURCHASE_OFFERS,     "op_tab_cust_get_purchase_offers", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_PURCHASE_OFFER,          "op_tab_cust_purchase_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_CANCEL_OFFER,            "op_tab_cust_cancel_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_CREATE_SUBSCRIBER,       "op_tab_cust_create_subscriber", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_ACCOUNT_INFO,   "op_tab_cust_get_account_info", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_CHANGE_OFFER,   "op_tab_cust_change_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_UPDATE_ACCOUNT_PROFILE,   "op_tab_cust_update_account_profile", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_UPDATE_ACCOUNT_STATUS,   "op_tab_cust_update_account_status", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_UPDATE_ADDRESSES, "op_tab_cust_update_addresses", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_CREATE_ACCOUNT,          "op_tab_cust_create_account", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_SET_SUBSCRIBER_PREFERENCES, "op_tab_cust_set_subscriber_preferences" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_BA_FROM_MSISDN, "op_tab_cust_get_ba_from_msisdn", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE, "op_tab_cust_update_invoice_preference" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_CANCEL_BUDGET_LIMIT, "op_tab_cust_cancel_budget_limit" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_MODIFY_CREDIT_LIMIT, "op_tab_cust_modify_credit_limit" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_CREDIT_LIMIT, "op_tab_cust_get_credit_limit" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_SWAP_SIM, "op_tab_cust_swap_sim", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_SET_BUDGET_LIMIT, "op_tab_cust_set_budget_limit" , CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_EXTRACT_CREDIT_LIMIT_HISTORY, "op_tab_cust_extract_credit_limit_history", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_UPDATE_PURCHASED_OFFERING,   "op_tab_cust_update_purchased_offering", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_MULTI_SIM,"op_tab_cust_get_multi_sim",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_ADD_GROUP_MEMBER, "op_tab_cust_add_group_member",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_MOVE_GROUP_MEMBER, "op_tab_cust_move_group_member",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_GET_GRP_BILLING_MEMBERS, "op_tab_cust_get_grp_billing_members",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_DELETE_GROUP_MEMBER,     "op_tab_cust_delete_group_member", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_MANAGE_MULTI_SIM,     "op_tab_cust_manage_multi_sim", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_CUST_GET_ACCOUNT_FROM_ID, "op_tab_cust_get_account_from_id",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_GET_BUNDLE_CONFIG, "op_tab_cust_get_bundle_config",CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_GET_WRITEOFF_STATUS, "op_tab_cust_get_writeoff_status", CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_UPDATE_WRITEOFF_STATUS, "op_tab_cust_update_writeoff_status" , CM_FM_OP_OVERRIDABLE},
	{ TAB_OP_CUST_GET_NOTIFICATION_HISTORY, "op_tab_cust_get_notification_history" , CM_FM_OP_OVERRIDABLE},
    { 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_cust_config_func()
{
  return ((void *) (fm_tab_cust_config));
}
#endif
