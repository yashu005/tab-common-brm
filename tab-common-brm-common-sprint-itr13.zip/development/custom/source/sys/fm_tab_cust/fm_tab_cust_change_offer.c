/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 16-DEC-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_CHANGE_OFFER operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include <stdlib.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_change_offer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_cust_change_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_change_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);


/**************************************************************************
 * Main routine for the TAB_OP_CUST_CHANGE_OFFER operation.
 *************************************************************************/
void
op_tab_cust_change_offer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_change_offer function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_CHANGE_OFFER) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_change_offer bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_change_offer input flist", in_flistp);
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CHANGE_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CHANGE_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CHANGE_OFFER, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_change_offer:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_change_offer(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_change_offer error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_cust_change_offer:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_change_offer: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_CHANGE_OFFER", &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_change_offer:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CHANGE_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CHANGE_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CHANGE_OFFER, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_change_offer output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to cancel
 * offer and purchase new offerings
 * based on cancel and new array.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_cust_change_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_cookie_t		cancel_package_cookie = NULL;
	pin_cookie_t		new_package_cookie = NULL;
	int        		*statusp = NULL;
	int32			cancel_package_elemid = 0;
	int32			new_package_elemid = 0;
	poid_t			*notify_pdp = NULL;
	poid_t			*service_pdp = NULL;
	pin_flist_t		*cancel_package_flistp = NULL;
	pin_flist_t		*cancel_offer_iflistp = NULL;
	pin_flist_t		*cancel_offer_oflistp = NULL;
	pin_flist_t		*new_package_flistp = NULL;
	pin_flist_t		*purchase_offer_iflistp = NULL;
	pin_flist_t		*purchase_offer_oflistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*temp_input_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*cancel_offer_rdata_flistp = NULL;
	pin_flist_t		*purchase_offer_rdata_flistp = NULL;
	pin_flist_t		*op_out_flistp = NULL;
	pin_flist_t		*rd_iflistp = NULL;
	pin_flist_t		*rd_rflistp = NULL;
	char			*account_nop = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_change_offer input flist", in_flistp);

	/*Account Number not passed in input*/
        account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

        if((account_nop && strlen(account_nop) == 0) ||
                (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
                        "Account Number is not passed in request", ebufp);
                goto cleanup;
        }
		
	/* Checking Service status as Can not add a deal into an non active service*/
	service_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
	rd_iflistp = PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_POID, service_pdp, ebufp);
	PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_purchase_offer read_flds input flist", rd_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, rd_iflistp, &rd_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_offer: "
			"PCM_OP_READ_OBJ input flist", rd_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
			"PCM_OP_READ_OBJ error", ebufp);
                PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);
		goto cleanup;
	}
	PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);
	if (rd_rflistp !=NULL)
	{
		statusp = PIN_FLIST_FLD_GET(rd_rflistp, PIN_FLD_STATUS, 0, ebufp);
		if(statusp && *statusp != PIN_STATUS_ACTIVE)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NON_ACTIVE_SERVICE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
				"Can not add a deal into an inactive/ closed service", ebufp);
			goto cleanup;
		}
	}	

	/*Check for mandatory New Package array*/
	if ((PIN_FLIST_ELEM_GET(in_flistp, TAB_FLD_NEW_PACKAGE, 
		PIN_ELEMID_ANY, 1, ebufp)) == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NEW_PACKAGE_ARRAY_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			"New Package Array missing in request", ebufp);
		goto cleanup;
	}

	/*Check for mandatory New Package array*/
	if ((PIN_FLIST_ELEM_GET(in_flistp, TAB_FLD_CANCEL_PACKAGE, 
		PIN_ELEMID_ANY, 1, ebufp)) == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_CANCEL_PACKAGE_ARRAY_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			"Cancel Package Array missing in request", ebufp);
		goto cleanup;
	}

	common_notification_flistp = PIN_FLIST_CREATE(ebufp);
	cancel_offer_rdata_flistp = PIN_FLIST_CREATE(ebufp);
	purchase_offer_rdata_flistp = PIN_FLIST_CREATE(ebufp);

	/*Moved out of loop for DTAC bug DBILLING-1573 start*/
	cancel_offer_iflistp = PIN_FLIST_CREATE(ebufp);
	cancel_offer_oflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,
			cancel_offer_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN,
			cancel_offer_iflistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,
			cancel_offer_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID,
			cancel_offer_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER,
			cancel_offer_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,
			cancel_offer_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EXCEPTION_FLAG,
			cancel_offer_iflistp, TAB_FLD_EXCEPTION_FLAG, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ,
			cancel_offer_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,
			cancel_offer_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ,
			cancel_offer_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	/*Moved out of loop for DTAC bug DBILLING-1573 end*/

	/*Loop through cancel package array and frame input required for TAB_OP_CUST_CANCEL_OFFER*/
	while ((cancel_package_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_CANCEL_PACKAGE, 
		&cancel_package_elemid, 1, &cancel_package_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		/*Copy input fields for generating notification*/
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
			common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
		PIN_FLIST_FLD_COPY(cancel_package_flistp, PIN_FLD_NAME, 
			common_notification_flistp, PIN_FLD_FROM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
			common_notification_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

		PIN_FLIST_ELEM_SET(cancel_offer_iflistp, cancel_package_flistp, PIN_FLD_PACKAGE_INFO, cancel_package_elemid, ebufp);
	}

	/*Moved out of loop for DTAC bug DBILLING-1573 start*/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_change_offer: TAB_OP_CUST_CANCEL_OFFER input flist", cancel_offer_iflistp);

	fm_tab_cust_cancel_offer(ctxp, cancel_offer_iflistp, &cancel_offer_oflistp, db_no, TAB_NOTIFY_DISABLE, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			" input flist ", cancel_offer_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			" Error during TAB_OP_CUST_CANCEL_OFFER opcode call", ebufp);
		PIN_FLIST_DESTROY_EX(&cancel_offer_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&cancel_offer_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_change_offer: TAB_OP_CUST_CANCEL_OFFER output flist", cancel_offer_oflistp);

	PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp,
	cancel_offer_oflistp, TAB_FLD_CANCEL_PACKAGE, cancel_package_elemid, ebufp);

	PIN_FLIST_DESTROY_EX(&cancel_offer_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&cancel_offer_oflistp, NULL);

	/*Moved out of loop for DTAC bug DBILLING-1573 end*/

	/*Loop through new package array and frame input required for TAB_OP_CUST_PURCHASE_OFFER*/
	while ((new_package_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_NEW_PACKAGE, 
		&new_package_elemid, 1, &new_package_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		/*Copy input fields for generating notification*/
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_NAME, 
				common_notification_flistp, PIN_FLD_TO_NAME, ebufp);
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_PACKAGE_ID, 
				common_notification_flistp, PIN_FLD_PACKAGE_ID, ebufp);
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_UNIQUE_ID, 
				common_notification_flistp, PIN_FLD_UNIQUE_ID, ebufp);
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_VALID_FROM_STR, 
				common_notification_flistp, PIN_FLD_VALID_FROM_STR, ebufp);
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_VALID_TO_STR, 
				common_notification_flistp, PIN_FLD_VALID_TO_STR, ebufp);
		PIN_FLIST_FLD_COPY(new_package_flistp, PIN_FLD_BUNDLE_INFO, 
				common_notification_flistp, PIN_FLD_BUNDLE_INFO, ebufp);

		purchase_offer_iflistp = PIN_FLIST_CREATE(ebufp);
		//purchase_offer_oflistp = PIN_FLIST_CREATE(ebufp);

		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
				purchase_offer_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
				purchase_offer_iflistp, PIN_FLD_MSISDN, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
				purchase_offer_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
				purchase_offer_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
				purchase_offer_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
				purchase_offer_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EXCEPTION_FLAG, 
				purchase_offer_iflistp, TAB_FLD_EXCEPTION_FLAG, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
				purchase_offer_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
				purchase_offer_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, 
				purchase_offer_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

		PIN_FLIST_ELEM_SET(purchase_offer_iflistp, new_package_flistp, PIN_FLD_PACKAGE_INFO, new_package_elemid, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_change_offer: TAB_OP_CUST_PURCHASE_OFFER input flist", purchase_offer_iflistp);

		fm_tab_cust_purchase_offer(ctxp, purchase_offer_iflistp, &purchase_offer_oflistp, db_no, TAB_NOTIFY_DISABLE, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
				" input flist ", purchase_offer_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
				" Error during TAB_OP_CUST_PURCHASE_OFFER opcode call", ebufp);
			
			//*out_flistpp = PIN_FLIST_COPY(purchase_offer_oflistp,ebufp);
			PIN_FLIST_DESTROY_EX(&purchase_offer_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&purchase_offer_oflistp, NULL);
			PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_change_offer: TAB_OP_CUST_PURCHASE_OFFER output flist", purchase_offer_oflistp);

		PIN_FLIST_ELEM_SET(purchase_offer_rdata_flistp, 
			purchase_offer_oflistp, TAB_FLD_NEW_PACKAGE, new_package_elemid, ebufp);

		PIN_FLIST_DESTROY_EX(&purchase_offer_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&purchase_offer_oflistp, NULL);
	}

	/*Prepare flist for notification*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	temp_input_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);

	if(cancel_offer_rdata_flistp != NULL && purchase_offer_rdata_flistp != NULL)
	{
		PIN_FLIST_CONCAT(purchase_offer_rdata_flistp, cancel_offer_rdata_flistp, ebufp);
		PIN_FLIST_SUBSTR_SET(notify_flistp, purchase_offer_rdata_flistp, PIN_FLD_OUT_FLIST, ebufp);
	}

	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CHANGE_OFFER, -1, ebufp);
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_change_offer:"
		" fm_tab_cust_change_offer_notification input flist ", notify_flistp);

	/* Call function to enrich notification details */
	fm_tab_cust_change_offer_notification(ctxp, notify_flistp, db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer:"
			" fm_tab_cust_change_offer_notification input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer: "
			" fm_tab_cust_change_offer_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&cancel_offer_rdata_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&purchase_offer_rdata_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rd_rflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_change_offer output flist", *out_flistpp);
	return;
}

/**
 * We use this function to generate
 * custom notification on change offer.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_cust_change_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_change_offer_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_change_offer_notification: "
		"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_change_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CHANGE_OFFER input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CHANGE_OFFER, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_change_offer_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_change_offer_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_change_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CHANGE_OFFER output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_change_offer_notification output flist", *r_flistpp);
	return;
}
