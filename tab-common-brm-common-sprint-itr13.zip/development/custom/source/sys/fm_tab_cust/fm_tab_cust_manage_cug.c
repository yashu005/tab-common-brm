/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah		| 			| New opcode implementation to
 *                                               			| Manage CUG.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_MANAGE_CUG operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_manage_cug(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_manage_cug(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static int32
fm_tab_cust_manage_cug_create(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static int32
fm_tab_cust_manage_cug_delete(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_pol_validate_cug(
    pcm_context_t		*ctxp,
    pin_flist_t			*in_flistp,
    pin_flist_t         **ret_flistpp,
    int64               db_no,
    pin_errbuf_t        *ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_profile_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	char			*profile_type,
	char			*profile_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern unsigned long
fm_tab_utils_common_get_max_elemid(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			fld_no,
	pin_errbuf_t		*ebufp);
	
static void
fm_tab_cust_manage_cug_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_MANAGE_CUG is implemented to manage 
 * CUG details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, PIN_FLD_NAME
 *                  and PIN_FLD_DATA_ARRAY.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN                STR [0] "981999999"
 * 0 PIN_FLD_ACCOUNT_NO            STR [0] "777777"
 * 0 PIN_FLD_ACTION                STR [0] "add"
 * 0 PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
 * 1    PIN_FLD_VALUE         STR [0] "45344534"
 * 1    PIN_FLD_NAME          STR [0] "123213"
 * 0 PIN_FLD_NAME                  STR [0] "CUG"
 * 0 PIN_FLD_CORRELATION_ID        STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER         STR [0] "CRM"
 *
 */

void
op_tab_cust_manage_cug(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_manage_cug function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_MANAGE_CUG) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_manage_cug bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_cug input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_db_no input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
        }

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADD_REMOVE_MEMBER_CUG;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADD_REMOVE_MEMBER_CUG)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_ADD_REMOVE_MEMBER_CUG, ebufp);
		}
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_manage_cug(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", enrich_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug: Error while Opening transaction",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
                return;
        }

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_MANAGE_CUG", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADD_REMOVE_MEMBER_CUG;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADD_REMOVE_MEMBER_CUG)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_ADD_REMOVE_MEMBER_CUG, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_cug output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to modify the profile information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_manage_cug(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;

	pin_cookie_t	data_cookie = NULL;
	int32			data_elemid = 0;
	time_t			current_time;

	char			*action = NULL;
	char			*msisdn = NULL;
	char			*group_name = NULL;
	char			*name = NULL;
	char			*value = NULL;
	pin_flist_t		*manage_cug_rflistp = NULL;
	pin_flist_t     *validatecug_rflistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug: input flist", in_flistp);
	current_time = pin_virtual_time(NULL);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug: Error PIN_FLD_MSISDN - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		goto cleanup;
	}

	action = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACTION, 1, ebufp);
	if ((action == NULL || strlen(action) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACTION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug: Error PIN_FLD_ACTION - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		goto cleanup;
	}
	if(action && !((strcmp(action, TAB_ACTION_ADD) == 0) || (strcmp(action, TAB_ACTION_DELETE) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ACTION_CODE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug: Error Invalid Action Code passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		goto cleanup;
	}

	group_name = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);
	if ((group_name == NULL || strlen(group_name) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GRP_NAME_NOT_PASSED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug: Error PIN_FLD_NAME - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		goto cleanup;
	}

	data_elemid = 0;
	data_cookie = NULL;
	while ((data_array_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_DATA_ARRAY,
		&data_elemid, 1, &data_cookie, ebufp)) != NULL)
	{
		name = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_NAME, 1, ebufp);
		if((name == NULL || strlen(name) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_MISSING_ARG, PIN_FLD_NAME, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_cug function: Error PIN_FLD_NAME - Input is missing",
				ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
				"input flist", in_flistp);
		}
		value = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_VALUE, 1, ebufp);
		if((value == NULL || strlen(value) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_MISSING_ARG, PIN_FLD_VALUE, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_cug function: Error PIN_FLD_VALUE - Input is missing",
					ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
				"input flist", in_flistp);
		}
		PIN_FLIST_FLD_SET(data_array_flistp, PIN_FLD_VALID_FROM, &current_time, ebufp);
	}

	/* To Create CUG */
	if( action && strcmp(action, TAB_ACTION_ADD) == 0 )
    {
        /*BU Specific Validation when ActionCode=ADD*/
        fm_tab_cust_pol_validate_cug(ctxp, in_flistp, &validatecug_rflistp, db_no, ebufp);
        if(PIN_ERR_IS_ERR(ebufp))
        {
            PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
                "input flist", in_flistp);
            PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
                "flist error", ebufp);
            PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
                "return flist", validatecug_rflistp);
            *ret_flistpp = validatecug_rflistp;
            goto cleanup;
        }
		/*calling CUG Create if there is no errors*/
		fm_tab_cust_manage_cug_create(ctxp, in_flistp, &manage_cug_rflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug:"
				" fm_tab_cust_manage_cug_create output flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug: "
				"fm_tab_cust_manage_cug_create error ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
				"input flist", in_flistp);
			goto cleanup;
		}
	}
	/* To delete CUG */
	if( action && strcmp(action, TAB_ACTION_DELETE) == 0 &&
		!fm_tab_cust_manage_cug_delete(ctxp, in_flistp, &manage_cug_rflistp, db_no, ebufp) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug:"
			" fm_tab_cust_manage_cug_delete output flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug: "
			"fm_tab_cust_manage_cug_delete error ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", in_flistp);
		goto cleanup;
	}
	// Call function to enrich notification details
	fm_tab_cust_manage_cug_notification(ctxp, in_flistp, manage_cug_rflistp, db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			" fm_tab_cust_manage_cug_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug: "
			" fm_tab_cust_manage_cug_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
        PIN_FLIST_DESTROY_EX(&manage_cug_rflistp, NULL);	
	return;
}

/**
 * We use this function to create the profile data array info 
 * by calling opcode PCM_OP_CUST_MODIFY_CUSTOMER
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return boolean value true or false.
 */
static int32
fm_tab_cust_manage_cug_create(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*acc_pdp = NULL;

	pin_flist_t		*modify_in_flistp = NULL;
	pin_flist_t		*modify_out_flistp = NULL;
	pin_flist_t		*sub_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*profiles_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*data_array_in_flistp = NULL;
	pin_flist_t		*inherited_flistp = NULL;

	int32			data_elemid = 0;
	pin_cookie_t		data_cookie = NULL;

	int32			data_in_elemid = 0;
	pin_cookie_t		data_in_cookie = NULL;

	char			*group_name = NULL;
	char			*name = NULL;
	char			*value = NULL;
	char			*in_name = NULL;
	char			*in_value = NULL;

	int32			match_found = 0;
	int32			status = PIN_BOOLEAN_TRUE;
	unsigned long		data_array_max = 0;
	int32			flag = PCM_OPFLG_ADD_ENTRY;
	time_t			*valid_to = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug_create function entry error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		return status;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_create:"
		" input flist ", in_flistp);
	acc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	group_name = (char *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);

	modify_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(modify_in_flistp, PIN_FLD_POID, (void *)acc_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, modify_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, modify_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	sub_flistp = PIN_FLIST_SUBSTR_ADD(modify_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_utils_common_get_profile_details(ctxp, in_flistp, TAB_PROFILE_SERV_EXTRATING, group_name, 
		&r_flistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
		" fm_tab_utils_common_get_profile_details input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create: "
			"fm_tab_utils_common_get_profile_details error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}

	if (r_flistp && (result_flistp = PIN_FLIST_ELEM_GET(r_flistp, 
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug_create: "
		"fm_tab_utils_common_get_profile_details result flist", result_flistp);

		/* Get max members array elem */
		data_array_max = fm_tab_utils_common_get_max_elemid(ctxp, result_flistp, 
				PIN_FLD_DATA_ARRAY, ebufp);

		profiles_flistp = PIN_FLIST_ELEM_ADD(modify_in_flistp, PIN_FLD_PROFILES, 0,ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID, profiles_flistp, PIN_FLD_PROFILE_OBJ, ebufp);
		inherited_flistp = PIN_FLIST_SUBSTR_ADD(profiles_flistp, PIN_FLD_INHERITED_INFO, ebufp);

		match_found = 0;
		data_in_elemid = 0;
		data_in_cookie = NULL;
		while ((data_array_in_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_DATA_ARRAY,
			&data_in_elemid, 1, &data_in_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			in_name = (char *)PIN_FLIST_FLD_GET(data_array_in_flistp, PIN_FLD_NAME, 1, ebufp);
			in_value = (char *)PIN_FLIST_FLD_GET(data_array_in_flistp, PIN_FLD_VALUE, 1, ebufp);

			data_elemid = 0;
			data_cookie = NULL;
			while ((data_array_flistp = PIN_FLIST_ELEM_GET_NEXT(result_flistp, PIN_FLD_DATA_ARRAY,
				&data_elemid, 1, &data_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				name = (char *)PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_NAME, 1, ebufp);
				value = (char *)PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_VALUE, 1, ebufp);
				valid_to = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_VALID_TO, 1, ebufp);

				if(name && in_name && in_value && value && strcmp(name, in_name) == 0 &&
					strcmp(value, in_value) == 0 && (*valid_to == 0 || valid_to == NULL))
				{
					match_found = 1;
					break;
				}
				else
				{
					match_found = 2;
				}
			}
			if( match_found == 1 )
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_create: "
					"input flist", in_flistp);
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_DUP_CUG, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
					"Duplicate CUG found for the given account number", ebufp);
				status = PIN_BOOLEAN_FALSE;
				goto cleanup;
			}
			if( match_found != 1 )
			{
				PIN_FLIST_ELEM_COPY(in_flistp, PIN_FLD_DATA_ARRAY, data_in_elemid,
					inherited_flistp, PIN_FLD_DATA_ARRAY, ++data_array_max, ebufp);
			}
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_create: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_CUG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
			"No CUG found for the given account number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;

	}
	if( match_found == 1 )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_create: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DUP_CUG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
			"Duplicate CUG found for the given account number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	/*if( match_found == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_create: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_CUG_DATA_ARRAY_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
			"No DataArray found for the given account number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;

	}*/

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 4190005 166
	 * 0 PIN_FLD_PROGRAM_NAME    STR [0] "manage msisdn_sim"
	 * 0 PIN_FLD_PROFILES      ARRAY [0] allocated 20, used 3
	 * 1     PIN_FLD_PROFILE_OBJ    POID [0] 0.0.0.1 /profile/serv_extrating 14547851 0
	 * 1     PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 2
	 * 2         PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
	 * 3            PIN_FLD_VALUE        STR [0] "45344534"
	 * 3            PIN_FLD_NAME         STR [0] "123213"
	 * 3            PIN_FLD_VALID_TO     TSTAMP [0] (0) <null>
	 * 3            PIN_FLD_VALID_FROM   TSTAMP [0] (0) <null>
	 * 0 PIN_FLD_CONTEXT_INFO SUBSTRUCT [0] allocated 20, used 2
	 * 1     PIN_FLD_CORRELATION_ID       STR [0] "45344534"
	 * 1     PIN_FLD_EXTERNAL_USER        STR [0] "123213"
	 *
	 * */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_create:"
		" CUST_MODIFY_CUSTOMER input flist ", modify_in_flistp);

	PCM_OP(ctxp, PCM_OP_CUST_MODIFY_CUSTOMER, flag, modify_in_flistp, &modify_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
			" input flist ", modify_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_create:"
			" Error in Modify Customer: ", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_create:"
		" CUST_MODIFY_CUSTOMER output flist ", modify_out_flistp);

	/*******************************************************************
	 *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&modify_in_flistp, NULL);
	*ret_flistpp = modify_out_flistp;
	return status;
}

/**
 * We use this function to delete the profile data array info
 * by calling opcode PCM_OP_CUST_MODIFY_CUSTOMER
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return boolean value true or false.
 */
static int32
fm_tab_cust_manage_cug_delete(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	poid_t			*acc_pdp = NULL;

	pin_flist_t		*modify_in_flistp = NULL;
	pin_flist_t		*modify_out_flistp = NULL;
	pin_flist_t		*sub_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*profiles_flistp = NULL;
	pin_flist_t		*profiles_data_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*data_array_in_flistp = NULL;
	pin_flist_t		*inherited_flistp = NULL;

	int32			data_elemid = 0;
	pin_cookie_t		data_cookie = NULL;

	int32			data_in_elemid = 0;
	pin_cookie_t		data_in_cookie = NULL;

	char			*group_name = NULL;
	char			*name = NULL;
	char			*value = NULL;
	char			*in_name = NULL;
	char			*in_value = NULL;

	int32			status = PIN_BOOLEAN_TRUE;
	int32			match_found = 0;
	time_t			current_time;
	time_t			*valid_to = NULL;
	int32			flag = PCM_OPFLG_ADD_ENTRY;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_cug_delete function entry error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		return status;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_delete:"
		" input flist ", in_flistp);
	acc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	current_time = pin_virtual_time(NULL);
	group_name = (char *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);

	modify_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(modify_in_flistp, PIN_FLD_POID, (void *)acc_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, modify_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, modify_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	sub_flistp = PIN_FLIST_SUBSTR_ADD(modify_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_utils_common_get_profile_details(ctxp, in_flistp, TAB_PROFILE_SERV_EXTRATING, 
		group_name, &r_flistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete:"
			" fm_tab_utils_common_get_profile_details input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete: "
			"fm_tab_utils_common_get_profile_details error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}

	if (r_flistp && (result_flistp = PIN_FLIST_ELEM_GET(r_flistp,
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug_delete: "
			"fm_tab_utils_common_get_profile_details result flist", result_flistp);

		profiles_flistp = PIN_FLIST_ELEM_ADD(modify_in_flistp, PIN_FLD_PROFILES, 0,ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID, profiles_flistp, PIN_FLD_PROFILE_OBJ, ebufp);
		inherited_flistp = PIN_FLIST_SUBSTR_ADD(profiles_flistp, PIN_FLD_INHERITED_INFO, ebufp); 

		match_found = 0;
		data_in_elemid = 0;
		data_in_cookie = NULL;
		while ((data_array_in_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_DATA_ARRAY,
			&data_in_elemid, 1, &data_in_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			in_name = (char *)PIN_FLIST_FLD_GET(data_array_in_flistp, PIN_FLD_NAME, 1, ebufp);
			in_value = (char *)PIN_FLIST_FLD_GET(data_array_in_flistp, PIN_FLD_VALUE, 1, ebufp);
			data_elemid = 0;
			data_cookie = NULL;
			while ((data_array_flistp = PIN_FLIST_ELEM_GET_NEXT(result_flistp, PIN_FLD_DATA_ARRAY,
				&data_elemid, 1, &data_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				name = (char *)PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_NAME, 1, ebufp);
				value = (char *)PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_VALUE, 1, ebufp);
				valid_to = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_VALID_TO, 1, ebufp);

				if(name && in_name && in_value && value && strcmp(name, in_name) == 0 && 
					strcmp(value, in_value) == 0 && (*valid_to == 0 || valid_to == NULL)) 
				{
					profiles_data_flistp = PIN_FLIST_ELEM_ADD(inherited_flistp, PIN_FLD_DATA_ARRAY, 
						data_elemid, ebufp);
					PIN_FLIST_FLD_COPY(data_array_flistp, PIN_FLD_NAME, profiles_data_flistp, 
						PIN_FLD_NAME, ebufp);
					PIN_FLIST_FLD_COPY(data_array_flistp, PIN_FLD_VALUE, profiles_data_flistp, 
						PIN_FLD_VALUE, ebufp);
					PIN_FLIST_FLD_COPY(data_array_flistp, PIN_FLD_VALID_FROM, profiles_data_flistp, 
						PIN_FLD_VALID_FROM, ebufp);
					PIN_FLIST_FLD_SET(profiles_data_flistp, PIN_FLD_VALID_TO, &current_time, ebufp);
					match_found = 1;
					PIN_FLIST_ELEM_DROP(result_flistp, PIN_FLD_DATA_ARRAY, data_elemid, ebufp);
				}
				else
				{
					PIN_FLIST_ELEM_COPY(result_flistp, PIN_FLD_DATA_ARRAY, data_elemid,
						inherited_flistp, PIN_FLD_DATA_ARRAY, data_elemid, ebufp);
				}
			}

		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_delete: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_CUG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete:"
			"No CUG found for the given account number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;

	}
	if( match_found == 0 )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_cug_delete: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_CUG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete:"
			"No CUG found for the given account number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 4190005 166
	 * 0 PIN_FLD_PROGRAM_NAME    STR [0] "manage msisdn_sim"
	 * 0 PIN_FLD_PROFILES      ARRAY [0] allocated 20, used 3
	 * 1     PIN_FLD_PROFILE_OBJ    POID [0] 0.0.0.1 /profile/serv_extrating 14547851 0
	 * 1     PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 2
	 * 2         PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
	 * 3            PIN_FLD_VALUE        STR [0] "45344534"
	 * 3            PIN_FLD_NAME         STR [0] "123213"
	 * 3            PIN_FLD_VALID_TO     TSTAMP [0] (0) <null>
	 * 3            PIN_FLD_VALID_FROM   TSTAMP [0] (0) <null>
	 * 0 PIN_FLD_CONTEXT_INFO SUBSTRUCT [0] allocated 20, used 2
	 * 1     PIN_FLD_CORRELATION_ID       STR [0] "45344534"
	 * 1     PIN_FLD_EXTERNAL_USER        STR [0] "123213"
	 *
	 * */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_delete:"
		" CUST_MODIFY_CUSTOMER input flist ", modify_in_flistp);

	PCM_OP(ctxp, PCM_OP_CUST_MODIFY_CUSTOMER, flag, modify_in_flistp, &modify_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete:"
			" input flist ", modify_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_delete:"
			" Error in Modify Customer: ", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_delete:"
		" CUST_MODIFY_CUSTOMER output flist ", modify_out_flistp);

	/*******************************************************************
	 *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&modify_in_flistp, NULL);
	*ret_flistpp = modify_out_flistp;
	return status;

}

static void
fm_tab_cust_manage_cug_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*readobj_iflistp =NULL;
	pin_flist_t		*readobj_rflistp =NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	poid_t			*notify_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_cug_notification: "
		"input flist", i_flistp);
		
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, readobj_iflistp, PIN_FLD_POID, ebufp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, readobj_iflistp, &readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"input flist", readobj_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_cug:"
			"Error while doing event read_obj", ebufp);
		goto cleanup;
	}
	
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	common_notification_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MANAGE_CUG, -1, ebufp);
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, common_notification_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_ACCOUNT_NO, common_notification_flistp, 
			PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);

	res_flistp = PIN_FLIST_ELEM_GET(i_flistp,PIN_FLD_DATA_ARRAY, PIN_ELEMID_ANY, 1, ebufp);
	if (res_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_VALUE, common_notification_flistp, PIN_FLD_VALUE, ebufp);
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_NAME, common_notification_flistp, PIN_FLD_NAME, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_purchase_offer:"
		" fm_tab_cust_manage_cug_notification input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MANAGE_CUG, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_manage_cug_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_manage_cug_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_cug_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_MANAGE_CUG output flist ", enrich_notify_flistp);

	cleanup:
    /******************************************************************
     * Clean up.
    ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_iflistp,NULL);
		
	*r_flistpp = enrich_notify_flistp;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_manage_cug_notification output flist", *r_flistpp);
	return;
}

static void
fm_tab_cust_pol_validate_cug(
    pcm_context_t           *ctxp,
    pin_flist_t             *in_flistp,
    pin_flist_t             **ret_flistpp,
    int64                   db_no,
    pin_errbuf_t            *ebufp)
{

    pin_flist_t             *validate_cug_iflistp = NULL;
    pin_flist_t             *validate_cug_rflistp = NULL;

    if(PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug error", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
            " input flist", in_flistp);
        return ;
    }

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_validate_cug:"
         " input flist ", in_flistp);

    validate_cug_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

    PCM_OP(ctxp, TAB_OP_CUST_POL_VALIDATE_CUG, 0, validate_cug_iflistp, &validate_cug_rflistp, ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
            "input flist", in_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_validate_cug:"
             "flist error", ebufp);
		*ret_flistpp = validate_cug_rflistp;
       goto cleanup;
    }

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_validate_cug:"
        "return flist", validate_cug_rflistp);
cleanup:
    /******************************************************************
     * Clean up.
    ******************************************************************/
    PIN_FLIST_DESTROY_EX(&validate_cug_iflistp, NULL);
    return ;
}

