/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/****************************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 19-NOV-2021		| Darshan		|		| New file.

 ****************************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_PURCHASE_OFFERS operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_get_purchase_offers(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_cust_get_purchase_offers(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void 
fm_tab_cust_enrich_product_offerings(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t     *pur_bundle_rflistp,
	char			*invoice_langp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void fm_tab_cust_enrich_discount_offerings(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t     *pur_bundle_rflistp,
	pin_flist_t		*prod_out_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_product_cache(
	pcm_context_t		*ctxp,
	poid_t			*product_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_discount_cache(
	pcm_context_t		*ctxp,
	poid_t		*discount_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_deal_cache(
	pcm_context_t		*ctxp,
	poid_t			*deal_pdp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_plan_cache(
	pcm_context_t		*ctxp,
	poid_t			*plan_pdp,
	pin_flist_t		*bundle_rflistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_purchased_bundle_details(
	pcm_context_t		*ctxp,
	poid_t			*acct_pdp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_CUST_GET_PURCHASE_OFFERS operation.
 *************************************************************************/
void
op_tab_cust_get_purchase_offers(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			status_fail = PIN_BOOLEAN_FALSE;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char                    log_msg[512]= "";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_purchase_offers error",ebufp);
		return ;
	}

	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_CUST_GET_PURCHASE_OFFERS) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_purchase_offers opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_cust_get_purchase_offers input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*out_flistpp = r_flistp;
		return;
	}

	fm_tab_cust_get_purchase_offers(ctxp, in_flistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
			"op_tab_cust_get_purchase_offers error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_purchase_offers:"
			" input flist ", in_flistp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_PURCHASE_OFFERS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_PURCHASE_OFFERS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PURCHASE_OFFERS, ebufp);
		}
		status = TAB_FAIL;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	else{
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*out_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"op_tab_cust_get_purchase_offers output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * fm_tab_cust_get_purchase_offers()
 *	
 * This function will be used to initiate calls to
 * retrieve product and discount offerings
 * 
 * @param ctxp The context pointer.
 * @param in_flistp input flist.
 * @param out_flistp The return flist.
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *********************************************************************/

void fm_tab_cust_get_purchase_offers(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*api_validate_oflistp = NULL;
	pin_flist_t		*get_purchased_offerings_iflistp = NULL;
	pin_flist_t		*get_purchased_offerings_oflistp = NULL;
	pin_flist_t		*enriched_prod_offerings_flistp = NULL;
	pin_flist_t		*enriched_disc_offerings_flistp = NULL;
	pin_flist_t		*profile_customer_iflistp = NULL;
	pin_flist_t		*profile_customer_oflistp = NULL;
	pin_flist_t		*customer_info_flistp = NULL;
	pin_flist_t		*enriched_oflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*get_pkg_info_flistp = NULL;
	pin_flist_t		*get_bundle_info_flistp = NULL;
	pin_flist_t		*enriched_prod_offerings_oflistp = NULL;
	
	int32			*statusp = NULL;
	int32			package_info_elemid = 0;
	int32			bundle_info_elemid = 0;
	pin_cookie_t		package_info_cookie = NULL;
	pin_cookie_t		bundle_info_cookie = NULL;
	char			*invoice_langp = NULL;
	char			*account_nop = NULL;
	char			*msisdnp = NULL;
	int			status_flag = 0;
	poid_t			*account_pdp = NULL;
	pin_flist_t		*bundle_resflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_get_purchase_offers input flist", in_flistp);
		
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	
	/*Check for account number or MSISDN*/
	if((account_nop == NULL || strlen(account_nop ) == 0) 
		&& (msisdnp == NULL || strlen(msisdnp) == 0)) 
    {
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	/*Validate and normalize input*/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &api_validate_oflistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_purchase_offers: fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
			" input flist", in_flistp);
		return;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_purchase_offers: "
			"fm_tab_utils_common_validate_and_normalize_input output flist", api_validate_oflistp);
	}

	if (api_validate_oflistp != NULL)
	{
		get_purchased_offerings_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_POID, get_purchased_offerings_iflistp, PIN_FLD_POID, ebufp);

		/*Get offering input status*/
		statusp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_STATUS, 1, ebufp);

		if(statusp == NULL || PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_STATUS, 1, ebufp) == NULL)
		{
			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_ACTIVE;
			PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp, PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);
		}
		else if(statusp != NULL && *statusp == TAB_FLG_OFFERING_STATUS_ACTIVE)
		{
			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_ACTIVE;
			PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp, PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);
		}
		else if(statusp != NULL && *statusp == TAB_FLG_OFFERING_STATUS_INACTIVE)
		{
			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_INACTIVE;
			PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp, PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);
		}
		else if(statusp != NULL && *statusp == TAB_FLG_OFFERING_STATUS_CLOSED)
		{
			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_CLOSED;
			PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp, PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);
		}
		else if(statusp != NULL && *statusp == TAB_FLG_OFFERING_STATUS_ACTIVE_INACTIVE)
		{
			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_ACTIVE+PIN_SUBS_FLG_OFFERING_STATUS_INACTIVE;
			PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp, PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_purchase_offers: "
			"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS input", get_purchased_offerings_iflistp);

		PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS, 0, get_purchased_offerings_iflistp, &get_purchased_offerings_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS:"
				" input flist ", get_purchased_offerings_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS:"
				" Error while searching purchased offerings", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_purchase_offers: "
			"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS output", get_purchased_offerings_oflistp);

		/*Check if there is alteast one product or discount offering*/
		if(get_purchased_offerings_oflistp != NULL && 
			((PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_PRODUCTS, ebufp) > 0)  || 
			 (PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_DISCOUNTS, ebufp) > 0 )))
		{
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_POID, 
				get_purchased_offerings_oflistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_SERVICE_OBJ, 
				get_purchased_offerings_oflistp, PIN_FLD_SERVICE_OBJ, ebufp);
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_ACCOUNT_NO, 
				get_purchased_offerings_oflistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_MSISDN, 
				get_purchased_offerings_oflistp, PIN_FLD_MSISDN, ebufp);
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_BAL_GRP_OBJ, 
				get_purchased_offerings_oflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

			/* Get profile customer details */
			profile_customer_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_POID, profile_customer_iflistp, PIN_FLD_POID, ebufp);

			fm_tab_utils_common_get_profile_customer_details(ctxp, profile_customer_iflistp, 
				&profile_customer_oflistp, db_no, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_customer_details:"
					" input flist ", profile_customer_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_customer_details:"
					" Error while getting profile customer details", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_profile_customer_details "
					"output flist", profile_customer_oflistp);

				if(profile_customer_oflistp != NULL)
				{
					results_flistp = PIN_FLIST_ELEM_GET(profile_customer_oflistp, PIN_FLD_RESULTS, 
						PIN_ELEMID_ANY, 1, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_profile_customer_details "
						"results_flistp", results_flistp);

					if(results_flistp != NULL)
					{
						customer_info_flistp = PIN_FLIST_SUBSTR_GET(results_flistp, 
							PIN_FLD_CUSTOMER_CARE_INFO, 1, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_profile_customer_details: "
							"customer_info_flistp", customer_info_flistp);

						if(customer_info_flistp != NULL)
						{
							invoice_langp = PIN_FLIST_FLD_GET(customer_info_flistp, TAB_FLD_INV_LANG, 1, ebufp);
						}
					}
				}
			}
			
			account_pdp = PIN_FLIST_FLD_GET(api_validate_oflistp, PIN_FLD_POID, 1, ebufp);
			fm_tab_utils_common_get_purchased_bundle_details(ctxp, account_pdp, &bundle_resflistp, db_no, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
		                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details error", ebufp);
		                PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchased_bundle_details:"
                                	" account poid", account_pdp);
                		goto cleanup;
			}
			/*Enrich Product Offerings*/
			if(PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_PRODUCTS, ebufp) > 0)
			{
				fm_tab_cust_enrich_product_offerings(ctxp, get_purchased_offerings_oflistp, bundle_resflistp, invoice_langp, 
					&enriched_prod_offerings_flistp,db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_product_offerings:"
						" input flist ", get_purchased_offerings_oflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_product_offerings:"
						" Error while enriching product offerings", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings output flist", 
						enriched_prod_offerings_flistp);						

					PCM_OP(ctxp, TAB_OP_CUST_POL_GET_POLICY_LABEL, 0, enriched_prod_offerings_flistp, 
						&enriched_prod_offerings_oflistp, ebufp);

					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_GET_POLICY_LABEL:"
							" input flist ", enriched_prod_offerings_flistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_enrich_product_offerings:"
							" Error in getting policy label name", ebufp);
						*out_flistpp = enriched_prod_offerings_oflistp;
						goto cleanup;
					}

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
						" TAB_OP_CUST_POL_GET_POLICY_LABEL output flist ", enriched_prod_offerings_oflistp);
				}
			}

			/*Enrich Discount Offerings*/
			fm_tab_cust_enrich_discount_offerings(ctxp, get_purchased_offerings_oflistp, bundle_resflistp, 
					enriched_prod_offerings_oflistp, &enriched_disc_offerings_flistp, db_no,ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_discount_offerings:"
					" input flist ", get_purchased_offerings_oflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_discount_offerings:"
					" Error while enriching discount offerings", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,  "fm_tab_cust_enrich_discount_offerings output flist", 
					enriched_disc_offerings_flistp);

				if(enriched_disc_offerings_flistp != NULL)
				{
					enriched_oflistp = PIN_FLIST_COPY(enriched_disc_offerings_flistp, ebufp);
				}
			}

			PIN_FLIST_FLD_COPY(get_purchased_offerings_oflistp, PIN_FLD_POID, 
				enriched_oflistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
				enriched_oflistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
				enriched_oflistp, PIN_FLD_MSISDN, ebufp);
				
			if(enriched_oflistp != NULL)
			{
				package_info_elemid = 0;
				package_info_cookie = NULL;
				while ((get_pkg_info_flistp = PIN_FLIST_ELEM_GET_NEXT(enriched_oflistp, PIN_FLD_PACKAGE_INFO, 
					&package_info_elemid, 1, &package_info_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					if(PIN_FLIST_FLD_GET(get_pkg_info_flistp, PIN_FLD_POID, 1, ebufp) != NULL)
					{
						PIN_FLIST_FLD_DROP(get_pkg_info_flistp, PIN_FLD_POID, ebufp);
					}
					
					bundle_info_elemid = 0;
					bundle_info_cookie = NULL;
					while ((get_bundle_info_flistp = PIN_FLIST_ELEM_GET_NEXT(get_pkg_info_flistp, PIN_FLD_BUNDLE_INFO, 
						&bundle_info_elemid, 1, &bundle_info_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						if(PIN_FLIST_FLD_GET(get_bundle_info_flistp, PIN_FLD_POID, 1, ebufp) != NULL)
						{
							PIN_FLIST_FLD_DROP(get_bundle_info_flistp, PIN_FLD_POID, ebufp);
						}
					}
				}
			}


			*out_flistpp = enriched_oflistp;
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_PURCHASED_OFFERINGS, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_purchase_offers:"
				"No purchased offerings associated with the account", ebufp);
			goto cleanup;
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_purchased_offerings_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enriched_prod_offerings_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enriched_disc_offerings_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enriched_prod_offerings_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_purchased_offerings_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&profile_customer_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&profile_customer_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&api_validate_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bundle_resflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_purchase_offers output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * fm_tab_cust_enrich_product_offerings()
 * 
 * This function will be used to enrich flist based on the
 * product offerings associated with the account
 * @param ctxp The context pointer.
 * @param in_flistp input flist.
 * @param out_flistp The return flist.
 * @param invoice_langp Invoice lang.
 * @param ebufp The error buffer.
 * @return flistp.
 * 
 *********************************************************************/
void fm_tab_cust_enrich_product_offerings(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t     *pur_bundle_rflistp,
	char			*invoice_langp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*products_flistp = NULL;
	pin_flist_t		*product_read_flds_oflistp = NULL;
	pin_flist_t		*pur_bundle_read_flds_oflistp = NULL;
	pin_flist_t		*deal_read_flds_oflistp = NULL;
	pin_flist_t		*prod_offerings_oflistp = NULL;
	pin_flist_t		*package_info_flistp = NULL;
	pin_flist_t		*bundle_info_flistp = NULL;
	pin_flist_t		*add_product_flistp = NULL;
	pin_flist_t		*cycle_fees_flistp = NULL;
	pin_flist_t		*get_pkg_info_flistp = NULL;
	pin_flist_t		*get_bundle_info_flistp = NULL;
	pin_flist_t		*get_product_flistp = NULL;
	pin_flist_t		*policy_label_flistp = NULL;
	pin_flist_t		*marketing_name_iflistp = NULL;
	pin_flist_t		*enrich_marketing_name_oflistp = NULL;
	pin_flist_t		*hook_package_flistp = NULL;
	poid_t			*product_pdp = NULL;
	poid_t			*deal_pdp = NULL;
	poid_t			*purchased_bundle_pdp = NULL;
	poid_t			*out_purchase_bundle_pdp = NULL;
	poid_t			*out_deal_purchase_bundle_pdp = NULL;
	unsigned long		package_count = 0;
	unsigned long		hook_package_count = 0;
	unsigned long		bundle_count = 0;
	unsigned long		product_count = 0;
	pin_cookie_t		package_info_cookie = NULL;
	pin_cookie_t		products_cookie = NULL;
	pin_cookie_t		bundle_info_cookie = NULL;
	pin_cookie_t		product_cookie = NULL;
	pin_cookie_t		policy_label_cookie = NULL;
	char			*in_package_namep = NULL;
	char			*out_package_namep = NULL;
	char			*in_deal_name = NULL;
	char			*out_deal_name = NULL;
	char			*in_prod_name = NULL;
	char			*out_prod_name = NULL;
	char			*product_name_labelp = NULL;
	char			*valid_from_strp = NULL;
	char			*valid_to_strp = NULL;
	char			*created_strp = NULL;
	char			*charged_from_strp = NULL;
	char			*charged_to_strp = NULL;
	char			*prod_pur_start_strp = NULL;
	char			*prod_pur_end_strp = NULL;
	int32			package_info_elemid = 0;
	int32			bundle_info_elemid = 0;
	int32			product_elemid = 0;
	int32			policy_label_elemid = 0;
	int32			products_elemid = 0;
	int			package_status = TAB_NOT_FOUND;
	int			bundle_status = TAB_NOT_FOUND;
	int			product_status = TAB_NOT_FOUND;
	time_t			*purchase_start_t =	 NULL;
	time_t			*purchase_end_t =  NULL;
	time_t			*valid_from_t =	 NULL;
	time_t			*valid_to_t =  NULL;
	time_t			*created_t =  NULL;
	time_t			*charged_from_t =  NULL;
	time_t			*charged_to_t =	 NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_enrich_product_offerings input flist", in_flistp);

	prod_offerings_oflistp = PIN_FLIST_CREATE(ebufp);

	while ((products_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_PRODUCTS, 
		&products_elemid, 1, &products_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		bundle_count = 0;
		package_status = TAB_NOT_FOUND;
		bundle_status = TAB_NOT_FOUND;
		product_status = TAB_NOT_FOUND;

		/*Purchased Bundle Poid Read Flds*/
		purchased_bundle_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);

		if(!PIN_POID_IS_NULL(purchased_bundle_pdp))
		{
			fm_tab_utils_common_read_plan_cache(ctxp, purchased_bundle_pdp, pur_bundle_rflistp, &pur_bundle_read_flds_oflistp, db_no, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_plan_cache :"
					" bundle poidp ", purchased_bundle_pdp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_plan_cache:"
					" Error while reading purchased bundle object", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
					"read purchased bundle flds output flist", pur_bundle_read_flds_oflistp);

				if(pur_bundle_read_flds_oflistp != NULL)
				{
					in_package_namep = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_NAME, 1, ebufp);
					
					package_status = TAB_NOT_FOUND;
					package_info_elemid = 0;
					package_info_cookie = NULL;

					/*Check if package name under PACKAGE_INFO array already exists*/
					while ((get_pkg_info_flistp = PIN_FLIST_ELEM_GET_NEXT(prod_offerings_oflistp, PIN_FLD_PACKAGE_INFO, 
						&package_info_elemid, 1, &package_info_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						out_package_namep = PIN_FLIST_FLD_GET(get_pkg_info_flistp, PIN_FLD_NAME, 1, ebufp);
						out_purchase_bundle_pdp = PIN_FLIST_FLD_GET(get_pkg_info_flistp, PIN_FLD_POID, 1, ebufp);

						if (in_package_namep && out_package_namep && 
						!strcmp(in_package_namep, out_package_namep)
						&& !PIN_POID_IS_NULL(out_purchase_bundle_pdp) &&
						!PIN_POID_COMPARE(purchased_bundle_pdp, out_purchase_bundle_pdp, 0, ebufp))
						{
							package_status = TAB_FOUND;
							
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
							" prod_offerings_oflistp", prod_offerings_oflistp);

							/*Hook opocode for populating marketing name*/
							marketing_name_iflistp = PIN_FLIST_CREATE(ebufp);

							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
								marketing_name_iflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
								marketing_name_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
								marketing_name_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
								marketing_name_iflistp, PIN_FLD_MSISDN, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, 
								marketing_name_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

							if(prod_offerings_oflistp != NULL)
							{
								PIN_FLIST_ELEM_COPY(prod_offerings_oflistp, PIN_FLD_PACKAGE_INFO, package_info_elemid,
									marketing_name_iflistp, PIN_FLD_PACKAGE_INFO, 0, ebufp);
							}

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
								" TAB_OP_CUST_POL_GET_MARKETING_NAME input flist ", marketing_name_iflistp);

							PCM_OP(ctxp, TAB_OP_CUST_POL_GET_MARKETING_NAME, 0, marketing_name_iflistp, 
								&enrich_marketing_name_oflistp, ebufp);

							if (PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_enrich_product_offerings:"
									" input flist ", marketing_name_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_enrich_product_offerings:"
									" Error in getting marketing name", ebufp);
								*out_flistpp = enrich_marketing_name_oflistp;
								goto cleanup;
							}

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
								" TAB_OP_CUST_POL_GET_MARKETING_NAME output flist ", enrich_marketing_name_oflistp);

							if (enrich_marketing_name_oflistp && (hook_package_flistp = 
								PIN_FLIST_ELEM_GET(enrich_marketing_name_oflistp, PIN_FLD_PACKAGE_INFO, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
							{
								PIN_FLIST_FLD_COPY(hook_package_flistp, PIN_FLD_DESCR, 
									get_pkg_info_flistp, PIN_FLD_DESCR, ebufp);
							}

							
							PIN_FLIST_DESTROY_EX(&marketing_name_iflistp, NULL);
							PIN_FLIST_DESTROY_EX(&enrich_marketing_name_oflistp, NULL);
							break;
						}		
					}

					/*Add the package under PACKAGE_INFO array*/
					if(package_status == TAB_NOT_FOUND)
					{
						package_info_flistp = PIN_FLIST_ELEM_ADD(prod_offerings_oflistp, PIN_FLD_PACKAGE_INFO, 
								++package_count, ebufp);
						hook_package_count = package_count;
						PIN_FLIST_FLD_SET(package_info_flistp, PIN_FLD_POID, purchased_bundle_pdp, ebufp);
						PIN_FLIST_FLD_COPY(pur_bundle_read_flds_oflistp, PIN_FLD_DESCR, package_info_flistp, 
								TAB_FLD_PACKAGE_TYPE, ebufp);
						PIN_FLIST_FLD_COPY(pur_bundle_read_flds_oflistp, PIN_FLD_NAME, 
								package_info_flistp, PIN_FLD_NAME, ebufp);
						PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PACKAGE_ID, 
								package_info_flistp, PIN_FLD_PACKAGE_ID, ebufp);
						PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_DESCR, 
								package_info_flistp, PIN_FLD_UNIQUE_ID, ebufp);

						valid_from_t = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_VALID_FROM, 1, ebufp);

						valid_from_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, valid_from_t, ebufp);
						PIN_FLIST_FLD_PUT(package_info_flistp, PIN_FLD_VALID_FROM_STR, 
							valid_from_strp, ebufp);

						valid_to_t = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_VALID_TO, 1, ebufp);
						/*changed for displaying zero dates too*/
						
						valid_to_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, valid_to_t, ebufp);
						PIN_FLIST_FLD_PUT(package_info_flistp, PIN_FLD_VALID_TO_STR, 
							valid_to_strp, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
							" prod_offerings_oflistp", prod_offerings_oflistp);

						/*Hook opocode for populating marketing name*/
						marketing_name_iflistp = PIN_FLIST_CREATE(ebufp);

						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
							marketing_name_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
							marketing_name_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
							marketing_name_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
							marketing_name_iflistp, PIN_FLD_MSISDN, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, 
							marketing_name_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

						if(prod_offerings_oflistp != NULL)
						{
							PIN_FLIST_ELEM_COPY(prod_offerings_oflistp, PIN_FLD_PACKAGE_INFO, hook_package_count,
								marketing_name_iflistp, PIN_FLD_PACKAGE_INFO, 0, ebufp);
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
							" TAB_OP_CUST_POL_GET_MARKETING_NAME input flist ", marketing_name_iflistp);

						PCM_OP(ctxp, TAB_OP_CUST_POL_GET_MARKETING_NAME, 0, marketing_name_iflistp, 
							&enrich_marketing_name_oflistp, ebufp);

						if (PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_enrich_product_offerings:"
								" input flist ", marketing_name_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_enrich_product_offerings:"
								" Error in getting marketing name", ebufp);
							*out_flistpp = enrich_marketing_name_oflistp;
							goto cleanup;
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_enrich_product_offerings:"
							" TAB_OP_CUST_POL_GET_MARKETING_NAME output flist ", enrich_marketing_name_oflistp);

						if (enrich_marketing_name_oflistp && (hook_package_flistp = 
							PIN_FLIST_ELEM_GET(enrich_marketing_name_oflistp, PIN_FLD_PACKAGE_INFO, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
						{
							PIN_FLIST_FLD_COPY(hook_package_flistp, PIN_FLD_DESCR, 
								package_info_flistp, PIN_FLD_DESCR, ebufp);
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
							"PIN_FLD_PACKAGE_INFO flist", prod_offerings_oflistp);

						PIN_FLIST_DESTROY_EX(&marketing_name_iflistp, NULL);
						PIN_FLIST_DESTROY_EX(&enrich_marketing_name_oflistp, NULL);
					}

					/*Deal Poid Read Flds*/
					deal_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);

					if(!PIN_POID_IS_NULL(deal_pdp))
					{
						fm_tab_utils_common_read_deal_cache(ctxp, deal_pdp, &deal_read_flds_oflistp, db_no, ebufp);
						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_deal_cache :"
								" Deal_pdp ", deal_pdp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_deal_cache:"
								" Error while reading deal object", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
								"read deal flds output flist", deal_read_flds_oflistp);

							if(deal_read_flds_oflistp != NULL)
							{
								in_deal_name = PIN_FLIST_FLD_GET(deal_read_flds_oflistp, PIN_FLD_NAME, 1, ebufp);

								if(get_pkg_info_flistp != NULL)
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: " 	
									"get_pkg_info_flistp", get_pkg_info_flistp);

									bundle_status = TAB_NOT_FOUND;
									bundle_info_elemid = 0;
									bundle_info_cookie = NULL;

									/*Check if deal name exists under BUNDLE_INFO array*/
									while ((get_bundle_info_flistp = PIN_FLIST_ELEM_GET_NEXT(get_pkg_info_flistp, 
										PIN_FLD_BUNDLE_INFO, &bundle_info_elemid, 1, &bundle_info_cookie, 
										ebufp)) != (pin_flist_t *)NULL)
									{
										out_deal_name = PIN_FLIST_FLD_GET(get_bundle_info_flistp, 
											PIN_FLD_NAME, 1, ebufp);
										out_deal_purchase_bundle_pdp = PIN_FLIST_FLD_GET(get_bundle_info_flistp, PIN_FLD_POID, 1, ebufp);
										
										if (in_deal_name && out_deal_name && !strcmp(in_deal_name, out_deal_name)
											&& !PIN_POID_IS_NULL(out_purchase_bundle_pdp) &&
											!PIN_POID_COMPARE(purchased_bundle_pdp, out_deal_purchase_bundle_pdp, 0, ebufp))
										{
											bundle_status = TAB_FOUND;
											break;
										}		
									}
								}

								/*Add the deal name under BUNDLE_INFO array if its unique*/
								if(bundle_status == TAB_NOT_FOUND)
								{
									if(package_status == TAB_FOUND)
									{
										/* Get max array elem */
										if(get_pkg_info_flistp != NULL)
										{
											bundle_count = fm_tab_utils_common_get_max_elemid(ctxp, 
												get_pkg_info_flistp, PIN_FLD_BUNDLE_INFO, ebufp);
										}

										bundle_info_flistp = PIN_FLIST_ELEM_ADD(get_pkg_info_flistp, 
											PIN_FLD_BUNDLE_INFO, ++bundle_count, ebufp);
									}
									if(package_status == TAB_NOT_FOUND)
									{
										/* Get max array elem */
										if(get_pkg_info_flistp != NULL)
										{
											bundle_count = fm_tab_utils_common_get_max_elemid(ctxp, 
												package_info_flistp, PIN_FLD_BUNDLE_INFO, ebufp);
										}

										bundle_info_flistp = PIN_FLIST_ELEM_ADD(package_info_flistp, 
											PIN_FLD_BUNDLE_INFO, ++bundle_count, ebufp);

									}

									PIN_FLIST_FLD_COPY(deal_read_flds_oflistp, PIN_FLD_NAME, 
										bundle_info_flistp, PIN_FLD_NAME, ebufp);
										
									PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_POID, purchased_bundle_pdp, ebufp);

									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
										"PIN_FLD_PACKAGE_INFO flist", prod_offerings_oflistp);
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
										"PIN_FLD_BUNDLE_INFO flist", package_info_flistp);
								}
							}

							/*Product Poid Read Flds*/
							product_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PRODUCT_OBJ, 1, ebufp);

							if(!PIN_POID_IS_NULL(product_pdp))
							{
								fm_tab_utils_common_read_product_cache(ctxp, product_pdp, &product_read_flds_oflistp, db_no, ebufp);
								if(PIN_ERR_IS_ERR(ebufp))
								{
									PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"Product object fm_tab_utils_common_read_product_cache:"
										" product_pdp ", product_pdp);
									PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_product_cache:"
										" Error while reading product object", ebufp);
									goto cleanup;
								}
								else
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_product_offerings: "
										"read product flds output flist", product_read_flds_oflistp);

									if(product_read_flds_oflistp != NULL)
									{
										/*in_prod_name = PIN_FLIST_FLD_GET(product_read_flds_oflistp, 
											PIN_FLD_NAME, 1, ebufp);

										if(get_bundle_info_flistp != NULL)
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
												"fm_tab_cust_enrich_product_offerings: " 
												"get_bundle_info_flistp", get_bundle_info_flistp);

											product_status = TAB_NOT_FOUND;
											product_elemid = 0;
											product_cookie = NULL;

											while ((get_product_flistp = PIN_FLIST_ELEM_GET_NEXT(
												get_bundle_info_flistp, PIN_FLD_PRODUCTS, &product_elemid, 
												1, &product_cookie, ebufp)) != (pin_flist_t *)NULL)
											{
												out_prod_name = PIN_FLIST_FLD_GET(get_product_flistp, 
													PIN_FLD_NAME, 1, ebufp);

												if (in_prod_name && out_prod_name && !strcmp(in_prod_name, out_prod_name))
												{
													product_status = TAB_FOUND;
													break;
												}		
											}
										}*/

										/*Add PIN_FLD_PRODUCTS array if its unique */
										if(bundle_status == TAB_FOUND)
										{
											/* Get max array elem */
											if(bundle_info_flistp != NULL)
											{
												product_count = fm_tab_utils_common_get_max_elemid(
												ctxp, get_bundle_info_flistp, PIN_FLD_PRODUCTS, ebufp);
											}

											add_product_flistp = PIN_FLIST_ELEM_ADD(
												get_bundle_info_flistp, PIN_FLD_PRODUCTS, ++product_count, ebufp);
										}

										if(bundle_status == TAB_NOT_FOUND)
										{
											/* Get max array elem */
											if(bundle_info_flistp != NULL)
											{
												product_count = fm_tab_utils_common_get_max_elemid(
												ctxp, bundle_info_flistp, PIN_FLD_PRODUCTS, ebufp);
											}

											add_product_flistp = PIN_FLIST_ELEM_ADD(bundle_info_flistp, 
												PIN_FLD_PRODUCTS, ++product_count, ebufp);
										}

										PIN_FLIST_FLD_COPY(product_read_flds_oflistp, 
											PIN_FLD_NAME, add_product_flistp, PIN_FLD_NAME, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_QUANTITY, 
											add_product_flistp, PIN_FLD_QUANTITY, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_STATUS, 
											add_product_flistp, PIN_FLD_STATUS, ebufp);

										created_t = PIN_FLIST_FLD_GET(products_flistp, 
												PIN_FLD_CREATED_T, 1, ebufp);
										if(created_t != NULL)
										{
											created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, created_t, ebufp);
											PIN_FLIST_FLD_PUT(add_product_flistp, TAB_FLD_CREATED_TIME, 
												created_strp, ebufp);
										}

										if ((cycle_fees_flistp = PIN_FLIST_ELEM_GET(products_flistp, 
											PIN_FLD_CYCLE_FEES, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
										{
											charged_from_t = PIN_FLIST_FLD_GET(cycle_fees_flistp, 
													PIN_FLD_CHARGED_FROM_T, 1, ebufp);
											if(charged_from_t != NULL)
											{
												charged_from_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, charged_from_t, ebufp);
												PIN_FLIST_FLD_PUT(add_product_flistp, 
													TAB_FLD_CHARGED_FROM_STR, charged_from_strp, ebufp);
											}

											charged_to_t = PIN_FLIST_FLD_GET(cycle_fees_flistp, 
													PIN_FLD_CHARGED_TO_T, 1, ebufp);
											if(charged_to_t != NULL)
											{
												charged_to_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, charged_to_t, ebufp);
												PIN_FLIST_FLD_PUT(add_product_flistp, 
													TAB_FLD_CHARGED_TO_STR, charged_to_strp, ebufp);
											}
										}

										purchase_start_t = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PURCHASE_START_T, 1, ebufp);

										prod_pur_start_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, purchase_start_t, ebufp);
										PIN_FLIST_FLD_PUT(add_product_flistp, PIN_FLD_VALID_FROM_STR, 
												prod_pur_start_strp, ebufp);

										purchase_end_t = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PURCHASE_END_T, 1, ebufp);

										prod_pur_end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, purchase_end_t, ebufp);
										PIN_FLIST_FLD_PUT(add_product_flistp, PIN_FLD_VALID_TO_STR, 
												prod_pur_end_strp, ebufp);

										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
											"fm_tab_cust_enrich_product_offerings: PIN_FLD_PACKAGE_INFO flist", prod_offerings_oflistp);
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
											"fm_tab_cust_enrich_product_offerings: PIN_FLD_BUNDLE_INFO flist", package_info_flistp);
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
											"fm_tab_cust_enrich_product_offerings: PIN_FLD_PRODUCTS flist", bundle_info_flistp);
									}
								}

								PIN_FLIST_DESTROY_EX(&product_read_flds_oflistp, NULL);
							}
						}

						PIN_FLIST_DESTROY_EX(&deal_read_flds_oflistp, NULL);
					}
				}
			}

			PIN_FLIST_DESTROY_EX(&pur_bundle_read_flds_oflistp, NULL);
		}

	}
	
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&product_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&deal_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&pur_bundle_read_flds_oflistp, NULL);	

	*out_flistpp = prod_offerings_oflistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_enrich_product_offerings output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * fm_tab_cust_enrich_discount_offerings()
 * 
 * This function will be used to enrich flist based on the
 * discount offerings associated with the account
 * @param ctxp The context pointer.
 * @param in_flistp input flist.
 * @param out_flistp The return flist.
 * @param prod_out_flistp Product offerings flist.
 * @param ebufp The error buffer.
 * @return flistp.
 * 
 *********************************************************************/
void fm_tab_cust_enrich_discount_offerings(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t     *pur_bundle_rflistp,
	pin_flist_t		*prod_out_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*discounts_flistp = NULL;
	pin_flist_t		*discount_read_flds_oflistp = NULL;
	pin_flist_t		*deal_read_flds_oflistp = NULL;
	pin_flist_t		*pur_bundle_read_flds_oflistp = NULL;
	pin_flist_t		*get_pkg_info_flistp = NULL;
	pin_flist_t		*get_bundle_info_flistp = NULL;
	pin_flist_t		*add_discount_flistp = NULL;
	pin_flist_t		*package_info_flistp = NULL;
	pin_flist_t		*bundle_info_flistp = NULL;
	pin_flist_t		*get_discount_flistp = NULL;
	pin_flist_t		*disc_offerings_oflistp = NULL;
	poid_t			*discount_pdp = NULL;
	poid_t			*deal_pdp = NULL;
	poid_t			*purchased_bundle_pdp = NULL;
	poid_t			*out_purchase_bundle_pdp = NULL;
	poid_t			*out_deal_purchase_bundle_pdp = NULL;
	pin_cookie_t		package_info_cookie = NULL;
	pin_cookie_t		discounts_cookie = NULL;
	pin_cookie_t		bundle_info_cookie = NULL;
	pin_cookie_t		discount_cookie = NULL;
	int32			package_info_elemid = 0;
	int32			discounts_elemid = 0;
	int32			bundle_info_elemid = 0;
	int32			discount_elemid = 0;
	int			package_status = TAB_NOT_FOUND;
	int			bundle_status = TAB_NOT_FOUND;
	int			discount_status = TAB_NOT_FOUND;
	unsigned long		package_count = 0;
	unsigned long		bundle_count = 0;
	unsigned long		discount_count = 0;
	time_t			*purchase_start_t =	 NULL;
	time_t			*purchase_end_t =  NULL;
	time_t			*created_t =  NULL;
	time_t			*valid_from_t =	 NULL;
	time_t			*valid_to_t =  NULL;
	char			*in_package_namep = NULL;
	char			*out_package_namep = NULL;
	char			*in_deal_name = NULL;
	char			*out_deal_name = NULL;
	char			*in_disc_name = NULL;
	char			*out_disc_name = NULL;
	char			*created_strp = NULL;
	char			*prod_pur_start_strp = NULL;
	char			*prod_pur_end_strp = NULL;
	char			*valid_from_strp = NULL;
	char			*valid_to_strp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_enrich_discount_offerings input flist", in_flistp);

	disc_offerings_oflistp = PIN_FLIST_COPY(prod_out_flistp, ebufp);

	if (disc_offerings_oflistp == NULL){
		disc_offerings_oflistp = PIN_FLIST_CREATE(ebufp);
	}

	while ((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_DISCOUNTS, 
					&discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		bundle_count = 0;
		package_status = TAB_NOT_FOUND;
		bundle_status = TAB_NOT_FOUND;
		discount_status = TAB_NOT_FOUND;
		/*Purchased Bundle Poid Read Flds*/
		purchased_bundle_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);

		if(!PIN_POID_IS_NULL(purchased_bundle_pdp))
		{
			fm_tab_utils_common_read_plan_cache(ctxp, purchased_bundle_pdp, pur_bundle_rflistp, &pur_bundle_read_flds_oflistp, db_no, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_plan_cache :"
					"bundle poidp ", purchased_bundle_pdp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					" Error while reading purchased bundle object", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
					"read purchased bundle flds output flist", pur_bundle_read_flds_oflistp);

				if(pur_bundle_read_flds_oflistp != NULL)
				{
					in_package_namep = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_NAME, 1, ebufp);

					if(disc_offerings_oflistp != NULL)
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
							"disc_offerings_oflistp", disc_offerings_oflistp);

						package_status = TAB_NOT_FOUND;
						package_info_elemid = 0;
						package_info_cookie = NULL;

						/*Check if package name exists under PIN_FLD_PACKAGE_INFO array*/
						while ((get_pkg_info_flistp = PIN_FLIST_ELEM_GET_NEXT(disc_offerings_oflistp, PIN_FLD_PACKAGE_INFO, 
							&package_info_elemid, 1, &package_info_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							out_package_namep = PIN_FLIST_FLD_GET(get_pkg_info_flistp, PIN_FLD_NAME, 1, ebufp);
							out_purchase_bundle_pdp = PIN_FLIST_FLD_GET(get_pkg_info_flistp, PIN_FLD_POID, 1, ebufp);
							
							if (in_package_namep && out_package_namep && 
							!strcmp(in_package_namep, out_package_namep)
							&& !PIN_POID_IS_NULL(out_purchase_bundle_pdp) &&
							!PIN_POID_COMPARE(purchased_bundle_pdp, out_purchase_bundle_pdp, 0, ebufp))
							{
								package_status = TAB_FOUND;
								break;
							}		
						}
					}

					/*Add package level details under PIN_FLD_PACKAGE_INFO array*/
					if(package_status == TAB_NOT_FOUND)
					{
						/* Get max packge info array elem */
						if(disc_offerings_oflistp != NULL)
						{
							package_count = fm_tab_utils_common_get_max_elemid(ctxp, disc_offerings_oflistp, 
								PIN_FLD_PACKAGE_INFO, ebufp);
						}

						package_info_flistp = PIN_FLIST_ELEM_ADD(disc_offerings_oflistp, PIN_FLD_PACKAGE_INFO, 
							++package_count, ebufp);
						PIN_FLIST_FLD_SET(package_info_flistp, PIN_FLD_POID, purchased_bundle_pdp, ebufp);
						PIN_FLIST_FLD_COPY(pur_bundle_read_flds_oflistp, PIN_FLD_DESCR, 
							package_info_flistp, TAB_FLD_PACKAGE_TYPE, ebufp);
						PIN_FLIST_FLD_COPY(pur_bundle_read_flds_oflistp, PIN_FLD_NAME, 
							package_info_flistp, PIN_FLD_NAME, ebufp);
						PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_PACKAGE_ID, 
							package_info_flistp, PIN_FLD_PACKAGE_ID, ebufp);
						PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DESCR, 
							package_info_flistp, PIN_FLD_UNIQUE_ID, ebufp);

						valid_from_t = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_VALID_FROM, 1, ebufp);

						valid_from_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, valid_from_t, ebufp);
						PIN_FLIST_FLD_PUT(package_info_flistp, PIN_FLD_VALID_FROM_STR, 
							valid_from_strp, ebufp);

						valid_to_t = PIN_FLIST_FLD_GET(pur_bundle_read_flds_oflistp, PIN_FLD_VALID_TO, 1, ebufp);
						/*changed for displaying zero dates too*/

						valid_to_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, valid_to_t, ebufp);
						PIN_FLIST_FLD_PUT(package_info_flistp, PIN_FLD_VALID_TO_STR, 
							valid_to_strp, ebufp);
				
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
							"PIN_FLD_PACKAGE_INFO flist", disc_offerings_oflistp);
					}

					/*Deal Poid Read Flds*/
					deal_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);

					if(!PIN_POID_IS_NULL(deal_pdp))
					{
						fm_tab_utils_common_read_deal_cache(ctxp, deal_pdp, &deal_read_flds_oflistp, db_no, ebufp);
						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"Deal object fm_tab_utils_common_read_deal_cache:"
								" deal_pdp ", deal_pdp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_deal_cache:"
								" Error while reading deal object", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
								"read deal flds output flist", deal_read_flds_oflistp);

							if(deal_read_flds_oflistp != NULL)
							{
								in_deal_name = PIN_FLIST_FLD_GET(deal_read_flds_oflistp, PIN_FLD_NAME, 1, ebufp);

								if(get_pkg_info_flistp != NULL)
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: " 											"get_pkg_info_flistp", get_pkg_info_flistp);

									bundle_status = TAB_NOT_FOUND;
									bundle_info_elemid = 0;
									bundle_info_cookie = NULL;

									/*Check if deal name exists under PIN_FLD_BUNDLE_INFO array*/
									while ((get_bundle_info_flistp = PIN_FLIST_ELEM_GET_NEXT(get_pkg_info_flistp, 
										PIN_FLD_BUNDLE_INFO, &bundle_info_elemid, 1, &bundle_info_cookie, 
										ebufp)) != (pin_flist_t *)NULL)
									{
										out_deal_name = PIN_FLIST_FLD_GET(get_bundle_info_flistp, 
											PIN_FLD_NAME, 1, ebufp);
										
										out_deal_purchase_bundle_pdp = PIN_FLIST_FLD_GET(get_bundle_info_flistp, PIN_FLD_POID, 1, ebufp);

										if (in_deal_name && out_deal_name && !strcmp(in_deal_name, out_deal_name)
											&& !PIN_POID_IS_NULL(out_purchase_bundle_pdp) &&
											!PIN_POID_COMPARE(purchased_bundle_pdp, out_deal_purchase_bundle_pdp, 0, ebufp))
										{
											bundle_status = TAB_FOUND;
											break;
										}		
									}
								}

								/*Add deal level details under PIN_FLD_BUNDLE_INFO array*/
								if(bundle_status == TAB_NOT_FOUND)
								{
									if(package_status == TAB_FOUND)
									{
										/* Get max array elem */
										if(get_pkg_info_flistp != NULL)
										{
											bundle_count = fm_tab_utils_common_get_max_elemid(ctxp, 
												get_pkg_info_flistp, PIN_FLD_BUNDLE_INFO, ebufp);
										}

										bundle_info_flistp = PIN_FLIST_ELEM_ADD(get_pkg_info_flistp, 
											PIN_FLD_BUNDLE_INFO, ++bundle_count, ebufp);
									}
									if(package_status == TAB_NOT_FOUND)
									{
										/* Get max array elem */
										if(package_info_flistp != NULL)
										{
											bundle_count = fm_tab_utils_common_get_max_elemid(ctxp, 
												package_info_flistp, PIN_FLD_BUNDLE_INFO, ebufp);
										}

										bundle_info_flistp = PIN_FLIST_ELEM_ADD(package_info_flistp, 
											PIN_FLD_BUNDLE_INFO, ++bundle_count, ebufp);
									}

									PIN_FLIST_FLD_COPY(deal_read_flds_oflistp, PIN_FLD_NAME, 
										bundle_info_flistp, PIN_FLD_NAME, ebufp);
									
									PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_POID, purchased_bundle_pdp, ebufp);

									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
										"PIN_FLD_BUNDLE_INFO flist", disc_offerings_oflistp);

									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
										"PIN_FLD_BUNDLE_INFO flist", package_info_flistp);
								}
							}

							/*Discount Poid Read Flds*/
							discount_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);

							if(!PIN_POID_IS_NULL(discount_pdp))
							{
								fm_tab_utils_common_read_discount_cache(ctxp, discount_pdp, &discount_read_flds_oflistp, db_no, ebufp);
								if(PIN_ERR_IS_ERR(ebufp))
								{
									PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"Discount object fm_tab_utils_common_read_discount_cache:"
										" discount poidp ", discount_pdp);
									PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_discount_cache:"
										" Error while reading discount object", ebufp);
									goto cleanup;
								}
								else
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_discount_offerings: "
										"read discount flds output flist", discount_read_flds_oflistp);

									if(discount_read_flds_oflistp != NULL)
									{
										/*in_disc_name = PIN_FLIST_FLD_GET(discount_read_flds_oflistp, 
											PIN_FLD_NAME, 1, ebufp);

										if(get_bundle_info_flistp != NULL)
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
												"fm_tab_cust_enrich_discount_offerings: get_bundle_info_flistp", get_bundle_info_flistp);

											discount_status = TAB_NOT_FOUND;
											discount_elemid = 0;
											discount_cookie = NULL;

											while ((get_discount_flistp = PIN_FLIST_ELEM_GET_NEXT(
												get_bundle_info_flistp, PIN_FLD_DISCOUNTS, &discount_elemid,
												1, &discount_cookie, ebufp)) != (pin_flist_t *)NULL)
											{
												out_disc_name = PIN_FLIST_FLD_GET(get_discount_flistp, 
													PIN_FLD_NAME, 1, ebufp);

												if (in_disc_name && out_disc_name && !strcmp(in_disc_name, 
													out_disc_name))
												{
													discount_status = TAB_FOUND;
													break;
												}		
											}
										}*/
										
										if(bundle_status == TAB_FOUND)
										{
											/* Get max array elem */
											if(bundle_info_flistp != NULL)
											{
												discount_count = fm_tab_utils_common_get_max_elemid(ctxp, get_bundle_info_flistp, PIN_FLD_DISCOUNTS, ebufp);
											}
											add_discount_flistp = PIN_FLIST_ELEM_ADD(
													get_bundle_info_flistp, PIN_FLD_DISCOUNTS, 
													++discount_count, ebufp);
										}

										/*Add discount level details under PIN_FLD_DISCOUNTS array*/
										if(bundle_status == TAB_NOT_FOUND)
										{
											/* Get max array elem */
											if(bundle_info_flistp != NULL)
											{
												discount_count = fm_tab_utils_common_get_max_elemid(ctxp, bundle_info_flistp, PIN_FLD_DISCOUNTS, ebufp);
											}

											add_discount_flistp = PIN_FLIST_ELEM_ADD(
													bundle_info_flistp, PIN_FLD_DISCOUNTS, 
													++discount_count, ebufp);
										}

										PIN_FLIST_FLD_COPY(discount_read_flds_oflistp, 
												PIN_FLD_NAME, add_discount_flistp, PIN_FLD_NAME, ebufp);
										PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_QUANTITY, 
												add_discount_flistp, PIN_FLD_QUANTITY, ebufp);
										PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_STATUS, 
												add_discount_flistp, PIN_FLD_STATUS, ebufp);

										created_t = PIN_FLIST_FLD_GET(discounts_flistp, 
												PIN_FLD_CREATED_T, 1, ebufp);
										if(created_t != NULL)
										{
											created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, created_t, ebufp);
											PIN_FLIST_FLD_PUT(add_discount_flistp, 
													TAB_FLD_CREATED_TIME, created_strp, ebufp);
										}

										purchase_start_t = PIN_FLIST_FLD_GET(discounts_flistp, 
												PIN_FLD_PURCHASE_START_T, 1, ebufp);

										prod_pur_start_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, purchase_start_t, ebufp);
										PIN_FLIST_FLD_PUT(add_discount_flistp, PIN_FLD_VALID_FROM_STR, prod_pur_start_strp, ebufp);


										purchase_end_t = PIN_FLIST_FLD_GET(discounts_flistp, 
												PIN_FLD_PURCHASE_END_T, 1, ebufp);
												
										prod_pur_end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, purchase_end_t, ebufp);
										PIN_FLIST_FLD_PUT(add_discount_flistp, PIN_FLD_VALID_TO_STR, 
												prod_pur_end_strp, ebufp);


										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
											"fm_tab_cust_enrich_discount_offerings: PIN_FLD_PACKAGE_INFO flist", disc_offerings_oflistp);
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
											"fm_tab_cust_enrich_discount_offerings: PIN_FLD_DISCOUNTS flist", bundle_info_flistp);

									}

								}

								PIN_FLIST_DESTROY_EX(&discount_read_flds_oflistp, NULL);
							}
						}

						PIN_FLIST_DESTROY_EX(&deal_read_flds_oflistp, NULL);
					}
				}
			}
			PIN_FLIST_DESTROY_EX(&pur_bundle_read_flds_oflistp, NULL);
		}
	}
	
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp = disc_offerings_oflistp;
	PIN_FLIST_DESTROY_EX(&pur_bundle_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&deal_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&discount_read_flds_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_enrich_discount_offerings output flist", *out_flistpp);
	return;
}
