/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 06-DEC-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_PURCHASE_OFFER operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "pin_bill.h"
#include "pin_ar.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_purchase_offer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_cust_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int				notify_flag,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_create_purchase_bundle(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_enrich_purchase_deal_output(
	pcm_context_t		*ctxp,
	pin_flist_t		*enrich_flistp,
	pin_flist_t		*purchase_deal_oflistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_purchase_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_get_max_purchased_date(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	poid_t                  *pur_pdp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void	
fm_tab_cust_purchase_offer_error_hook(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp);

/*Extern functions*/
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t           *ctxp,
	poid_t                  *pdp,
	pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	int32                   status,
	poid_t                  *account_pdp,
	char                    *opcode_name,
	pin_flist_t             **r_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_get_plan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_deal_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_discount_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_product_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern time_t 
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_purchase_bundle_dtls(
	pcm_context_t		*ctxp,
	pin_flist_t			*i_flistp,
	pin_flist_t			**r_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_CUST_PURCHASE_OFFER operation.
 *************************************************************************/
void
op_tab_cust_purchase_offer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";
	poid_t			*account_pdp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_purchase_offer function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_PURCHASE_OFFER) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_purchase_offer bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_purchase_offer input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_PURCHASE_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_PURCHASE_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_PURCHASE_OFFER, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_purchase_offer(ctxp, enrich_iflistp, &r_flistp, db_no, TAB_NOTIFY_ENABLE, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_purchase_offer error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_cust_purchase_offer:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_purchase_offer: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_PURCHASE_OFFER", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_purchase_offer:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_PURCHASE_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_PURCHASE_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_PURCHASE_OFFER, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_OUT_FLIST, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, PIN_FLD_OUT_FLIST, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp; 

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_purchase_offer output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to purchase
 * product and discount offerings.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_cust_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int			notify_flag,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*deal_mode_flistp = NULL;
	pin_flist_t		*package_flistp = NULL;
	pin_flist_t		*bunde_flistp = NULL;
	pin_flist_t		*plan_details_iflistp = NULL;
	pin_flist_t		*plan_details_oflistp = NULL;
	pin_flist_t		*create_pur_bundle_iflistp = NULL;
	pin_flist_t		*create_pur_bundle_oflistp = NULL;
	pin_flist_t		*purchase_deal_iflistp = NULL;
	pin_flist_t		*purchase_deal_oflistp = NULL;
	pin_flist_t		*deal_details_iflistp = NULL;
	pin_flist_t		*deal_details_oflistp = NULL;
	pin_flist_t		*deal_info_flistp = NULL;
	pin_flist_t		*deal_details_flistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*plan_details_flistp = NULL;
	pin_flist_t		*hook_deal_in_flistp = NULL;
	pin_flist_t		*products_flistp = NULL;
	pin_flist_t		*discounts_flistp = NULL;
	pin_flist_t		*product_flistp = NULL;
	pin_flist_t		*deal_products_flistp = NULL;
	pin_flist_t		*deal_discounts_flistp = NULL;
	pin_flist_t		*discount_flistp = NULL;
	pin_flist_t		*add_product_flistp = NULL;
	pin_flist_t		*add_discount_flistp = NULL;
	pin_flist_t		*get_product_details_iflistp = NULL;
	pin_flist_t		*get_product_details_oflistp = NULL;
	pin_flist_t		*get_discount_details_iflistp = NULL;
	pin_flist_t		*get_discount_details_oflistp = NULL;
	pin_flist_t		*prod_obj_flistp = NULL;
	pin_flist_t		*disc_obj_flistp = NULL;
	pin_flist_t		*purchase_oflistp = NULL;
	pin_flist_t		*temp_bundle_flistp = NULL;
	pin_flist_t		*temp_package_flistp = NULL;
	pin_flist_t		*temp_disc_flistp = NULL;
	pin_flist_t		*temp_prod_flistp = NULL;
	pin_flist_t		*bundle_pdp_flistp = NULL;
	pin_flist_t		*results_products_flistp = NULL;
	pin_flist_t		*results_discounts_flistp = NULL;
	pin_flist_t		*prod_read_flds_iflistp = NULL;
	pin_flist_t		*prod_read_flds_oflistp = NULL;
	pin_flist_t		*disc_read_flds_iflistp = NULL;
	pin_flist_t		*disc_read_flds_oflistp = NULL;
	pin_flist_t		*hook_update_threshold_flistp = NULL;
	pin_flist_t		*set_limit_cr_iflistp = NULL;
	pin_flist_t		*get_pur_bundle_iflistp = NULL;
	pin_flist_t		*get_pur_bundle_oflistp = NULL;
	pin_flist_t		*purchase_offer_rdata_flistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*temp_input_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*package_info_flistp = NULL;
	pin_flist_t		*bundle_info_notf_flistp = NULL;
	pin_flist_t		*discount_notf_flistp = NULL;
	pin_flist_t		*product_notf_flistp = NULL;
	pin_flist_t		*date_iflistp = NULL;
	pin_flist_t		*date_rflistp = NULL;
	pin_flist_t		*write_iflistp = NULL;
	pin_flist_t		*write_oflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*rd_iflistp = NULL;
	pin_flist_t		*rd_rflistp = NULL;
	pin_flist_t		*hook_offer_iflistp = NULL;
	poid_t			*service_pdp = NULL;
	poid_t			*plan_pdp = NULL;
	poid_t			*pur_bundle_pdp = NULL;
	poid_t			*deal_mode_prd_pdp = NULL;
	poid_t			*prod_pdp = NULL;
	pin_decimal_t		*default_quantity = NULL;
	pin_decimal_t		*prod_quantityp = NULL;
	pin_decimal_t		*disc_quantityp = NULL;
	int				create_pur_bundle_flag = 0;
	int				match_pur_bundle_flag = 0;
	int				exist_pur_bundle_mode_flag = 0;
	int        		*statusp = NULL;
	int32			*product_type = NULL;
	int32			*discount_type = NULL;
	int32			prod_status = PIN_PRODUCT_STATUS_ACTIVE;
	int32			disc_status = PIN_DISCOUNT_STATUS_ACTIVE;
	int32			package_idp = NULL;
	int32			deal_mode_elemid = 0;
	int32			package_elemid = 0;
	int32			products_elemid = 0;
	int32			discounts_elemid = 0;
	int32			deal_products_elemid = 0;
	int32			deal_discounts_elemid = 0;
	int32			bundle_elemid = 0;
	int32			*modep = NULL;
	int32           cerror_code = 0;
	int32			package_info_inp_count = 0;
	int32			package_info_hook_count = 0;
	int64			pur_bundle_id = 0;
	char			*package_typep = NULL;
	char			*package_namep = NULL;
	//char			*unique_idp = NULL;
	char			*deal_namep = NULL;
	char			*product_namep = NULL;
	char			*discount_namep = NULL;
	char			*permitted_typep = NULL;
	char			*valid_from_strp = NULL;
	char			*valid_to_strp = NULL;
	char			*start_date_strp = NULL;
	char			*end_date_strp = NULL;
	char			*account_nop = NULL;
	char			*prod_pur_end_strp = NULL;
	char			*prod_bund_start_strp = NULL;
	char			*ret_hook_err_code = NULL;
	poid_t			*notify_pdp = NULL;
	poid_t			*deal_mode_disc_pdp = NULL;
	poid_t			*disc_pdp = NULL;
	poid_t			*exist_pur_bundle_pdp = NULL;
	poid_t			*account_pdp = NULL;
	time_t			*valid_from_t =	 NULL;
	time_t			*valid_to_t =  NULL;
	time_t			start_t = 0;
	time_t			end_t = 0;
	time_t			now_t = 0;
	time_t			start_offset_t = 0;
	time_t			end_offset_t = 0;
	time_t			default_val_zero_t = 0;
	time_t			*purchase_end_t =  NULL;
	time_t			*purchase_bund_start_t =  NULL;
	pin_cookie_t		package_cookie = NULL;
	pin_cookie_t		deal_mode_cookie = NULL;
	pin_cookie_t		products_cookie = NULL;
	pin_cookie_t		discounts_cookie = NULL;
	pin_cookie_t		deal_products_cookie = NULL;
	pin_cookie_t		deal_discounts_cookie = NULL;
	pin_cookie_t		bundle_cookie = NULL;
	void			*vp = NULL;
	pin_errbuf_t	local_ebuf = {0} ;
	pin_errbuf_t	*local_ebufp = &local_ebuf;
		
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_purchase_offer input flist", in_flistp);
		
	/*Account Number not passed in input*/	
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);

	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}
		
	if((account_nop == NULL || strlen(account_nop) == 0) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
			"Account Number is not passed in request", ebufp);
		goto cleanup;
	}

	//create output flist when PACKAGE_INFO is present in input
	if ((PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_PACKAGE_INFO, 
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		purchase_oflistp = PIN_FLIST_COPY(in_flistp, ebufp);
		purchase_offer_rdata_flistp = PIN_FLIST_CREATE(ebufp);
		notify_flistp = PIN_FLIST_CREATE(ebufp);

		/*Drop Fields from function return flist*/
		if(purchase_oflistp != NULL)
		{
			if(PIN_FLIST_FLD_GET(purchase_oflistp, TAB_FLD_EXCEPTION_FLAG, 1, 
					ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, TAB_FLD_EXCEPTION_FLAG, ebufp);
			}

			if(PIN_FLIST_FLD_GET(purchase_oflistp, PIN_FLD_PROGRAM_NAME, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, PIN_FLD_PROGRAM_NAME, ebufp);
			}

			if(PIN_FLIST_FLD_GET(purchase_oflistp, PIN_FLD_SERVICE_OBJ, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, PIN_FLD_SERVICE_OBJ, ebufp);
			}

			if(PIN_FLIST_FLD_GET(purchase_oflistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
			}

			if(PIN_FLIST_FLD_GET(purchase_oflistp, PIN_FLD_BAL_GRP_OBJ, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
			}

			if(PIN_FLIST_FLD_GET(purchase_oflistp, PIN_FLD_GROUP_OBJ, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(purchase_oflistp, PIN_FLD_GROUP_OBJ, ebufp);
			}
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer purchase_oflistp", 
				purchase_oflistp);

		default_quantity = (pin_decimal_t *)pin_decimal("1.0", ebufp);

		/*Call BU hook TAB_OP_CUST_POL_PRE_PURCHASE_OFFER to enrich input*/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
			"TAB_OP_CUST_POL_PRE_PURCHASE_OFFER input flist", in_flistp);

		PCM_OP(ctxp, TAB_OP_CUST_POL_PRE_PURCHASE_OFFER, 0, in_flistp, &hook_offer_iflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
				"TAB_OP_CUST_POL_PRE_PURCHASE_OFFER Hook opcode Input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
				"TAB_OP_CUST_POL_PRE_PURCHASE_OFFER Hook opcode input flist error", ebufp);
			*out_flistpp = hook_offer_iflistp;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
			"TAB_OP_CUST_POL_PRE_PURCHASE_OFFER output flist", hook_offer_iflistp);

		package_info_inp_count = PIN_FLIST_ELEM_COUNT(purchase_oflistp, PIN_FLD_PACKAGE_INFO,ebufp);
		package_info_hook_count = PIN_FLIST_ELEM_COUNT(hook_offer_iflistp, PIN_FLD_PACKAGE_INFO,ebufp);
		if (package_info_inp_count!=package_info_hook_count)
		{
			PIN_FLIST_ELEM_DROP(purchase_oflistp, PIN_FLD_PACKAGE_INFO, PIN_ELEMID_ANY, ebufp);
			PIN_FLIST_FLD_COPY(hook_offer_iflistp, PIN_FLD_PACKAGE_INFO,
										purchase_oflistp, PIN_FLD_PACKAGE_INFO, ebufp);
			
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
			"purchase_oflistp flist", purchase_oflistp);
			
		/*Loop through input package info array*/
		while ((package_flistp = PIN_FLIST_ELEM_GET_NEXT(hook_offer_iflistp, PIN_FLD_PACKAGE_INFO, 
			&package_elemid, 1, &package_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			start_offset_t = 0;
			end_offset_t = 0;
			default_val_zero_t = 0;
			match_pur_bundle_flag = 0;
			pur_bundle_pdp = NULL;
			exist_pur_bundle_pdp = NULL;
			start_t = 0;
			end_t = 0;
			start_date_strp = NULL;
			end_date_strp = NULL;
			valid_from_strp = NULL;
			valid_to_strp = NULL;
			prod_bund_start_strp = NULL;
			prod_pur_end_strp = NULL;
			vp = NULL;

			if (purchase_oflistp != NULL)
			{
				/*Drop Fields from return flist as we will set these fields after creating new purchased bundle object*/
				temp_package_flistp = PIN_FLIST_ELEM_GET(purchase_oflistp, PIN_FLD_PACKAGE_INFO, 
						package_elemid, 1, ebufp);
				
				if(temp_package_flistp != NULL)
				{
					if(PIN_FLIST_FLD_GET(temp_package_flistp, PIN_FLD_VALID_FROM_STR, 1, 
						ebufp) != NULL)
					{
						PIN_FLIST_FLD_DROP(temp_package_flistp, PIN_FLD_VALID_FROM_STR, ebufp);
					}
					if(PIN_FLIST_FLD_GET(temp_package_flistp, PIN_FLD_VALID_TO_STR, 1, 
						ebufp) != NULL)
					{
						PIN_FLIST_FLD_DROP(temp_package_flistp, PIN_FLD_VALID_TO_STR, ebufp);
					}
				}	
			}

			/*Check for mandatory package type. Values - Primary or Addon*/
			package_typep = PIN_FLIST_FLD_GET(package_flistp, TAB_FLD_PACKAGE_TYPE, 1, ebufp);

			if(((package_typep && strlen(package_typep) == 0)) || 
				(PIN_FLIST_FLD_GET(package_flistp, TAB_FLD_PACKAGE_TYPE, 1, ebufp) == NULL))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_PKG_TYPE_MISSING, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
					"Package type is missing in request", ebufp);
				goto cleanup;
			}

			/*Check for mandatory package name*/
			package_namep = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_NAME, 1, ebufp);

			if(((package_namep && strlen(package_namep) == 0)) || 
					(PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_PACKAGE_INFO, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
					"Package name is missing in request", ebufp);
				goto cleanup;
			}

			/*unique_idp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_UNIQUE_ID, 1, ebufp);

			  if(((unique_idp && strlen(unique_idp) == 0)) || 
			  (PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_UNIQUE_ID, 1, ebufp) == NULL))
			  {
			  pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			  TAB_ERR_CODE_INVALID_PACKAGE_INFO, 0, 0, 0);
			  PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
			  "Unique id is missing in request", ebufp);
			  goto cleanup;
			  }*/

			/*Check for mandatory bundle array*/
			if ((PIN_FLIST_ELEM_GET(package_flistp, PIN_FLD_BUNDLE_INFO, 
				PIN_ELEMID_ANY, 1, ebufp)) == NULL)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_BUNDLE_ARRAY_MISSING, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
					"Bundle array is missing in request", ebufp);
				goto cleanup;
			}
			
			vp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);
			if(vp) {
				package_idp = *(int32 *)vp;
			} else {
				fm_purchase_offer_get_package_id (ctxp, account_pdp, &package_idp, ebufp);
				
				if (PIN_ERR_IS_ERR(ebufp) || (!account_pdp)) {
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_cust_purchase_offer error generating PACKAGE_ID", ebufp);
					return NULL;
				}
			}
				
			/*Prepare flist for notification*/
			common_notification_flistp = PIN_FLIST_CREATE(ebufp);

			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
					common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
					common_notification_flistp, PIN_FLD_MSISDN, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
					common_notification_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
			package_info_flistp = PIN_FLIST_ELEM_ADD(common_notification_flistp, 
					PIN_FLD_PACKAGE_INFO, package_elemid, ebufp);	
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME, 
					package_info_flistp, PIN_FLD_NAME, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID, 
					package_info_flistp, PIN_FLD_PACKAGE_ID, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, 
					package_info_flistp, PIN_FLD_UNIQUE_ID, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, TAB_FLD_PACKAGE_TYPE, 
					package_info_flistp, PIN_FLD_OBJ_TYPE, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_FROM_STR, 
					package_info_flistp, PIN_FLD_VALID_FROM_STR, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_TO_STR, 
					package_info_flistp, PIN_FLD_VALID_TO_STR, ebufp);

			// to verify if any existing purchased_bundle object exists with same as package_namep
			if(package_namep != NULL)
			{
				plan_details_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, plan_details_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_SET(plan_details_iflistp, PIN_FLD_NAME, package_namep, ebufp);

				/*Search for plan object using package name*/
				fm_tab_utils_common_get_plan_details(ctxp, plan_details_iflistp, 
					&plan_details_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_plan_details:"
						" input flist ", plan_details_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_plan_details:"
						" Error while getting plan object", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
						"fm_tab_utils_common_get_plan_details output flist", plan_details_oflistp);
				}
				
				/*Search for purchased bundle object using package name*/
				now_t = pin_virtual_time(NULL);
				start_date_strp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp);
				if(start_date_strp != NULL)
				{
					/*Convert date in string format to unix timestamp*/
					start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, start_date_strp, ebufp);

					if(start_t)
					{
						start_offset_t = start_t - now_t;
					}
				}

				end_date_strp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp);
				if(end_date_strp != NULL)
				{
					/*Convert date in string format to unix timestamp*/
					end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_date_strp, ebufp);
					if(end_t)
					{
						end_offset_t = end_t - now_t;
					}
				}

				/*Fetch purchased bundle object using input package name*/
				get_pur_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME, get_pur_bundle_iflistp, PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_pur_bundle_iflistp, PIN_FLD_POID, ebufp);
				if(start_t != 0)
				{
					PIN_FLIST_FLD_SET(get_pur_bundle_iflistp, PIN_FLD_VALID_FROM, 
							(void *)&start_t, ebufp);
				}

				if(end_t != 0)
				{
					PIN_FLIST_FLD_SET(get_pur_bundle_iflistp, PIN_FLD_VALID_TO, 
							(void *)&end_t, ebufp);
				}
				
				/*
				*	Search /purchased_bundle for package name and same validity
				*	If found, get /purchased_bundle poid at exist_pur_bundle_pdp
				*/
				fm_tab_utils_common_get_purchase_bundle_dtls(ctxp, get_pur_bundle_iflistp,
					&get_pur_bundle_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchase_bundle_dtls:"
						" input flist ", get_pur_bundle_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_purchase_bundle_dtls:"
						" Error while getting purchased bundle details", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_purchase_bundle_dtls "
						"output flist", get_pur_bundle_oflistp);
				}
				
				/*
				*	exist_pur_bundle_pdp retrieved below will be used for populating under PIN_FLD_PLAN_OBJ. 
				*	Check products and discounts mode.
				*	If mode!=0 then set exist_pur_bundle_mode_flag = 1 at later stage
				*/
				
				if (get_pur_bundle_oflistp && (results_flistp = PIN_FLIST_ELEM_GET(get_pur_bundle_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					exist_pur_bundle_pdp = PIN_FLIST_FLD_GET(results_flistp, PIN_FLD_POID, 1, ebufp);

					/*
					 *	PIN_FLD_VALID_FROM_STR is being set to return flist under PACKAGE_INFO
					*/
					purchase_bund_start_t = PIN_FLIST_FLD_GET(results_flistp,
						PIN_FLD_VALID_FROM, 1, ebufp);

					if((temp_package_flistp != NULL) && purchase_bund_start_t != NULL 
						&& *purchase_bund_start_t != 0)
					{
						prod_bund_start_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp,
							purchase_bund_start_t, ebufp);
						PIN_FLIST_FLD_PUT(temp_package_flistp, PIN_FLD_VALID_FROM_STR,
							prod_bund_start_strp, ebufp);
					}
				}
			}

			/*Loop through input bundle info array*/
			bundle_elemid = 0;
			bundle_cookie = NULL;
			while ((bunde_flistp = PIN_FLIST_ELEM_GET_NEXT(package_flistp, PIN_FLD_BUNDLE_INFO, 
				&bundle_elemid, 1, &bundle_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				create_pur_bundle_flag = 0;
				exist_pur_bundle_mode_flag = 0;
				//pur_bundle_pdp = NULL;

				// prepare the response flist
				if (temp_package_flistp != NULL)
				{
					temp_bundle_flistp = PIN_FLIST_ELEM_GET(temp_package_flistp, PIN_FLD_BUNDLE_INFO, 
							bundle_elemid, 1, ebufp);
				}
				deal_namep = PIN_FLIST_FLD_GET(bunde_flistp, PIN_FLD_NAME, 1, ebufp);

				/*Check for mandatory deal name value under bundle info array*/
				if((deal_namep && strlen(deal_namep) == 0) || 
					PIN_FLIST_FLD_GET(bunde_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_DEAL_NAME_MISSING, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
						"Deal name is missing in request", ebufp);
					goto cleanup;
				}

				//notification flist updation with bundle details
				bundle_info_notf_flistp = PIN_FLIST_ELEM_ADD(package_info_flistp, 
						PIN_FLD_BUNDLE_INFO, bundle_elemid, ebufp);	
				PIN_FLIST_FLD_COPY(bunde_flistp, PIN_FLD_NAME, 
						bundle_info_notf_flistp, PIN_FLD_NAME, ebufp);

				/*Search for deal object using deal name*/
				deal_details_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, deal_details_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_SET(deal_details_iflistp, PIN_FLD_NAME, deal_namep, ebufp);

				fm_tab_utils_common_get_deal_details(ctxp, deal_details_iflistp, 
					&deal_details_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
						" input flist ", deal_details_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
						" Error while getting deal object", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
						"fm_tab_utils_common_get_deal_details output flist", deal_details_oflistp);
				}

				/*Prepare Input flist for TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL*/
				purchase_deal_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, purchase_deal_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CELL_ID, purchase_deal_iflistp, PIN_FLD_CELL_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ZONEMAP_TARGET, purchase_deal_iflistp, PIN_FLD_ZONEMAP_TARGET, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ZONEMAP_NAME, purchase_deal_iflistp, PIN_FLD_ZONEMAP_NAME, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, purchase_deal_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

				context_info_flistp = PIN_FLIST_SUBSTR_ADD(purchase_deal_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
				deal_info_flistp = PIN_FLIST_SUBSTR_ADD(purchase_deal_iflistp, PIN_FLD_DEAL_INFO, ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, TAB_FLD_PACKAGE_TYPE, deal_info_flistp, TAB_FLD_PACKAGE_TYPE, ebufp);

				// to set the timestamps using OOTB functions and decide whether to create purchased bundle object or not
				if(deal_details_oflistp != NULL && (deal_details_flistp = PIN_FLIST_ELEM_GET(deal_details_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					/*Convert deal products array date details into offset and unit. Ex: PIN_FLD_PURCHASE_END_DETAILS*/
					fm_subs_convert_date_details_into_offset_unit(ctxp, PIN_FLD_PRODUCTS, &deal_details_flistp, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,  "fm_tab_cust_purchase_offer: "
						"fm_subs_convert_date_details_into_offset_unit PIN_FLD_PRODUCTS output flist", deal_details_flistp);

					/*Convert deal discount array date details into offset and unit. Ex: PIN_FLD_PURCHASE_END_DETAILS*/
					fm_subs_convert_date_details_into_offset_unit(ctxp, PIN_FLD_DISCOUNTS, &deal_details_flistp, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
						"fm_subs_convert_date_details_into_offset_unit PIN_FLD_DISCOUNTS output flist",deal_details_flistp);

					permitted_typep = PIN_FLIST_FLD_GET(deal_details_flistp, PIN_FLD_PERMITTED, 1, ebufp);

					if(permitted_typep && (strncmp(permitted_typep, PIN_OBJ_TYPE_ACCOUNT, 
						strlen(PIN_OBJ_TYPE_ACCOUNT))))
					{
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, purchase_deal_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
					}

					/* Create purchase bundle for products and discounts of type 602*/
					/* loop through products array and verify if any PRODUCT is of subscription type. */ 
					/* If yes then we have create purchased , Else no need to create (for example one time Item type products */
					/* All products and discounts under a bundle should be configured with LONGEST/EXTEND mode */
					/* If any product is of type LONEGST/EXTEND mode then exising valid purchased bundle should be used */

					deal_products_elemid = 0;
					deal_products_cookie = NULL;
					while ((results_products_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_PRODUCTS, 
						&deal_products_elemid, 1, &deal_products_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						modep = PIN_FLIST_FLD_GET(results_products_flistp, PIN_FLD_MODE, 1, ebufp);
						if( !PIN_POID_IS_NULL(exist_pur_bundle_pdp) && modep && *modep != 0 && 
							exist_pur_bundle_mode_flag == 0)
						{
							exist_pur_bundle_mode_flag = 1;
						}
						prod_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(results_products_flistp, PIN_FLD_PRODUCT_OBJ, 
								prod_read_flds_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(prod_read_flds_iflistp, PIN_FLD_TYPE, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
							"Read prod flds input flist", prod_read_flds_iflistp);
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, prod_read_flds_iflistp, &prod_read_flds_oflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" input flist ", prod_read_flds_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" Error while reading product flds", ebufp);
							PIN_FLIST_DESTROY_EX(&prod_read_flds_iflistp, NULL);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
								"Read prod flds output flist", prod_read_flds_oflistp);

							if(prod_read_flds_oflistp != NULL)
							{
								product_type = PIN_FLIST_FLD_GET(prod_read_flds_oflistp, PIN_FLD_TYPE, 1, ebufp);

								if(product_type && (*product_type == PIN_PROD_TYPE_ONGOING))
								{
									/*Set flag value to 1 if the type is 602*/
									create_pur_bundle_flag = 1;
								}
							}
						}

						PIN_FLIST_DESTROY_EX(&prod_read_flds_iflistp, NULL);
						PIN_FLIST_DESTROY_EX(&prod_read_flds_oflistp, NULL);
					}

					/*Create purchase bundle for products and discounts of type 602
					* check for discounts array for scenario where a bundle can only contains discounts
					*/
					if(create_pur_bundle_flag == 0)
					{
						deal_discounts_elemid = 0;
						deal_discounts_cookie = NULL;
						while ((results_discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_DISCOUNTS, 
							&deal_discounts_elemid, 1, &deal_discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							modep = PIN_FLIST_FLD_GET(results_discounts_flistp, PIN_FLD_MODE, 1, ebufp);
							if( !PIN_POID_IS_NULL(exist_pur_bundle_pdp) && modep && 
								*modep != 0 && exist_pur_bundle_mode_flag == 0)
							{
								exist_pur_bundle_mode_flag = 1;
							}
							disc_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
							PIN_FLIST_FLD_COPY(results_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 
									disc_read_flds_iflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_SET(disc_read_flds_iflistp, PIN_FLD_TYPE, NULL, ebufp);

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
								"Read disc flds input flist", disc_read_flds_iflistp);
							PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, disc_read_flds_iflistp, &disc_read_flds_oflistp, ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
									" input flist ", disc_read_flds_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
									" Error while reading discount flds", ebufp);
								PIN_FLIST_DESTROY_EX(&disc_read_flds_iflistp, NULL);
								goto cleanup;
							}
							else
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
									"Read disc flds output flist", disc_read_flds_oflistp);

								if(disc_read_flds_oflistp != NULL)
								{
									discount_type = PIN_FLIST_FLD_GET(disc_read_flds_oflistp, PIN_FLD_TYPE, 1, ebufp);

									if(discount_type && (*discount_type == PIN_DISC_TYPE_ONGOING))
									{
										/*Set flag value to 1 if the type is 602*/
										create_pur_bundle_flag = 1;
									}
								}
							}

							PIN_FLIST_DESTROY_EX(&disc_read_flds_iflistp, NULL);
							PIN_FLIST_DESTROY_EX(&disc_read_flds_oflistp, NULL);
						}
					}

					/*Create purchase bundle based on the flag value create_pur_bundle_flag
					* exist_pur_bundle_mode_flag is set to 1 in above PRODUCTS and DISCOUNTS while loop 
					* PIN_POID_IS_NULL(pur_bundle_pdp) && match_pur_bundle_flag == 0 is not to create a new purchased bundle object when purchase is happening 
					* for multiple bundles under package (pur_bundle_pdp & match_pur_bundle_flag will be set to skip creating purchased bundle again) 
					*/
					if(create_pur_bundle_flag == 1 && PIN_POID_IS_NULL(pur_bundle_pdp) && match_pur_bundle_flag == 0
							&& exist_pur_bundle_mode_flag == 0)
					{
						if(plan_details_oflistp != NULL && (plan_details_flistp = PIN_FLIST_ELEM_GET(plan_details_oflistp,
							PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
						{
							plan_pdp = PIN_FLIST_FLD_GET(plan_details_flistp, PIN_FLD_POID, 1, ebufp);
						}
						else
						{
							/*Create Purchase bundle based on package name*/
							
							create_pur_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
									create_pur_bundle_iflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(package_flistp, TAB_FLD_PACKAGE_TYPE, 
									create_pur_bundle_iflistp, TAB_FLD_PACKAGE_TYPE, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
									create_pur_bundle_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
									create_pur_bundle_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
							PIN_FLIST_FLD_SET(create_pur_bundle_iflistp, PIN_FLD_DESCR, package_typep, ebufp);

							if(start_t != 0)
							{
								PIN_FLIST_FLD_SET(create_pur_bundle_iflistp, PIN_FLD_START_T, 
										(void *)&start_t, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(create_pur_bundle_iflistp, PIN_FLD_START_T, 
										(void *)&now_t, ebufp);
							}

							if(end_t != 0)
							{
								PIN_FLIST_FLD_SET(create_pur_bundle_iflistp, PIN_FLD_END_T, 
										(void *)&end_t, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(create_pur_bundle_iflistp, PIN_FLD_END_T, 
										(void *)&default_val_zero_t, ebufp);
							}

							PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME, 
									create_pur_bundle_iflistp, PIN_FLD_NAME, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
									create_pur_bundle_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
									create_pur_bundle_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
								"fm_tab_cust_create_purchase_bundle input flist", create_pur_bundle_iflistp);

							fm_tab_cust_create_purchase_bundle(ctxp, create_pur_bundle_iflistp, 
									&create_pur_bundle_oflistp, db_no, ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_purchase_bundle:"
										" input flist ", create_pur_bundle_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_purchase_bundle:"
										" Error while calling PCM_OP_SUBSCRIPTION_SET_BUNDLE", ebufp);
								goto cleanup;
							}
							else
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
									"fm_tab_cust_create_purchase_bundle output flist", create_pur_bundle_oflistp);

								PIN_FLIST_ELEM_SET(purchase_offer_rdata_flistp, create_pur_bundle_oflistp, 
									PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);

								// to prepare response flist under packages
								if (create_pur_bundle_oflistp && (bundle_pdp_flistp = 
									PIN_FLIST_ELEM_GET(create_pur_bundle_oflistp, PIN_FLD_BUNDLE_INFO, 
										PIN_ELEMID_ANY, 1, ebufp)) != NULL)
								{
									valid_from_t = PIN_FLIST_FLD_GET(bundle_pdp_flistp, 
											PIN_FLD_VALID_FROM, 1, ebufp);
									if(valid_from_t && *valid_from_t != 0)
									{
										valid_from_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
												valid_from_t, ebufp);
										PIN_FLIST_FLD_PUT(temp_package_flistp, PIN_FLD_VALID_FROM_STR, 
												valid_from_strp, ebufp);
										
									}

									valid_to_t = PIN_FLIST_FLD_GET(bundle_pdp_flistp, 
											PIN_FLD_VALID_TO, 1, ebufp);
									if(valid_to_t)
									{
										valid_to_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
												valid_to_t, ebufp);
										PIN_FLIST_FLD_PUT(temp_package_flistp, PIN_FLD_VALID_TO_STR, 
												valid_to_strp, ebufp);
									}

									pur_bundle_pdp = PIN_FLIST_FLD_GET(bundle_pdp_flistp, PIN_FLD_POID, 1, ebufp);
									match_pur_bundle_flag = 1;
								}
								
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
									"fm_tab_cust_create_purchase_bundle: temp_package_flistp2", temp_package_flistp);
							}
						}
					}

					/*If the input contains only deal name under BUNDLE_INFO array. i.e. products array is not passed*/
					if(PIN_FLIST_ELEM_GET(bunde_flistp, PIN_FLD_PRODUCTS, PIN_ELEMID_ANY, 1, ebufp) == NULL)
					{
						/*Loop through deal products array based on retrieved deal details*/
						deal_products_elemid = 0;
						deal_products_cookie = NULL;
						while ((deal_products_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_PRODUCTS, 
							&deal_products_elemid, 1, &deal_products_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							product_flistp = PIN_FLIST_ELEM_ADD(deal_info_flistp, PIN_FLD_PRODUCTS, deal_products_elemid, ebufp);
							PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
							PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, product_flistp, PIN_FLD_DESCR, ebufp);
							PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PRODUCT_OBJ, product_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_MODE, product_flistp, PIN_FLD_MODE, ebufp);

							modep = PIN_FLIST_FLD_GET(deal_products_flistp, PIN_FLD_MODE, 1, ebufp);

							/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/
							if(start_t)
							{
								now_t = pin_virtual_time(NULL);
								start_offset_t = start_t - now_t;
							}

							/*Set calculated relative start offset based on input start date*/
							if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
							}
							else
							{
								/*Set calculated relative start offset based on input start date*/
								if(start_offset_t != 0)
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
								}
								else
								{
									/*Copy start date detail's unit and offset from flist converted using 
									 * fm_subs_convert_date_details_into_offset_unit*/
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&default_val_zero_t, ebufp);

									/* this will set the validities configured in PDC */
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PURCHASE_START_UNIT,
										product_flistp, PIN_FLD_PURCHASE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PURCHASE_START_OFFSET,
										product_flistp, PIN_FLD_PURCHASE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_USAGE_START_OFFSET,
										product_flistp, PIN_FLD_USAGE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_USAGE_START_UNIT,
										product_flistp, PIN_FLD_USAGE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_CYCLE_START_UNIT,
										product_flistp, PIN_FLD_CYCLE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_CYCLE_START_OFFSET,
										product_flistp, PIN_FLD_CYCLE_START_OFFSET, ebufp);
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Copying in Nested else ", deal_products_flistp);
								}
							}

							/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/	
							if (end_t)
							{
								now_t = pin_virtual_time(NULL);
								end_offset_t = end_t - now_t;
							}

							/*Set calculated relative end offset based on input end date*/
							if(end_offset_t !=0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
							}
							else
							{
								/*Set calculated relative end offset based on input end date*/
								if(end_offset_t !=0)
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
								}
								else
								{
									/*Copy end date detail's unit and offset from flist converted using 
									 * fm_subs_convert_date_details_into_offset_unit*/
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&default_val_zero_t, ebufp);

									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PURCHASE_END_UNIT,
										product_flistp, PIN_FLD_PURCHASE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PURCHASE_END_OFFSET,
										product_flistp, PIN_FLD_PURCHASE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_USAGE_END_UNIT,
										product_flistp, PIN_FLD_USAGE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_USAGE_END_OFFSET,
										product_flistp, PIN_FLD_USAGE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_CYCLE_END_UNIT,
										product_flistp, PIN_FLD_CYCLE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_CYCLE_END_OFFSET,
										product_flistp, PIN_FLD_CYCLE_END_OFFSET, ebufp);
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Copying in Nested else ", deal_products_flistp);
								}
							}

							PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_STATUS, &prod_status, ebufp);

							add_product_flistp = PIN_FLIST_ELEM_ADD(temp_bundle_flistp, PIN_FLD_PRODUCTS, deal_products_elemid, ebufp);
							PIN_FLIST_FLD_SET(add_product_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
							PIN_FLIST_FLD_COPY(deal_products_flistp, PIN_FLD_PRODUCT_OBJ, 
								add_product_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);

						}
					}

					/*If the input contains only deal name under BUNDLE_INFO array. i.e. discounts array is not passed*/
					if(PIN_FLIST_ELEM_GET(bunde_flistp, PIN_FLD_DISCOUNTS, PIN_ELEMID_ANY, 1, ebufp) == NULL)
					{
						/*Loop through deal discounts array based on retrieved deal details*/
						deal_discounts_elemid = 0;
						deal_discounts_cookie = NULL;
						while ((deal_discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_DISCOUNTS, 
							&deal_discounts_elemid, 1, &deal_discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							discount_flistp = PIN_FLIST_ELEM_ADD(deal_info_flistp, PIN_FLD_DISCOUNTS, deal_discounts_elemid, ebufp);
							PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
							PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, discount_flistp, PIN_FLD_DESCR, ebufp);
							PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 
								discount_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_MODE, discount_flistp, PIN_FLD_MODE, ebufp);
							modep = PIN_FLIST_FLD_GET(deal_discounts_flistp, PIN_FLD_MODE, 1, ebufp);

							/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/
							if(start_t)
							{
								now_t = pin_virtual_time(NULL);
								start_offset_t = start_t - now_t;
							}

							/*Set calculated relative start offset based on input start date*/
							if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
							}
							else
							{
								/*Set calculated relative start offset based on input start date*/
								if(start_offset_t != 0)
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&default_val_zero_t, ebufp);

									/*Copy start date detail's unit and offset from flist converted using
									* fm_subs_convert_date_details_into_offset_unit*/
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_PURCHASE_START_UNIT,
										discount_flistp, PIN_FLD_PURCHASE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_PURCHASE_START_OFFSET,
										discount_flistp, PIN_FLD_PURCHASE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_USAGE_START_UNIT,
										discount_flistp, PIN_FLD_USAGE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_USAGE_START_OFFSET,
										discount_flistp, PIN_FLD_USAGE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_CYCLE_START_UNIT,
										discount_flistp, PIN_FLD_CYCLE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_CYCLE_START_OFFSET,
										discount_flistp, PIN_FLD_CYCLE_START_OFFSET, ebufp);
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "copying in Nested else", deal_discounts_flistp);
								}
							}

							/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/	
							if (end_t)
							{
								now_t = pin_virtual_time(NULL);
								end_offset_t = end_t - now_t;
							}

							/*Set calculated relative end offset based on input end date*/
							if(end_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
							}
							else
							{
								/*Set calculated relative end offset based on input end date*/
								if(end_offset_t != 0)
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&default_val_zero_t, ebufp);

									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_PURCHASE_END_UNIT,
										discount_flistp, PIN_FLD_PURCHASE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_PURCHASE_END_OFFSET,
										discount_flistp, PIN_FLD_PURCHASE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_USAGE_END_UNIT,
										discount_flistp, PIN_FLD_USAGE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_USAGE_END_OFFSET,
										discount_flistp, PIN_FLD_USAGE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_CYCLE_END_UNIT,
										discount_flistp, PIN_FLD_CYCLE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_CYCLE_END_OFFSET,
										discount_flistp, PIN_FLD_CYCLE_END_OFFSET, ebufp);
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Copying in Nested else ", deal_discounts_flistp);
								}
							}

							PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_STATUS, &disc_status, ebufp);

							add_discount_flistp = PIN_FLIST_ELEM_ADD(temp_bundle_flistp, PIN_FLD_DISCOUNTS, 
								deal_discounts_elemid, ebufp);
							PIN_FLIST_FLD_SET(add_discount_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
							PIN_FLIST_FLD_COPY(deal_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 
								add_discount_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
						}
					}
				}
				else
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_DEAL_NOT_FOUND, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
						"Deal not found in BRM DB", ebufp);
					goto cleanup;
				}

				PIN_FLIST_FLD_COPY(deal_details_flistp, PIN_FLD_POID, deal_info_flistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(bunde_flistp, PIN_FLD_NAME, deal_info_flistp, PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_SET (deal_info_flistp, PIN_FLD_PACKAGE_ID, (void*)(&package_idp), ebufp);
				PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_START_T, (void *)&default_val_zero_t, ebufp);
				PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_END_T, (void *)&default_val_zero_t, ebufp);

				/* Loop through input products array passed under BUNDLE_INFO array*/
				/* if input contains the PRODUCTS and DISCOUNTS array present under the BUNDLE_INFO in input*/
				/* below while loops flow will not be executed in case where input of API doesnot contain product and discount information */
				products_elemid = 0;
				products_cookie = NULL;
				while ((products_flistp = PIN_FLIST_ELEM_GET_NEXT(bunde_flistp, PIN_FLD_PRODUCTS, 
					&products_elemid, 1, &products_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					//notification flist updation with PRODUCTS details if input contains PRODUCTS details
					product_notf_flistp = PIN_FLIST_ELEM_ADD(bundle_info_notf_flistp, 
							PIN_FLD_PRODUCTS, products_elemid, ebufp);	
					PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_NAME, 
							product_notf_flistp, PIN_FLD_NAME, ebufp);

					// adding PRODUCTS array to PURCHASE_DEAL input flist
					product_flistp = PIN_FLIST_ELEM_ADD(deal_info_flistp, PIN_FLD_PRODUCTS, products_elemid, ebufp);

					prod_quantityp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_QUANTITY, 1, ebufp);
					if(!pbo_decimal_is_null(prod_quantityp, ebufp))
					{
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_QUANTITY, prod_quantityp, ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
					}

					PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, product_flistp, PIN_FLD_DESCR, ebufp);
					PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID, product_flistp, 
						PIN_FLD_PACKAGE_ID, ebufp);

					product_namep = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_NAME, 1, ebufp);

					/* MODULAR1-START*/
					/*Check for mandatory Product Name*/
					if((product_namep && strlen(product_namep) == 0) || 
						(PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_PRODUCT_NAME_MISSING, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							"Product name is not passed in request", ebufp);
						goto cleanup;
					}

					/*Fetch product object using product name*/
					get_product_details_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_NAME, get_product_details_iflistp, PIN_FLD_NAME, ebufp);

					fm_tab_utils_common_get_product_details(ctxp, get_product_details_iflistp, 
						&get_product_details_oflistp, db_no, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_product_details:"
							" input flist ", get_product_details_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_product_details:"
							" Error while getting product details", ebufp);
						PIN_FLIST_DESTROY_EX(&get_product_details_iflistp, NULL);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
							"fm_tab_utils_common_get_product_details output flist", get_product_details_oflistp);

						if (get_product_details_oflistp && (prod_obj_flistp = PIN_FLIST_ELEM_GET(get_product_details_oflistp, 
							PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
						{
							prod_pdp = PIN_FLIST_FLD_GET(prod_obj_flistp, PIN_FLD_POID, 1, ebufp);
							PIN_FLIST_FLD_COPY(prod_obj_flistp, PIN_FLD_POID, product_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
						}
						else
						{
							/*If the product is not found in BRM DB*/
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_PRODUCT_NOT_FOUND, 0, 0, 0);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
								"Product not found in BRM DB", ebufp);
							goto cleanup;
						}
					}

					/* MODULAR1-END*/ 
					/*to set product or discount obj */
					/*If the input product matches with deal products retrieved using search*/
					deal_mode_elemid = 0;
					deal_mode_cookie = NULL;
					while ((deal_mode_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_PRODUCTS, 
						&deal_mode_elemid, 1, &deal_mode_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						deal_mode_prd_pdp = PIN_FLIST_FLD_GET(deal_mode_flistp, PIN_FLD_PRODUCT_OBJ, 1, ebufp);
						modep = PIN_FLIST_FLD_GET(deal_mode_flistp, PIN_FLD_MODE, 1, ebufp);
						if(!PIN_POID_IS_NULL(prod_pdp) && !PIN_POID_IS_NULL(deal_mode_prd_pdp) && 
							!PIN_POID_COMPARE(prod_pdp, deal_mode_prd_pdp, 0, ebufp))
						{
							if(start_t)
							{
								now_t = pin_virtual_time(NULL);
								start_offset_t = start_t - now_t;
							}

							if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
							}
							else
							{
								if(start_offset_t != 0)
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_START_UNIT,
										product_flistp, PIN_FLD_PURCHASE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_START_OFFSET,
										product_flistp, PIN_FLD_PURCHASE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_START_UNIT,
										product_flistp, PIN_FLD_USAGE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_START_OFFSET,
										product_flistp, PIN_FLD_USAGE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_START_UNIT,
										product_flistp, PIN_FLD_CYCLE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_START_OFFSET,
										product_flistp, PIN_FLD_CYCLE_START_OFFSET, ebufp);
								}
							}

							if (end_t)
							{
								now_t = pin_virtual_time(NULL);
								end_offset_t = end_t - now_t;
							}
							
							if(end_offset_t !=0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
							}
							else
							{
								if(end_offset_t !=0)
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_END_UNIT,
										product_flistp, PIN_FLD_PURCHASE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_END_OFFSET,
										product_flistp, PIN_FLD_PURCHASE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_END_UNIT,
										product_flistp, PIN_FLD_USAGE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_END_OFFSET,
										product_flistp, PIN_FLD_USAGE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_END_UNIT,
										product_flistp, PIN_FLD_CYCLE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_END_OFFSET,
										product_flistp, PIN_FLD_CYCLE_END_OFFSET, ebufp);
								}
							}

							break;

						}
					}

					/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/
					if(start_t)
					{
						now_t = pin_virtual_time(NULL);
						start_offset_t = start_t - now_t;
					}


					/*Set calculated relative start offset based on input start date*/
					if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
					{
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
					}

					/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/	
					if (end_t)
					{
						now_t = pin_virtual_time(NULL);
						end_offset_t = end_t - now_t;
					}

					/*Set calculated relative end offset based on input end date*/
					if(end_offset_t !=0 && modep && (*modep == 0 || *modep == 4))
					{
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
						PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
					}

					PIN_FLIST_FLD_SET(product_flistp, PIN_FLD_STATUS, &prod_status, ebufp);

					// to prepare response flist
					// to add products information under bundle
					if ((temp_prod_flistp = PIN_FLIST_ELEM_GET(temp_bundle_flistp, PIN_FLD_PRODUCTS, 
						products_elemid, 1, ebufp)) != NULL)
					{
						PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_FROM_STR, 
							temp_prod_flistp, PIN_FLD_VALID_FROM_STR, ebufp);
						PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_TO_STR, 
							temp_prod_flistp, PIN_FLD_VALID_TO_STR, ebufp);
						PIN_FLIST_FLD_COPY(prod_obj_flistp, PIN_FLD_POID, 
							temp_prod_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
					}

					PIN_FLIST_DESTROY_EX(&get_product_details_iflistp, NULL);
					PIN_FLIST_DESTROY_EX(&get_product_details_oflistp, NULL);
				}

				/*Loop through input discount array passed under BUNDLE_INFO array*/
				discounts_elemid = 0;
				discounts_cookie = NULL;
				while ((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(bunde_flistp, PIN_FLD_DISCOUNTS,
					&discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					discount_notf_flistp = PIN_FLIST_ELEM_ADD(bundle_info_notf_flistp, 
						PIN_FLD_DISCOUNTS, discounts_elemid, ebufp);	
					PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_NAME, 
						discount_notf_flistp, PIN_FLD_NAME, ebufp);

					discount_flistp = PIN_FLIST_ELEM_ADD(deal_info_flistp, PIN_FLD_DISCOUNTS, discounts_elemid, ebufp);

					disc_quantityp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_QUANTITY, 1, ebufp);
					if(!pbo_decimal_is_null(disc_quantityp, ebufp))
					{
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_QUANTITY, disc_quantityp, ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_QUANTITY, default_quantity, ebufp);
					}

					PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, 
							discount_flistp, PIN_FLD_DESCR, ebufp);
					PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID, 
							discount_flistp, PIN_FLD_PACKAGE_ID, ebufp);

					discount_namep = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_NAME, 1, ebufp);

					/*Ceck for mandatory Discount Name*/
					if((discount_namep && strlen(discount_namep) == 0) || 
						(PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_DISCOUNT_NAME_MISSING, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							"Discount name is not passed in request", ebufp);
						goto cleanup;
					}

					/*Fetch discount object using input discount name under DISCOUNTS array*/
					get_discount_details_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_NAME, get_discount_details_iflistp, PIN_FLD_NAME, ebufp);

					fm_tab_utils_common_get_discount_details(ctxp, get_discount_details_iflistp, 
						&get_discount_details_oflistp, db_no, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_discount_details:"
							" input flist ", get_discount_details_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_discount_details:"
							" Error while getting discount details", ebufp);
						PIN_FLIST_DESTROY_EX(&get_discount_details_iflistp, NULL);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
							"fm_tab_utils_common_get_discount_details output flist", get_discount_details_oflistp);

						if (get_discount_details_oflistp && (disc_obj_flistp = PIN_FLIST_ELEM_GET(get_discount_details_oflistp, 
							PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
						{
							disc_pdp = PIN_FLIST_FLD_GET(disc_obj_flistp, PIN_FLD_POID, 1, ebufp);
							PIN_FLIST_FLD_COPY(disc_obj_flistp, PIN_FLD_POID, discount_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
						}
						else
						{
							/*If the input discount is not found in BRM DB*/
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_DISCOUNT_NOT_FOUND, 0, 0, 0);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
								"Discount not found in BRM DB", ebufp);
							goto cleanup;
						}
					}

					/*If the input discount matches with deal discounts retrieved using search*/
					deal_mode_elemid = 0;
					deal_mode_cookie = NULL;
					while ((deal_mode_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_DISCOUNTS, 
						&deal_mode_elemid, 1, &deal_mode_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						deal_mode_disc_pdp = PIN_FLIST_FLD_GET(deal_mode_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);
						modep = PIN_FLIST_FLD_GET(deal_mode_flistp, PIN_FLD_MODE, 1, ebufp);

						if(!PIN_POID_IS_NULL(disc_pdp) && !PIN_POID_IS_NULL(deal_mode_disc_pdp) && 
							!PIN_POID_COMPARE(disc_pdp, deal_mode_disc_pdp, 0, ebufp))
						{
							if(start_t)
							{
								now_t = pin_virtual_time(NULL);
								start_offset_t = start_t - now_t;
							}

							if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
							}
							else
							{
								if(start_offset_t != 0)
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&default_val_zero_t, ebufp);

									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_START_UNIT,
										discount_flistp, PIN_FLD_PURCHASE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_START_OFFSET,
										discount_flistp, PIN_FLD_PURCHASE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_START_UNIT,
										discount_flistp, PIN_FLD_USAGE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_START_OFFSET,
										discount_flistp, PIN_FLD_USAGE_START_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_START_UNIT,
										discount_flistp, PIN_FLD_CYCLE_START_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_START_OFFSET,
										discount_flistp, PIN_FLD_CYCLE_START_OFFSET, ebufp);
								}
							}

							if (end_t)
							{
								now_t = pin_virtual_time(NULL);
								end_offset_t = end_t - now_t;
							}

							if(end_offset_t !=0 && modep && (*modep == 0 || *modep == 4))
							{
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
								PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
							}
							else
							{
								if(end_offset_t !=0)
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
								}
								else
								{
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&default_val_zero_t, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_END_UNIT,
										discount_flistp, PIN_FLD_PURCHASE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_PURCHASE_END_OFFSET,
										discount_flistp, PIN_FLD_PURCHASE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_END_UNIT,
										discount_flistp, PIN_FLD_USAGE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_USAGE_END_OFFSET,
										discount_flistp, PIN_FLD_USAGE_END_OFFSET, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_END_UNIT,
										discount_flistp, PIN_FLD_CYCLE_END_UNIT, ebufp);
									PIN_FLIST_FLD_COPY(deal_mode_flistp, PIN_FLD_CYCLE_END_OFFSET,
										discount_flistp, PIN_FLD_CYCLE_END_OFFSET, ebufp);
								}
							}								

							break;

						}
					}

					/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/
					if(start_t)
					{
						now_t = pin_virtual_time(NULL);
						start_offset_t = start_t - now_t;
					}

					/*Set calculated relative start offset based on input start date*/
					if(start_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
					{
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_START_T, (void *)&start_offset_t, ebufp);
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_START_T, (void *)&start_offset_t, ebufp);
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_START_T, (void *)&start_offset_t, ebufp);
					}

					/*re calculating the end date for relative time difference for DTAC bug DBILLING-1360*/	
					if (end_t)
					{
						now_t = pin_virtual_time(NULL);
						end_offset_t = end_t - now_t;
					}

					/*Set calculated relative end offset based on input end date*/
					if(end_offset_t != 0 && modep && (*modep == 0 || *modep == 4))
					{
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_offset_t, ebufp);
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_offset_t, ebufp);
						PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_USAGE_END_T, (void *)&end_offset_t, ebufp);
					}

					PIN_FLIST_FLD_SET(discount_flistp, PIN_FLD_STATUS, &disc_status, ebufp);

					// to prepare response flist
					// to add discounts information under bundle
					if ((temp_disc_flistp = PIN_FLIST_ELEM_GET(temp_bundle_flistp, PIN_FLD_DISCOUNTS, 
						discounts_elemid, 1, ebufp)) != NULL)
					{
						PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_FROM_STR, temp_disc_flistp, PIN_FLD_VALID_FROM_STR, ebufp);
						PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_TO_STR, temp_disc_flistp, PIN_FLD_VALID_TO_STR, ebufp);
						PIN_FLIST_FLD_COPY(disc_obj_flistp, PIN_FLD_POID, temp_disc_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
					}

					PIN_FLIST_DESTROY_EX(&get_discount_details_iflistp, NULL);
					PIN_FLIST_DESTROY_EX(&get_discount_details_oflistp, NULL);
				}

				if(!PIN_POID_IS_NULL(plan_pdp))
				{
					PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_PLAN_OBJ, plan_pdp, ebufp);
				}

				if(!PIN_POID_IS_NULL(pur_bundle_pdp))
				{
					PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_PLAN_OBJ, pur_bundle_pdp, ebufp);
				}
				
				if(!PIN_POID_IS_NULL(exist_pur_bundle_pdp) && exist_pur_bundle_mode_flag==1 )
				{
					PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_PLAN_OBJ, exist_pur_bundle_pdp, ebufp);
				}

				/*Call BU hook TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL to enrich purchase deal input*/
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
					"TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL input flist", purchase_deal_iflistp);

				PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL, 0, purchase_deal_iflistp, &hook_deal_in_flistp, ebufp);

				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
						"TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL Hook opcode prepare Input flist", purchase_deal_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
						"TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL Hook opcode prepare input flist error", ebufp);
					*out_flistpp = hook_deal_in_flistp;
					goto cleanup;
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
					"TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL output flist", hook_deal_in_flistp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
					"PCM_OP_SUBSCRIPTION_PURCHASE_DEAL input flist", hook_deal_in_flistp);
					
					
				/*Below validation moved as per CTP-21219*/
				
				/* Checking Service status as Can not add a deal into an non active service*/
				rd_iflistp = PIN_FLIST_CREATE(ebufp);
				service_pdp = PIN_FLIST_FLD_GET(hook_deal_in_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
				if(!PIN_POID_IS_NULL(service_pdp))
				{
					PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_POID, service_pdp, ebufp);
					PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_STATUS, NULL, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
							"fm_tab_cust_purchase_offer read_flds input flist", rd_iflistp);
					PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, rd_iflistp, &rd_rflistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_offer: "
							"PCM_OP_READ_OBJ input flist", rd_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
							"PCM_OP_READ_OBJ error", ebufp);
						goto cleanup;
					}
					if (rd_rflistp !=NULL)
					{
						statusp = PIN_FLIST_FLD_GET(rd_rflistp, PIN_FLD_STATUS, 0, ebufp);
						if(statusp && *statusp != PIN_STATUS_ACTIVE)
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_NON_ACTIVE_SERVICE, 0, 0, 0);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
								"Can not add a deal into an inactive/ closed service", ebufp);
							goto cleanup;
						}
					}
				}				

				/*Execute PCM_OP_SUBSCRIPTION_PURCHASE_DEAL opcode*/
				PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_PURCHASE_DEAL, 0, hook_deal_in_flistp, &purchase_deal_oflistp, ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					fm_tab_cust_purchase_offer_error_hook(ctxp,in_flistp, &purchase_deal_oflistp, ebufp);
					
					cerror_code = ebufp->pin_err;
					if(cerror_code == PIN_ERR_CREDIT_LIMIT_EXCEEDED )
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_CREDIT_EXCEEDED, 0, 0, 0);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" input flist ", hook_deal_in_flistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" Error in purchase deal", ebufp);
						goto cleanup;
					}
					else if(cerror_code == PIN_ERR_NO_CREDIT_BALANCE ){
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_NO_BALANCE_PURCHASE, 0, 0, 0);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" input flist ", hook_deal_in_flistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" Error in purchase deal", ebufp);
						goto cleanup;
					}
					else
					{
						if (purchase_deal_oflistp!= NULL)
						{						
							ret_hook_err_code = PIN_FLIST_FLD_GET(purchase_deal_oflistp, PIN_FLD_ERROR_CODE, 1, local_ebufp);
							if(ret_hook_err_code && strlen(ret_hook_err_code) != 0)
							{
								PIN_FLIST_FLD_COPY(purchase_deal_oflistp, PIN_FLD_ERROR_CODE, *out_flistpp, PIN_FLD_ERROR_CODE, local_ebufp);
								PIN_FLIST_FLD_COPY(purchase_deal_oflistp, PIN_FLD_ERROR_DESCR, *out_flistpp, PIN_FLD_ERROR_DESCR, local_ebufp);
							}
							else
							{
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_PURCHASE_OFFER, 0, 0, 0);
							} 
						}
						else
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_PURCHASE_OFFER, 0, 0, 0);
						}
						
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" input flist ", hook_deal_in_flistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
							" Error in purchase deal", ebufp);
						goto cleanup;
					}
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_purchase_offer:"
					" PCM_OP_SUBSCRIPTION_PURCHASE_DEAL output flist ", purchase_deal_oflistp);

				PIN_FLIST_ELEM_SET(purchase_offer_rdata_flistp, purchase_deal_oflistp, PIN_FLD_RESULTS_DATA,
					PIN_ELEMID_ASSIGN, ebufp);

				/*Enrich PCM_OP_SUBSCRIPTION_PURCHASE_DEAL Output flist*/
				if(purchase_deal_oflistp != NULL)
				{
					fm_tab_cust_enrich_purchase_deal_output(ctxp, temp_bundle_flistp, 
						purchase_deal_oflistp, db_no, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_purchase_deal_output:"
							" input flist ", temp_bundle_flistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_purchase_deal_output:"
							" Error while enriching purchase deal response", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
							"fm_tab_cust_enrich_purchase_deal_output output flist", purchase_deal_oflistp);

					}
				}

				/*Call TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD to update credit threshold*/
				set_limit_cr_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(bunde_flistp, PIN_FLD_NAME, set_limit_cr_iflistp, PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, TAB_FLD_PACKAGE_TYPE, set_limit_cr_iflistp, TAB_FLD_PACKAGE_TYPE, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, set_limit_cr_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, set_limit_cr_iflistp, PIN_FLD_MSISDN, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, set_limit_cr_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, set_limit_cr_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, set_limit_cr_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, set_limit_cr_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, set_limit_cr_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, set_limit_cr_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, set_limit_cr_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

				if(start_t != 0)
				{
					PIN_FLIST_FLD_SET(set_limit_cr_iflistp, PIN_FLD_VALID_FROM, 
							(void *)&start_t, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(set_limit_cr_iflistp, PIN_FLD_VALID_FROM, 
							(void *)&now_t, ebufp);
				}

				PIN_FLIST_SUBSTR_SET(set_limit_cr_iflistp, purchase_deal_oflistp, PIN_FLD_INHERITED_INFO, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
					"TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD input flist", set_limit_cr_iflistp);

				PCM_OP(ctxp, TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD, 0, set_limit_cr_iflistp, &hook_update_threshold_flistp, ebufp);

				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
						"TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD Hook opcode prepare Input flist", set_limit_cr_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer: "
						"TAB_OP_CUST_POL_PURCHASE_DEAL_UPDATE_THRESHOLD Hook opcode prepare input flist error", ebufp);
					*out_flistpp = hook_update_threshold_flistp;
					goto cleanup;
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer: "
					"TAB_OP_CUST_POL_ENRICH_PURCHASE_DEAL output flist", hook_update_threshold_flistp);

				PIN_FLIST_DESTROY_EX(&deal_details_iflistp, NULL);
				PIN_FLIST_DESTROY_EX(&deal_details_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&purchase_deal_iflistp, NULL);
				PIN_FLIST_DESTROY_EX(&purchase_deal_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&hook_deal_in_flistp, NULL);
				PIN_FLIST_DESTROY_EX(&create_pur_bundle_iflistp, NULL);
				PIN_FLIST_DESTROY_EX(&set_limit_cr_iflistp, NULL);
				PIN_FLIST_DESTROY_EX(&hook_update_threshold_flistp, NULL);
				//PIN_FLIST_DESTROY_EX(&create_pur_bundle_oflistp, NULL);
			}
			
			/*
			*	New purchased_bundle poid is getting generated when exist_pur_bundle_mode_flag is 0.
			*	Need to check for exist_pur_bundle_mode_flag == 0, as we have to update valid_to 
			*	for purchased_bundle with max of purchased_product_t among
			*	existing purchased_bundle/ or new purchased_bundle having same package_name 
			*	with different package_id or unique_id. In this case return package_id and unique_id
			*/
			/*
				CDTAC-13476
				if (exist_pur_bundle_mode_flag == 0 && (start_date_strp != NULL || end_date_strp != NULL))
			*/
		    /*DBILLING-927-Case Re-purchase the existing package,API should not return the existing unique ID.*/
			/* CDTAC-14623 Modified the condition to call max_purchased_date for both existing bundle  
			 * for mode other than 0 and new bundle to return proper max purchase end and
			 * to overwrite the purchased bundle with proper max purchase end */
			if ((!PIN_POID_IS_NULL(exist_pur_bundle_pdp) && exist_pur_bundle_mode_flag == 1) 
				|| !PIN_POID_IS_NULL(pur_bundle_pdp))
			{
				date_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME, date_iflistp, PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID, 
						date_iflistp, PIN_FLD_PACKAGE_ID, ebufp);
				PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID, date_iflistp, 
						PIN_FLD_UNIQUE_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, date_iflistp, 
						PIN_FLD_ACCOUNT_OBJ, ebufp);

				if(!PIN_POID_IS_NULL(exist_pur_bundle_pdp) && exist_pur_bundle_mode_flag == 1)
				{
					fm_tab_get_max_purchased_date(ctxp, date_iflistp, db_no, exist_pur_bundle_pdp, 
						&date_rflistp, ebufp);
				}
				else if(!PIN_POID_IS_NULL(pur_bundle_pdp))
				{
					fm_tab_get_max_purchased_date(ctxp, date_iflistp, db_no, pur_bundle_pdp, 
						&date_rflistp, ebufp);
				}

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_max_purchased_date:"
						" input flist ", date_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_max_purchased_date:"
						" Error", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
						"fm_tab_get_max_purchased_date output flist", date_rflistp);
				}
				
				// this is to update the dates of valid_to in existing purchased bundle object
				// also set the dates in response of API
				if (date_rflistp != NULL)
				{
					purchase_end_t = PIN_FLIST_FLD_GET(date_rflistp, PIN_FLD_PURCHASE_END_T, 1, ebufp);
					
					/*
					*	PIN_FLD_VALID_TO_STR is being set to return flist under PACKAGE_INFO
					*/
					if((temp_package_flistp != NULL) && purchase_end_t != NULL && *purchase_end_t != 0)
					{
						prod_pur_end_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
								purchase_end_t, ebufp);
						PIN_FLIST_FLD_PUT(temp_package_flistp, PIN_FLD_VALID_TO_STR, 
								prod_pur_end_strp, ebufp);
					}

					write_iflistp = PIN_FLIST_CREATE(ebufp);
					if(!PIN_POID_IS_NULL(pur_bundle_pdp))
					{
						PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_POID, pur_bundle_pdp, ebufp);
					}
					
					if(!PIN_POID_IS_NULL(exist_pur_bundle_pdp) && exist_pur_bundle_mode_flag == 1)
					{
						PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_POID, exist_pur_bundle_pdp, ebufp);
					}
					
					PIN_FLIST_FLD_COPY(date_rflistp, PIN_FLD_PURCHASE_END_T, write_iflistp, PIN_FLD_VALID_TO, ebufp);
					PIN_FLIST_FLD_COPY(date_rflistp, PIN_FLD_PURCHASE_START_T, write_iflistp, PIN_FLD_VALID_FROM, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
							"cust_purchase offer write_flds input flist", write_iflistp);
					PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 0, write_iflistp, &write_oflistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"cust_purchase offer write_flds error input flist", write_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"Error in cust_purchase offer write_flds input flist", ebufp);
						goto cleanup;
					}
					
					if(temp_package_flistp != NULL)
					{
						if(exist_pur_bundle_mode_flag == 1)
						{
							PIN_FLIST_FLD_COPY(date_rflistp, PIN_FLD_DESCR, temp_package_flistp, 
									PIN_FLD_UNIQUE_ID, ebufp);
						}
						PIN_FLIST_FLD_COPY(date_rflistp, PIN_FLD_PACKAGE_ID, temp_package_flistp, 
									PIN_FLD_PACKAGE_ID, ebufp);
					}
				}
			}
			PIN_FLIST_DESTROY_EX(&plan_details_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&plan_details_oflistp, NULL);
			PIN_FLIST_DESTROY_EX(&get_pur_bundle_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&get_pur_bundle_oflistp, NULL);
			PIN_FLIST_DESTROY_EX(&write_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&write_oflistp, NULL);
		}
		PIN_FLIST_DESTROY_EX(&hook_offer_iflistp, NULL);

		*out_flistpp = purchase_oflistp;

		// - need to check why there are outside below notify flag if condition
		temp_input_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
		PIN_FLIST_SUBSTR_SET(notify_flistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);

		/*Added for change offer and create subscriber/account. Its removed in op_tab_cust_purchase_offer function*/
		PIN_FLIST_SUBSTR_SET(*out_flistpp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);

		if(purchase_oflistp != NULL && purchase_offer_rdata_flistp != NULL)
		{
			PIN_FLIST_CONCAT(purchase_offer_rdata_flistp, purchase_oflistp, ebufp);
			if (PIN_FLIST_ELEM_GET(purchase_offer_rdata_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, 1, ebufp) != NULL)
			{
				PIN_FLIST_ELEM_DROP(purchase_offer_rdata_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, ebufp);
			}

			PIN_FLIST_SUBSTR_SET(notify_flistp, purchase_offer_rdata_flistp, PIN_FLD_OUT_FLIST, ebufp);

			PIN_FLIST_FLD_COPY(notify_flistp, PIN_FLD_OUT_FLIST, *out_flistpp, PIN_FLD_OUT_FLIST, ebufp);
		}

		notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_PURCHASE_OFFERS, -1, ebufp);
		PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
		PIN_FLIST_SUBSTR_SET(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);

		PIN_FLIST_FLD_COPY(notify_flistp, TAB_FLD_NOTIFICATION, *out_flistpp, TAB_FLD_NOTIFICATION, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_purchase_offer:"
			" fm_tab_cust_purchase_offer_notification input flist ", notify_flistp);

		//  - need to check why there are outside below notify flag if condition

		if(notify_flag == TAB_NOTIFY_ENABLE)
		{
			/* Call function to enrich notification details */
			fm_tab_cust_purchase_offer_notification(ctxp, notify_flistp, db_no, &notify_oflistp, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
					" fm_tab_cust_purchase_offer_notification input flist ", notify_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer: "
					" fm_tab_cust_purchase_offer_notification error", ebufp);
				goto cleanup;
			}

			if (notify_oflistp)
			{
				if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
					PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
				}
				else
				{
					PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
				}
			}
		}

		cleanup:
		/******************************************************************
		 * Clean up.
		 ******************************************************************/
		PIN_FLIST_DESTROY_EX(&plan_details_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&plan_details_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&create_pur_bundle_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&create_pur_bundle_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&deal_details_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&set_limit_cr_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&purchase_offer_rdata_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&temp_input_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&get_pur_bundle_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&get_pur_bundle_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&deal_details_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&purchase_deal_iflistp, NULL);
		//PIN_FLIST_DESTROY_EX(&hook_deal_in_flistp, NULL); commented due to EOF
		PIN_FLIST_DESTROY_EX(&purchase_deal_oflistp, NULL);

		if(default_quantity != NULL)
		{
			pin_decimal_destroy(default_quantity);
		}
		//PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_purchase_offer output flist", *out_flistpp);
	PIN_FLIST_DESTROY_EX(&date_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&date_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rd_rflistp, NULL);
	return;
}

/**
 * We use this function to enrich
 * output based on purchase deal response.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_enrich_purchase_deal_output(
	pcm_context_t		*ctxp,
	pin_flist_t		*enrich_flistp,
	pin_flist_t		*purchase_deal_oflistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	int32			enrich_products_elemid = 0;
	int32			deal_products_elemid = 0;
	int32			deal_discounts_elemid = 0;
	int32			enrich_discounts_elemid = 0;
	pin_cookie_t		enrich_products_cookie = NULL;
	pin_cookie_t		deal_products_cookie = NULL;
	pin_cookie_t		deal_discounts_cookie = NULL;
	pin_cookie_t		enrich_discounts_cookie = NULL;
	pin_flist_t		*enrich_products_flistp = NULL;
	pin_flist_t		*enrich_discounts_flistp = NULL;
	//pin_flist_t		*purchased_prod_read_iflistp = NULL;
	pin_flist_t		*purchased_prod_read_oflistp = NULL;
	//pin_flist_t		*purchased_disc_read_iflistp = NULL;
	pin_flist_t		*purchased_disc_read_oflistp = NULL;
	pin_flist_t		*deal_products_flistp = NULL;
	pin_flist_t		*deal_discounts_flistp = NULL;
	pin_flist_t		*prod_read_iflistp = NULL;
	pin_flist_t		*prod_read_oflistp = NULL;
	pin_flist_t		*disc_read_iflistp = NULL;
	pin_flist_t		*disc_read_oflistp = NULL;
	poid_t			*pur_product_pdp = NULL;
	poid_t			*pur_discount_pdp = NULL;
	poid_t			*enrich_product_pdp = NULL;
	poid_t			*deal_product_pdp = NULL;
	poid_t			*enrich_discount_pdp = NULL;
	poid_t			*deal_discount_pdp = NULL;
	//time_t		*purchase_start_t =	 NULL;
	//time_t		*purchase_end_t =  NULL;
	//char			*prod_pur_end_strp = NULL;
	//char			*disc_pur_start_strp = NULL;
	//char			*disc_pur_end_strp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_purchase_deal_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_enrich_purchase_deal_output:"
			" input flist", enrich_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_enrich_purchase_deal_output enrich flist", enrich_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_enrich_purchase_deal_output purchase deal output flist", purchase_deal_oflistpp);

	enrich_products_elemid = 0;
	enrich_products_cookie = NULL;
	while ((enrich_products_flistp = PIN_FLIST_ELEM_GET_NEXT(enrich_flistp, PIN_FLD_PRODUCTS, 
		&enrich_products_elemid, 1, &enrich_products_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		enrich_product_pdp = PIN_FLIST_FLD_GET(enrich_products_flistp, PIN_FLD_PRODUCT_OBJ, 1, ebufp);

		deal_products_elemid = 0;
		deal_products_cookie = NULL;
		while ((deal_products_flistp = PIN_FLIST_ELEM_GET_NEXT(purchase_deal_oflistpp, PIN_FLD_PRODUCTS, 
			&deal_products_elemid, 1, &deal_products_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			deal_product_pdp = PIN_FLIST_FLD_GET(deal_products_flistp, PIN_FLD_PRODUCT_OBJ, 1, ebufp);

			if(!PIN_POID_COMPARE(enrich_product_pdp, deal_product_pdp, 0, ebufp))
			{
				pur_product_pdp = PIN_FLIST_FLD_GET(deal_products_flistp, PIN_FLD_OFFERING_OBJ, 1, ebufp);

				if(!PIN_POID_IS_NULL(pur_product_pdp))
				{
					/*purchased_prod_read_iflistp = PIN_FLIST_CREATE(ebufp);
					  PIN_FLIST_FLD_SET(purchased_prod_read_iflistp, PIN_FLD_POID, pur_product_pdp, ebufp);
					  PIN_FLIST_FLD_SET(purchased_prod_read_iflistp, PIN_FLD_PURCHASE_START_T, NULL, ebufp);
					  PIN_FLIST_FLD_SET(purchased_prod_read_iflistp, PIN_FLD_PURCHASE_END_T, NULL, ebufp);

					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					  "fm_tab_cust_enrich_purchase_deal_output : Read purchased prod input flist", purchased_prod_read_iflistp);
					  PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, purchased_prod_read_iflistp, &purchased_prod_read_oflistp, ebufp);
					  PIN_FLIST_DESTROY_EX(&purchased_prod_read_iflistp, NULL);

					  if(PIN_ERR_IS_ERR(ebufp))
					  {
					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					  " input flist ", purchased_prod_read_iflistp);
					  PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					  " Error while reading purchased product", ebufp);
					  goto cleanup;
					  }
					  else
					  {
					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					  "fm_tab_cust_enrich_purchase_deal_output: Read purchased prod output flist", 
					  purchased_prod_read_oflistp);

					  if (purchased_prod_read_oflistp != NULL)
					  {
					  purchase_start_t = PIN_FLIST_FLD_GET(purchased_prod_read_oflistp, 
					  PIN_FLD_PURCHASE_START_T, 1, ebufp);
					  if(purchase_start_t != NULL)
					  {
					  prod_pur_start_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
					  purchase_start_t, ebufp);
					  PIN_FLIST_FLD_PUT(enrich_products_flistp, PIN_FLD_VALID_FROM_STR, 
					  prod_pur_start_strp, ebufp);
					  }

					  purchase_end_t = PIN_FLIST_FLD_GET(purchased_prod_read_oflistp, PIN_FLD_PURCHASE_END_T, 1, ebufp);
					  if(purchase_end_t != NULL && *purchase_end_t != 0)
					  {
					  prod_pur_end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
					  purchase_end_t, ebufp);
					  PIN_FLIST_FLD_PUT(enrich_products_flistp, PIN_FLD_VALID_TO_STR, 
					  prod_pur_end_strp, ebufp);
					  }
					  }
					  }*/

					/*Populate product name*/
					if(PIN_FLIST_FLD_GET(enrich_products_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
					{
						prod_read_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(enrich_products_flistp, PIN_FLD_PRODUCT_OBJ, 
								prod_read_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(prod_read_iflistp, PIN_FLD_NAME, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
							"Read prod flds input flist", prod_read_iflistp);
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, prod_read_iflistp, &prod_read_oflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" input flist ", prod_read_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" Error while reading product", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
								"Read prod flds output flist", prod_read_oflistp);

							if(prod_read_oflistp != NULL)
							{
								PIN_FLIST_FLD_COPY(prod_read_oflistp, PIN_FLD_NAME, 
										enrich_products_flistp, PIN_FLD_NAME, ebufp);
							}
						}
					}
				}
				else
				{
					/*Populate product name*/
					if(PIN_FLIST_FLD_GET(enrich_products_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
					{
						prod_read_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(enrich_products_flistp, PIN_FLD_PRODUCT_OBJ, 
								prod_read_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(prod_read_iflistp, PIN_FLD_NAME, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
							"Read prod flds input flist", prod_read_iflistp);
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, prod_read_iflistp, &prod_read_oflistp, ebufp);
						PIN_FLIST_DESTROY_EX(&prod_read_iflistp, NULL);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" input flist ", prod_read_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" Error while reading product", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
								"Read prod flds output flist", prod_read_oflistp);

							if(prod_read_oflistp != NULL)
							{
								PIN_FLIST_FLD_COPY(prod_read_oflistp, PIN_FLD_NAME, 
									enrich_products_flistp, PIN_FLD_NAME, ebufp);
							}
						}
					}
				}

				PIN_FLIST_DESTROY_EX(&purchased_prod_read_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&prod_read_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&prod_read_iflistp, NULL);
			}
		}

		if(PIN_FLIST_FLD_GET(enrich_products_flistp, PIN_FLD_PRODUCT_OBJ, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(enrich_products_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
		}
	}

	enrich_discounts_elemid = 0;
	enrich_discounts_cookie = NULL;
	while ((enrich_discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(enrich_flistp, PIN_FLD_DISCOUNTS, 
		&enrich_discounts_elemid, 1, &enrich_discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		enrich_discount_pdp = PIN_FLIST_FLD_GET(enrich_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);

		deal_discounts_elemid = 0;
		deal_discounts_cookie = NULL;
		while ((deal_discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(purchase_deal_oflistpp, PIN_FLD_DISCOUNTS, 
			&deal_discounts_elemid, 1, &deal_discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			deal_discount_pdp = PIN_FLIST_FLD_GET(deal_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);

			if(!PIN_POID_COMPARE(enrich_discount_pdp, deal_discount_pdp, 0, ebufp))
			{
				pur_discount_pdp = PIN_FLIST_FLD_GET(deal_discounts_flistp, PIN_FLD_OFFERING_OBJ, 1, ebufp);

				if(!PIN_POID_IS_NULL(pur_discount_pdp))
				{
					/*purchased_disc_read_iflistp = PIN_FLIST_CREATE(ebufp);
					  PIN_FLIST_FLD_SET(purchased_disc_read_iflistp, PIN_FLD_POID, pur_discount_pdp, ebufp);
					  PIN_FLIST_FLD_SET(purchased_disc_read_iflistp, PIN_FLD_PURCHASE_START_T, NULL, ebufp);
					  PIN_FLIST_FLD_SET(purchased_disc_read_iflistp, PIN_FLD_PURCHASE_END_T, NULL, ebufp);

					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					  "fm_tab_cust_enrich_purchase_deal_output : Read purchased disc input flist", 
					  purchased_disc_read_iflistp);
					  PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, purchased_disc_read_iflistp, &purchased_disc_read_oflistp, ebufp);
					  PIN_FLIST_DESTROY_EX(&purchased_disc_read_iflistp, NULL);

					  if(PIN_ERR_IS_ERR(ebufp))
					  {
					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					  " input flist ", purchased_disc_read_iflistp);
					  PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					  " Error while reading purchased discount", ebufp);
					  goto cleanup;
					  }
					  else
					  {
					  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					  "fm_tab_cust_enrich_purchase_deal_output: Read purchased disc output flist", 
					  purchased_disc_read_oflistp);

					  if (purchased_disc_read_oflistp != NULL)
					  {
					  purchase_start_t = PIN_FLIST_FLD_GET(purchased_disc_read_oflistp, 
					  PIN_FLD_PURCHASE_START_T, 1, ebufp);
					  if(purchase_start_t != NULL)
					  {
					  disc_pur_start_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
					  purchase_start_t, ebufp);
					  PIN_FLIST_FLD_PUT(enrich_discounts_flistp, PIN_FLD_VALID_FROM_STR, 
					  disc_pur_start_strp, ebufp);
					  }

					  purchase_end_t = PIN_FLIST_FLD_GET(purchased_disc_read_oflistp, 
					  PIN_FLD_PURCHASE_END_T, 1, ebufp);

					  if(purchase_end_t != NULL && *purchase_end_t != 0)
					  {
					  disc_pur_end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
					  purchase_end_t, ebufp);
					  PIN_FLIST_FLD_PUT(enrich_discounts_flistp, PIN_FLD_VALID_TO_STR, 
					  disc_pur_end_strp, ebufp);
					  }
					  }
					  }*/

					/*Populate product name*/
					if(PIN_FLIST_FLD_GET(enrich_discounts_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
					{
						disc_read_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(enrich_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 
								disc_read_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(disc_read_iflistp, PIN_FLD_NAME, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
							"Read discount flds input flist", disc_read_iflistp);
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, disc_read_iflistp, &disc_read_oflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" input flist ", disc_read_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" Error while reading discount", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_enrich_purchase_deal_output: "
								"Read discount flds output flist", disc_read_oflistp);

							if(disc_read_oflistp != NULL)
							{
								PIN_FLIST_FLD_COPY(disc_read_oflistp, PIN_FLD_NAME, 
									enrich_discounts_flistp, PIN_FLD_NAME, ebufp);
							}
						}
					}
				}

				PIN_FLIST_DESTROY_EX(&purchased_disc_read_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&disc_read_oflistp, NULL);
				PIN_FLIST_DESTROY_EX(&disc_read_iflistp, NULL);
			}
		}

		if(PIN_FLIST_FLD_GET(enrich_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(enrich_discounts_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&purchased_prod_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&purchased_disc_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&disc_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&prod_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&prod_read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&disc_read_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_enrich_purchase_deal_output enriched flist", enrich_flistp);

	return;
}

/**
 * We use this function to create purchase 
 * bundle using PCM_OP_SUBSCRIPTION_SET_BUNDLE 
 * opcode.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_create_purchase_bundle(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*purchase_bundle_iflistp = NULL;
	pin_flist_t		*purchase_bundle_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*bundle_info_flistp = NULL;
	int			bundle_status = PIN_BUNDLE_STATUS_ACTIVE;
	poid_t			*pur_bundle_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_purchase_bundle error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_purchase_bundle:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_create_purchase_bundle input", i_flistp);

	purchase_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, purchase_bundle_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, purchase_bundle_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	bundle_info_flistp = PIN_FLIST_ELEM_ADD(purchase_bundle_iflistp, PIN_FLD_BUNDLE_INFO, 1, ebufp);
	pur_bundle_pdp = PIN_POID_CREATE(db_no, "/purchased_bundle", -1, ebufp);
	PIN_FLIST_FLD_PUT(bundle_info_flistp, PIN_FLD_POID, (void *)pur_bundle_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PACKAGE_TYPE, bundle_info_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, bundle_info_flistp, PIN_FLD_NAME, ebufp);
	PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_STATUS, &bundle_status, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_START_T, bundle_info_flistp, PIN_FLD_VALID_FROM, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_END_T, bundle_info_flistp, PIN_FLD_VALID_TO, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(purchase_bundle_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_purchase_bundle: "
		"PCM_OP_SUBSCRIPTION_SET_BUNDLE input", purchase_bundle_iflistp);

	PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SET_BUNDLE, 0, purchase_bundle_iflistp, &purchase_bundle_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
			" input flist ", purchase_bundle_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
			" Error while creating /purchased_bundle object", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_purchase_bundle: "
		"PCM_OP_SUBSCRIPTION_SET_BUNDLE output", purchase_bundle_oflistp);

	cleanup:
	PIN_FLIST_DESTROY_EX(&purchase_bundle_iflistp, NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*r_flistpp = purchase_bundle_oflistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_create_purchase_bundle output flist", *r_flistpp);

	return;
}

/**
 * We use this function to generate
 * custom notification on purchase offer.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_cust_purchase_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_purchase_offer_notification: "
		"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_purchase_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_PURCHASE_OFFER input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_PURCHASE_OFFER, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_purchase_offer_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_purchase_offer_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_purchase_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_PURCHASE_OFFER output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_purchase_offer_notification output flist", *r_flistpp);
	return;
}

/**************************************************************************
 * Purchase offer response to give dates from purchased products 
 * (valid_from as least purchase_start_t and valid_to as max of 
 * purchased_end_t, unique_id and package id of old purchase) and same dates
 * need to be updated in the purchased bundle
 
 *************************************************************************/
static void
fm_tab_get_max_purchased_date(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	poid_t                  *pur_pdp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t             *search_flistp = NULL;
	pin_flist_t             *res_flistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t             *tmp_flistp = NULL;
	pin_flist_t             *result_flistp = NULL;
	pin_flist_t             *search_bundle_flistp = NULL;
	pin_flist_t             *search_bundle_rflistp = NULL;
	void                    *vp = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;
	time_t                  *purchase_end_t = NULL;
	time_t                  *max_purchase_end_t = NULL;
	time_t                  *purchase_start_t = NULL;
	time_t                  *min_purchase_start_t = NULL;
	int32                   elem_id = 0;
	pin_cookie_t    cookie = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_max_purchased_date error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_max_purchased_date:"
			"error input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_get_max_purchased_date input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_bundle_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(search_bundle_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_bundle_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 = V3 ";
	PIN_FLIST_FLD_SET(search_bundle_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_bundle_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(search_bundle_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_bundle_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, pur_pdp, ebufp);

	res_flistp = PIN_FLIST_ELEM_ADD(search_bundle_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_get_max_purchased_date input flist", search_bundle_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_bundle_flistp, &search_bundle_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_max_purchased_date error input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_max_purchased_date: "
			"Error in getting purchased bundle object", ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_get_max_purchased_date search_bundle_rflistp", search_bundle_rflistp);
			
	if ((search_bundle_rflistp != NULL) &&
		PIN_FLIST_ELEM_COUNT(search_bundle_rflistp, PIN_FLD_RESULTS, ebufp) > 0)
	{
		search_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
		
		vp =  (void *)"select X from /purchased_product 1, /purchased_bundle 2 where "
				"2.F1 = V1 and 1.F3 = 2.F2 and 2.F4 = V4 and 2.F5 = V5 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, 
				args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_PLAN_OBJ, NULL, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, pur_pdp, ebufp);

		res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PURCHASE_END_T, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PURCHASE_START_T, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_DESCR, NULL, ebufp);
		PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_PACKAGE_ID, (void *)0, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_max_purchased_date purchased bundle prod input flist", search_flistp);

		/***********************************************************
		 * Perform the search.
		 ***********************************************************/
		PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_get_max_purchased_date error input flist", search_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_get_max_purchased_date: "
				"Error in getting purchased bundle object", ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_max_purchased_date r_flistp flist", r_flistp);
	}

	/* Verify if there is more than one purchased bundle with same name, package_id and unique_id*/
	if ( r_flistp != NULL && PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_RESULTS, ebufp) > 0)
	{
		tmp_flistp = PIN_FLIST_CREATE(ebufp);
		while ((result_flistp = PIN_FLIST_ELEM_GET_NEXT(r_flistp, PIN_FLD_RESULTS,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
		{
			purchase_end_t = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_PURCHASE_END_T, 1, ebufp);  
			max_purchase_end_t = PIN_FLIST_FLD_GET(tmp_flistp, PIN_FLD_PURCHASE_END_T, 1, ebufp);

			purchase_start_t = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_PURCHASE_START_T, 1, ebufp);
			min_purchase_start_t = PIN_FLIST_FLD_GET(tmp_flistp, PIN_FLD_PURCHASE_START_T, 1, ebufp);

			/* CDTAC-14623 Added the below condition to return max purchase end 
			 * bundle with multiple products with different validity */
			if (max_purchase_end_t == NULL && *purchase_end_t != 0)
			{
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PURCHASE_END_T, 
					tmp_flistp, PIN_FLD_PURCHASE_END_T, ebufp); 
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_DESCR, 
					tmp_flistp, PIN_FLD_DESCR, ebufp);
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PACKAGE_ID, 
					tmp_flistp, PIN_FLD_PACKAGE_ID, ebufp);
			}
			else if(max_purchase_end_t == NULL && *purchase_end_t == 0)
			{
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PURCHASE_END_T,
					tmp_flistp, PIN_FLD_PURCHASE_END_T, ebufp);
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_DESCR,
					tmp_flistp, PIN_FLD_DESCR, ebufp);
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PACKAGE_ID,
					tmp_flistp, PIN_FLD_PACKAGE_ID, ebufp);
			}
			
			if (max_purchase_end_t != NULL  && ((*max_purchase_end_t !=0 && *max_purchase_end_t < *purchase_end_t && *purchase_end_t != 0) ||
				*purchase_end_t == 0) )
			{	
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PURCHASE_END_T, 
					tmp_flistp, PIN_FLD_PURCHASE_END_T, ebufp); 
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_DESCR, 
					tmp_flistp, PIN_FLD_DESCR, ebufp);
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PACKAGE_ID, 
					tmp_flistp, PIN_FLD_PACKAGE_ID, ebufp);
			}
			
			/*DBILLING-1432 min start_t of the purchsed product*/
			if (min_purchase_start_t == NULL && *purchase_start_t != 0)
			{
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PURCHASE_START_T,
					tmp_flistp, PIN_FLD_PURCHASE_START_T, ebufp);
			}			

			if (min_purchase_start_t != NULL && ( (*min_purchase_start_t > *purchase_start_t && *purchase_start_t != 0) ||
				*purchase_start_t == 0))
			{
				PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_PURCHASE_START_T,
					tmp_flistp, PIN_FLD_PURCHASE_START_T, ebufp);
			}
		}
	}
	PIN_POID_DESTROY(srchp,ebufp);
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_bundle_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_bundle_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	
	*r_flistpp = tmp_flistp;
	return;
}
/**
 * We use this function to call opcode
 * TAB_OP_UTILS_COMMON_POL_ERROR
 * @param ctxp The context pointer.
 * @param i_flistp in the input flist.
 * @param ebufp The error buffer.
 * @err_flistpp flistp.
 *
 */
static void
fm_tab_cust_purchase_offer_error_hook(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **err_flistpp,
        pin_errbuf_t            *ebufp)
{
        char            *errorField = NULL;
        char             log_msg[512]="";
        int32            errorCode = 0;
        int32            errorLoc = 0;

        pin_errbuf_t    local_ebuf = {0} ;
        pin_errbuf_t    *local_ebufp = &local_ebuf;
        pin_flist_t     *in_error_flistp=NULL;
        pin_flist_t     *out_error_flistp=NULL;
        pin_flist_t     *error_flistp=NULL;

        in_error_flistp = PIN_FLIST_COPY(i_flistp, local_ebufp);

        errorField = (char *)PIN_FIELD_GET_NAME(ebufp->field);
        errorCode = ebufp->pin_err;
        errorLoc = ebufp->location;
        sprintf(log_msg,"%d",errorCode);
        PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
        error_flistp=PIN_FLIST_ELEM_ADD(in_error_flistp,PIN_FLD_ERROR_INFO,0, local_ebufp);
        PIN_FLIST_FLD_SET(error_flistp, PIN_FLD_ERROR_CODE,log_msg, local_ebufp);
        PIN_FLIST_FLD_SET(error_flistp, TAB_FLD_ERROR_LOCATION, &errorLoc, local_ebufp);
        PIN_FLIST_FLD_SET(error_flistp, TAB_FLD_ERROR_FIELD_NAME, errorField, local_ebufp);

        /* call hook opcode to get the DB number*/
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_cust_purchase_offer_error_hook: POL_ERROR input flist", in_error_flistp);

        PCM_OP(ctxp,TAB_OP_UTILS_COMMON_POL_ERROR, 0, in_error_flistp, &out_error_flistp, local_ebufp);
		if (PIN_ERR_IS_ERR(local_ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_purchase_offer_error_hook:"
				" input flist ", in_error_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_purchase_offer_error_hook:"
				" Error in TAB_OP_UTILS_COMMON_POL_ERROR", local_ebufp);
			*err_flistpp = PIN_FLIST_COPY(out_error_flistp, local_ebufp);
			pin_errbuf_copy(ebufp,local_ebufp,ebufp);
			PIN_ERR_CLEAR_ERR(local_ebufp);
			goto cleanup;
		}
		else{
			PIN_FLIST_FLD_COPY(out_error_flistp, PIN_FLD_ERROR_CODE, *err_flistpp, PIN_FLD_ERROR_CODE, local_ebufp);
			PIN_FLIST_FLD_COPY(out_error_flistp, PIN_FLD_ERROR_DESCR, *err_flistpp, PIN_FLD_ERROR_DESCR, local_ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_purchase_offer_error_hook: POL_ERROR output flist", out_error_flistp);

cleanup:
        //PIN_ERR_CLEAR_ERR(local_ebufp);
        PIN_FLIST_DESTROY_EX(&in_error_flistp, NULL);
        //PIN_FLIST_DESTROY_EX(&out_error_flistp, NULL);
		
		*err_flistpp = out_error_flistp;
        return;
}

/******************************************************************
 * fm_purchase_offer_get_package_id()
 *
 * Generate a new id, if package_id not passed in input
 *
 *****************************************************************/
void
fm_purchase_offer_get_package_id(
	pcm_context_t	*ctxp,
	poid_t		*a_pdp,
	int32		*pkg_idp,
	pin_errbuf_t	*ebufp)
{
	char		separator[1024];
	char		sequence_id[1024];

	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERR_CLEAR_ERR(ebufp);

	/***********************************************************
	* Generate the Package id
	***********************************************************/
	memset(separator, '\0', sizeof(separator));
	memset(sequence_id, '\0', sizeof(sequence_id));

	fm_utils_get_tids(ctxp, PIN_POID_GET_DB(a_pdp), 1,
		PIN_SEQUENCE_TYPE_PACKAGE_ID, pkg_idp,
			&sequence_id[0], &separator[0], ebufp);

	return;
}
