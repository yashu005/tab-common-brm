/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah		| 			| New opcode implementation to
 *                                               			| manage msisdn and sim.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_MANAGE_MSISDN_SIM operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_manage_msisdn_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_manage_msisdn_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static int32
fm_tab_cust_manage_msisdn_sim_update(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_notify_manage_msisdn_sim_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t         *o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_poid_from_msisdn_sim(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_MANAGE_MSISDN_SIM is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, TAB_FLD_NEW_MSISDN, TAB_FLD_OLD_IMSI
 *                  TAB_FLD_NEW_IMSI and PIN_FLD_ACTION.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID               POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN             STR [0] "981999999"
 * 0 TAB_FLD_NEW_MSISDN          STR [0] "81999900"
 * 0 TAB_FLD_OLD_IMSI                STR [0] "666666"
 * 0 TAB_FLD_NEW_IMSI               STR [0] "777777"
 * 0 PIN_FLD_ACTION             STR [0] "msisdn"
 * 0 PIN_FLD_CORRELATION_ID     STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 *
 */

void
op_tab_cust_manage_msisdn_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_manage_msisdn_sim function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_MANAGE_MSISDN_SIM) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_manage_msisdn_sim bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_msisdn_sim input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	//To get db no
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	sprintf(log_msg,"%d", db_no);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_msisdn_sim: DB Number");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MANAGE_MSISDN_SIM;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MANAGE_MSISDN_SIM )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MANAGE_MSISDN_SIM, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
        if(PIN_POID_IS_NULL(account_pdp))
        {
                account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
        }

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_msisdn_sim:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_manage_msisdn_sim(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			" input flist", enrich_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_MANAGE_MSISDN_SIM", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MANAGE_MSISDN_SIM;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MANAGE_MSISDN_SIM )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MANAGE_MSISDN_SIM, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_msisdn_sim output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to update the service information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_manage_msisdn_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*msisdn = NULL;
	char			*action = NULL;
	char			*device_id = NULL;
	char			*new_imsi = NULL;
	pin_flist_t		*msisdn_sim_iflistp = NULL;
	pin_flist_t		*msisdn_sim_oflistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*update_rflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
	msisdn =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim: Error PIN_FLD_MSISDN-Input is missing", ebufp);
		goto cleanup;
	}

	action = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACTION, 1, ebufp);
	if ((action == NULL || strlen(action) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACTION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim: Error PIN_FLD_ACTION - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
		goto cleanup;
	}

	if(action && (strcmp(action, TAB_ACTION_MSISDN_NAME) == 0))
	{
		device_id = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_NEW_MSISDN, 1, ebufp);	
		if(device_id == NULL || strlen(device_id) == 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NEW_MSISDN_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim: Error TAB_FLD_NEW_MSISDN - Input is missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
			goto cleanup;
		}
		msisdn_sim_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, msisdn_sim_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_MSISDN, msisdn_sim_iflistp, PIN_FLD_MSISDN, ebufp);
		fm_tab_utils_common_get_poid_from_msisdn_sim(ctxp, msisdn_sim_iflistp, &msisdn_sim_oflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim: "
				"fm_tab_utils_common_get_poid_from_msisdn_sim error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
				" input flist", in_flistp);
			goto cleanup;
		}
		if (msisdn_sim_oflistp && (result_flistp = PIN_FLIST_ELEM_GET(msisdn_sim_oflistp,
			PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: "
				"result flist", result_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NEW_MSISDN_PRESENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim: Error TAB_FLD_NEW_MSISDN present in DB", ebufp);
			goto cleanup;
		}
	}
	if(action && (strcmp(action, TAB_ACTION_IMSI_NAME) == 0))
	{
		new_imsi = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_NEW_IMSI, 1, ebufp);
		if(new_imsi == NULL || strlen(new_imsi) == 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NEW_IMSI_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim: Error TAB_FLD_NEW_IMSI - Input is missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
			goto cleanup;
		}
		msisdn_sim_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, msisdn_sim_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_IMSI, msisdn_sim_iflistp, PIN_FLD_MSISDN, ebufp);
		fm_tab_utils_common_get_poid_from_msisdn_sim(ctxp, msisdn_sim_iflistp, &msisdn_sim_oflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim: "
				"fm_tab_utils_common_get_poid_from_msisdn_sim error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
				" input flist", in_flistp);
			goto cleanup;
		}
		if (msisdn_sim_oflistp && (result_flistp = PIN_FLIST_ELEM_GET(msisdn_sim_oflistp,
			PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: "
				"result flist", result_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NEW_IMSI_PRESENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim: Error TAB_FLD_NEW_IMSI- present in DB", ebufp);
			goto cleanup;
		}
	}
	if(action && !((strcmp(action, TAB_ACTION_IMSI_NAME) == 0) || (strcmp(action, TAB_ACTION_MSISDN_NAME) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVAL_ACTION_CODE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_manage_msisdn_sim: Error Invalid Action Code passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: input flist", in_flistp);
		goto cleanup;
	}
	if( !fm_tab_cust_manage_msisdn_sim_update(ctxp, in_flistp, &update_rflistp,db_no, ebufp) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim:"
		" fm_tab_cust_manage_msisdn_sim_update output flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim: "
		"fm_tab_cust_manage_msisdn_sim_update error", ebufp);
		goto cleanup;	
	}
	// Call function to enrich notification details
	fm_tab_notify_manage_msisdn_sim_prepare_notification(ctxp, in_flistp, update_rflistp, db_no, 
			&notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim:"
		" notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim: "
		" notification error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_msisdn_sim:"
			" notification output flist ", notify_oflistp);
			
	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&msisdn_sim_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&msisdn_sim_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_rflistp, NULL);
	return;
}

/**
 * We use this function to update the service info 
 * by calling opcode PCM_OP_CUST_UPDATE_SERVICE
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return boolean value true or false.
 */
static int32
fm_tab_cust_manage_msisdn_sim_update(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*acc_pdp = NULL;
	poid_t			*svc_pdp = NULL;

	char			*action = NULL;
	char			*device_id = NULL;
	char			*oldImsi = NULL;
	char			*newImsi = NULL;
	char			*namep = NULL;

	pin_flist_t		*update_in_flistp = NULL;
	pin_flist_t		*update_out_flistp = NULL;
	pin_flist_t		*alias_flistp = NULL;
	pin_flist_t		*serv_array_flistp = NULL;
	pin_flist_t		*service_alias_flistp = NULL;
	pin_flist_t		*service_in_flistp = NULL;
	pin_flist_t		*service_out_flistp = NULL;
	pin_flist_t		*temp_alias_flistp = NULL;
	pin_flist_t		*sub_flistp = NULL;

	pin_cookie_t		svc_cookie = NULL;
	int32			svc_elemid = 0;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			match_found = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_manage_msisdn_sim_update function entry error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		return status;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_msisdn_sim_update:"
		" input flist ", in_flistp);

	svc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 0, ebufp);
	acc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 0, ebufp);
	action = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACTION, 1, ebufp);
	device_id = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_NEW_MSISDN, 1, ebufp);
	oldImsi = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_OLD_IMSI, 1, ebufp);
	newImsi = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_NEW_IMSI, 1, ebufp);

	update_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(update_in_flistp, PIN_FLD_POID, (void *)acc_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, update_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	sub_flistp = PIN_FLIST_SUBSTR_ADD(update_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	serv_array_flistp = PIN_FLIST_ELEM_ADD(update_in_flistp, PIN_FLD_SERVICES, 1, ebufp);
	PIN_FLIST_FLD_SET(serv_array_flistp, PIN_FLD_POID, (void *)svc_pdp, ebufp);
	if(action && strcmp(action, TAB_ACTION_MSISDN_NAME) == 0 && device_id)
	{ 
		alias_flistp = PIN_FLIST_ELEM_ADD(serv_array_flistp, PIN_FLD_ALIAS_LIST, 0, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_MSISDN, alias_flistp, PIN_FLD_NAME, ebufp);
		match_found = 1;
	}
	if(action && strcmp(action, TAB_ACTION_IMSI_NAME) == 0 )
	{ 
		if((oldImsi == NULL || strlen(oldImsi) == 0) && newImsi)
		{
			alias_flistp = PIN_FLIST_ELEM_ADD(serv_array_flistp, PIN_FLD_ALIAS_LIST, 1, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_IMSI, alias_flistp, PIN_FLD_NAME, ebufp);
			match_found = 1;
		}
		if(oldImsi && newImsi)
		{
			/* Read the service object for POID validation */
			service_in_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(service_in_flistp, PIN_FLD_POID, svc_pdp, ebufp);
			service_alias_flistp = PIN_FLIST_ELEM_ADD(service_in_flistp, PIN_FLD_ALIAS_LIST, 
				PIN_ELEMID_ANY, ebufp);
			PIN_FLIST_FLD_SET(service_alias_flistp, PIN_FLD_NAME, NULL, ebufp);

			/* Sample Input Flist *
			 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /service 4190005 166
			 * 0 PIN_FLD_ALIAS_LIST    ARRAY [*] allocated 20, used 1
			 * */
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_manage_msisdn_sim_update: Service Read Input", service_in_flistp);

			PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, service_in_flistp, &service_out_flistp, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_DM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_SERVICE_NOT_FOUND, PIN_FLD_POID, 0, 0);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim_update: Service Read Input", service_in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_manage_msisdn_sim_update: Service Read error", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_manage_msisdn_sim_update:"
					" Service Read Output", service_out_flistp);
				svc_elemid = 0;
				svc_cookie = NULL;
				while ((temp_alias_flistp = PIN_FLIST_ELEM_GET_NEXT(service_out_flistp,
				PIN_FLD_ALIAS_LIST, &svc_elemid, 1, &svc_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
					"fm_tab_cust_manage_msisdn_sim_update: temp_alias_flistp flist", 
					temp_alias_flistp);
					namep = PIN_FLIST_FLD_GET(temp_alias_flistp, PIN_FLD_NAME, 1, ebufp);
					/* Check for IMSI */
					if (namep && strcmp(namep, oldImsi) == 0)
					{
						alias_flistp = PIN_FLIST_ELEM_ADD(serv_array_flistp, 
							PIN_FLD_ALIAS_LIST, svc_elemid, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_IMSI, alias_flistp, 
							PIN_FLD_NAME, ebufp);
						match_found = 1;
						break;
					}
					else
					{
						match_found = 2;
					}
				}
				
			}
		}
	}
	if( match_found == 2 )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim_update: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_OLD_IMSI, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim_update:"
			"oldimsi not found for the given account/msisdn number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	if( match_found == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_manage_msisdn_sim_update: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MANAGE_MSISDN_SIM, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim_update:"
			"Error while changing MSISDN/SIM for the given account/msisdn number", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;

	}

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 4190005 166
	 * 0 PIN_FLD_PROGRAM_NAME    STR [0] "corr_id|extern_user"
	 * 0 PIN_FLD_SERVICES      ARRAY [1] allocated 20, used 3
	 * 1     PIN_FLD_POID           POID [0] 0.0.0.1 /service/telco/gsm/telephony 4188597 1
	 * 1     PIN_FLD_ALIAS_LIST    ARRAY [0] allocated 20, used 1
	 * 2         PIN_FLD_NAME            STR [0] "23122020016"
	 * 1     PIN_FLD_ALIAS_LIST    ARRAY [1] allocated 20, used 1
	 * 2         PIN_FLD_NAME            STR [0] "2312202000016"
	 * 0 PIN_FLD_CONTEXT_INFO      SUBSTR [0] allocated 20, used 3
	 * 1     PIN_FLD_CORRELATION_ID         STR [0] "corr_id"
	 * 1     PIN_FLD_EXTERNAL_USER          STR [0] "extern_user"
	 * */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_msisdn_sim_update:"
		" CUST_UPDATE_SERVICES input flist ", update_in_flistp);

	PCM_OP(ctxp, PCM_OP_CUST_UPDATE_SERVICES, 0, update_in_flistp, &update_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim_update:"
			" input flist ", update_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_manage_msisdn_sim_update:"
			" Error in Update Service: ", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_manage_msisdn_sim_update:"
		" CUST_UPDATE_SERVICES output flist ", update_out_flistp);

	/*******************************************************************
	 *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&service_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_in_flistp, NULL);
	*ret_flistpp = update_out_flistp;
	return status;
}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_MANAGE_MSISDN_SIM for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_notify_manage_msisdn_sim_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t         *o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_manage_msisdn_sim_prepare_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_manage_msisdn_sim_prepare_notification: "
			"input flist", i_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	// Create Notification Flists
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MANAGE_MSISDN_SIM, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_NEW_MSISDN, notify_flistp, TAB_FLD_NEW_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_OLD_IMSI, notify_flistp, TAB_FLD_OLD_IMSI, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_NEW_IMSI, notify_flistp, TAB_FLD_NEW_IMSI, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_manage_msisdn_sim_prepare_notification:"
		" pol input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_MANAGE_MSISDN_SIM_NOTIFICATION, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_manage_msisdn_sim_prepare_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_manage_msisdn_sim_prepare_notification:"
			" Error in Notification", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_manage_msisdn_sim_prepare_notification:"
		" pol output flist ", enrich_notify_flistp);

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	*r_flistpp = enrich_notify_flistp;
	
	return;
}	
