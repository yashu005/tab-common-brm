/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 07-MAR-2022   | Shubha   			|               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_EXTRACT_CREDIT_LIMIT_HISTORY operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_cust.h"
#include "tab_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_extract_credit_limit_history(
    cm_nap_connection_t *connp,
    int                 opcode,
    int                 flags,
    pin_flist_t         *in_flistp,
    pin_flist_t         **out_flistpp,
    pin_errbuf_t        *ebufp);
    
void fm_tab_cust_extract_credit_limit_history(
    pcm_context_t       *ctxp,
    pin_flist_t         *in_flistp,
    pin_flist_t         **out_flistpp,
    int64		db_no,
    pin_errbuf_t        *ebufp);
    
	
void 
fm_tab_cust_extract_cl_hist_prepare_output(
	pcm_context_t 	    *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64		    db_no,
	pin_errbuf_t        *ebufp);
	
/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
    pcm_context_t       *ctxp,
    poid_t              *pdp,
    pin_errbuf_t        *ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
    pcm_context_t       *ctxp,
    pin_flist_t         *in_flistp,
    pin_flist_t         **out_flistp,
    int64		db_no,
    pin_errbuf_t        *ebufp);
    
extern void
fm_tab_utils_common_request_set_error(
    pcm_context_t       *ctxp,
    pin_flist_t         *i_flistp,
    int32               flag,
    int32               customErrorCode,
    pin_flist_t         **err_flistpp,
    int64		db_no,
    pin_errbuf_t        *ebufp);
    
extern int32
fm_tab_utils_common_get_tab_order_before(
    pcm_context_t       *ctxp,
    pin_flist_t         *i_flistp,
    int64		db_no,
    pin_errbuf_t        *ebufp);
    
extern void
fm_tab_utils_common_trans_manage_order(
    pcm_context_t       *ctxp,
    pin_flist_t         *i_flistp,
    int32               status,
    poid_t              *account_pdp,
    char                *opcode_name,
    pin_flist_t         **r_flistpp,
    int64		db_no,
    pin_errbuf_t        *ebufp);
    
	
extern void
fm_tab_utils_common_read_object(
	pcm_context_t       *ctxp,
	poid_t		    *poid_pdp,
	pin_flist_t         **ret_flistpp,
	pin_errbuf_t        *ebufp);
	
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

	
time_t fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_EXTRACT_CREDIT_LIMIT_HISTORY is implemented to 
 * retrieve historical credit limit information for the provided Account Number/MSISDN.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN & PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "CN-0999009"
 * 0 PIN_FLD_MSISN      STR [0] "91909990099"
 * 0 TAB_FLD_START_T_STR STR [0] “01-Jan-22 00:00:00”
 * 0 TAB_FLD_END_T_STR STR [0] “01-Feb-22 00:00:00”
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"

 *
 */ 
/**************************************************************************
 * Main routine for the TAB_OP_CUST_EXTRACT_CREDIT_LIMIT_HISTORY operation.
 *************************************************************************/
void
op_tab_cust_extract_credit_limit_history(
    cm_nap_connection_t     *connp,
    int                     opcode,
    int                     flags,
    pin_flist_t             *in_flistp,
    pin_flist_t             **ret_flistpp,
    pin_errbuf_t            *ebufp)
{
	pcm_context_t           *ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	int32                   status = PIN_BOOLEAN_TRUE;
	int32                   tab_order_flag = 0;
	int32                   error_clear_flag = 1;
	int32                   cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

    if(PIN_ERR_IS_ERR(ebufp))
    {
	    PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			    "op_tab_cust_extract_credit_limit_history function entry error", ebufp);
	    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_extract_credit_limit_history function entry error:"
			    " input flist ", in_flistp);
	    return;
    }
    
    *ret_flistpp = NULL;
    /*******************************************************************
     * Insanity check.
     *******************************************************************/
    if(opcode != TAB_OP_CUST_EXTRACT_CREDIT_LIMIT_HISTORY) {

	    pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			    PIN_ERR_BAD_OPCODE, 0, 0, opcode);
	    PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_extract_credit_limit_history bad opcode error",
			    ebufp);
	    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_extract_credit_limit_history bad opcode error:"
			    " input flist ", in_flistp);
	    return;
    }

    /*******************************************************************
     * Check for the input flist details
     *******************************************************************/
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_extract_credit_limit_history input flist", in_flistp);

    db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
    if(PIN_ERR_IS_ERR(ebufp))
    {
	    PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			    "Error getting database number");
	    pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			    TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
	    PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			    "fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
	    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no: Error while getting database no"
			    " input flist ", in_flistp);
	    fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
	    PIN_ERR_CLEAR_ERR(ebufp);
	    /*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	     * in the response with the errorCode coming from the return flist*/
	    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	    *ret_flistpp = r_flistp;
	    return;
    }
	
    PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);

	
    /*******************************************************************
     *                      call main function
    *******************************************************************/
		
    fm_tab_cust_extract_credit_limit_history(ctxp, in_flistp, &r_flistp, db_no, ebufp);

    if(PIN_ERR_IS_ERR(ebufp))
    {
	    PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_extract_credit_limit_history error", ebufp);
	    status = TAB_FAIL;
	    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_extract_credit_limit_history error"
			    " input flist ", in_flistp);
	    goto cleanup;
    }

    cleanup:
    if(PIN_ERR_IS_ERR(ebufp))
    {
	    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			    " input flist ", in_flistp);
	    PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_extract_credit_limit_history:"
			    " Error while creating /tab_order object", ebufp);

	    cerror_code = ebufp->pin_err;
	    if(cerror_code < 1000 )
	    {
		    cerror_code = TAB_ERR_CODE_API_EXTRACT_CREDIT_LIMIT;
		    sprintf(log_msg,"%d",cerror_code);
		    PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	    }
	    fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			    cerror_code, &r_flistp, db_no, ebufp);

	    PIN_ERR_CLEAR_ERR(ebufp);

	    sprintf(log_msg,"%d",cerror_code);
	    PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	    if(cerror_code == TAB_ERR_CODE_API_EXTRACT_CREDIT_LIMIT )
	    {
		    PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
		    PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_EXTRACT_CREDIT_LIMIT, ebufp);
	    }
    }
    else
    {
        status = TAB_SUCCESS;
        PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
    }
    /*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
     * in the response with the errorCode coming from the return flist*/
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
    *ret_flistpp = r_flistp;
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "output flist", *ret_flistpp);
    return;
}

void fm_tab_cust_extract_credit_limit_history(
    pcm_context_t       *ctxp,
    pin_flist_t         *in_flistp,
    pin_flist_t         **out_flistpp,
    int64		db_no,
    pin_errbuf_t        *ebufp)
{
	char                *msisdnp = NULL;
	char                *account_nop = NULL;
	char                *start_t_str = NULL;
	char		    *end_t_str = NULL;	
	int32		    error_code = 0;
	time_t	            start_date=0;
	time_t		    end_date=0;
	pin_flist_t         *enrich_iflistp = NULL;	
	pin_flist_t         *enrich_oflistp = NULL;
	pin_flist_t 	    *formated_out_flistp= NULL;
    
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_cust_extract_credit_limit_history input flist", in_flistp);

	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	start_t_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_START_T_STR,1,ebufp);
	end_t_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_END_T_STR,1,ebufp);
	
	/*******************************************************************
		* Checking for existence of Account number & MSISDN
	*******************************************************************/
	
	if((account_nop == NULL || strlen(account_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_credit_limit_history:"
				"Both MSISDN & Account Number not passed in input", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_cust_extract_credit_limit_history:"
				"Both MSISDN & Account Number not passed in input: input flist", in_flistp);
		return;
	}
	
	/*******************************************************************
		* Validating and normalizing input
	*******************************************************************/
	
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_credit_limit_history: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_cust_extract_credit_limit_history: "
				"fm_tab_utils_common_validate_and_normalize_input error: input flist", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_extract_credit_limit_history:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/*******************************************************************
		* Setting the start and end dates 
	*******************************************************************/
	
	if( start_t_str == NULL && end_t_str == NULL)
	{
		end_date=pin_virtual_time(NULL);
		start_date=end_date-30*ONEDAY;
	}
	else if(start_t_str != NULL && end_t_str == NULL)
	{
		start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,start_t_str,ebufp);
		end_date=start_date+30*ONEDAY;
	}
	else if(start_t_str == NULL && end_t_str != NULL)
	{
		end_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,end_t_str,ebufp);
		start_date=end_date-30*ONEDAY;
	}
	else
	{
		start_date =fm_tab_utils_common_convert_date_to_timestamp(ctxp,start_t_str,ebufp);
		end_date =fm_tab_utils_common_convert_date_to_timestamp(ctxp,end_t_str,ebufp);
	}

	/*******************************************************************
		* Setting the start and end dates in input flist to call hook opcode
	*******************************************************************/
	
	PIN_FLIST_FLD_SET(enrich_iflistp,PIN_FLD_START_T,&start_date,ebufp);
	PIN_FLIST_FLD_SET(enrich_iflistp,PIN_FLD_END_T,&end_date,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "TAB_OP_CUST_POL_EXTRACT_CL_HIST input flist", enrich_iflistp);
		
	/*******************************************************************
		* Calling hook Opcode
	*******************************************************************/
		
	PCM_OP( ctxp, TAB_OP_CUST_POL_EXTRACT_CL_HIST, 0, enrich_iflistp, &enrich_oflistp, ebufp );

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "TAB_OP_CUST_POL_EXTRACT_CL_HIST"
				"error CL not present", enrich_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "TAB_OP_CUST_POL_EXTRACT_CL_HIST"
				"error CL not present", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp= PIN_FLIST_COPY(enrich_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "TAB_OP_CUST_POL_EXTRACT_CL_HIST output flist", enrich_oflistp);
		
	/*******************************************************************
	* Set output as per Specs
	*******************************************************************/ 	
		
	fm_tab_cust_extract_cl_hist_prepare_output(ctxp,enrich_oflistp,&formated_out_flistp,db_no,ebufp);
	if(formated_out_flistp == NULL || PIN_ERR_IS_ERR( ebufp ))
	{						
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_cl_hist_prepare_output: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_cl_hist_prepare_output: "
				"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_EXTRACT_CREDIT_LIMIT, 0, 0, 0);	
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_extract_credit_limit_history: "
		"fm_tab_cust_extract_cl_hist_prepare_output Output Flist", formated_out_flistp);

	*out_flistpp = PIN_FLIST_COPY(formated_out_flistp, ebufp);
		
    	cleanup:
    /******************************************************************
     * Clean up.
    ******************************************************************/
 
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&formated_out_flistp, NULL);
    
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
        	"fm_tab_cust_extract_credit_limit_history output flist", *out_flistpp);
    	return;
}

void 
fm_tab_cust_extract_cl_hist_prepare_output(
	pcm_context_t 	    *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64		    db_no,
	pin_errbuf_t        *ebufp)
{	
	
	int		elem_list=0;
	pin_cookie_t 	cookie_list = NULL;
	pin_flist_t	*list_flistp=NULL;
	pin_flist_t	*return_list_flistp = NULL;
	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_extract_cl_hist_prepare_output input", in_flistp);	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_cl_hist_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_extract_cl_hist_prepare_output:"
			" input flist", in_flistp);
		return;
	}

	
	/*******************************************************************
	* Prepare return flist
	*******************************************************************/ 	
	pin_flist_t	*return_flistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);	
	

	
	/*******************************************************************
	* Verify and set Output
	*******************************************************************/ 	

	/*******************************************************************
	* List Traverse
	*******************************************************************/ 	
	
	while ((list_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_LIST_CL,
	&elem_list, 1, &cookie_list, ebufp)) != (pin_flist_t*)NULL)
	{
		return_list_flistp=PIN_FLIST_ELEM_ADD(return_flistp,TAB_FLD_LIST_CL,elem_list,ebufp);
		
		if ((PIN_FLIST_FLD_GET(list_flistp,PIN_FLD_RESOURCE_ID,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, PIN_FLD_RESOURCE_ID, return_list_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,PIN_FLD_CREDIT_LIMIT,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, PIN_FLD_CREDIT_LIMIT, return_list_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
		}		
		else 
		{						
			pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
			PIN_FLIST_FLD_SET(return_list_flistp, PIN_FLD_CREDIT_LIMIT, zero, ebufp);
			pbo_decimal_destroy(&zero);
		}

		if ((PIN_FLIST_FLD_GET(list_flistp,TAB_FLD_CL_TYPE,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, TAB_FLD_CL_TYPE, return_list_flistp, TAB_FLD_CL_TYPE, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,TAB_FLD_OLD_CREDIT_LIMIT,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, TAB_FLD_OLD_CREDIT_LIMIT, return_list_flistp, TAB_FLD_OLD_CREDIT_LIMIT, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,PIN_FLD_CHANNEL,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, PIN_FLD_CHANNEL, return_list_flistp, PIN_FLD_CHANNEL, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,PIN_FLD_USER_NAME,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, PIN_FLD_USER_NAME, return_list_flistp, PIN_FLD_USER_NAME, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,PIN_FLD_DESCR,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, PIN_FLD_DESCR, return_list_flistp, PIN_FLD_DESCR, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,TAB_FLD_EFFECTIVE_T_STR,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, TAB_FLD_EFFECTIVE_T_STR, return_list_flistp, TAB_FLD_EFFECTIVE_T_STR, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(list_flistp,TAB_FLD_END_T_STR,1,ebufp))!=NULL)
		{		
			PIN_FLIST_FLD_COPY(list_flistp, TAB_FLD_END_T_STR, return_list_flistp, TAB_FLD_END_T_STR, ebufp);
		}
	}
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_balances_prepare_output input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_balances_prepare_output: Error in date range selection", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_prepare_output output flist", return_flistp);			
	}

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	
	*out_flistpp= return_flistp;	
	
	return;	
}
