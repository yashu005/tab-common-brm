/*******************************************************************************
 * 
 * This material is the confidential property of Oracle Corporation or its
 * licensors and may be used, reproduced, stored or transmitted only in
 * accordance with a valid agreement.
 *     
 *******************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date        | Programmer        | Req/bug/Gap           | Change details
 *
 * 1  | 10/Jan/2022 | Ruhi Bhatnagar    |                       | New opcode implementation
 *                                                              | to get writeoff status.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_WRITEOFF_STATUS operation.
 *******************************************************************/
#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "pin_subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_cust_get_writeoff_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_get_writeoff_status(
	pcm_context_t		*ctxp,
	int32           	flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	int32		flag,
	int32		customErrorCode,
	pin_flist_t	**err_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/******************************************************************************
 *
 * New opcode TAB_OP_CUST_GET_WRITEOFF_STATUS is implemented to 
 * status of service.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist.
 * @param ret_flistpp The output flist.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 *******************************************************************************/
/**************************************************************************
 * Main routine for the TAB_OP_CUST_GET_WRITEOFF_STATUS operation.
 *************************************************************************/
void
op_tab_cust_get_writeoff_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_get_writeoff_status function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_WRITEOFF_STATUS) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_writeoff_status bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_writeoff_status input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_writeoff_status: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_writeoff_status:"
			"fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_cust_get_writeoff_status(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_writeoff_status", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_writeoff_status: input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_writeoff_status:"
			"Error while getting writeoff status", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_WRITEOFF_STATUS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_WRITEOFF_STATUS)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_WRITEOFF_STATUS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_writeoff_status: output flist", *ret_flistpp);
	return;
}

/***************************************************
 * We use this function 
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 **************************************************/

void fm_tab_cust_get_writeoff_status(
	pcm_context_t           *ctxp,
	int32                   flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **ret_flistpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t		*hook_rflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	char                    *account_no = NULL;
	char			*tran_id = NULL;
	int32                   error_code = 0;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_writeoff_status: function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_writeoff_status: input flist", in_flistp);

	/* Validate the input arguments */
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if(account_no == NULL || strlen(account_no) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_writeoff_status: Error PIN_FLD_ACCOUNT_NO is missing", ebufp);
		goto cleanup;
	}

	tran_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	if(tran_id == NULL || strlen(tran_id) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_writeoff_status: Error PIN_FLD_TRANS_ID is missing", ebufp);
		goto cleanup;
	}

	PCM_OP(ctxp, TAB_OP_CUST_POL_GET_WRITEOFF_STATUS, 0, in_flistp, &hook_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_writeoff_status: "
			"TAB_OP_CUST_POL_GET_WRITEOFF_STATUS input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_writeoff_status: "
			"TAB_OP_CUST_POL_GET_WRITEOFF_STATUS error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(hook_rflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_writeoff_status: "
			"TAB_OP_CUST_POL_GET_WRITEOFF_STATUS output flist", hook_rflistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

        if(hook_rflistp != NULL)
        {
                if(PIN_FLIST_FLD_GET(hook_rflistp, PIN_FLD_POID, 1, ebufp) != NULL)
                {
                        PIN_FLIST_FLD_DROP(hook_rflistp, PIN_FLD_POID, ebufp);
                }

                PIN_FLIST_CONCAT(r_flistp, hook_rflistp, ebufp);
        }

        *ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
cleanup:
	/******************************************************************
	  Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
        PIN_FLIST_DESTROY_EX(&hook_rflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_writeoff_status: return flist", *ret_flistpp);
	return;
}
