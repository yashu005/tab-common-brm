/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  | 08/Nov/2021 | Madhavi Dandi     |       	        | New opcode implementation
 *                                                      	| to get FNF Members
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_FNF operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_get_fnf(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_fnf(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_profile_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	char			*profile_type,
	char			*profile_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_CUST_GET_FNF is implemented to get the
 * FNF members associated with given Account_No
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN,PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "0.0.0.1-14435750"
 * 0 PIN_FLD_MSISDN          STR [0] "9818888000"
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 * */

void
op_tab_cust_get_fnf(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

					
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_fnf function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_FNF) {

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_fnf input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		goto cleanup;
	}

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_fnf:"
		"fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_cust_get_fnf(ctxp, flags, enrich_iflistp, &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_fnf error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
			" Error while getting fnf", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_FNF;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_FNF, ebufp);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,cerror_code, &r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_FNF )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_FNF, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_fnf output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to get cug information.
 * If account have FNF members containng then the
 * Profiles array return in output flist
 * *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 * *
 *  */

static void
fm_tab_cust_get_fnf(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_fnf_rflistp = NULL;
	pin_flist_t		*get_enrich_rflistp = NULL;
	
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*custom_res_flistp =NULL;
	pin_flist_t		*data_grp_flistp =NULL;
	pin_flist_t		*data_profile_flistp =NULL;
	pin_flist_t		*grp_flistp =NULL;
	pin_flist_t		*profile_flistp=NULL;
	pin_cookie_t		cookie = NULL;
	pin_cookie_t		data_cookie = NULL;
	pin_flist_t		*dataarray_flistp = NULL;
	int32			elem_id = 0;
	int32			data_elem_id = 0;
	char			*msisdn =NULL;
	time_t			*valid_from = NULL;
	time_t			*valid_to = NULL;
	char			*output_start_datep = NULL;
	char			*output_end_datep = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_fnf input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_fnf function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_fnf: input flist", in_flistp);
	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_fnf input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_fnf: Error PIN_FLD_MSISDN-Input is missing", ebufp);
		goto cleanup;
	}


	/***Calling fm_tab_utils_common_get_profile_details which contians PCM_OP_SEARCH**
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 256
	  0 PIN_FLD_TEMPLATE        STR [0] " select X from /profile where F1.type = V1 and F2 = V2 and (F3 like V3 or F4 like V4 or F5 like V5)"
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_POID      POID [0] 0.0.0.1 /profile/serv_extrating -1 0
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1 PIN_FLD_SERVICE_OBJ    POID [0] 0.0.0.1 /service/telco/gsm/telephony 14546571 1
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1 PIN_FLD_NAME            STR [0] "%FNF%"
	  0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	  1 PIN_FLD_NAME            STR [0] "%FnF%"
	  0 PIN_FLD_ARGS          ARRAY [5] allocated 20, used 1
	  1 PIN_FLD_NAME            STR [0] "%fnf%"
	  0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1 PIN_FLD_NAME            STR [0] NULL
	  1 PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
	  2     PIN_FLD_NAME            STR [0] NULL
	  2     PIN_FLD_VALID_FROM   TSTAMP [0] (0) <null>
	  2     PIN_FLD_VALID_TO     TSTAMP [0] (0) <null>
	  2     PIN_FLD_VALUE           STR [0] NULL*/

	fm_tab_utils_common_get_profile_details(ctxp, in_flistp, TAB_PROFILE_SERV_EXTRATING, "FNF", 
			&get_fnf_rflistp,db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
			" fm_tab_utils_common_get_profile_details input flist ", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_FNF, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:fm_tab_utils_common_get_profile_details" 
			"error", ebufp);
		goto cleanup;
	}
	/* TAB_FLD_COUNTER will be returned PIN_FLD_RESULTS array*/
	PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_GET_FNF, 0, get_fnf_rflistp, &get_enrich_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_FNF, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
			" enrich input flist ", get_fnf_rflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
			" Error in getting enrich information", ebufp);
		goto cleanup;
	}
	
	if (get_enrich_rflistp && (res_flistp = PIN_FLIST_ELEM_GET(get_enrich_rflistp, PIN_FLD_RESULTS,
		PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		if (res_flistp && (dataarray_flistp = PIN_FLIST_ELEM_GET(res_flistp, PIN_FLD_DATA_ARRAY,
		PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{

			custom_res_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, custom_res_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, custom_res_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, custom_res_flistp, PIN_FLD_MSISDN, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, custom_res_flistp, PIN_FLD_CORRELATION_ID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, custom_res_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
			elem_id = 0;
			cookie = NULL;

			while((grp_flistp = PIN_FLIST_ELEM_GET_NEXT(get_enrich_rflistp, PIN_FLD_RESULTS,
				&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				profile_flistp = PIN_FLIST_ELEM_ADD(custom_res_flistp, PIN_FLD_PROFILES, elem_id, ebufp);
				PIN_FLIST_FLD_COPY (grp_flistp,PIN_FLD_NAME,profile_flistp, PIN_FLD_GROUP_NAME, ebufp);
				PIN_FLIST_FLD_COPY (grp_flistp,TAB_FLD_COUNTER,profile_flistp, TAB_FLD_COUNTER, ebufp);

				data_elem_id = 0;
				data_cookie = NULL;
				while((data_grp_flistp = PIN_FLIST_ELEM_GET_NEXT(grp_flistp, PIN_FLD_DATA_ARRAY,
					&data_elem_id, 1, &data_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					data_profile_flistp = PIN_FLIST_ELEM_ADD(profile_flistp, PIN_FLD_DATA_ARRAY,
							data_elem_id, ebufp);
					PIN_FLIST_FLD_COPY(data_grp_flistp, PIN_FLD_NAME,
							data_profile_flistp, PIN_FLD_NAME, ebufp);
					PIN_FLIST_FLD_COPY(data_grp_flistp, PIN_FLD_VALUE,
							data_profile_flistp, PIN_FLD_VALUE, ebufp);

					valid_from = PIN_FLIST_FLD_GET(data_grp_flistp, PIN_FLD_VALID_FROM, 1, ebufp);
					if(valid_from != NULL)
					{
						output_start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,
								valid_from, ebufp);
						PIN_FLIST_FLD_PUT(data_profile_flistp, PIN_FLD_VALID_FROM_STR,
								output_start_datep, ebufp);
					}

					valid_to = PIN_FLIST_FLD_GET(data_grp_flistp, PIN_FLD_VALID_TO, 1, ebufp);
					if(valid_to != NULL)
					{
						output_end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,
								valid_to, ebufp);
						PIN_FLIST_FLD_PUT(data_profile_flistp, PIN_FLD_VALID_TO_STR,
								output_end_datep, ebufp);
					}
				}
			}

			*ret_flistpp = PIN_FLIST_COPY(custom_res_flistp, ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_fnf: input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_FNF_DATA_ARRAY_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
					"No DataArray found for the given account number", ebufp);
			goto cleanup;
		}		
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_fnf: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_FNF, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_fnf:"
				"No FNF found for the given account number", ebufp);
		goto cleanup;

	}

cleanup:
	/******************************************************************
	 * Clean up.
	 * ******************************************************************/
	PIN_FLIST_DESTROY_EX (&get_fnf_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&get_enrich_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&custom_res_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_fnf output flist", *ret_flistpp);

	return;
}

