/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date        | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  | 03/Jan/2022 | Ruhi Bhatnagar    |       	        | New opcode implementation
 *                                                      	| to get multi sim.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_MULTI_SIM operation.
 *******************************************************************/
#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_get_multi_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_multi_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/* Extern functions */

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32                   cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_GET_MULTI_SIM is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN          STR [0] "9818888000"
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 * */

void
op_tab_cust_get_multi_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_get_multi_sim function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_MULTI_SIM) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_multi_sim bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_multi_sim input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp,in_flistp,error_clear_flag,cerror_code,&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_multi_sim: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_multi_sim:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_cust_get_multi_sim(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_multi_sim error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_multi_sim: input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_multi_sim: Error while getting multi sim", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_MULTISIM;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_MULTISIM, ebufp);
		}
		fm_tab_utils_common_request_set_error(ctxp,in_flistp,error_clear_flag,cerror_code,&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_MULTISIM)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_MULTISIM, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_multi_sim output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get multi sim.
 * *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 **/

static void
fm_tab_cust_get_multi_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*hook_rflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	char                    *msisdn = NULL;
	int32			error_code = 0;

	PIN_ERR_CLEAR_ERR(ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_multi_sim function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_multi_sim: input flist", in_flistp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_multi_sim: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_multi_sim: Error PIN_FLD_MSISDN-Input is missing", ebufp);
		goto cleanup;
	}

	PCM_OP(ctxp, TAB_OP_CUST_POL_GET_MULTI_SIM, 0, in_flistp, &hook_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_multi_sim: "
			"TAB_OP_CUST_POL_GET_MULTI_SIM input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_multi_sim: "
			" TAB_OP_CUST_POL_GET_MULTI_SIM error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(hook_rflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_multi_sim: "
		"TAB_OP_CUST_POL_GET_MULTI_SIM output flist", hook_rflistp);


	r_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if(hook_rflistp != NULL)
	{
		if(PIN_FLIST_FLD_GET(hook_rflistp, PIN_FLD_POID, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(hook_rflistp, PIN_FLD_POID, ebufp);
		}

		PIN_FLIST_CONCAT(r_flistp, hook_rflistp, ebufp);
	}

	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 * ******************************************************************/
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_multi_sim output flist", *ret_flistpp);

	return;
}
