/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah 		| 			| New opcode implementation to
 *                                               			| create subscriber.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_CREATE_ACCOUNT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "pin_bill.h"
#include "pin_inv.h"

EXPORT_OP void
op_tab_cust_create_account(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**ret_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void 
fm_tab_cust_create_account_prep_nameinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void 
fm_tab_cust_create_account_prep_payinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void 
fm_tab_cust_create_account_prep_acctinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void 
fm_tab_cust_create_account_prep_billinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account_prep_bal_info(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **customerpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp);

static void 
fm_tab_cust_create_account_prep_profile(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void 
fm_tab_cust_create_account_prep_subscription(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account_create_dsg(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_create_account_create_csg(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
static void
fm_tab_cust_create_account_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_account_details(
	pcm_context_t		*ctxp,
	char			*account_no,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_billinfo_by_acctno (
	pcm_context_t		*ctxp,
	char			*acc_no,
	int32			active_flag,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_cust_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int				notify_flag,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_subscription_create_sharing_group(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int
fm_tab_utils_common_get_credit_thresholds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_CREATE_ACCOUNT is implemented to 
 * create subscriber
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *
 */
void
op_tab_cust_create_account(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*hook_iflistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_create_account function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	* Insanity check.
	*******************************************************************/
	if(opcode != TAB_OP_CUST_CREATE_ACCOUNT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_create_account bad opcode error",
			ebufp);
		return;
	}

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	sprintf(log_msg,"%d", db_no);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_create_account: DB Number");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_create_account input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_ACCOUNT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_ACCOUNT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_CREATE_ACCOUNT, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);

	/* call hook opcode to get the DB number*/
	PCM_OP(ctxp, TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO, 0, in_flistp, &hook_iflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_GET_DB_NO output flist", hook_iflistp);
		*ret_flistpp = hook_iflistp;
		status = TAB_FAIL;
		goto cleanup;
	}

	account_pdp = PIN_FLIST_FLD_GET(hook_iflistp, PIN_FLD_POID, 1, ebufp);
	db_no = PIN_POID_GET_DB(account_pdp);

	sprintf(log_msg,"%d", db_no);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_create_subscriber: DB Number after hook opcode");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* call main function */
		fm_tab_cust_create_account(ctxp, flags, hook_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_create_account error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_CREATE_ACCOUNT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_ACCOUNT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_ACCOUNT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_CREATE_ACCOUNT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_create_account output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&hook_iflistp, NULL);
	return;
}

/**
 * We use this function to create subscriber.
 * call the PCM_OP_CUST_COMMIT_CUSTOMER opcode. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ret_flistpp in the output flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return flistp.
 */
static void
fm_tab_cust_create_account(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	int			global_trans_flag = PIN_TXN_FLAG_USE_GLOBAL;
	int			c_flags = 0;
	int			dsg_count = 0;
	int			csg_count = 0;
	int			pkg_count = 0;
	char			db_no_str[10];
	
	pin_flist_t		*commit_iflistp = NULL;
	pin_flist_t		*svc_flistp = NULL;
	pin_flist_t		*enrich_commit_iflistp = NULL;
	pin_flist_t		*commit_oflistp = NULL;
	pin_flist_t		*purchase_oflistp = NULL;
	pin_flist_t		*dsg_oflistp = NULL;
	pin_flist_t		*csg_oflistp = NULL;
	pin_flist_t		*sub_flistp = NULL;
	pin_flist_t		*hook_iflistp = NULL;
	pin_flist_t		*hook_oflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: input flist", in_flistp);

	/********************************************************************************
	 * Create input flist for PCM_OP_CUST_COMMIT_CUSTOMER
	 ********************************************************************************/
	commit_iflistp = PIN_FLIST_CREATE(ebufp);

	/* Validate the input arguments */
	fm_tab_cust_create_account_validate_input(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while looking up customer segment");
		goto cleanup;
	}

	/********************************************************************************
	* Call VALIDATE HOOK opcode to validate input flist specific to BU's
	********************************************************************************/
	hook_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

	/*Add source database*/
	memset(db_no_str, '\0', sizeof(db_no_str));
	snprintf(db_no_str, sizeof(db_no_str), "%d", db_no);

	if(db_no_str != NULL)
	{
		PIN_FLIST_FLD_SET(hook_iflistp, PIN_FLD_SRC_DATABASE, db_no_str, ebufp);
	}

	PCM_OP(ctxp, TAB_OP_CUST_POL_CREATE_ACCT_VALIDATE_INPUT, 0, hook_iflistp, &hook_oflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_INPUT_VALIDATE input flist", hook_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_INPUT_VALIDATE error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: "
			"TAB_OP_CUST_POL_CREATE_ACCT_INPUT_VALIDATE output flist", hook_oflistp);
		PIN_FLIST_DESTROY_EX(ret_flistpp, NULL);
		*ret_flistpp = hook_oflistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: "
		"TAB_OP_CUST_POL_CREATE_ACCT_INPUT_VALIDATE output flist", hook_oflistp);

	PIN_FLIST_DESTROY_EX(&hook_oflistp, NULL);

	/******************************************************************************
	 * Prepare Subscription information for the BRM Standard API.
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_subscription(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_subscription");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_subscription input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_subscription error", ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare the Account information for the BRM Standard API.
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_acctinfo(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_acctinfo");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_acctinfo input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_acctinfo error", ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare the Address/Contact information for the BRM Standard API.
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_nameinfo(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_nameinfo");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_nameinfo input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_nameinfo error", ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare the Billing profile information for the BRM Standard API
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_billinfo(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_billinfo");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_billinfo input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_billinfo error", ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare the Balance information for the BRM Standard API
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_bal_info(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_bal_info");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_bal_info input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_bal_info error", ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare the Account Profile information for the BRM Standard API
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_profile(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_profile");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_profile input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_profile error", ebufp);
		goto cleanup;
	}
	/******************************************************************************
	 * Prepare the Payment profile information for the BRM Standard API
	 *******************************************************************************/
	fm_tab_cust_create_account_prep_payinfo(ctxp, in_flistp, &commit_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while preparing prep_payinfo");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_payinfo input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			"fm_tab_cust_create_account_prep_payinfo error", ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_SET(commit_iflistp, PIN_FLD_TXN_FLAGS, &global_trans_flag, ebufp);
	PIN_FLIST_FLD_SET(commit_iflistp, PIN_FLD_FLAGS, &c_flags, ebufp);

	sub_flistp = PIN_FLIST_SUBSTR_ADD(commit_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_create_account:"
		" ENRICH_CREATE_ACCOUNT input flist ", commit_iflistp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_CREATE_ACCOUNT, 0, commit_iflistp, 
		&enrich_commit_iflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Hook opcode prepare Input flist", commit_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Hook opcode prepare input flist error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Hook opcode prepare output flist", enrich_commit_iflistp);
		PIN_FLIST_DESTROY_EX(ret_flistpp, NULL);
		*ret_flistpp = enrich_commit_iflistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: "
	"ENRICH_CREATE_ACCOUNT output flist", enrich_commit_iflistp);

	PCM_OP(ctxp, PCM_OP_CUST_COMMIT_CUSTOMER, 0, enrich_commit_iflistp, &commit_oflistp, ebufp);
	
	PIN_FLIST_DESTROY_EX(&enrich_commit_iflistp, NULL);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			" input flist ", enrich_commit_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			" Error in commit customer: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_create_account:"
		" COMMIT_CUSTOMER output flist ", commit_oflistp);

	/*******************************************************************************
	* call fm_tab_cust_create_account_purchase_offer function for bundle purchase
	********************************************************************************/
	svc_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, PIN_ELEMID_ANY, 1, ebufp);
	if (svc_flistp != NULL)
	{
		pkg_count =  PIN_FLIST_ELEM_COUNT(svc_flistp, PIN_FLD_PACKAGE_INFO, ebufp);
	}

	if(pkg_count > 0)
	{
		fm_tab_cust_create_account_purchase_offer(ctxp, in_flistp, commit_oflistp, 
			&purchase_oflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp)) {
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while calling subscriber_purchase_offer");
			goto cleanup;
		}
	}
	
	/******************************************************************************
	* call fm_tab_cust_create_account_create_dsg function for DSG
	******************************************************************************/
	dsg_count =  PIN_FLIST_ELEM_COUNT(in_flistp, PIN_FLD_DISCOUNT_LIST, ebufp);
	if(dsg_count > 0)
	{
		fm_tab_cust_create_account_create_dsg(ctxp, in_flistp, commit_oflistp, 
			&dsg_oflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp)) {
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while calling subscriber_create_dsg");
			goto cleanup;
		}
	}

	/******************************************************************************
	* call fm_tab_cust_create_account_create_csg function for CSG
	******************************************************************************/
	csg_count =  PIN_FLIST_ELEM_COUNT(in_flistp, PIN_FLD_CHARGES, ebufp);
	if(csg_count > 0)
	{
		fm_tab_cust_create_account_create_csg(ctxp, in_flistp, commit_oflistp, 
			&csg_oflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp)) {
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "Error while calling subscriber_create_csg");
			goto cleanup;
		}
	}
	
	// Call function to enrich notification details
	fm_tab_cust_create_account_notification(ctxp, in_flistp, commit_oflistp,
			db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			" fm_tab_cust_create_account_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account: "
			" fm_tab_cust_create_account_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	
cleanup:
	PIN_FLIST_DESTROY_EX(&purchase_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&dsg_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&csg_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&commit_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&commit_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	return;
}

/**
 * We use this function to validate
 * the input flist for create subscriber
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
void 
fm_tab_cust_create_account_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**ret_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*acct_no = NULL;
	pin_flist_t		*acct_results_flistp = NULL;
	pin_flist_t		*acct_flistp = NULL;
	//pin_flist_t		*profiles_iflistp = NULL;
	pin_flist_t		*billinfo_iflistp = NULL;
	//pin_flist_t		*services_iflistp = NULL;
	pin_flist_t		*payinfo_iflistp = NULL;
	int			*pay_type = NULL;
	int			*bdom = NULL;
	int			*billwhenp = NULL;
	int			*actg_typep = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account: "
		"fm_tab_cust_create_account_validate_input input flist", i_flistp);

	acct_no = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if ((acct_no == NULL || strlen(acct_no) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error PIN_FLD_ACCOUNT_NO - Input is missing", ebufp);
		goto cleanup;
	}
	/***********************************************************
	 * Validate existence of Account number in the database
	 *      If account exist already
	 ***********************************************************/
	fm_tab_utils_common_get_account_details(ctxp, acct_no, &acct_results_flistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
			" input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account: "
			"fm_tab_utils_common_get_account_details error while searching", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"Account lookup results flist", acct_results_flistp);

	acct_flistp = PIN_FLIST_ELEM_GET(acct_results_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if (acct_flistp) 
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error Account number present in DB");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DUP_ACCT_NO, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error Account number present in DB",ebufp);
		goto cleanup;
	}

	/********************************************************
	 * Get PROFILES array from input flist
	 *********************************************************/
	//profiles_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_PROFILES, PIN_ELEMID_ANY, 1, ebufp);
	// CTP-17219
	/*if (profiles_iflistp == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error PROFILES array missing from input flist");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PROFILES_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error PROFILES array missing from input flist",ebufp);
		goto cleanup;
	}*/

	/********************************************************
	 * Get billinfo array from input flist
	 *********************************************************/
	billinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp);
	if (billinfo_iflistp == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error BILLINFO array missing from input flist");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error BILLINFO array missing from input flist",ebufp);
		goto cleanup;
	}

	bdom = PIN_FLIST_FLD_GET (billinfo_iflistp, PIN_FLD_ACTG_CYCLE_DOM, 1, ebufp);
	if(bdom && (*bdom <= 0 || *bdom > 31))
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_BDOM, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Error invalid bdom passed in Billinfo array from input flist",ebufp);
		goto cleanup;
	}

	pay_type = (int *) PIN_FLIST_FLD_GET (billinfo_iflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (pay_type == NULL) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PAYTYPE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Error pay_type in Billinfo array is missing from input flist",ebufp);
		goto cleanup;
	}

	billwhenp = PIN_FLIST_FLD_GET(billinfo_iflistp, PIN_FLD_BILL_WHEN, 1, ebufp);
	if(billwhenp && !(*billwhenp == TAB_BILL_TYPE_MONTHLY || *billwhenp == TAB_BILL_TYPE_QUARTERLY
		|| *billwhenp == TAB_BILL_TYPE_SEMIANNUAL|| *billwhenp == TAB_BILL_TYPE_ANNUAL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_BILLWHEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_create_account: Error invalid billwhen "
				"passed in Billinfo array from input flist",ebufp);
		goto cleanup;
	}

	actg_typep = PIN_FLIST_FLD_GET(billinfo_iflistp, PIN_FLD_ACTG_TYPE, 1, ebufp);
	if(actg_typep && !(*actg_typep == PIN_ACTG_TYPE_OPEN_ITEMS || *actg_typep == PIN_ACTG_TYPE_BALANCE_FORWARD))
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ACTG_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error invalid ACTG_TYPE "
			"passed in Billinfo array from input flist",ebufp);
		goto cleanup;
	}
	/* Below changes for CINT-725
	if( *pay_type == PIN_PAY_TYPE_PREPAID )
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PREPAID_ACCT_NOT_SUPPORTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_cust_create_account: Error Prepaid Paytpe was passed in the input",ebufp);
		goto cleanup;
	}
	*/
	
	/********************************************************
	 * Get services array from input flist
	 *********************************************************/
	/* Below changes for CINT-725
	services_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_SERVICES, PIN_ELEMID_ANY, 1, ebufp);
	if (services_iflistp == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error SERVICES array missing from input flist");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERVICES_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error SERVICES array missing from input flist",ebufp);
		goto cleanup;
	}*/

	/********************************************************
	 * Get payinfo array from input flist
	 *********************************************************/
	
	// Below changes for CINT-725
	payinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_PAYINFO, PIN_ELEMID_ANY, 1, ebufp);		
	if ( (*pay_type != PIN_PAY_TYPE_PREPAID) && (payinfo_iflistp == NULL))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
			"Error PAYINFO array missing from input flist");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PAYINFO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account: Error PAYINFO array missing from input flist",ebufp);
		goto cleanup;
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&acct_results_flistp, NULL);
	return;
}

/**
 * We use this function to prepare
 * nameinfo array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_nameinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*nameinfo_flistp = NULL;
	pin_cookie_t		cookie = NULL;
	int			rec_id = 0;
	int32			nameinfo_cnt =0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_nameinfo function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_nameinfo input flist", i_flistp);

	/*******************************************************************
	 * Take the input Nameinfo and set it to commit customer flist 
	 *******************************************************************/
	rec_id = 0;
	cookie = NULL;
	while( NULL != (nameinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_NAMEINFO,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_prep_nameinfo nameinfo flist ", nameinfo_flistp);
		if(nameinfo_cnt == 0)
		{
			nameinfo_cnt = PIN_FLIST_ELEM_COUNT(*customerpp, PIN_FLD_NAMEINFO, ebufp);
		}

		PIN_FLIST_ELEM_COPY(i_flistp, PIN_FLD_NAMEINFO, rec_id, *customerpp,
			PIN_FLD_NAMEINFO, ++nameinfo_cnt, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_nameinfo return flist", *customerpp);
	return;
}

/**
 * We use this function to prepare
 * payinfo array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_payinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*cpayinfo_flistp = NULL;
	pin_flist_t		*payinfo_iflistp = NULL;
	pin_flist_t		*inh_info_flistp = NULL;
	pin_flist_t		*billinfo_iflistp = NULL;
	pin_flist_t		*temp_info_flistp = NULL;
	pin_flist_t		*inv_info_flistp = NULL;

	pin_cookie_t		cookie = NULL;
	int			rec_id = 0;

	int32			pay_type = 0;
	int32			inv_terms = 0;
	int32			inv_type = PIN_INV_TYPE_DETAIL;
	int32			payment_term = 0;
	int64			payment_offset = -1;
	poid_t			*payinfo_pdp = NULL;
	void			*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_payinfo function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_payinfo input flist", i_flistp);

	/********************************************************
	 * Get payinfo array from input flist
	 *********************************************************/
	payinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_PAYINFO, PIN_ELEMID_ANY, 1, ebufp);
	billinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp);
	if (billinfo_iflistp)
	{
		vp = PIN_FLIST_FLD_GET (billinfo_iflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if(vp)
		{
			pay_type = *(int32*) vp;
		}
	}
	
	if ((payinfo_iflistp == NULL) && (pay_type == PIN_PAY_TYPE_PREPAID))
	{
		cpayinfo_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_PAYINFO, 0, ebufp);
		payinfo_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_PAYINFO_PREPAID, -1, ebufp);
		
		PIN_FLIST_FLD_PUT(cpayinfo_flistp, PIN_FLD_POID, payinfo_pdp, ebufp);
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_PAY_TYPE, (void *)&pay_type, ebufp);
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_INV_TYPE, (void *)&inv_type, ebufp);		
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_PAYMENT_TERM, (void *)&payment_term, ebufp);
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_PAYMENT_OFFSET, (void *)&payment_offset, ebufp);
	}
	else
	{
		/*******************************************************************
		 * Add payinfo array and inherited-info into commit_customer input flist
		 *********************************************************************/
		cpayinfo_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_PAYINFO, 0, ebufp);
		switch (pay_type) {
			case PIN_PAY_TYPE_CC:
				payinfo_pdp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_PAYINFO_CC, -1, ebufp);
				break;
			case PIN_PAY_TYPE_DD:
				payinfo_pdp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_PAYINFO_DD, -1, ebufp);
				break;
			case PIN_PAY_TYPE_INVOICE:
				payinfo_pdp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_PAYINFO_INVOICE, -1, ebufp);
				break;
			case PIN_PAY_TYPE_SUBORD:
				payinfo_pdp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_PAYINFO_SUBORD, -1, ebufp);
				break;
			case TAB_PAY_TYPE_AUTOPAY:
				payinfo_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_PAYINFO_AUTOPAY, -1, ebufp);
				break;
			default:
				break;
		}

		PIN_FLIST_FLD_PUT(cpayinfo_flistp, PIN_FLD_POID, payinfo_pdp, ebufp);
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_PAY_TYPE, (void *)&pay_type, ebufp);
		PIN_FLIST_FLD_SET(cpayinfo_flistp, PIN_FLD_INV_TYPE, (void *)&inv_type, ebufp);
		PIN_FLIST_FLD_COPY(payinfo_iflistp, PIN_FLD_PAYMENT_TERM, cpayinfo_flistp, 
				PIN_FLD_PAYMENT_TERM, ebufp);
		PIN_FLIST_FLD_COPY(payinfo_iflistp, PIN_FLD_PAYMENT_OFFSET, cpayinfo_flistp, 
				PIN_FLD_PAYMENT_OFFSET, ebufp);

		/*******************************************************************
		 * Get the input payinfo structure and make a copy.
		 *********************************************************************/
		if( pay_type == PIN_PAY_TYPE_DD ) 
		{
			rec_id = 0;
			cookie = NULL;
			inh_info_flistp = PIN_FLIST_SUBSTR_ADD(cpayinfo_flistp, PIN_FLD_INHERITED_INFO, ebufp);
			while( NULL != (temp_info_flistp = PIN_FLIST_ELEM_GET_NEXT(payinfo_iflistp, PIN_FLD_DD_INFO, 
				&rec_id, 1, &cookie, ebufp) ) )
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_create_account_prep_payinfo info flist ", temp_info_flistp);
				PIN_FLIST_ELEM_COPY(payinfo_iflistp, PIN_FLD_DD_INFO, rec_id, inh_info_flistp, 
					PIN_FLD_DD_INFO, rec_id, ebufp);
			}
		} 
		if( pay_type == PIN_PAY_TYPE_CC ) 
		{
			rec_id = 0;
			cookie = NULL;
			inh_info_flistp = PIN_FLIST_SUBSTR_ADD(cpayinfo_flistp, PIN_FLD_INHERITED_INFO, ebufp);
			while( NULL != (temp_info_flistp = PIN_FLIST_ELEM_GET_NEXT(payinfo_iflistp, PIN_FLD_CC_INFO,
				&rec_id, 1, &cookie, ebufp) ) )
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_cust_create_account_prep_payinfo info flist ", temp_info_flistp);
				PIN_FLIST_ELEM_COPY(payinfo_iflistp, PIN_FLD_CC_INFO, rec_id, inh_info_flistp,
					PIN_FLD_CC_INFO, rec_id, ebufp);
			}
		}
		if( pay_type == TAB_PAY_TYPE_AUTOPAY)
		{
			inh_info_flistp = PIN_FLIST_SUBSTR_ADD(cpayinfo_flistp, PIN_FLD_INHERITED_INFO, ebufp);
			if(NULL != (temp_info_flistp = PIN_FLIST_SUBSTR_GET(payinfo_iflistp, 
					PIN_FLD_PAYMENT, 1, ebufp)))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_create_account_prep_payinfo info flist ", temp_info_flistp);
				PIN_FLIST_SUBSTR_SET(inh_info_flistp, temp_info_flistp, PIN_FLD_PAYMENT, ebufp);
			}
		}
		if( pay_type == PIN_PAY_TYPE_INVOICE)
		{
			inh_info_flistp = PIN_FLIST_SUBSTR_ADD(cpayinfo_flistp, PIN_FLD_INHERITED_INFO, ebufp);
			inv_info_flistp = PIN_FLIST_ELEM_ADD(inh_info_flistp, PIN_FLD_INV_INFO, 0 ,ebufp);
			PIN_FLIST_FLD_SET(inv_info_flistp, PIN_FLD_INV_TERMS, (void *)&inv_terms, ebufp);	
		}
	}	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_payinfo return flist", *customerpp);
	return;

}

/**
 * We use this function to prepare
 * acctinfo array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_acctinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*acctinfo_flistp = NULL;
	pin_flist_t		*exemptions_flistp = NULL;
	pin_flist_t		*acct_results_flistp = NULL;
	pin_flist_t		*bal_info_flistp = NULL;
	pin_flist_t		*acct_flistp = NULL;
	pin_flist_t		*flistp = NULL;
	poid_t			*acct_pdp = NULL;
	poid_t			*parent_acct_pdp = NULL;
	pin_decimal_t		*precent = NULL;
	int32			exemptions_type = 1;
	time_t			current_time;
	char			*parent_acct_no = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_acctinfo function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_acctinfo input flist", i_flistp);

	current_time = pin_virtual_time(NULL);

	/***************************************************************
	* Add PIN_FLD_ACCTINFO array and related information
	* in commit_customer input flist
	****************************************************************/
	acctinfo_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_ACCTINFO, 0 ,ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, acctinfo_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	bal_info_flistp = PIN_FLIST_ELEM_ADD(acctinfo_flistp, PIN_FLD_BAL_INFO, 0 ,ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account bal_info_flistp ", bal_info_flistp);

	acct_pdp = PIN_POID_CREATE(db_no, "/account", -1, ebufp);
	PIN_FLIST_FLD_PUT(acctinfo_flistp, PIN_FLD_POID, acct_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, acctinfo_flistp, 
		PIN_FLD_CUSTOMER_SEGMENT_LIST, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_GL_SEGMENT, acctinfo_flistp, 
		PIN_FLD_GL_SEGMENT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BUSINESS_TYPE, acctinfo_flistp, 
		PIN_FLD_BUSINESS_TYPE, ebufp);

	precent = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_PERCENT, 1, ebufp);
	if (precent)
	{
		exemptions_flistp = PIN_FLIST_ELEM_ADD(acctinfo_flistp, PIN_FLD_EXEMPTIONS, 0 ,ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PERCENT, exemptions_flistp, 
			PIN_FLD_PERCENT, ebufp);
		PIN_FLIST_FLD_SET(exemptions_flistp, PIN_FLD_TYPE, &exemptions_type, ebufp);
		PIN_FLIST_FLD_SET(exemptions_flistp, PIN_FLD_START_T, &current_time, ebufp);
		PIN_FLIST_FLD_SET(exemptions_flistp, PIN_FLD_END_T, NULL, ebufp);
	}
	parent_acct_no = (char *)PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_PARENT_ACT_NO, 1, ebufp);
	if(parent_acct_no)
	{
		/***********************************************************
		 * Validate existence of Parent Account number in the database
		 *      If account exist already
		 ***********************************************************/
		fm_tab_utils_common_get_account_details(ctxp, parent_acct_no, &acct_results_flistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account_prep_acctinfo:"
				" input flist", i_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account_prep_acctinfo: "
				"fm_tab_utils_common_get_account_details error while searching", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account_prep_acctinfo:"
				"Account lookup results flist", acct_results_flistp);

		acct_flistp = PIN_FLIST_ELEM_GET(acct_results_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if (acct_flistp)
		{
			parent_acct_pdp = PIN_FLIST_FLD_GET(acct_flistp, PIN_FLD_POID, 1, ebufp);
			if(parent_acct_pdp)
			{
				flistp = PIN_FLIST_SUBSTR_ADD(*customerpp, PIN_FLD_GROUP_INFO, ebufp);
				PIN_FLIST_FLD_SET(flistp, PIN_FLD_PARENT, parent_acct_pdp, ebufp);
			}
		}
		else
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_prep_acctinfo:"
				"Error Parent Account number not present in DB");
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_PARENT_DATA_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_acctinfo: Error Parent Account number not present in DB",ebufp);
			goto cleanup;
		}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_acctinfo return flist", *customerpp);
cleanup:
	PIN_FLIST_DESTROY_EX(&acct_results_flistp, NULL);
	return;
}

/**
 * We use this function to prepare
 * billinfo array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_billinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*billinfo_iflistp = NULL;
	pin_flist_t		*cbillinfo_flistp = NULL;
	pin_flist_t		*sbillinfo_rflistp = NULL;

	poid_t			*billinfo_pdp = NULL;
	char			*billinfo_id = TAB_NAME_BILLINFO_ID;
	char			*parent_acct_no = NULL;
	void			*vp = NULL;
	int32			pay_type = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_billinfo function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_prep_billinfo input flist", i_flistp);

	/********************************************************
	 * Get billinfo array from input flist
	 *********************************************************/
	billinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp);
	if ( billinfo_iflistp) 
	{
		/*******************************************************************
		 * Add PIN_FLD_BILLINFO array and its related values
		 * in commit_customer input flist
		 *******************************************************************/
		cbillinfo_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_BILLINFO, 0, ebufp);

		billinfo_pdp = PIN_POID_CREATE(db_no, "/billinfo", -1, ebufp);
		PIN_FLIST_FLD_PUT(cbillinfo_flistp, PIN_FLD_POID, billinfo_pdp, ebufp);

		PIN_FLIST_ELEM_SET(cbillinfo_flistp, (void *)NULL, PIN_FLD_BAL_INFO, 0, ebufp);
		PIN_FLIST_FLD_SET(cbillinfo_flistp, PIN_FLD_BILLINFO_ID, billinfo_id, ebufp);

		PIN_FLIST_FLD_COPY(billinfo_iflistp, PIN_FLD_BILL_WHEN, cbillinfo_flistp, 
			PIN_FLD_BILL_WHEN, ebufp);
		PIN_FLIST_FLD_COPY(billinfo_iflistp, PIN_FLD_ACTG_TYPE, cbillinfo_flistp, 
			PIN_FLD_ACTG_TYPE, ebufp);
		PIN_FLIST_FLD_COPY(billinfo_iflistp, PIN_FLD_BILLING_SEGMENT, cbillinfo_flistp, 
			PIN_FLD_BILLING_SEGMENT, ebufp);
		PIN_FLIST_FLD_COPY(billinfo_iflistp, PIN_FLD_ACTG_CYCLE_DOM, cbillinfo_flistp, 
			PIN_FLD_ACTG_CYCLE_DOM, ebufp);

		vp = PIN_FLIST_FLD_GET (billinfo_iflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if(vp == NULL)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_prep_billinfo:"
				"Error Paytype missing in the billinfo array input");
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_ACCOUNT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account_prep_billinfo: "
				"Error Paytype missing in the billinfo array input",ebufp);
			goto cleanup;
		}
		else
		{
			pay_type = *(int32*) vp;
		}
		PIN_FLIST_FLD_COPY(billinfo_iflistp, PIN_FLD_PAY_TYPE, cbillinfo_flistp,
			PIN_FLD_PAY_TYPE, ebufp);

		parent_acct_no = (char *)PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_PARENT_ACT_NO, 1, ebufp);
		if(parent_acct_no)
		{
			fm_tab_utils_common_get_billinfo_by_acctno(ctxp, parent_acct_no, 1, &sbillinfo_rflistp, 
				db_no, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,":"
				" fm_tab_utils_common_get_billinfo_by_acctno input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_change_bdom_update: "
					"fm_tab_utils_common_get_billinfo error", ebufp);
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_create_account_prep_billinfo: "
				"fm_tab_utils_common_get_billinfo output flist is ",sbillinfo_rflistp);
			if(pay_type && pay_type == PIN_PAY_TYPE_SUBORD)
			{
				PIN_FLIST_FLD_COPY(sbillinfo_rflistp, PIN_FLD_POID, cbillinfo_flistp, 
					PIN_FLD_PARENT_BILLINFO_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(sbillinfo_rflistp, PIN_FLD_AR_BILLINFO_OBJ, cbillinfo_flistp, 
					PIN_FLD_AR_BILLINFO_OBJ, ebufp);
			}
			else
			{
				PIN_FLIST_FLD_COPY(sbillinfo_rflistp, PIN_FLD_POID, cbillinfo_flistp, 
					PIN_FLD_PARENT_BILLINFO_OBJ, ebufp);
			}
		}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_billinfo return flist", *customerpp);
cleanup:
	PIN_FLIST_DESTROY_EX(&sbillinfo_rflistp, NULL);
	return;

}

/**
 * We use this function to prepare
 * bal_info array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_bal_info(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             **customerpp,
	int64                   db_no,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *billinfo_flistp = NULL;
	pin_flist_t             *billinfo_iflistp = NULL;
	pin_flist_t             *balinfo_flistp = NULL;
	pin_flist_t             *limit_flistp = NULL;
	pin_flist_t             *climit_flistp = NULL;
	pin_flist_t             *limit_cflistp = NULL;

	void                    *vp = NULL;
	int32                   pay_type = 0;

	poid_t                  *bal_info_pdp = NULL;
	pin_cookie_t            cookie = NULL;
	int                     rec_id = 0;
	int                     t_credit_percent = 0;
	int32                   *currencyp = NULL;
	int32                   currency = 0;
	int32                   err = 0;
	char                    *prepaid_credit_floorp = NULL;

	pin_decimal_t           *credit_limit = (pin_decimal_t *)NULL;
	pin_decimal_t           *credit_floor = (pin_decimal_t *)NULL;
	pin_decimal_t           *neg_credit_limit = (pin_decimal_t *)NULL;
	pin_decimal_t           *value_decimal = (pin_decimal_t *)NULL;
	credit_floor = pbo_decimal_from_str("0.0", ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{
	  PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		  "fm_tab_cust_create_account_prep_bal_info function entry error", ebufp);
	  return;
 	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_prep_bal_info input flist", i_flistp);

	/*********************************************************
	 * Need to add the Balance Info array to customer flist.
	 * Assumes single billinfo and balance group.
	 *********************************************************/
	balinfo_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_BAL_INFO, 0, ebufp);
	billinfo_flistp = PIN_FLIST_ELEM_ADD(balinfo_flistp, PIN_FLD_BILLINFO, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_create_account_prep_bal_info limit flist ", billinfo_flistp);

	bal_info_pdp = PIN_POID_CREATE(db_no, "/balance_group", -1, ebufp);
	PIN_FLIST_FLD_PUT(balinfo_flistp, PIN_FLD_POID, bal_info_pdp, ebufp);

	billinfo_iflistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp);
	if ( billinfo_iflistp)
	{
		vp = PIN_FLIST_FLD_GET (billinfo_iflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if(vp == NULL)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_prep_bal_info:"
				"Error Paytype missing in the billinfo array input");
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CREATE_SUBSCRIBER, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_create_account_prep_bal_info: "
				"Error Paytype missing in the billinfo array input",ebufp);
			goto cleanup;
		}
		else
		{
			pay_type = *(int32*) vp;
		}
	}

	pin_conf("fm_cust_pol", "currency", PIN_FLDT_INT, (caddr_t *)&currencyp, &(err));
	if (currencyp != (int32 *) NULL) {
		currency = *currencyp;
		free(currencyp);
	}

	rec_id = 0;
	cookie = NULL;
	while( NULL != (limit_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_LIMIT,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_prep_bal_info limit flist ", limit_flistp);

		credit_limit = (pin_decimal_t *)PIN_FLIST_FLD_GET(limit_flistp, PIN_FLD_CREDIT_LIMIT, 1, ebufp);
		climit_flistp = PIN_FLIST_ELEM_ADD(balinfo_flistp, PIN_FLD_LIMIT, currency, ebufp);
		if( pay_type == PIN_PAY_TYPE_PREPAID && currency < 1000 )
		{
			neg_credit_limit = pbo_decimal_negate(credit_limit, ebufp);
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_LIMIT, credit_floor, ebufp);
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_FLOOR, neg_credit_limit, ebufp);
		}
		else if( pay_type == PIN_PAY_TYPE_PREPAID && currency > 1000 )
		{
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_LIMIT, credit_floor, ebufp);
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_FLOOR, credit_limit, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_LIMIT, credit_limit, ebufp);
			PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_FLOOR, credit_floor, ebufp);
		}

		t_credit_percent = fm_tab_utils_common_get_credit_thresholds(ctxp, limit_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account:"
				" fm_tab_utils_common_get_credit_thresholds input flist ", limit_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_prep_bal_info: "
				" fm_tab_utils_common_get_credit_thresholds error", ebufp);
			goto cleanup;
		}
		PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_THRESHOLDS, (void *)&t_credit_percent, ebufp);
		pbo_decimal_destroy(&neg_credit_limit);
	}

	limit_cflistp = PIN_FLIST_ELEM_GET(balinfo_flistp, PIN_FLD_LIMIT, currency, 1, ebufp);
	if(limit_cflistp == NULL)
	{
		if( pay_type == PIN_PAY_TYPE_PREPAID && currency < 1000 )
		{
			pin_conf("fm_cust_pol", "prepaid_credit_floor", PIN_FLDT_STR, (caddr_t *)&prepaid_credit_floorp, &(err));
			if (prepaid_credit_floorp != (char *) NULL) {
				value_decimal = pbo_decimal_from_str(prepaid_credit_floorp, ebufp);

				climit_flistp = PIN_FLIST_ELEM_ADD(balinfo_flistp, PIN_FLD_LIMIT, currency, ebufp);
				neg_credit_limit = pbo_decimal_negate(value_decimal, ebufp);
				PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_LIMIT, credit_floor, ebufp);
				PIN_FLIST_FLD_SET(climit_flistp, PIN_FLD_CREDIT_FLOOR, neg_credit_limit, ebufp);
			}
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_prep_bal_info return flist", *customerpp);
cleanup:
	if(neg_credit_limit)
	{
		pbo_decimal_destroy(&neg_credit_limit);
	}
	if(credit_floor)
	{
		pbo_decimal_destroy(&credit_floor);
	}
	if(value_decimal)
	{
		pbo_decimal_destroy(&value_decimal);
	}
	return;
}

/**
 * We use this function to prepare
 * profile array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_profile(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_profile function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_profile input flist", i_flistp);

	return;
}

/**
 * We use this function to prepare
 * services array information
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_prep_subscription(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*svc_flistp = NULL;

	poid_t			*svc_pdp = NULL;
	poid_t			*plan_pdp = NULL;
	pin_cookie_t		cookie = NULL;
	int			rec_id = 0;
	int32			svc_elemid = 0;
	char			*svc_type = TAB_OBJ_TYPE_SERVICE_GSM;
	int32                   bal_info_index = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_prep_subscription function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:" 
		"fm_tab_cust_create_account_prep_subscription input flist", i_flistp);

	/*************************************************************
	* Add plan poid in commit_customer inputlist
	***************************************************************/
	plan_pdp = PIN_POID_CREATE(db_no, "/plan", -1, ebufp);
	PIN_FLIST_FLD_PUT(*customerpp, PIN_FLD_POID, plan_pdp, ebufp);

	/*******************************************************************
	* Take the input services and set it to commit customer flist
	*******************************************************************/
	rec_id = 0;
	cookie = NULL;

	while( NULL != (services_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_SERVICES,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_prep_subscription services flist ", services_flistp);

		svc_flistp = PIN_FLIST_ELEM_ADD(*customerpp, PIN_FLD_SERVICES, ++svc_elemid, ebufp);
		svc_pdp = PIN_POID_CREATE(db_no, svc_type, -1,ebufp);
		PIN_FLIST_FLD_PUT(svc_flistp, PIN_FLD_SERVICE_OBJ, svc_pdp, ebufp);

		PIN_FLIST_ELEM_SET(svc_flistp, (void *)NULL, PIN_FLD_BAL_INFO, 0, ebufp);
		PIN_FLIST_FLD_SET(svc_flistp, PIN_FLD_BAL_INFO_INDEX, &bal_info_index, ebufp);
	}
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_prep_subscription return flist", *customerpp);

	return;
}

/**
 * We use this function to Create DSG
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param cust_oflistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_create_dsg(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*dsg_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*discount_flistp = NULL;
	pin_flist_t		*offer_flistp = NULL;
	pin_cookie_t		dsg_cookie = NULL;
	pin_cookie_t		cookie = NULL;

	int			dsg_rec_id = 0;
	int			rec_id = 0;
	char			*corr_id = NULL;
	char			*dsg_name = NULL;
	char			*extern_user = NULL;
	char			prog_name[255];
	char			*order_type = TAB_ACTION_DSG_CREATE;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_create_dsg entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_create_dsg input flist", i_flistp);

	/********************************************************************************
	 * Create input flist for DSG 
	 ********************************************************************************/
	dsg_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, dsg_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(dsg_iflistp, PIN_FLD_ORDER_TYPE, order_type, ebufp);
	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, dsg_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, dsg_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);

	rec_id = 0;
	cookie = NULL;
	while( NULL != (services_flistp = PIN_FLIST_ELEM_GET_NEXT(cust_oflistp, PIN_FLD_SERVICES,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_dsg services flist ", services_flistp);

		PIN_FLIST_FLD_COPY(services_flistp, PIN_FLD_SERVICE_OBJ, dsg_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	}

	dsg_rec_id = 0;
	dsg_cookie = NULL;
	while( NULL != (discount_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_DISCOUNT_LIST,
		&dsg_rec_id, 1, &dsg_cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_dsg discount list flist ", discount_flistp);

		dsg_name = PIN_FLIST_FLD_GET(discount_flistp, PIN_FLD_NAME, 1, ebufp);
		if(dsg_name)
		{
			offer_flistp = PIN_FLIST_ELEM_ADD(dsg_iflistp, PIN_FLD_OFFER, dsg_rec_id, ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp, PIN_FLD_NAME, offer_flistp, PIN_FLD_DISCOUNT_INFO, ebufp);
		}
		PIN_FLIST_FLD_COPY(discount_flistp, PIN_FLD_GROUP_NAME, dsg_iflistp, PIN_FLD_NAME, ebufp);
	}

	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);

	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(dsg_iflistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}


	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, dsg_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, dsg_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_subscription_create_sharing_group(ctxp, dsg_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_create_sharing_group error", ebufp);
		*customerpp = r_flistp;
		goto cleanup;
	}

	*customerpp = r_flistp;
cleanup:
	PIN_FLIST_DESTROY_EX(&dsg_iflistp, NULL);
	return;
}

/**
 * We use this function to Create CSG
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param cust_oflistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_create_csg(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*csg_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*charge_flistp = NULL;
	pin_flist_t		*offer_flistp = NULL;
	pin_cookie_t		csg_cookie = NULL;
	pin_cookie_t		cookie = NULL;

	int			csg_rec_id = 0;
	int			rec_id = 0;
	char			*corr_id = NULL;
	char			*extern_user = NULL;
	char			*csg_name = NULL;
	char			prog_name[255];
	char			*order_type = TAB_ACTION_CSG_CREATE;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_create_csg entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_create_csg input flist", i_flistp);

	/********************************************************************************
	 * Create input flist for CSG
	 ********************************************************************************/
	csg_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, csg_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(csg_iflistp, PIN_FLD_ORDER_TYPE, order_type, ebufp);
	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, csg_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, csg_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);

	rec_id = 0;
	cookie = NULL;
	while( NULL != (services_flistp = PIN_FLIST_ELEM_GET_NEXT(cust_oflistp, PIN_FLD_SERVICES,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_csg services flist ", services_flistp);

		PIN_FLIST_FLD_COPY(services_flistp, PIN_FLD_SERVICE_OBJ, csg_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	}

	csg_rec_id = 0;
	csg_cookie = NULL;
	while( NULL != (charge_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_CHARGES,
		&csg_rec_id, 1, &csg_cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_csg discount list flist ", charge_flistp);

		csg_name = PIN_FLIST_FLD_GET(charge_flistp, PIN_FLD_NAME, 1, ebufp);
		if(csg_name)
		{
			offer_flistp = PIN_FLIST_ELEM_ADD(csg_iflistp, PIN_FLD_OFFER, csg_rec_id, ebufp);
			PIN_FLIST_FLD_COPY(charge_flistp, PIN_FLD_NAME, offer_flistp, PIN_FLD_PRODUCT_NAME, ebufp);
		}
		PIN_FLIST_FLD_COPY(charge_flistp, PIN_FLD_GROUP_NAME, csg_iflistp, PIN_FLD_NAME, ebufp);
	}

	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);
	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(csg_iflistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, csg_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, csg_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_subscription_create_sharing_group(ctxp, csg_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_create_sharing_group error", ebufp);
		*customerpp = r_flistp;
		goto cleanup;
	}

	*customerpp = r_flistp;
cleanup:
	PIN_FLIST_DESTROY_EX(&csg_iflistp, NULL);
	return;
}

/**
 * We use this function to purchase the offer 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param cust_oflistp in the input flist.
 * @param db_no the Database number
 * @param ebufp The error buffer.
 * @return customerpp The output flist.
 */
static void
fm_tab_cust_create_account_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	pin_flist_t		**customerpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*purchase_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*services_oflistp = NULL;
	pin_flist_t		*package_flistp = NULL;
	pin_cookie_t		purchase_cookie = NULL;
	pin_cookie_t		svc_cookie = NULL;
	pin_cookie_t		cookie = NULL;
	int			purchase_rec_id = 0;
	int			svc_rec_id = 0;
	int			rec_id = 0;
	char			*corr_id = NULL;
	char			*extern_user = NULL;
	char			prog_name[255];


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_create_account_create_purchase_offer entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account:"
		"fm_tab_cust_create_account_create_purchase_offer input flist", i_flistp);

	/********************************************************************************
	 * Create input flist for Purchase Offer
	 ********************************************************************************/
	purchase_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, purchase_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(cust_oflistp, PIN_FLD_ACCOUNT_OBJ, purchase_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, purchase_iflistp, PIN_FLD_ACCOUNT_NO, ebufp);

	svc_rec_id = 0;
	svc_cookie = NULL;
	while( NULL != (services_oflistp = PIN_FLIST_ELEM_GET_NEXT(cust_oflistp, PIN_FLD_SERVICES,
		&svc_rec_id, 1, &svc_cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_csg commit customer services flist ", services_oflistp);
		PIN_FLIST_FLD_COPY(services_oflistp, PIN_FLD_SERVICE_OBJ, purchase_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	}

	rec_id = 0;
	cookie = NULL;
	while( NULL != (services_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_SERVICES,
		&rec_id, 1, &cookie, ebufp) ) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_create_account_create_purchase_offer services flist ", services_flistp);

		purchase_rec_id = 0;
		purchase_cookie = NULL;
		while( NULL != (package_flistp = PIN_FLIST_ELEM_GET_NEXT(services_flistp, PIN_FLD_PACKAGE_INFO,
			&purchase_rec_id, 1, &purchase_cookie, ebufp) ) )
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_create_account_create_purchase_offer flist ", package_flistp);
			PIN_FLIST_ELEM_COPY(services_flistp, PIN_FLD_PACKAGE_INFO, purchase_rec_id, purchase_iflistp,
				PIN_FLD_PACKAGE_INFO, purchase_rec_id, ebufp);
		}
	}
	corr_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);
	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(purchase_iflistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, purchase_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, purchase_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_cust_purchase_offer(ctxp, purchase_iflistp, &r_flistp, db_no, TAB_NOTIFY_DISABLE, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_purchase_offer error", ebufp);
		*customerpp = r_flistp;
		goto cleanup;
	}

	*customerpp = r_flistp;
cleanup:
	PIN_FLIST_DESTROY_EX(&purchase_iflistp, NULL);
	return;
}


/**
 * We use this function to generate
 * custom notification on create account.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
 
static void
fm_tab_cust_create_account_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*cust_oflistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*temp_input_iflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*nameinfo_flistp = NULL;
	pin_flist_t		*cust_iflistp = NULL;
	pin_flist_t		*ob_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_create_account_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_create_account_notification: "
		"input flist", i_flistp);
		
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	temp_input_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
	cust_iflistp = PIN_FLIST_COPY(cust_oflistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);
	
	ob_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(ob_flistp, cust_iflistp, PIN_FLD_RESULTS_DATA, 0, ebufp);	
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, ob_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CREATE_ACCOUNT, -1, ebufp);
	common_notification_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, 
		common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
		common_notification_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	
	if((billinfo_flistp = PIN_FLIST_ELEM_GET(i_flistp, 
			PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, 
			common_notification_flistp, PIN_FLD_PAY_TYPE, ebufp);
	}
	
	if((nameinfo_flistp = PIN_FLIST_ELEM_GET(i_flistp, 
			PIN_FLD_NAMEINFO, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_FLIST_FLD_COPY(nameinfo_flistp, PIN_FLD_FIRST_NAME, 
			common_notification_flistp, PIN_FLD_FIRST_NAME, ebufp);
		PIN_FLIST_FLD_COPY(nameinfo_flistp, PIN_FLD_MIDDLE_NAME, 
			common_notification_flistp, PIN_FLD_MIDDLE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(nameinfo_flistp, PIN_FLD_LAST_NAME, 
			common_notification_flistp, PIN_FLD_LAST_NAME, ebufp);
	}
	
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_create_account:"
		" fm_tab_cust_create_account_notification input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CREATE_ACCOUNT, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_create_account_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_create_account_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_create_account_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CREATE_ACCOUNT output flist ", enrich_notify_flistp);

	cleanup:
    /******************************************************************
     * Clean up.
    ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	
	*r_flistpp = enrich_notify_flistp;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_create_account_notification output flist", *r_flistpp);
	return;
}

