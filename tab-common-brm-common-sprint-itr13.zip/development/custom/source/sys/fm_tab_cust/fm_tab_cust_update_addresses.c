/*******************************************************************************
*
* This material is the confidential property of Telenor/Oracle Corporation or its
* licensors and may be used, reproduced, stored or transmitted only in
* accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *					
 *	Delivery Code	| No	| Date		| Programmer		| Req/bug/Gap		| Change details 
 *					
 *			| 1	| 07-DEC-2021	| Shubham		|			| New file.
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_UPDATE_ADDRESSES operation. 
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

EXPORT_OP void 
op_tab_cust_update_addresses(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
		
static void 
fm_tab_cust_update_addresses(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_notify_update_addresses_prepare_notification(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int64                   db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		**opresp_flistpp,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern int64 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
				
extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
 
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern unsigned long
fm_tab_utils_common_get_max_elemid(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			fld_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_CUST_UPDATE_ADDRESSES is implemented to 
 * update address of a account.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_NAMEINFO, PIN_FLD_PHONES 
 *	and PIN_FLD_ACCOUNT_NO .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID				POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_ACCOUNT_NO			STR [0] " 1-DIGI_AT_16"
 0 PIN_FLD_VAT_CERT			STR [0] ""
 0 PIN_FLD_NAMEINFO			ARRAY [1] allocated 22, used 22
 1	 PIN_FLD_CONTACT_TYPE	STR [0] " Billing"
 1	 PIN_FLD_ADDRESS	STR [0] "sampleAcnt"
 1	 PIN_FLD_CITY		STR [0] "sampleAcnt"
 1	 PIN_FLD_COMPANY	STR [0] "Oracle"
 1	 PIN_FLD_COUNTRY	STR [0] "INDIA"
 1	 PIN_FLD_EMAIL_ADDR	STR [0] "sampleAcnt@oracle.com"
 1	 PIN_FLD_FIRST_NAME	STR [0] "DIGI_AT_16"
 1	 PIN_FLD_LAST_NAME	STR [0] "sample_data"
 1	 PIN_FLD_MIDDLE_NAME	STR [0] ""
 1	 PIN_FLD_SALUTATION	STR [0] ""
 1	 PIN_FLD_STATE		STR [0] "RAJ"
 1	 PIN_FLD_ZIP		STR [0] "312222"
 1	 PIN_FLD_PHONES		ARRAY [0] allocated 20, used 2
 2		PIN_FLD_PHONE	STR [0] "8239352896"
 2		PIN_FLD_TYPE	ENUM [0] 1
 0 PIN_FLD_CORRELATION_ID		STR [0] "er2345"
 0 PIN_FLD_EXTERNAL_USER		STR [0] "CRM"
 */

void
op_tab_cust_update_addresses(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_update_addresses function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_UPDATE_ADDRESSES) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_addresses bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_addresses input flist", in_flistp);


	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_ADDRESS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_ADDRESS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_ADDRESS, ebufp);
		}
        fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
				" input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_addresses:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_update_addresses(ctxp,flags,enrich_iflistp,&r_flistp,db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_update_addresses error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses:"
				" input flist", enrich_iflistp); 
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_cust_update_addresses:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_update_addresses: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_UPDATE_ADDRESSES", &r_flistp,db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
		" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_update_addresses:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_ADDRESS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_ADDRESS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_UPDATE_ADDRESS , ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		 /*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_addresses output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to update address for a account.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param flags The opcode flags. 
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_cust_update_addresses(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*contact_type = NULL;
	char			*action = NULL;
	char			*accountno = NULL;
	char			*readobj_contact_type = NULL;
	char			*phone = NULL;
	long			max_elemid = 0;
	pin_flist_t		*update_inflistp = NULL;
	pin_flist_t		*update_iflistp = NULL;
	pin_flist_t		*nameinfo_flistp = NULL;
	pin_flist_t		*contextinfo_flistp = NULL;
	pin_flist_t		*readobj_inflistp = NULL;
	pin_flist_t		*readobj_outflistp = NULL;
	pin_flist_t		*readobj_rflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*phones_iflistp = NULL; 
	int32			nameinfo_elemid = 0;
	int32			phones_elemid = 0;
	int32			array_found = 0;
	int32			contact_type_valid = 0;
	int32			phone_type = 0;
	pin_cookie_t		nameinfo_cookie = NULL;
	pin_cookie_t		phones_cookie = NULL;
	int32			readobj_nameinfo_elemid = 0;
	pin_cookie_t		readobj_nameinfo_cookie = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses function entry error", ebufp);
		return;
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_addresses input flist", in_flistp);
	
	accountno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
        if ((accountno == NULL || strlen(accountno) == 0))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_cust_update_addresses: Error PIN_FLD_ACCOUNT_NO - Input is missing", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_addresses input flist", in_flistp);
                goto cleanup;
        }
	
	action = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACTION, 1, ebufp);
	if ((action == NULL || strlen(action) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACTION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Error PIN_FLD_ACTION - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_addresses input flist", in_flistp);
		goto cleanup;
	}

	readobj_inflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, readobj_inflistp, PIN_FLD_POID, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_READ_OBJ to get PIN_FLD_NAMEINFO input flist", readobj_inflistp);

	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, readobj_inflistp, &readobj_outflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Base opcode error", readobj_inflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Base opcode error", ebufp);
		goto cleanup;
	}

	update_inflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, update_inflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, update_inflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, update_inflistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, update_inflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	contextinfo_flistp = PIN_FLIST_SUBSTR_ADD(update_inflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, contextinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, contextinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	nameinfo_elemid = 0;
	nameinfo_cookie = NULL;
	while((r_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_NAMEINFO, 
		&nameinfo_elemid, 1, &nameinfo_cookie,ebufp)) != (pin_flist_t *)NULL)
	{
		array_found = 1;
		contact_type_valid = 0;

		contact_type = PIN_FLIST_FLD_GET(r_flistp, PIN_FLD_CONTACT_TYPE, 1, ebufp);
		if ((contact_type == NULL || strlen(contact_type) == 0)) 
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_CONTACT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Error PIN_FLD_CONTACT_TYPE - Input is missing", ebufp);
			goto cleanup;
		}
		
		readobj_nameinfo_elemid = 0;
		readobj_nameinfo_cookie = NULL;
		while((readobj_rflistp = PIN_FLIST_ELEM_GET_NEXT(readobj_outflistp, PIN_FLD_NAMEINFO, 
				&readobj_nameinfo_elemid, 1, &readobj_nameinfo_cookie,ebufp)) != (pin_flist_t *)NULL)
		{
			readobj_contact_type = PIN_FLIST_FLD_GET(readobj_rflistp, PIN_FLD_CONTACT_TYPE, 1, ebufp);
			if(strcasecmp(contact_type,readobj_contact_type) == 0)
			{
				contact_type_valid = 1;
				break;
			}
		}

		if( (strcasecmp(TAB_ACTION_MODIFY, action) == 0) && (contact_type_valid == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_CONTACT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: PIN_FLD_CONTACT_TYPE seems incorrect in array.", ebufp);
			goto cleanup;
		}
		else if(strcasecmp(TAB_ACTION_MODIFY, action) == 0)
		{
			nameinfo_flistp = PIN_FLIST_ELEM_ADD(update_inflistp, PIN_FLD_NAMEINFO, readobj_nameinfo_elemid, ebufp);
			PIN_FLIST_CONCAT(nameinfo_flistp, r_flistp, ebufp);
		}
		else if((strcasecmp(TAB_ACTION_ADD, action) == 0) && (contact_type_valid == 1))
		{
			
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EXISTING_CONTACT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_update_addresses: PIN_FLD_CONTACT_TYPE in array already exists in DB.", ebufp);
			goto cleanup;
		}
		else if(strcasecmp(TAB_ACTION_ADD, action) == 0)
		{		
			phones_elemid = 0;
			phones_cookie = NULL;
			while((phones_iflistp = PIN_FLIST_ELEM_GET_NEXT(r_flistp, PIN_FLD_PHONES,
				&phones_elemid, 1, &phones_cookie, ebufp)) != (pin_flist_t *)NULL)
			{	
				phone_type = PIN_FLIST_FLD_GET(phones_iflistp, PIN_FLD_TYPE, 1, ebufp);
				if (phone_type == 0)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_MISSING_PHONE_TYPE, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_cust_update_addresses: Error PIN_FLD_TYPE - "
					"Input is missing in phones array", ebufp);
					goto cleanup;
				}

				phone = PIN_FLIST_FLD_GET(phones_iflistp, PIN_FLD_PHONE, 1, ebufp);
				if ((phone == NULL || strlen(phone) == 0))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_MISSING_PHONE_NO, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_cust_update_addresses: Error PIN_FLD_PHONE - "
						"Input is missing in phones array", ebufp);
					goto cleanup;
				}
			}	
			max_elemid = fm_tab_utils_common_get_max_elemid(ctxp, readobj_outflistp, PIN_FLD_NAMEINFO, ebufp);
			nameinfo_flistp = PIN_FLIST_ELEM_ADD(update_inflistp, PIN_FLD_NAMEINFO, max_elemid+nameinfo_elemid+1, ebufp);
			PIN_FLIST_CONCAT(nameinfo_flistp, r_flistp, ebufp);
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_ACTION_CODE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_update_addresses: PIN_FLD_ACTION seems incorrect.", ebufp);
			goto cleanup;
		}
	}
	if(array_found == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MEMBER_ARRAY_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Error PIN_FLD_NAMEINFO - Input is missing", ebufp);
		goto cleanup;
	}
	
	PIN_FLIST_FLD_SET(update_inflistp, PIN_FLD_ACTION, action, ebufp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_VALIDATE_UPDATE_ADDRESSES, 0, update_inflistp, &update_iflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_cust_update_addresses: Hook opcode error", update_inflistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_cust_update_addresses: Hook opcode error", ebufp);
		*ret_flistpp = update_iflistp;
                goto cleanup;
        }

	if (PIN_FLIST_FLD_GET(update_iflistp, PIN_FLD_ACTION, 1, ebufp))
                        PIN_FLIST_FLD_DROP(update_iflistp, PIN_FLD_ACTION, ebufp);
	
	PCM_OP(ctxp, PCM_OP_CUST_UPDATE_CUSTOMER, 0, update_iflistp, &ret_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Base opcode error", update_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_addresses: Base opcode error", ebufp);
		PIN_FLIST_DESTROY_EX(&update_iflistp, NULL);
		goto cleanup;
	}

	//PIN_FLIST_DESTROY_EX(&update_iflistp, NULL);
	// Call function to enrich notification details
	fm_tab_notify_update_addresses_prepare_notification(ctxp, in_flistp, db_no, ret_flistp, ret_flistpp, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses:"
			" fm_tab_notify_update_addresses_prepare_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses: "
			" fm_tab_notify_update_addresses_prepare_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&update_inflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_inflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_outflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	return;

}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_UPDATE_ADDRESSES for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_notify_update_addresses_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		**opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*nameinfo_flistp = NULL;
	pin_flist_t		*nameinfo_inflistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	pin_cookie_t		nameinfo_cookie = NULL;
	poid_t			*notify_pdp = NULL;
	int32			nameinfo_elemid = 0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"fm_tab_notify_update_addresses_prepare_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_update_addresses_prepare_notification: "
		"input flist", i_flistp);
		
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, *opresp_flistpp, PIN_FLD_OUT_FLIST, ebufp);

	out_flistp = PIN_FLIST_SUBSTR_GET(notify_iflistp, PIN_FLD_OUT_FLIST, 1, ebufp);
	PIN_FLIST_SUBSTR_SET(out_flistp, results_flistp, PIN_FLD_RESULTS_DATA, ebufp);
	// Create Notification Flists
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_UPDATE_ADDRESSES, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, notify_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	while((nameinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp, PIN_FLD_NAMEINFO, 
		&nameinfo_elemid, 1, &nameinfo_cookie,ebufp)) != (pin_flist_t *)NULL)
	{
		nameinfo_inflistp = PIN_FLIST_ELEM_ADD(notify_flistp, PIN_FLD_NAMEINFO, nameinfo_elemid, ebufp);
		PIN_FLIST_CONCAT(nameinfo_inflistp, nameinfo_flistp, ebufp);
	}
	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_update_addresses_prepare_notification:"
		" TAB_OP_NOTIFY_POL_UPDATE_ADDRESSES_NOTIFICATION input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_UPDATE_ADDRESSES_NOTIFICATION, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_update_addresses_prepare_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_update_addresses_prepare_notification:"
			" Error in Notification", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_update_addresses_prepare_notification:"
		" TAB_OP_NOTIFY_POL_UPDATE_ADDRESSES_NOTIFICATION output flist ", enrich_notify_flistp);
cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	
	*r_flistpp = enrich_notify_flistp;
	
	return;
}
