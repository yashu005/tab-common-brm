/*******************************************************************************
*
* This material is the confidential property of Telenor/Oracle Corporation or its
* licensors and may be used, reproduced, stored or transmitted only in
* accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *					
 *	Delivery Code	| No	| Date		| Programmer		| Req/bug/Gap		| Change details 
 *					
 *			| 1	| 10-MAR-2022	| Shubham		|			| New file.
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_BUNDLE_CONFIG operation. 
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

EXPORT_OP void 
op_tab_cust_get_bundle_config(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
		
static void 
fm_tab_cust_get_bundle_config(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
 
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_deal_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_GET_BUNDLE_CONFIG is implemented to 
 * retrieve bundle info.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_BUNDLE.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 */

void
op_tab_cust_get_bundle_config(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_bundle_config function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_BUNDLE_CONFIG) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_bundle_config bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_bundle_config input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config:"
		" fm_tab_cust_get_bundle_config input flist", in_flistp);

	/* call main function */
	fm_tab_cust_get_bundle_config(ctxp,flags,in_flistp,&r_flistp,db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_bundle_config error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_bundle_config:"
			" input flist", in_flistp); 
		status = TAB_FAIL;
		goto cleanup;
	}

	cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_bundle_config:"
		" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_bundle_config:"
			"Error while getting bundle info", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_BUNDLE_DETAILS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_BUNDLE_DETAILS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_GET_BUNDLE_DETAILS , ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		 /*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_bundle_config output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to retrieve bundle info.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param flags The opcode flags. 
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_cust_get_bundle_config(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*bundle_name = NULL;
	int32			products_elemid = 0;
	int32			discounts_elemid = 0;
	int32			usage_elemid = 0;
	pin_cookie_t		products_cookie = NULL;
	pin_cookie_t		discounts_cookie = NULL;
	pin_cookie_t		usage_cookie = NULL;	
	pin_flist_t		*deal_details_iflistp = NULL; 
	pin_flist_t		*deal_details_oflistp = NULL;
	pin_flist_t		*deal_details_flistp = NULL;
	pin_flist_t		*usage_map_flistp = NULL;
	pin_flist_t		*readobj_iflistp = NULL;
	pin_flist_t		*readobj_rflistp = NULL;
	pin_flist_t		*hook_iflistp = NULL;
	pin_flist_t		*hook_rflistp = NULL;
	pin_flist_t		*products_flistp = NULL;
	pin_flist_t		*products_oflistp = NULL;
	pin_flist_t		*charges_flistp = NULL;
	pin_flist_t		*discounts_flistp = NULL;
	pin_flist_t		*discounts_oflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32			error_code = 0;

	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_bundle_config function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config input flist", in_flistp);

	bundle_name = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);
	if (bundle_name == NULL || strlen(bundle_name) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DEAL_NAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_bundle_config: Error PIN_FLD_NAME - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_bundle_config input flist", in_flistp);
		goto cleanup;
	}
	 
	/*Search for deal object using deal name*/
	deal_details_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, deal_details_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(deal_details_iflistp, PIN_FLD_NAME, bundle_name, ebufp);
	
	fm_tab_utils_common_get_deal_details(ctxp, deal_details_iflistp,
                        &deal_details_oflistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
				" input flist ", deal_details_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
				" Error while getting deal object", ebufp);
		goto cleanup;
	}

	if(deal_details_oflistp != NULL) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config: "
			"fm_tab_utils_common_get_deal_details output flist", deal_details_oflistp);

		deal_details_flistp = PIN_FLIST_ELEM_GET(deal_details_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if( deal_details_flistp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_DEAL_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
					" input flist ", deal_details_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_bundle_config:"
					"Deal not found in BRM DB", ebufp);
			goto cleanup;
		}
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DEAL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_deal_details:"
				" input flist ", deal_details_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_bundle_config:"
				"Deal not found in BRM DB", ebufp);
		goto cleanup;
	}

	hook_iflistp = PIN_FLIST_CREATE(ebufp);
	while((products_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_PRODUCTS, 
		&products_elemid, 1, &products_cookie,ebufp)) != (pin_flist_t *)NULL)
	{
		readobj_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PRODUCT_OBJ, readobj_iflistp, PIN_FLD_POID, ebufp);
		
		PCM_OP (ctxp, PCM_OP_READ_OBJ, 0, readobj_iflistp, &readobj_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_bundle_config: Base opcode error", readobj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_bundle_config: Base opcode error", ebufp);
			PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
			goto cleanup;
		}
		
		if(readobj_rflistp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PRODUCT_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ:"
				" input flist ", readobj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_bundle_config:"
				"Product not found in BRM DB", ebufp);
			PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
			goto cleanup;
		}	

		PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config:"
			"product readobj return flist", readobj_rflistp);
		
		products_oflistp = PIN_FLIST_ELEM_ADD(hook_iflistp, PIN_FLD_PRODUCTS, products_elemid, ebufp);	
		PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PRODUCT_OBJ, products_oflistp, PIN_FLD_PRODUCT_OBJ, ebufp);	
		PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_NAME, products_oflistp, PIN_FLD_NAME, ebufp);
		PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_DESCR, products_oflistp, PIN_FLD_DESCR, ebufp);
		
		usage_elemid = 0;
		usage_cookie = NULL;
		
		while((usage_map_flistp = PIN_FLIST_ELEM_GET_NEXT(readobj_rflistp, PIN_FLD_USAGE_MAP,
			&usage_elemid, 1, &usage_cookie,ebufp)) != (pin_flist_t *)NULL)
		{
			charges_flistp = PIN_FLIST_ELEM_ADD(products_oflistp, PIN_FLD_CHARGES, usage_elemid, ebufp);
			PIN_FLIST_FLD_COPY(usage_map_flistp, PIN_FLD_EVENT_TYPE, charges_flistp, PIN_FLD_EVENT_TYPE, ebufp);
			PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_ORDER_PRICE, NULL, ebufp);
		}
		PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
	}
	
	while((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_details_flistp, PIN_FLD_DISCOUNTS,
		&discounts_elemid, 1, &discounts_cookie,ebufp)) != (pin_flist_t *)NULL)
	{
		readobj_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DISCOUNT_OBJ, readobj_iflistp, PIN_FLD_POID, ebufp);

		PCM_OP (ctxp, PCM_OP_READ_OBJ, 0, readobj_iflistp, &readobj_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_bundle_config: Base opcode error", readobj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_bundle_config: Base opcode error", ebufp);
			PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
			goto cleanup;
		}
		
		if(readobj_rflistp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DISCOUNT_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ:"
				" input flist ", readobj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_bundle_config:"
				"Discount not found in BRM DB", ebufp);
			PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config:"
			"discount readobj return flist", readobj_rflistp);

		discounts_oflistp = PIN_FLIST_ELEM_ADD(hook_iflistp, PIN_FLD_DISCOUNTS, discounts_elemid, ebufp);
		PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DISCOUNT_OBJ, discounts_oflistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_NAME, discounts_oflistp, PIN_FLD_NAME, ebufp);
		PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_DESCR, discounts_oflistp, PIN_FLD_DESCR, ebufp);

		PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
	}

	PIN_FLIST_FLD_COPY(deal_details_flistp, PIN_FLD_POID, hook_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(deal_details_flistp, PIN_FLD_NAME, hook_iflistp, PIN_FLD_NAME, ebufp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_GET_BUNDLE, 0, hook_iflistp, &hook_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_bundle_config: Hook opcode error", hook_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_bundle_config: Hook opcode error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(hook_rflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_bundle_config: "
		"TAB_OP_CUST_POL_ENRICH_GET_BUNDLE output flist", hook_rflistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if(hook_rflistp != NULL)
	{
		products_elemid = 0;
		products_cookie = NULL;
		while((products_flistp = PIN_FLIST_ELEM_GET_NEXT(hook_rflistp, PIN_FLD_PRODUCTS,
			&products_elemid, 1, &products_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_FLIST_FLD_DROP(products_flistp,PIN_FLD_PRODUCT_OBJ,ebufp);
		}

		discounts_elemid = 0;
		discounts_cookie = NULL;
		while((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(hook_rflistp, PIN_FLD_DISCOUNTS,
			&discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_FLIST_FLD_DROP(discounts_flistp,PIN_FLD_DISCOUNT_OBJ,ebufp);
		}

		if(PIN_FLIST_FLD_GET(hook_rflistp, PIN_FLD_POID, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(hook_rflistp, PIN_FLD_POID, ebufp);
		}

		PIN_FLIST_CONCAT(r_flistp, hook_rflistp, ebufp);
	}

	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	PIN_FLIST_DESTROY_EX(&deal_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&deal_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readobj_rflistp, NULL);
	return;
}
