/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 20-DEC-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_ACCOUNT_INFO operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_get_account_info(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_cust_get_account_info(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_get_account_info_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_get_billinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_pol_get_payinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_cust_get_services(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/**************************************************************************
 * Main routine for the TAB_OP_CUST_GET_ACCOUNT_INFO operation.
 *************************************************************************/
void
op_tab_cust_get_account_info(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_account_info function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_ACCOUNT_INFO) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_account_info bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_account_info input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* Validate the input arguments */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_cust_get_account_info(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_account_info error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_account_info:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_ACCOUNT_INFO;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_ACCOUNT_INFO )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_ACCOUNT_INFO, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_account_info output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to get
 * account related info.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void 
fm_tab_cust_get_account_info(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_payinfo_iflistp = NULL;
	pin_flist_t		*get_payinfo_oflistp = NULL;
	pin_flist_t		*get_serv_details_iflistp = NULL;
	pin_flist_t		*get_serv_details_oflistp = NULL;
	pin_flist_t		*get_billinfo_iflistp = NULL;
	pin_flist_t		*get_billinfo_oflistp = NULL;
	pin_flist_t		*get_profile_iflistp = NULL;
	pin_flist_t		*get_profile_oflistp = NULL;
	pin_flist_t		*account_info_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	poid_t			*account_pdp = NULL;
	poid_t			*bal_grp_pdp = NULL;
	char			*obj_typep = NULL;
	char			*account_nop = NULL;
	char			*msisdnp = NULL;
	pin_flist_t		*r_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_get_account_info input flist", in_flistp);
		
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	
	/*Check for account number or MSISDN*/
	if((account_nop == NULL || strlen(account_nop ) == 0) 
		&& (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	/*Check for mandatory input type*/
	obj_typep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_OBJECT_TYPE, 1, ebufp);

	if(((obj_typep && strlen(obj_typep) == 0)) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_OBJECT_TYPE, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DATALIST_OPTION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Object Type is missing in request", ebufp);
		goto cleanup;
	}
	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	/*Get account level info*/
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	fm_tab_cust_get_account_info_details(ctxp, in_flistp, &account_info_oflistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			" Error while getting account info details", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
			"fm_tab_cust_get_account_info_details output flist", account_info_oflistp);

		if(PIN_FLIST_FLD_GET(account_info_oflistp, PIN_FLD_POID, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(account_info_oflistp, PIN_FLD_POID, ebufp);
		}

		if(account_info_oflistp != NULL)
		{
			PIN_FLIST_CONCAT(r_flistp, account_info_oflistp, ebufp);
		}
	}

	/*Get payment info if the object type is paymentInfo or All*/
	if(obj_typep && (!strncmp(obj_typep, TAB_OBJECT_TYPE_PAYMENT_INFO, strlen(TAB_OBJECT_TYPE_PAYMENT_INFO)) ||
		!strncmp(obj_typep, TAB_OBJECT_TYPE_ALL, strlen(TAB_OBJECT_TYPE_ALL))))
	{
		get_payinfo_iflistp = PIN_FLIST_CREATE(ebufp);

		if(!PIN_POID_IS_NULL(account_pdp))
		{
			PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_POID, account_pdp, ebufp);
		}

		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, get_payinfo_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, get_payinfo_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, get_payinfo_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
			"fm_tab_cust_pol_get_payinfo input flist", get_payinfo_iflistp);

		fm_tab_cust_pol_get_payinfo(ctxp, get_payinfo_iflistp, &get_payinfo_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo:"
				" input flist ", get_payinfo_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo:"
				" Error while getting payinfo details", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
				"fm_tab_cust_pol_get_payinfo output flist", get_payinfo_oflistp);

			if(get_payinfo_oflistp != NULL)
			{
				PIN_FLIST_CONCAT(r_flistp, get_payinfo_oflistp, ebufp);
			}
		}
	}

	/*Get billinfo info if the object type is billUnit or All*/
	if(obj_typep && (!strncmp(obj_typep, TAB_OBJECT_TYPE_BILL_UNIT, strlen(TAB_OBJECT_TYPE_BILL_UNIT)) ||
		!strncmp(obj_typep, TAB_OBJECT_TYPE_ALL, strlen(TAB_OBJECT_TYPE_ALL))))
	{
		get_billinfo_iflistp = PIN_FLIST_CREATE(ebufp);
		bal_grp_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BAL_GRP_OBJ, 1, ebufp);

		if(!PIN_POID_IS_NULL(bal_grp_pdp))
		{
			PIN_FLIST_FLD_SET(get_billinfo_iflistp, PIN_FLD_POID, bal_grp_pdp, ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
			"fm_tab_cust_get_billinfo input flist", get_billinfo_iflistp);

		fm_tab_cust_get_billinfo(ctxp, get_billinfo_iflistp, &get_billinfo_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_billinfo:"
				" input flist ", get_payinfo_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_billinfo:"
				" Error while getting billinfo details", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
				"fm_tab_cust_get_billinfo output flist", get_billinfo_oflistp);

			if(get_billinfo_oflistp != NULL)
			{
				PIN_FLIST_CONCAT(r_flistp, get_billinfo_oflistp, ebufp);
			}
		}
	}

	/*Get service info if the object type is Services or All*/
	if(obj_typep && (!strncmp(obj_typep, TAB_OBJECT_TYPE_SERVICES, strlen(TAB_OBJECT_TYPE_SERVICES)) || 
		!strncmp(obj_typep, TAB_OBJECT_TYPE_ALL, strlen(TAB_OBJECT_TYPE_ALL))))
	{
		get_serv_details_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, get_serv_details_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_serv_details_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
			"fm_tab_cust_get_services input flist", get_serv_details_iflistp);

		fm_tab_cust_get_services(ctxp, get_serv_details_iflistp, &get_serv_details_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services:"
				" input flist ", get_serv_details_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services:"
				" Error while getting service details", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info: "
				"fm_tab_cust_get_services output flist", get_serv_details_oflistp);

			if(get_serv_details_oflistp != NULL)
			{
				PIN_FLIST_CONCAT(r_flistp, get_serv_details_oflistp, ebufp);
			}
		}
	}

	/*Get profile info if the object type is accountProfile or All*/
	if(obj_typep && (!strncmp(obj_typep, TAB_OBJECT_TYPE_ACCOUNT_PROFILE, strlen(TAB_OBJECT_TYPE_ACCOUNT_PROFILE)) ||
		!strncmp(obj_typep, TAB_OBJECT_TYPE_ALL, strlen(TAB_OBJECT_TYPE_ALL))))
	{
		get_profile_iflistp = PIN_FLIST_CREATE(ebufp);
		if(!PIN_POID_IS_NULL(account_pdp))
		{
			PIN_FLIST_FLD_SET(get_profile_iflistp, PIN_FLD_POID, account_pdp, ebufp);
		}

		context_info_flistp = PIN_FLIST_SUBSTR_ADD(get_profile_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_account_info:"
			" TAB_OP_CUST_POL_GET_PROFILE input flist ", get_profile_iflistp);

		PCM_OP(ctxp, TAB_OP_CUST_POL_GET_PROFILE, 0, get_profile_iflistp, &get_profile_oflistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
				" input flist ", get_profile_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
				" Error in getting profile information", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_account_info:"
			" TAB_OP_CUST_POL_GET_PROFILE output flist ", get_profile_oflistp);

		if(get_profile_oflistp != NULL)
		{
			if(PIN_FLIST_FLD_GET(get_profile_oflistp, PIN_FLD_SRC_DATABASE, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(get_profile_oflistp, PIN_FLD_SRC_DATABASE, ebufp);
			}

			if(PIN_FLIST_FLD_GET(get_profile_oflistp, PIN_FLD_POID, 1, ebufp) != NULL)
			{
				PIN_FLIST_FLD_DROP(get_profile_oflistp, PIN_FLD_POID, ebufp);
			}

			PIN_FLIST_CONCAT(r_flistp, get_profile_oflistp, ebufp);
		}
	}
	*out_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_payinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_payinfo_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_serv_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_serv_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_billinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_billinfo_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_profile_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_profile_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&account_info_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_account_info output flist", *out_flistpp);
	return;
}

/**
 * We use this function to get account
 * level fields.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_get_account_info_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*exemptions_flistp = NULL;
	pin_flist_t		*acct_read_flds_iflistp = NULL;
	pin_flist_t		*acct_read_flds_oflistp = NULL;
	pin_flist_t		*bill_grp_get_parent_iflistp = NULL;
	pin_flist_t		*bill_grp_get_parent_oflistp = NULL;
	pin_flist_t		*parent_read_flds_iflistp = NULL;
	pin_flist_t		*parent_read_flds_oflistp = NULL;
	pin_flist_t		*balgrp_read_flds_iflistp = NULL;
	pin_flist_t		*balgrp_read_flds_oflistp = NULL;
	pin_flist_t		*billinfo_read_flds_iflistp = NULL;
	pin_flist_t		*billinfo_read_flds_oflistp = NULL;
	pin_flist_t		*collection_scenario_rflds_iflistp = NULL;
	pin_flist_t		*collection_scenario_rflds_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*account_details_flistp = NULL;
	poid_t			*account_pdp = NULL;
	poid_t			*parent_pdp = NULL;
	poid_t			*bal_grp_pdp = NULL;
	poid_t			*scenario_pdp = NULL;
	poid_t			*billinfo_pdp = NULL;
	pin_decimal_t	*percent = NULL;
	int32			*pay_typep = NULL;
	char			*dunning_created_strp = NULL;
	time_t			*dunning_created_t = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_account_info_details input", i_flistp);

	account_details_flistp = PIN_FLIST_CREATE(ebufp);
	percent = (pin_decimal_t *)pin_decimal("0.0", ebufp);

	account_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);

	if(!PIN_POID_IS_NULL(account_pdp))
	{
		acct_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_POID, account_pdp, ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_GL_SEGMENT, NULL, ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, NULL, ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_BUSINESS_TYPE, NULL, ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_STATUS, NULL, ebufp);
		PIN_FLIST_FLD_SET(acct_read_flds_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);
		exemptions_flistp = PIN_FLIST_ELEM_ADD(acct_read_flds_iflistp, PIN_FLD_EXEMPTIONS, PIN_ELEMID_ANY, ebufp);
		PIN_FLIST_FLD_SET(exemptions_flistp, PIN_FLD_PERCENT, NULL, ebufp);
		PIN_FLIST_ELEM_SET(acct_read_flds_iflistp, NULL, PIN_FLD_NAMEINFO, PIN_ELEMID_ANY, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
			"Read account flds input flist", acct_read_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, acct_read_flds_iflistp, &acct_read_flds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", acct_read_flds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading account object flds", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
				"Read account flds output flist", acct_read_flds_oflistp);

			if(acct_read_flds_oflistp != NULL)
			{
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_POID, 
						account_details_flistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_GL_SEGMENT, 
						account_details_flistp, PIN_FLD_GL_SEGMENT, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, 
						account_details_flistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_BUSINESS_TYPE, 
						account_details_flistp, PIN_FLD_BUSINESS_TYPE, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_STATUS, 
						account_details_flistp, PIN_FLD_STATUS, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_ACCOUNT_NO, 
						account_details_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
				PIN_FLIST_FLD_COPY(acct_read_flds_oflistp, PIN_FLD_NAMEINFO, 
						account_details_flistp, PIN_FLD_NAMEINFO, ebufp);

				if((exemptions_flistp = PIN_FLIST_ELEM_GET(acct_read_flds_oflistp, 
					PIN_FLD_EXEMPTIONS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(exemptions_flistp, PIN_FLD_PERCENT, 
						account_details_flistp, PIN_FLD_PERCENT, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(account_details_flistp, PIN_FLD_PERCENT, percent, ebufp);
				}
			}
		}

		/*Get parent account number*/
		bill_grp_get_parent_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(bill_grp_get_parent_iflistp, PIN_FLD_POID, account_pdp, ebufp);
		context_info_flistp = PIN_FLIST_SUBSTR_ADD(bill_grp_get_parent_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
			"PCM_OP_BILL_GROUP_GET_PARENT input flist", bill_grp_get_parent_iflistp);
		PCM_OP(ctxp,  PCM_OP_BILL_GROUP_GET_PARENT, 0, bill_grp_get_parent_iflistp, &bill_grp_get_parent_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_GROUP_GET_PARENT:"
				" input flist ", bill_grp_get_parent_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while calling PCM_OP_BILL_GROUP_GET_PARENT", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
				"PCM_OP_BILL_GROUP_GET_PARENT output flist", bill_grp_get_parent_oflistp);

			if(bill_grp_get_parent_oflistp != NULL)
			{
				parent_pdp = PIN_FLIST_FLD_GET(bill_grp_get_parent_oflistp, PIN_FLD_PARENT, 1, ebufp);

				if(!PIN_POID_IS_NULL(parent_pdp))
				{
					/*Get Parent Account Number*/
					parent_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_SET(parent_read_flds_iflistp, PIN_FLD_POID, parent_pdp, ebufp);
					PIN_FLIST_FLD_SET(parent_read_flds_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
						"Read parent account flds input flist", parent_read_flds_iflistp);
					PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, parent_read_flds_iflistp, &parent_read_flds_oflistp, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
							" parent input flist ", parent_read_flds_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
							" Error while reading parent account object flds", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
							"Read parent account flds output flist", parent_read_flds_oflistp);

						if(parent_read_flds_oflistp != NULL)
						{
							PIN_FLIST_FLD_COPY(parent_read_flds_oflistp, PIN_FLD_ACCOUNT_NO, 
									account_details_flistp, TAB_FLD_PARENT_ACT_NO, ebufp);
						}
					}
				}
			}
		}
	}
   
	bal_grp_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_BAL_GRP_OBJ, 1, ebufp);

	if(!PIN_POID_IS_NULL(bal_grp_pdp))
	{
		balgrp_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(balgrp_read_flds_iflistp, PIN_FLD_POID, bal_grp_pdp, ebufp);
		PIN_FLIST_FLD_SET(balgrp_read_flds_iflistp, PIN_FLD_BILLINFO_OBJ, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
			"Read balgrp flds input flist", balgrp_read_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, balgrp_read_flds_iflistp, &balgrp_read_flds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", balgrp_read_flds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading balgrp object flds", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
				"Read balgrp flds output flist", balgrp_read_flds_oflistp);

			billinfo_pdp = PIN_FLIST_FLD_GET(balgrp_read_flds_oflistp, PIN_FLD_BILLINFO_OBJ, 1, ebufp);
			if(balgrp_read_flds_oflistp != NULL && !PIN_POID_IS_NULL(billinfo_pdp))
			{
				billinfo_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_POID, billinfo_pdp, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_COLLECTION_DATE, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_SCENARIO_OBJ, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_PAY_TYPE, NULL, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
					"Read billinfo flds input flist", billinfo_read_flds_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, billinfo_read_flds_iflistp, &billinfo_read_flds_oflistp, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" input flist ", billinfo_read_flds_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" Error while reading billinfo object flds", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
						"Read billinfo flds output flist", billinfo_read_flds_oflistp);
					
					if(billinfo_read_flds_oflistp != NULL)
					{
						pay_typep = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
						if(pay_typep && (*pay_typep != PIN_PAY_TYPE_PREPAID))
						{
							scenario_pdp = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, PIN_FLD_SCENARIO_OBJ, 1, ebufp);							
							if(!PIN_POID_IS_NULL(scenario_pdp))
							{
								PIN_FLIST_FLD_SET(account_details_flistp, TAB_FLD_DUNNING_STATUS,
									TAB_DUNNING_STATUS_YES, ebufp);
								/*
									C400171354-1127
									dunningStartDate = scenario.created_t --> TAB_FLD_DUNNING_START_DATE
									dunningStartDate being copied in response
								*/
								collection_scenario_rflds_iflistp = PIN_FLIST_CREATE(ebufp);
								PIN_FLIST_FLD_SET(collection_scenario_rflds_iflistp, PIN_FLD_POID, scenario_pdp, ebufp);
								PIN_FLIST_FLD_SET(collection_scenario_rflds_iflistp, PIN_FLD_CREATED_T, NULL, ebufp);

								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
									"read collection scenario rflds input flist", collection_scenario_rflds_iflistp);
								PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, collection_scenario_rflds_iflistp, 
										&collection_scenario_rflds_oflistp, ebufp);

								if(PIN_ERR_IS_ERR(ebufp))
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
										"collection input flist ", collection_scenario_rflds_iflistp);
									PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
										" Error while reading collection scenario rflds input", ebufp);
									PIN_FLIST_DESTROY_EX(&collection_scenario_rflds_iflistp, NULL);
									PIN_FLIST_DESTROY_EX(&collection_scenario_rflds_oflistp, NULL);
									goto cleanup;
								}
								else
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_info_details: "
										"read collection scenario rflds output", collection_scenario_rflds_oflistp);
									if(collection_scenario_rflds_oflistp != NULL)
									{
										dunning_created_t = PIN_FLIST_FLD_GET(collection_scenario_rflds_oflistp, 
												PIN_FLD_CREATED_T, 1, ebufp);
										dunning_created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
												dunning_created_t, ebufp);
										PIN_FLIST_FLD_PUT(account_details_flistp, TAB_FLD_DUNNING_START_DATE, 
												dunning_created_strp, ebufp);
									}
								}
								PIN_FLIST_DESTROY_EX(&collection_scenario_rflds_iflistp, NULL);
								PIN_FLIST_DESTROY_EX(&collection_scenario_rflds_oflistp, NULL);
							}
							else
							{
								PIN_FLIST_FLD_SET(account_details_flistp, TAB_FLD_DUNNING_STATUS, 
									TAB_DUNNING_STATUS_NO, ebufp);
							}
						}
					}
				}
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&balgrp_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acct_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_grp_get_parent_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&parent_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acct_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_grp_get_parent_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&parent_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&balgrp_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_read_flds_oflistp, NULL);

	if(percent != NULL)
	{
		pin_decimal_destroy(percent);
	}

	*r_flistpp = account_details_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_account_info_details output flist", *r_flistpp);

	return;
}

/**
 * We use this function to get account's
 * payinfo details.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_pol_get_payinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_billinfo_details_oflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*payinfo_details_flistp = NULL;
	pin_flist_t		*payinfo_read_obj_iflistp = NULL;
	pin_flist_t		*payinfo_read_obj_oflistp = NULL;
	pin_flist_t		*get_payinfo_iflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*payinfo_flistp = NULL;
	poid_t			*payinfo_pdp = NULL;
	int32			*pay_typep = NULL;
	time_t			*created_t = NULL;
	char			*created_strp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_pol_get_payinfo input", i_flistp);

	/*Get profile subscriber preferences*/
	fm_tab_utils_common_get_owner_billinfo_details(ctxp, i_flistp, 
			&get_billinfo_details_oflistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
			" input flist ", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
			" Error while getting billinfo details", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_pol_get_payinfo: "
			"fm_tab_utils_common_get_owner_billinfo_details output flist", get_billinfo_details_oflistp);

		if(get_billinfo_details_oflistp != NULL && (results_flistp = PIN_FLIST_ELEM_GET(get_billinfo_details_oflistp,  
			PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			payinfo_pdp = PIN_FLIST_FLD_GET(results_flistp, PIN_FLD_PAYINFO_OBJ, 1, ebufp);

			pay_typep = PIN_FLIST_FLD_GET(results_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

			if(!PIN_POID_IS_NULL(payinfo_pdp))
			{
				payinfo_read_obj_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(payinfo_read_obj_iflistp, PIN_FLD_POID, payinfo_pdp, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_cust_pol_get_payinfo: Read payinfo obj input flist", payinfo_read_obj_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, payinfo_read_obj_iflistp, &payinfo_read_obj_oflistp, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ:"
						" input flist ", payinfo_read_obj_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ:"
						" Error while reading payinfo object", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_pol_get_payinfo: "
						"Read payinfo obj output flist", payinfo_read_obj_oflistp);

					if(payinfo_read_obj_oflistp != NULL)
					{
						if(pay_typep && (*pay_typep == PIN_PAY_TYPE_PREPAID || 
							*pay_typep == PIN_PAY_TYPE_INVOICE))
						{
							payinfo_details_flistp = PIN_FLIST_CREATE(ebufp);

							if(PIN_FLIST_FLD_GET(payinfo_read_obj_oflistp, PIN_FLD_POID, 1, ebufp) != NULL)
							{
								PIN_FLIST_FLD_DROP(payinfo_read_obj_oflistp, PIN_FLD_POID, ebufp);
							}

							payinfo_flistp = PIN_FLIST_ELEM_ADD(payinfo_details_flistp, PIN_FLD_PAYINFO, 0, ebufp);

							created_t = PIN_FLIST_FLD_GET(payinfo_read_obj_oflistp, 
									PIN_FLD_CREATED_T, 1, ebufp);
							if(created_t != NULL && *created_t != 0)
							{
								created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
										created_t, ebufp);
								PIN_FLIST_FLD_PUT(payinfo_flistp, TAB_FLD_CREATED_T_STR, 
										created_strp, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(payinfo_flistp, TAB_FLD_CREATED_T_STR, "", ebufp);
							}

							PIN_FLIST_FLD_COPY(payinfo_read_obj_oflistp, PIN_FLD_PAYMENT_OFFSET, 
									payinfo_flistp, PIN_FLD_PAYMENT_OFFSET, ebufp);
							PIN_FLIST_FLD_COPY(payinfo_read_obj_oflistp, PIN_FLD_PAYMENT_TERM, 
									payinfo_flistp, PIN_FLD_PAYMENT_TERM, ebufp);
							PIN_FLIST_FLD_SET(payinfo_flistp, PIN_FLD_PAY_TYPE, pay_typep, ebufp);
						}

						if(pay_typep && (*pay_typep == PIN_PAY_TYPE_CC || 
							*pay_typep == PIN_PAY_TYPE_DD || *pay_typep == TAB_PAY_TYPE_AUTOPAY))
						{
							get_payinfo_iflistp = PIN_FLIST_CREATE(ebufp);

							if(!PIN_POID_IS_NULL(payinfo_pdp))
							{
								PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_POID, payinfo_pdp, ebufp);
							}

							context_info_flistp = PIN_FLIST_SUBSTR_ADD(get_payinfo_iflistp, 
									PIN_FLD_CONTEXT_INFO, ebufp);
							PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, 
									context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
							PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, 
									context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_get_payinfo:"
								" TAB_OP_CUST_POL_GET_PAYINFO input flist ", get_payinfo_iflistp);

							PCM_OP(ctxp, TAB_OP_CUST_POL_GET_PAYINFO, 0, get_payinfo_iflistp, &payinfo_details_flistp, ebufp);

							if (PIN_ERR_IS_ERR(ebufp))
							{
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo:"
									" input flist ", get_payinfo_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_get_payinfo:"
									" Error in getting payinfo information", ebufp);
								*r_flistpp = payinfo_details_flistp;
								goto cleanup;
							}

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_get_payinfo:"
								" TAB_OP_CUST_POL_GET_PAYINFO output flist ", payinfo_details_flistp);

							if(payinfo_details_flistp != NULL)
							{
								if(PIN_FLIST_FLD_GET(payinfo_details_flistp, PIN_FLD_SRC_DATABASE, 1, ebufp) != NULL)
								{
									PIN_FLIST_FLD_DROP(payinfo_details_flistp, PIN_FLD_SRC_DATABASE, ebufp);
								}
								if(PIN_FLIST_FLD_GET(payinfo_details_flistp, PIN_FLD_POID, 1, ebufp) != NULL)
								{
									PIN_FLIST_FLD_DROP(payinfo_details_flistp, PIN_FLD_POID, ebufp);
								}
							}
						}
					}
				}
			}
		}
	}

	*r_flistpp = payinfo_details_flistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_billinfo_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&payinfo_read_obj_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&payinfo_read_obj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_payinfo_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_pol_get_payinfo output flist", *r_flistpp);

	return;
}

/**
 * We use this function to get account's
 * billinfo details.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_get_billinfo(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balgrp_read_flds_iflistp = NULL;
	pin_flist_t		*balgrp_read_flds_oflistp = NULL;
	pin_flist_t		*billinfo_read_flds_iflistp = NULL;
	pin_flist_t		*billinfo_read_flds_oflistp = NULL;
	pin_flist_t		*billinfo_details_flistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	poid_t			*bal_grp_pdp = NULL;
	poid_t			*billinfo_pdp = NULL;
	time_t			*next_bill_t = NULL;
	time_t			*future_bill_t = NULL;
	time_t			*last_bill_t = NULL;
	time_t			*collection_date_t = NULL;
	char			*collection_date_strp = NULL; 
	char			*future_bill_strp = NULL;
	char			*last_bill_strp = NULL;
	char			*next_bill_strp = NULL;
	int32			*pay_typep = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_billinfo error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_billinfo:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_billinfo input", i_flistp);

	billinfo_details_flistp = PIN_FLIST_CREATE(ebufp);	

	bal_grp_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);

	if(!PIN_POID_IS_NULL(bal_grp_pdp))
	{
		balgrp_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(balgrp_read_flds_iflistp, PIN_FLD_POID, bal_grp_pdp, ebufp);
		PIN_FLIST_FLD_SET(balgrp_read_flds_iflistp, PIN_FLD_BILLINFO_OBJ, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_billinfo: "
			"Read balgrp flds input flist", balgrp_read_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, balgrp_read_flds_iflistp, &balgrp_read_flds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", balgrp_read_flds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading balgrp object flds", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_billinfo: "
				"Read balgrp flds output flist", balgrp_read_flds_oflistp);

			billinfo_pdp = PIN_FLIST_FLD_GET(balgrp_read_flds_oflistp, PIN_FLD_BILLINFO_OBJ, 1, ebufp);

			if(balgrp_read_flds_oflistp != NULL && !PIN_POID_IS_NULL(billinfo_pdp))
			{
				billinfo_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_POID, billinfo_pdp, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_COLLECTION_DATE, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_PAY_TYPE, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_ACTG_CYCLE_DOM, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_BILL_WHEN, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_BILLING_SEGMENT, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_FUTURE_BILL_T, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_LAST_BILL_T, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_NEXT_BILL_T, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_EXEMPT_FROM_COLLECTIONS, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_BILL_ACTGCYCLES_LEFT, NULL, ebufp);
				PIN_FLIST_FLD_SET(billinfo_read_flds_iflistp, PIN_FLD_ACTG_TYPE, NULL, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_billinfo: "
					"Read billinfo flds input flist", billinfo_read_flds_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, billinfo_read_flds_iflistp, 
					&billinfo_read_flds_oflistp, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" input flist ", billinfo_read_flds_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" Error while reading billinfo object flds", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_billinfo: "
						"Read billinfo flds output flist", billinfo_read_flds_oflistp);

					if(billinfo_read_flds_oflistp != NULL)
					{
						if(PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, PIN_FLD_POID, 1, ebufp) != NULL)
						{
							PIN_FLIST_FLD_DROP(billinfo_read_flds_oflistp, PIN_FLD_POID, ebufp);
						}

						billinfo_flistp = PIN_FLIST_ELEM_ADD(billinfo_details_flistp, 
								PIN_FLD_BILLINFO, 0, ebufp);				
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_PAY_TYPE, 
								billinfo_flistp, PIN_FLD_PAY_TYPE, ebufp);
						/*
							C400171354-1127
							collectionDate = billinfo.collection_date --> TAB_FLD_COLLECTION_DATE_STR
							collectionDate being copied in response
						*/	
						pay_typep = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
						if(pay_typep && (*pay_typep != PIN_PAY_TYPE_PREPAID))
						{
							collection_date_t = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, 
									PIN_FLD_COLLECTION_DATE, 1, ebufp);
							collection_date_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
									collection_date_t, ebufp);
							PIN_FLIST_FLD_PUT(billinfo_flistp, TAB_FLD_COLLECTION_DATE_STR, 
									collection_date_strp, ebufp);	
						}									
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_PAY_TYPE, 
								billinfo_flistp, PIN_FLD_PAY_TYPE, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_ACTG_CYCLE_DOM, 
								billinfo_flistp, PIN_FLD_ACTG_CYCLE_DOM, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_BILL_WHEN, 
								billinfo_flistp, PIN_FLD_BILL_WHEN, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_BILLING_SEGMENT, 
								billinfo_flistp, PIN_FLD_BILLING_SEGMENT, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_EXEMPT_FROM_COLLECTIONS, 
								billinfo_flistp, PIN_FLD_EXEMPT_FROM_COLLECTIONS, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_BILL_ACTGCYCLES_LEFT, 
								billinfo_flistp, PIN_FLD_BILL_ACTGCYCLES_LEFT, ebufp);
						PIN_FLIST_FLD_COPY(billinfo_read_flds_oflistp, PIN_FLD_ACTG_TYPE, 
								billinfo_flistp, PIN_FLD_ACTG_TYPE, ebufp);


						future_bill_t = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, 
								PIN_FLD_FUTURE_BILL_T, 1, ebufp);
						if(future_bill_t != NULL && *future_bill_t != 0)
						{
							future_bill_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
									future_bill_t, ebufp);
							PIN_FLIST_FLD_PUT(billinfo_flistp, TAB_FLD_FUTURE_BILL_T_STR, 
									future_bill_strp, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(billinfo_flistp, TAB_FLD_FUTURE_BILL_T_STR, "", ebufp);
						}

						last_bill_t = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, 
								PIN_FLD_LAST_BILL_T, 1, ebufp);
						if(last_bill_t != NULL && *last_bill_t != 0)
						{
							last_bill_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
									last_bill_t, ebufp);
							PIN_FLIST_FLD_PUT(billinfo_flistp, TAB_FLD_LAST_BILL_T_STR, 
									last_bill_strp, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(billinfo_flistp, TAB_FLD_LAST_BILL_T_STR, "", ebufp);
						}

						next_bill_t = PIN_FLIST_FLD_GET(billinfo_read_flds_oflistp, 
								PIN_FLD_NEXT_BILL_T, 1, ebufp);
						if(next_bill_t != NULL && *next_bill_t != 0)
						{
							next_bill_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
									next_bill_t, ebufp);
							PIN_FLIST_FLD_PUT(billinfo_flistp, TAB_FLD_NEXT_BILL_T_STR, 
									next_bill_strp, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(billinfo_flistp, TAB_FLD_NEXT_BILL_T_STR, "", ebufp);
						}

					}
				}
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&billinfo_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&balgrp_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&balgrp_read_flds_oflistp, NULL);

	*r_flistpp = billinfo_details_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_billinfo output flist", *r_flistpp);

	return;
}


/**
 * We use this function to get account's
 * service details.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_cust_get_services(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*service_read_flds_iflistp = NULL;
	pin_flist_t		*service_read_flds_oflistp = NULL;
	pin_flist_t		*primary_srv_read_flds_iflistp = NULL;
	pin_flist_t		*primary_srv_read_flds_oflistp = NULL;
	pin_flist_t		*alias_list_flistp = NULL;
	pin_flist_t		*service_details_flistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*get_profile_sub_prefs_oflistp = NULL;
	pin_flist_t		*get_profile_multisim_map_oflistp = NULL;
	pin_flist_t		*service_details_rflistp = NULL;
	time_t			*last_status_t =	 NULL;
	time_t			*srv_state_exp_t =	 NULL;
	time_t			*effective_t = NULL;
	char			service_str[10];
	char			*last_stat_cmtp = NULL;
	char			*last_status_strp = NULL;
	char			*srv_state_exp_strp = NULL;
	char			*effective_strp = NULL;
	poid_t			*service_pdp = NULL;
	int32			*service_status = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_services input", i_flistp);

	service_details_flistp = PIN_FLIST_CREATE(ebufp);	

	service_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POID, 1, ebufp);

	if(!PIN_POID_IS_NULL(service_pdp))
	{
		services_flistp = PIN_FLIST_ELEM_ADD(service_details_flistp, PIN_FLD_SERVICES, 0, ebufp);

		/*Get profile multi sim map*/
		/*fm_tab_utils_common_get_profile_multisim_map(ctxp, i_flistp, 
		  &get_profile_multisim_map_oflistp, db_no, ebufp);*/

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_multisim_map:"
				" input flist ", i_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_multisim_map:"
				" Error while getting profile multi sim map object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
				"fm_tab_utils_common_get_profile_multisim_map output flist", get_profile_multisim_map_oflistp);

			if(get_profile_multisim_map_oflistp != NULL && (results_flistp = 
				PIN_FLIST_ELEM_GET(get_profile_multisim_map_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				primary_srv_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_SERVICE_OBJ, 
					primary_srv_read_flds_iflistp, PIN_FLD_POID, ebufp);
				alias_list_flistp = PIN_FLIST_ELEM_ADD(primary_srv_read_flds_iflistp, PIN_FLD_ALIAS_LIST, 
					PIN_ELEMID_ANY, ebufp);
				PIN_FLIST_FLD_SET(alias_list_flistp, PIN_FLD_NAME, NULL, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
					"Read primary service flds input flist", service_read_flds_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, primary_srv_read_flds_iflistp, &primary_srv_read_flds_oflistp, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Primary service PCM_OP_READ_FLDS:"
						" input flist ", primary_srv_read_flds_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" Error while reading primary service object flds", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
						"Read primary service flds output flist", primary_srv_read_flds_oflistp);

					if(primary_srv_read_flds_oflistp != NULL)
					{
						if ((alias_list_flistp = PIN_FLIST_ELEM_GET(primary_srv_read_flds_oflistp, 
							PIN_FLD_ALIAS_LIST, 0, 1, ebufp)) != NULL)
						{
							PIN_FLIST_FLD_COPY(alias_list_flistp, PIN_FLD_NAME, 
								services_flistp, TAB_FLD_PRIMARY_MSISDN, ebufp);
						}
					}
				}

			}
			else
			{
				PIN_FLIST_FLD_SET(services_flistp, TAB_FLD_PRIMARY_MSISDN, "", ebufp);
			}
		}

		service_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_POID, service_pdp, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_STATUS, NULL, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_LIFECYCLE_STATE, NULL, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_LAST_STATUS_T, NULL, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_LASTSTAT_CMNT, NULL, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_EFFECTIVE_T, NULL, ebufp);
		PIN_FLIST_FLD_SET(service_read_flds_iflistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, NULL, ebufp);
		alias_list_flistp = PIN_FLIST_ELEM_ADD(service_read_flds_iflistp, PIN_FLD_ALIAS_LIST, 
				PIN_ELEMID_ANY, ebufp);
		PIN_FLIST_FLD_SET(alias_list_flistp, PIN_FLD_NAME, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
			"Read service flds input flist", service_read_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, service_read_flds_iflistp, &service_read_flds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", service_read_flds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading service object flds", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
				"Read service flds output flist", service_read_flds_oflistp);

			if(service_read_flds_oflistp != NULL)
			{
				if ((alias_list_flistp = PIN_FLIST_ELEM_GET(service_read_flds_oflistp, 
					PIN_FLD_ALIAS_LIST, 0, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(alias_list_flistp, PIN_FLD_NAME, 
						services_flistp, PIN_FLD_MSISDN, ebufp);
				}

				if ((alias_list_flistp = PIN_FLIST_ELEM_GET(service_read_flds_oflistp, 
					PIN_FLD_ALIAS_LIST, 1, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(alias_list_flistp, PIN_FLD_NAME, 
						services_flistp, PIN_FLD_IMSI, ebufp);
				}

				/*Add service status*/
				service_status = PIN_FLIST_FLD_GET(service_read_flds_oflistp, PIN_FLD_STATUS, 1, ebufp);
				if(service_status != NULL)
				{
					memset(service_str, '\0', sizeof(service_str));
					snprintf(service_str, sizeof(service_str), "%d", *service_status);

					if(service_str != NULL)
					{
						PIN_FLIST_FLD_SET(services_flistp, PIN_FLD_SERVICE_STATUS, service_str, ebufp);
					}
				}

				last_stat_cmtp = PIN_FLIST_FLD_GET(service_read_flds_oflistp, PIN_FLD_LASTSTAT_CMNT, 1, ebufp);

				if(last_stat_cmtp != NULL && strlen(last_stat_cmtp) != 0)
				{
					PIN_FLIST_FLD_SET(services_flistp, PIN_FLD_REASON_CODE, last_stat_cmtp, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(services_flistp, PIN_FLD_REASON_CODE, "", ebufp);
				}

				PIN_FLIST_FLD_COPY(service_read_flds_oflistp, PIN_FLD_LIFECYCLE_STATE, 
						services_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);

				last_status_t = PIN_FLIST_FLD_GET(service_read_flds_oflistp, 
						PIN_FLD_LAST_STATUS_T, 1, ebufp);
				if(last_status_t != NULL && *last_status_t != 0)
				{
					last_status_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
							last_status_t, ebufp);
					PIN_FLIST_FLD_PUT(services_flistp, TAB_FLD_LAST_STATUS_STR, 
							last_status_strp, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(services_flistp, TAB_FLD_LAST_STATUS_STR, "", ebufp);
				}

				srv_state_exp_t = PIN_FLIST_FLD_GET(service_read_flds_oflistp, 
						PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
				if(srv_state_exp_t != NULL && *srv_state_exp_t != 0)
				{
					srv_state_exp_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
							srv_state_exp_t, ebufp);
					PIN_FLIST_FLD_PUT(services_flistp, PIN_FLD_VALID_TO_STR, 
							srv_state_exp_strp, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(services_flistp, PIN_FLD_VALID_TO_STR, "", ebufp);
				}

				effective_t = PIN_FLIST_FLD_GET(service_read_flds_oflistp, 
						PIN_FLD_EFFECTIVE_T, 1, ebufp);
				if(effective_t != NULL && *effective_t != 0)
				{
					effective_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
							effective_t, ebufp);
					PIN_FLIST_FLD_PUT(services_flistp, TAB_FLD_EFFECTIVE_T_STR, 
							effective_strp, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_SET(services_flistp, TAB_FLD_EFFECTIVE_T_STR, "", ebufp);
				}
			}

			/*Get profile subscriber preferences*/
			fm_tab_utils_common_get_profile_sub_preferences(ctxp, i_flistp, 
				&get_profile_sub_prefs_oflistp, db_no, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_sub_preferences:"
					" input flist ", i_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_profile_sub_preferences:"
					" Error while getting profile subscriber preferences object", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_services: "
					"fm_tab_utils_common_get_profile_sub_preferences output flist", get_profile_sub_prefs_oflistp);

				if(get_profile_sub_prefs_oflistp != NULL && (results_flistp = PIN_FLIST_ELEM_GET(get_profile_sub_prefs_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_SUBSCRIBER_PREFERENCES, 
						services_flistp, PIN_FLD_SUBSCRIBER_PREFERENCES, ebufp);
				}
			}

		}

		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
			service_details_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, 
			service_details_flistp, PIN_FLD_POID, ebufp);

		PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_GET_SERVICES, 0, service_details_flistp, &service_details_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_ACCOUNT_INFO, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services:"
				" pol_enrich_services input flist ", service_details_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_services:"
				" Error in getting services information", ebufp);
			*r_flistpp = service_details_rflistp;
			goto cleanup;
		}

		if(PIN_FLIST_FLD_GET(service_details_rflistp, PIN_FLD_POID, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(service_details_rflistp, PIN_FLD_POID, ebufp);
		}

		if(PIN_FLIST_FLD_GET(service_details_rflistp, PIN_FLD_SERVICE_OBJ, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(service_details_rflistp, PIN_FLD_SERVICE_OBJ, ebufp);
		}
	}

	*r_flistpp = service_details_rflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&service_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_profile_sub_prefs_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&service_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&primary_srv_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&primary_srv_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&service_details_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_profile_multisim_map_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_services output flist", *r_flistpp);

	return;
}
