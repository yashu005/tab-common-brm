/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 13-DEC-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_CANCEL_OFFER operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "pin_bill.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/

EXPORT_OP void 
op_tab_cust_cancel_offer(
	cm_nap_connection_t 	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_cust_cancel_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int			notify_flag,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_cancel_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_to_cancel_bundle_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
static void
fm_tab_cust_pol_post_cancel_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);
	
/*Extern Functions*/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern time_t 
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**************************************************************************
 * Main routine for the TAB_OP_CUST_CANCEL_OFFER operation.
 *************************************************************************/
void
op_tab_cust_cancel_offer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_cancel_offer function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_CANCEL_OFFER) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_offer bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_cancel_offer input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_OFFER, ebufp);
		}
        fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_cancel_offer(ctxp, enrich_iflistp, &r_flistp, db_no, TAB_NOTIFY_ENABLE, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_offer error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_cust_cancel_offer:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_cancel_offer: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_CANCEL_OFFER", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_cancel_offer:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_OFFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp); 

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_OFFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_OFFER, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_OUT_FLIST, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, PIN_FLD_OUT_FLIST, PIN_ELEMID_ANY, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);//SH
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_cancel_offer output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to purchase
 * product and discount offerings.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_cust_cancel_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int			notify_flag,
	pin_errbuf_t		*ebufp)
{
	char			*package_namep = NULL;
	char			*unique_idp = NULL;
	char			*prod_unique_idp = NULL;
	char			*disc_unique_idp = NULL;
	char			*end_date_strp = NULL;
	char			*start_date_strp = NULL;
	char			*account_nop = NULL;
	pin_cookie_t		products_cookie = NULL;
	pin_cookie_t		package_cookie = NULL;
	pin_cookie_t		discounts_cookie = NULL;
	pin_cookie_t		deal_cookie = NULL;
	pin_cookie_t		prod_cookie = NULL;
	pin_cookie_t		disc_cookie = NULL;
	pin_cookie_t		bundle_cookie = NULL;
	
	pin_flist_t		*package_flistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*pur_bundle_flistp = NULL;
	pin_flist_t		*get_pur_bundle_iflistp = NULL;
	pin_flist_t		*get_pur_bundle_oflistp = NULL;
	pin_flist_t		*cancel_pur_bundle_iflistp = NULL;
	pin_flist_t		*cancel_pur_bundle_oflistp = NULL;
	pin_flist_t		*get_purchased_offerings_iflistp = NULL;
	pin_flist_t		*get_purchased_offerings_oflistp = NULL;
	pin_flist_t		*bundle_info_flistp = NULL;
	pin_flist_t		*products_flistp = NULL;
	pin_flist_t		*discounts_flistp = NULL;
	pin_flist_t		*set_prodinfo_iflistp = NULL;
	pin_flist_t		*set_prodinfo_oflistp = NULL;
	pin_flist_t		*set_prod_flistp = NULL;
	pin_flist_t		*set_discinfo_iflistp = NULL;
	pin_flist_t		*set_discinfo_oflistp = NULL;
	pin_flist_t		*set_disc_flistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*temp_input_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*package_info_flistp = NULL;
	pin_flist_t		*cancel_offer_rdata_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*deal_elem_flistp = NULL;
	pin_flist_t		*deal_flistp = NULL;
	pin_flist_t		*cancel_deal_iflistp = NULL;
	pin_flist_t		*cancel_deal_oflistp = NULL;
	pin_flist_t		*deal_info_flistp = NULL;
	pin_flist_t		*write_iflistp = NULL;	
	pin_flist_t		*write_oflistp = NULL;
	pin_flist_t 		*enrich_canel_offer_flistp=NULL;
	pin_flist_t		*rd_iflistp = NULL;
	pin_flist_t		*rd_rflistp = NULL;
	pin_flist_t		*cancel_prod_iflistp = NULL;
	pin_flist_t		*cancel_prod_oflistp = NULL;
	pin_flist_t		*cancel_disc_iflistp = NULL;
	pin_flist_t		*cancel_disc_oflistp = NULL;
	pin_flist_t		*prod_array_flistp = NULL;
	pin_flist_t		*disc_array_flistp = NULL;
	pin_flist_t		*status_args_flistp = NULL;
	pin_flist_t		*prod_elem_flistp = NULL;
	pin_flist_t		*disc_elem_flistp = NULL;
	pin_flist_t		*posthook_rflistp = NULL;	
	int32			discounts_elemid = 0;
	int32			*prod_package_idp = NULL;
	int32			*disc_package_idp = NULL;
	int32			*package_idp = NULL;
	int32			package_elemid = 0;
	int32			products_elemid = 0;
	int32			deal_elemid = 0;
	int32			deal_count = 0;
	int32			bundle_elemid=0;
	int32			deal_matched = 0;
	int32			*package_flags = NULL;
	int32			prod_elemid = 0;
	int32			disc_elemid = 0;
	int32			prod_count = 0;
	int32			disc_count = 0;
	int32			package_counter = 0;
	int             	*statusp = NULL;
	int			bundle_status = PIN_BUNDLE_STATUS_CANCELLED;
	int			status_flag = PIN_SUBS_FLG_OFFERING_STATUS_ACTIVE+PIN_SUBS_FLG_OFFERING_STATUS_INACTIVE;
	int			closed_bundle_flag = 0;
	int			cancel_status = PIN_STATUS_CLOSED;
	int			cancel_status_flag = 0;
	time_t			now_t = pin_virtual_time(NULL);
	time_t			*valid_from_t =	 NULL;
	time_t			end_t = 0;
	time_t 			start_t = 0;
	poid_t			*pur_bundle_pdp = NULL;
	poid_t			*deal_pdp = NULL;
	poid_t			*deal_elem_pdp = NULL;
	poid_t			*cancel_dealpdp = NULL;
	poid_t			*plan_pdp = NULL;
	poid_t			*actual_plan_pdp = NULL;
	poid_t			*notify_pdp = NULL;
	poid_t			*service_pdp = NULL;
	poid_t			*service_objpdp = NULL;
	char			log_msg[512]= "";
	pin_errbuf_t    local_ebuf = {0} ;
        pin_errbuf_t    *local_ebufp = &local_ebuf;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_cust_cancel_offer input flist", in_flistp);

        /*Account Number not passed in input*/
        account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

        if((account_nop && strlen(account_nop) == 0) ||
                (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
        {
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
                        "Account Number is not passed in request", ebufp);
                goto cleanup;
        }
 	
	/* Checking Service status as Can not add a deal into an non active service*/
	service_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
	rd_iflistp = PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_POID, service_pdp, ebufp);
	PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_STATUS, NULL, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_purchase_offer read_flds input flist", rd_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, rd_iflistp, &rd_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_offer: "
			"PCM_OP_READ_OBJ input flist", rd_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
			"PCM_OP_READ_OBJ error", ebufp);
		goto cleanup;
	}
	//PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);---SH
	if (rd_rflistp !=NULL)
	{
		statusp = PIN_FLIST_FLD_GET(rd_rflistp, PIN_FLD_STATUS, 0, ebufp);
		if(statusp && *statusp != PIN_STATUS_ACTIVE)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NON_ACTIVE_SERVICE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_purchase_offer:"
				"Can not add a deal into an inactive/ closed service", ebufp);
			goto cleanup;
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
		" TAB_OP_CUST_POL_ENRICH_CANCEL_OFFER input flist ", in_flistp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_ENRICH_CANCEL_OFFER, 0, in_flistp, &enrich_canel_offer_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_offer:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_offer:"
			" Error in TAB_OP_CUST_POL_ENRICH_CANCEL_OFFER", ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrich_canel_offer_flistp, local_ebufp);//SH
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
		" TAB_OP_CUST_POL_ENRICH_CANCEL_OFFER output flist ", enrich_canel_offer_flistp);	

	/*Moved out of loop for DTAC bug DBILLING-1573 start*/
	/*Get all the purchased offerings based on input params */

	get_purchased_offerings_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,
		get_purchased_offerings_iflistp, PIN_FLD_POID, ebufp);
	/* CDIGI-12704
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ,
		get_purchased_offerings_iflistp, PIN_FLD_SCOPE_OBJ, ebufp);
	*/
	PIN_FLIST_FLD_SET(get_purchased_offerings_iflistp,
		PIN_FLD_STATUS_FLAGS, &status_flag, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
		"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS input", get_purchased_offerings_iflistp);

	PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS, 0, get_purchased_offerings_iflistp,
		&get_purchased_offerings_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS:"
			" input flist ", get_purchased_offerings_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS:"
			" Error while searching purchased offerings", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
		"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS output", get_purchased_offerings_oflistp);

	/*Moved out of loop for DTAC bug DBILLING-1573 end*/

	cancel_offer_rdata_flistp = PIN_FLIST_CREATE(ebufp);

	while ((package_flistp = PIN_FLIST_ELEM_GET_NEXT(enrich_canel_offer_flistp, PIN_FLD_PACKAGE_INFO, 
		&package_elemid, 1, &package_cookie, ebufp)) != (pin_flist_t *)NULL)
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
		"package_flistp output", package_flistp);

		pur_bundle_pdp = NULL;
		end_t = 0;
		start_t = 0;
		end_date_strp = NULL;
		package_counter = 1;
		
		/*Check for mandatory package name field*/
		package_namep = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_NAME, 1, ebufp);

		if(((package_namep && strlen(package_namep) == 0)) || 
			(PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_PACKAGE_INFO, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				"Package name is missing in request", ebufp);
			goto cleanup;
		}

		/*Check for mandatory package id field*/
		package_idp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);

		if((PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp) == NULL))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_PACKAGE_INFO, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				"Package id is missing in request", ebufp);
			goto cleanup;
		}
		
		unique_idp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_UNIQUE_ID, 1, ebufp);
		package_flags = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_FLAGS, 1, ebufp);

		/*Check for mandatory unique id field*/
		//Commented for Bug id CTP-14334
		/*
		if(((unique_idp && strlen(unique_idp) == 0)) || 
			(PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_UNIQUE_ID, 1, ebufp) == NULL))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_PACKAGE_INFO, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				"Unique id is missing in request", ebufp);
			goto cleanup;
		}*/

		end_date_strp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp);
		
		if(end_date_strp != NULL)
		{
			end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_date_strp, ebufp);
		}

		start_date_strp = PIN_FLIST_FLD_GET(package_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp);
		
		if(start_date_strp != NULL)
		{
			start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, start_date_strp, ebufp);
		}

		/*Fetch purchased bundle object based on package name*/
		get_pur_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME, get_pur_bundle_iflistp, PIN_FLD_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_pur_bundle_iflistp, PIN_FLD_POID, ebufp);

		fm_tab_cust_get_to_cancel_bundle_details(ctxp, get_pur_bundle_iflistp, 
			&get_pur_bundle_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_to_cancel_bundle_details:"
				" input flist ", get_pur_bundle_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_to_cancel_bundle_details:"
				" Error while getting purchased bundle details", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_cust_get_to_cancel_bundle_details output flist", get_pur_bundle_oflistp)
		
		if (!PIN_FLIST_ELEM_COUNT(get_pur_bundle_oflistp,PIN_FLD_RESULTS,ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PACKAGE_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				"Package name is not present in DB", ebufp);
			goto cleanup;
		}
		


		sprintf(log_msg,"end_t id: %ld",end_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		sprintf(log_msg,"now_t id: %ld",now_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
					
		bundle_elemid=0;
		bundle_cookie=NULL;
		
		while ((pur_bundle_flistp = PIN_FLIST_ELEM_GET_NEXT(get_pur_bundle_oflistp, PIN_FLD_RESULTS, 
			&bundle_elemid, 1, &bundle_cookie, ebufp)) != (pin_flist_t *)NULL)
		{

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
			"pur_bundle_flistp output", pur_bundle_flistp);

			pur_bundle_pdp = PIN_FLIST_FLD_GET(pur_bundle_flistp, PIN_FLD_POID, 1, ebufp);
			valid_from_t = PIN_FLIST_FLD_GET(pur_bundle_flistp, PIN_FLD_VALID_FROM, 1, ebufp);

			/*Verify if appropriate end date is passed in in the input*/
			/**valid_from_t<now_t added to avoid validation failure for the actual future date product cancellation*/
			if(valid_from_t && end_t && (end_t < *valid_from_t) && *valid_from_t<now_t)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INCORRECT_END_DATE, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
					"Incorrect end date passed in input", ebufp);
				goto cleanup;
			}
			
			if(end_date_strp && end_t > now_t)
			{											
				/* Verify if there is ateast one product or discount offering */
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: Inside date case");
				
				if(get_purchased_offerings_oflistp != NULL && 
					((PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_PRODUCTS, ebufp) > 0)  || 
					 (PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_DISCOUNTS, ebufp) > 0 )))
				{
					products_elemid = 0;
					products_cookie = NULL;
					
					while ((products_flistp = PIN_FLIST_ELEM_GET_NEXT(get_purchased_offerings_oflistp, PIN_FLD_PRODUCTS, 
						&products_elemid, 1, &products_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"products_flistp", products_flistp);

						prod_package_idp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);

						if(*package_idp!=*prod_package_idp)
							continue;

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Purchased bundle element :"
						" input flist ", pur_bundle_flistp);
												
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_SUBSCRIPTION_GET_PURCHASED_OFFERINGS:"
						" input flist ", products_flistp);						
						
						/*Get plan obj, package id and description from retrieved offerings*/
						plan_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
						prod_unique_idp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_DESCR, 1, ebufp); 

						/*Compare input purchased bundle obj, package id and description with that of the offerings 
						 * associated with the account and call PCM_OP_SUBSCRIPTION_SET_PRODINFO if there is a match*/
						
						/*below condition commented for C400171354-953. unique_id is optional except DTAC
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) && 
							(prod_package_idp && package_idp && (*package_idp == *prod_package_idp) && 
							prod_unique_idp && unique_idp&& !strncmp(unique_idp, prod_unique_idp, strlen(unique_idp))))
						*/
						/*sprintf(log_msg,"Prod package id: %s",*prod_package_idp);
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

						sprintf(log_msg,"package id: %s",*package_idp);
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);*/
						
						sprintf(log_msg,"prod_unique_idp id: %s",prod_unique_idp);
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);			

						sprintf(log_msg,"unique_idp id: %s",unique_idp);
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
						
						PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG,
							"pur_bundle_pdp poid", pur_bundle_pdp);
																			
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) &&
							((prod_package_idp && package_idp && (*package_idp == *prod_package_idp) &&
							prod_unique_idp && unique_idp&& !strncmp(unique_idp, prod_unique_idp, strlen(unique_idp)))||
							((unique_idp == NULL || strlen(unique_idp) == 0)
									&& prod_package_idp && package_idp && (*package_idp == *prod_package_idp)))) 
						{
							actual_plan_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
							PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: matching bundle product found");
							deal_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);
							/*Call PCM_OP_SUBSCRIPTION_SET_PRODINFO*/

							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG,
							"actual_plan_pdp poid", actual_plan_pdp);

							set_prodinfo_iflistp = PIN_FLIST_CREATE(ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
								set_prodinfo_iflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
								set_prodinfo_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

							context_info_flistp = PIN_FLIST_SUBSTR_ADD(set_prodinfo_iflistp, 
								PIN_FLD_CONTEXT_INFO, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
								context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
								context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

							set_prod_flistp = PIN_FLIST_ELEM_ADD(set_prodinfo_iflistp, 
								PIN_FLD_PRODUCTS, 1, ebufp);
							PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_OFFERING_OBJ, 
								set_prod_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PRODUCT_OBJ, 
								set_prod_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);

							if(end_t !=0 )
							{
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_USAGE_END_T, (void *)&end_t, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_PURCHASE_END_T, (void *)&now_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_CYCLE_END_T, (void *)&now_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_USAGE_END_T, (void *)&now_t, ebufp);
							}
							
							/*C400171354-942 Block added for to avoid inconsistancy of data*/						
							if(start_t> end_t) 
							{
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_INCORRECT_END_DATE, 0, 0, 0);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								"Incorrect end date passed in input", ebufp);
								goto cleanup;
							}
							
							/*C400171354-942 Block added to set the start_t if passed from bu hooks to 
							  keep the data consistency*/
							if(start_t !=0 )
							{
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_PURCHASE_START_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_CYCLE_START_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_prod_flistp, PIN_FLD_USAGE_START_T, (void *)&end_t, ebufp);
							}							
							

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
								"PCM_OP_SUBSCRIPTION_SET_PRODINFO input", set_prodinfo_iflistp);

							PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SET_PRODINFO, 0, set_prodinfo_iflistp, &set_prodinfo_oflistp, ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_PRODINFO:"
									" input flist ", set_prodinfo_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_PRODINFO:"
									" Error while setting end dates", ebufp);
								PIN_FLIST_DESTROY_EX(&set_prodinfo_oflistp, NULL);
								goto cleanup;
							}

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
								"PCM_OP_SUBSCRIPTION_SET_PRODINFO output", set_prodinfo_oflistp);

							PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp, set_prodinfo_oflistp, PIN_FLD_RESULTS_DATA, 
								PIN_ELEMID_ASSIGN, ebufp);
						}

						PIN_FLIST_DESTROY_EX(&set_prodinfo_oflistp, NULL);
						PIN_FLIST_DESTROY_EX(&set_prodinfo_iflistp, NULL);
					}

					discounts_elemid = 0;
					discounts_cookie = NULL;
					while ((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(get_purchased_offerings_oflistp, PIN_FLD_DISCOUNTS,
						&discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
					{

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"discounts_flistp", discounts_flistp);
						
						disc_package_idp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);

						if(*package_idp!=*disc_package_idp)
							continue;

						plan_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
						disc_unique_idp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DESCR, 1, ebufp);

						/*Compare input purchased bundle obj, package id and description with offerings 
						 * associated with the account and call PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO if there is a match*/
						
						/* below condition commented for C400171354-953. unique_id is optional except DTAC
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) && 
							(disc_package_idp && package_idp && (*package_idp == *disc_package_idp) &&
							disc_unique_idp && unique_idp&& !strncmp(unique_idp, disc_unique_idp, strlen(unique_idp))))
						*/
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) &&
							((disc_package_idp && package_idp && (*package_idp == *disc_package_idp) &&
							disc_unique_idp && unique_idp&& !strncmp(unique_idp, disc_unique_idp, strlen(unique_idp)))||
							((unique_idp == NULL || strlen(unique_idp) == 0)
									&& disc_package_idp && package_idp && (*package_idp == *disc_package_idp))))
						{
							PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: matching bundle discount found");
							actual_plan_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);							
							deal_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);
							/*Call PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO*/

							set_discinfo_iflistp = PIN_FLIST_CREATE(ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
								set_discinfo_iflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
								set_discinfo_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

							context_info_flistp = PIN_FLIST_SUBSTR_ADD(set_discinfo_iflistp, 
								PIN_FLD_CONTEXT_INFO, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
								context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
								context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

							set_disc_flistp = PIN_FLIST_ELEM_ADD(set_discinfo_iflistp, 
								PIN_FLD_DISCOUNTS, 1, ebufp);
							PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_OFFERING_OBJ, 
								set_disc_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DISCOUNT_OBJ, 
								set_disc_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);

							if(end_t !=0 )
							{
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_PURCHASE_END_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_CYCLE_END_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_USAGE_END_T, (void *)&end_t, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_PURCHASE_END_T, (void *)&now_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_CYCLE_END_T, (void *)&now_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_USAGE_END_T, (void *)&now_t, ebufp);
							}
							
							/*C400171354-942 Block added for to avoid inconsistancy of data*/						
							if(start_t> end_t) 
							{
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_INCORRECT_END_DATE, 0, 0, 0);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								"Incorrect end date passed in input", ebufp);
								goto cleanup;
							}
							
							/*C400171354-942 Block added to set the start_t if passed from bu hooks to 
							  keep the data consistency*/
							if(start_t !=0 )
							{
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_PURCHASE_START_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_CYCLE_START_T, (void *)&end_t, ebufp);
								PIN_FLIST_FLD_SET(set_disc_flistp, PIN_FLD_USAGE_START_T, (void *)&end_t, ebufp);
							}								

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
								"PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO input", set_discinfo_iflistp);

							PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO, 0, set_discinfo_iflistp, &set_discinfo_oflistp, ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO:"
									" input flist ", set_discinfo_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO:"
									" Error while setting end dates", ebufp);
								PIN_FLIST_DESTROY_EX(&set_discinfo_oflistp, NULL);
								goto cleanup;
							}

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
								"PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO output", set_discinfo_oflistp);

							PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp, set_discinfo_oflistp, PIN_FLD_RESULTS_DATA, 
								PIN_ELEMID_ASSIGN, ebufp);
						}

						PIN_FLIST_DESTROY_EX(&set_discinfo_oflistp, NULL);
						PIN_FLIST_DESTROY_EX(&set_discinfo_iflistp, NULL);
					}
				}
				/*
					Below lines were uncommented by Alok. Although we always search for active and inactive 
					purchased_bundle then handling for future dated cancellation for closed bundles shall 
					not arise.
					Still we are keeping earlier below codes for reading purchased_bundle to identify
					closed bundles and using write_flds to update valid_to in such case.
				*/
				/*Block commented for the bundle cancel*/
				if(!PIN_POID_IS_NULL(pur_bundle_pdp) && !PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp))
				{
					/********************************************************************************
					 *	Below code added for C400171354-942. Check status of /purchased_bundle.
					 *	If status =3 then perform WRITE_FLDS on VALID_TO received from input.
					 *	C400171354-953
					********************************************************************************/
					rd_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_SET(rd_iflistp, PIN_FLD_POID, pur_bundle_pdp, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
							"cust_cancel_offer write_flds input flist", rd_iflistp);
					PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, rd_iflistp, &rd_rflistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_offer: "
							"PCM_OP_READ_OBJ input flist", rd_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
							"PCM_OP_READ_OBJ error", ebufp);
						goto cleanup;
					}
					PIN_FLIST_DESTROY_EX(&rd_iflistp, NULL);
					if (rd_rflistp !=NULL)
					{
						statusp = PIN_FLIST_FLD_GET(rd_rflistp, PIN_FLD_STATUS, 0, ebufp);
						if(statusp && *statusp == 3)
						{
							closed_bundle_flag = 1;
						}
					}		
				}
				
				/*
					closed_bundle_flag == 1 added at below lines were provided w.r.t 
					to per previous comments.
				*/
							
				if (!PIN_POID_IS_NULL(pur_bundle_pdp) && 
						!PIN_POID_IS_NULL(actual_plan_pdp) &&
						!PIN_POID_COMPARE(pur_bundle_pdp, actual_plan_pdp, 0, ebufp) &&
						closed_bundle_flag == 1)
				{
					//write flds
					/********************************************************************************
					 *	If purchased_bundle status=3 then perform WRITE_FLDS on VALID_TO 
					 *	received from input.
					********************************************************************************/
					write_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_POID, pur_bundle_pdp, ebufp);
		
					if(end_t != 0)
					{
						PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_VALID_TO, (void *)&end_t, ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_VALID_TO, (void *)&now_t, ebufp);
					}
					
					/*C400171354-942 Block added to set the start_t if passed from bu hooks to 
					  keep the data consistency*/
					if(start_t !=0 )
					{
						PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_VALID_FROM, (void *)&start_t, ebufp);
					}					

					//PIN_FLIST_FLD_SET(write_iflistp, PIN_FLD_STATUS, &bundle_status, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
							"cust_cancel_offer write_flds input flist", write_iflistp);
					PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 0, write_iflistp, &write_oflistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"cust_cancel_offer offer write_flds error input flist", write_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"Error in cust_cancel_offer offer write_flds input flist", ebufp);
					}
					
					PIN_FLIST_DESTROY_EX(&write_iflistp, NULL);
					PIN_FLIST_DESTROY_EX(&write_oflistp, NULL);
				}
				/*Block commented for the bundle cancel*/
				/*
					Below code uncommented and added additional condition (closed_bundle_flag == 0)
					as per previous comments. PCM_OP_SUBSCRIPTION_SET_BUNDLE to be used to set
					future valid_to date for active and inactive bundles. PIN_FLD_RESULTS_DATA
					need to be populated as well.
				*/
				if (!PIN_POID_IS_NULL(pur_bundle_pdp) && 
						!PIN_POID_IS_NULL(actual_plan_pdp) &&
						!PIN_POID_COMPARE(pur_bundle_pdp, actual_plan_pdp, 0, ebufp) &&
						closed_bundle_flag == 0)
				{
					/*Cancel Purchased Bundle by calling PCM_OP_SUBSCRIPTION_SET_BUNDLE opcode*/
					cancel_pur_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
						cancel_pur_bundle_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
						cancel_pur_bundle_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

					bundle_info_flistp = PIN_FLIST_ELEM_ADD(cancel_pur_bundle_iflistp, PIN_FLD_BUNDLE_INFO, 1, ebufp);

					PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_POID, pur_bundle_pdp, ebufp);

					if(end_t != 0)
					{
						PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_VALID_TO, (void *)&end_t, ebufp);
					} 
					
					context_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_pur_bundle_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_cust_cancel_offer: PCM_OP_SUBSCRIPTION_SET_BUNDLE input", cancel_pur_bundle_iflistp);

					PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SET_BUNDLE, 0, cancel_pur_bundle_iflistp, &cancel_pur_bundle_oflistp, ebufp);
					
					PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_iflistp, NULL);
					
					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
							" input flist ", cancel_pur_bundle_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
							" Error while cancelling /purchased_bundle object", ebufp);
						goto cleanup;
					}

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_cust_cancel_offer: PCM_OP_SUBSCRIPTION_SET_BUNDLE output", cancel_pur_bundle_oflistp);

					PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp, cancel_pur_bundle_oflistp, PIN_FLD_RESULTS_DATA, 
							PIN_ELEMID_ASSIGN, ebufp);												
				}		
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: end_t not passed "
								"get_purchased_offerings_oflistp flist", get_purchased_offerings_oflistp);
				/* Verify if there is ateast one product or discount offering */
				if(get_purchased_offerings_oflistp != NULL && 
					((PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_PRODUCTS, ebufp) > 0)  || 
					 (PIN_FLIST_ELEM_COUNT(get_purchased_offerings_oflistp, PIN_FLD_DISCOUNTS, ebufp) > 0 )))
				{
					products_elemid = 0;
					products_cookie = NULL;
					deal_flistp = PIN_FLIST_CREATE(ebufp);
					if(package_flags && *package_flags == 1)
					{
						prod_array_flistp = PIN_FLIST_CREATE(ebufp);
						disc_array_flistp = PIN_FLIST_CREATE(ebufp);
					}

					while ((products_flistp = PIN_FLIST_ELEM_GET_NEXT(get_purchased_offerings_oflistp, 
						PIN_FLD_PRODUCTS, &products_elemid, 1, &products_cookie, 
						ebufp)) != (pin_flist_t *)NULL)
					{

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"products_flistp", products_flistp);

						prod_package_idp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);

						if(*package_idp!=*prod_package_idp)
							continue;
						
						/*Get plan obj, package id and description from retrieved offerings*/
						deal_matched = 0;
						plan_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
						deal_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);
						prod_unique_idp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_DESCR, 1, ebufp);					
						
						/*Compare input purchased bundle obj, package id and description with that of the offerings 
						 * associated with the account and call PCM_OP_SUBSCRIPTION_SET_PRODINFO if there is a match*/
						
						/*	below condition commented for C400171354-953. unique_id is optional except DTAC
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) && 
							(prod_package_idp && package_idp && (*package_idp == *prod_package_idp) && 
							prod_unique_idp && unique_idp&& !strncmp(unique_idp, prod_unique_idp, strlen(unique_idp))))
						
						*/
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) &&
							((prod_package_idp && package_idp && (*package_idp == *prod_package_idp) &&
							prod_unique_idp && unique_idp&& !strncmp(unique_idp, prod_unique_idp, strlen(unique_idp)))||
							((unique_idp == NULL || strlen(unique_idp) == 0)
									&& prod_package_idp && package_idp 
									&& (*package_idp == *prod_package_idp)))) 
						{
							actual_plan_pdp = PIN_FLIST_FLD_GET(products_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
							if(package_flags && *package_flags == 1)
							{
								if((prod_count = PIN_FLIST_ELEM_COUNT(prod_array_flistp, 
									PIN_FLD_PRODUCTS, ebufp)) > 0 )
								{
									args_flistp = PIN_FLIST_ELEM_ADD(prod_array_flistp, 
										PIN_FLD_PRODUCTS, prod_count , ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PRODUCT_OBJ, 
										args_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_OFFERING_OBJ,
										args_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_QUANTITY, 
										args_flistp, PIN_FLD_QUANTITY, ebufp);
									status_args_flistp = PIN_FLIST_ELEM_ADD(args_flistp, 
										PIN_FLD_STATUSES, 0, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, PIN_FLD_STATUS, 
										&cancel_status, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, 
										PIN_FLD_STATUS_FLAGS, &cancel_status_flag, ebufp);
								}
								else{
									args_flistp = PIN_FLIST_ELEM_ADD(prod_array_flistp, 
										PIN_FLD_PRODUCTS, 0, ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_PRODUCT_OBJ, 
										args_flistp, PIN_FLD_PRODUCT_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_OFFERING_OBJ,
										args_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(products_flistp, PIN_FLD_QUANTITY, 
										args_flistp, PIN_FLD_QUANTITY, ebufp);
									status_args_flistp = PIN_FLIST_ELEM_ADD(args_flistp, 
										PIN_FLD_STATUSES, 0, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, PIN_FLD_STATUS, 
										&cancel_status, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, 
										PIN_FLD_STATUS_FLAGS, &cancel_status_flag, ebufp);
								}
							}
							else
							{
								deal_elemid = 0;
								deal_cookie = NULL;
								while ((deal_elem_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_flistp, 
									PIN_FLD_DEALS, &deal_elemid, 1, &deal_cookie, 
									ebufp)) != (pin_flist_t *)NULL)
								{
									deal_elem_pdp = PIN_FLIST_FLD_GET(deal_elem_flistp, 
										PIN_FLD_DEAL_OBJ, 1, ebufp);
									if (PIN_POID_COMPARE(deal_pdp, deal_elem_pdp, 0,ebufp)==0)
									{
										deal_matched = 1;
										break;
									}
								}
								if(deal_matched == 0){
									if((deal_count = PIN_FLIST_ELEM_COUNT(deal_flistp, 
										PIN_FLD_DEALS,ebufp)) > 0 )
									{
										args_flistp = PIN_FLIST_ELEM_ADD(deal_flistp, 
											PIN_FLD_DEALS,  ++deal_count , ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_DEAL_OBJ, args_flistp, 
											PIN_FLD_DEAL_OBJ, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_SERVICE_OBJ, args_flistp, 
											PIN_FLD_SERVICE_OBJ, ebufp);
									}
									else{
										args_flistp = PIN_FLIST_ELEM_ADD(deal_flistp, 
											PIN_FLD_DEALS, 0, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_DEAL_OBJ, args_flistp, 
											PIN_FLD_DEAL_OBJ, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_SERVICE_OBJ, args_flistp, 
											PIN_FLD_SERVICE_OBJ, ebufp);
									}
								}
							}
						}
					}
					discounts_elemid = 0;
					discounts_cookie = NULL;
					while ((discounts_flistp = PIN_FLIST_ELEM_GET_NEXT(get_purchased_offerings_oflistp, PIN_FLD_DISCOUNTS,
						&discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
					{

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"discounts_flistp", discounts_flistp);

						disc_package_idp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);

						if(*package_idp!=*disc_package_idp)
							continue;
						
						deal_matched = 0;
						plan_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
						disc_package_idp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PACKAGE_ID, 1, ebufp);
						disc_unique_idp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DESCR, 1, ebufp);
						deal_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);

						/*Compare input purchased bundle obj, package id and description with offerings 
						 * associated with the account and call PCM_OP_SUBSCRIPTION_SET_DISCOUNTINFO if there is a match*/
						
						/*
						below condition commented for C400171354-953. unique_id is optional except DTAC
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) && 
							(disc_package_idp && package_idp && (*package_idp == *disc_package_idp) &&
							disc_unique_idp && unique_idp&& !strncmp(unique_idp, disc_unique_idp, strlen(unique_idp))))
						*/
						if(!PIN_POID_COMPARE(pur_bundle_pdp, plan_pdp, 0, ebufp) &&
							((disc_package_idp && package_idp && (*package_idp == *disc_package_idp) &&
							disc_unique_idp && unique_idp&& !strncmp(unique_idp, disc_unique_idp, strlen(unique_idp)))||
							((unique_idp == NULL || strlen(unique_idp) == 0)
									&& disc_package_idp && package_idp 
									&& (*package_idp == *disc_package_idp)))) 
						{
							actual_plan_pdp = PIN_FLIST_FLD_GET(discounts_flistp, PIN_FLD_PLAN_OBJ, 1, ebufp);
							if(package_flags && *package_flags == 1)
							{
								if((disc_count = PIN_FLIST_ELEM_COUNT(disc_array_flistp, 
									PIN_FLD_DISCOUNTS, ebufp)) > 0 )
								{
									args_flistp = PIN_FLIST_ELEM_ADD(disc_array_flistp, 
										PIN_FLD_DISCOUNTS, disc_count , ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DISCOUNT_OBJ,
										args_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_OFFERING_OBJ,
										args_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_QUANTITY, 
										args_flistp, PIN_FLD_QUANTITY, ebufp);
									status_args_flistp = PIN_FLIST_ELEM_ADD(args_flistp, 
										PIN_FLD_STATUSES, 0, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, PIN_FLD_STATUS, 
										&cancel_status, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, 
										PIN_FLD_STATUS_FLAGS, &cancel_status_flag, ebufp);
								}
								else{
									args_flistp = PIN_FLIST_ELEM_ADD(disc_array_flistp, 
										PIN_FLD_DISCOUNTS, 0, ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_DISCOUNT_OBJ,
										args_flistp, PIN_FLD_DISCOUNT_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_OFFERING_OBJ,
										args_flistp, PIN_FLD_OFFERING_OBJ, ebufp);
									PIN_FLIST_FLD_COPY(discounts_flistp, PIN_FLD_QUANTITY, 
										args_flistp, PIN_FLD_QUANTITY, ebufp);
									status_args_flistp = PIN_FLIST_ELEM_ADD(args_flistp, 
										PIN_FLD_STATUSES, 0, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, PIN_FLD_STATUS, 
										&cancel_status, ebufp);
									PIN_FLIST_FLD_SET(status_args_flistp, 
										PIN_FLD_STATUS_FLAGS, &cancel_status_flag, ebufp);
								}
							}
							else
							{
								deal_elemid = 0;
								deal_cookie = NULL;
								while ((deal_elem_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_flistp, 
									PIN_FLD_DEALS, &deal_elemid, 1, &deal_cookie, 
									ebufp)) != (pin_flist_t *)NULL)
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
									"discount deal_elem_flistp flist", deal_elem_flistp);
									deal_elem_pdp = PIN_FLIST_FLD_GET(deal_elem_flistp, 
										PIN_FLD_DEAL_OBJ, 1, ebufp);
									if (PIN_POID_COMPARE(deal_pdp, deal_elem_pdp, 0,ebufp)==0)
									{
										deal_matched = 1;
										break;
									}
								}
								if(deal_matched == 0){
									if((deal_count = PIN_FLIST_ELEM_COUNT(deal_flistp, 
										PIN_FLD_DEALS,ebufp)) > 0 )
									{
										args_flistp = PIN_FLIST_ELEM_ADD(deal_flistp, 
											PIN_FLD_DEALS,  ++deal_count , ebufp);
										PIN_FLIST_FLD_COPY(discounts_flistp, 
											PIN_FLD_DEAL_OBJ, args_flistp, 
											PIN_FLD_DEAL_OBJ, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_SERVICE_OBJ, args_flistp, 
											PIN_FLD_SERVICE_OBJ, ebufp);
									}
									else{
										args_flistp = PIN_FLIST_ELEM_ADD(deal_flistp, 
											PIN_FLD_DEALS, 0, ebufp);
										PIN_FLIST_FLD_COPY(discounts_flistp, 
											PIN_FLD_DEAL_OBJ, args_flistp, 
											PIN_FLD_DEAL_OBJ, ebufp);
										PIN_FLIST_FLD_COPY(products_flistp, 
											PIN_FLD_SERVICE_OBJ, args_flistp, 
											PIN_FLD_SERVICE_OBJ, ebufp);
									}
								}
							}
						}
					}
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer: Deal list input", 
							deal_flistp);
				}
				if(disc_array_flistp && PIN_FLIST_ELEM_COUNT(disc_array_flistp, PIN_FLD_DISCOUNTS, ebufp) > 0 )
				{
					/*Traverse distinct discounts array and call PCM_OP_SUBSCRIPTION_CANCEL_DISCOUNT */
					disc_elemid = 0;
					disc_cookie = NULL;
					while ((disc_elem_flistp = PIN_FLIST_ELEM_GET_NEXT(disc_array_flistp, PIN_FLD_DISCOUNTS,
						&disc_elemid, 1, &disc_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						/*Input flist for PCM_OP_SUBSCRIPTION_CANCEL_DISCOUNT */
						cancel_disc_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, cancel_disc_iflistp,
							PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, cancel_disc_iflistp,
							PIN_FLD_SERVICE_OBJ, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, cancel_disc_iflistp,
							PIN_FLD_PROGRAM_NAME, ebufp);
						PIN_FLIST_FLD_SET(cancel_disc_iflistp, PIN_FLD_END_T, (void *)&now_t, ebufp);
						PIN_FLIST_ELEM_COPY(disc_array_flistp, PIN_FLD_DISCOUNTS,
							disc_elemid, cancel_disc_iflistp, PIN_FLD_DISCOUNTS, 0, ebufp);

						context_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_disc_iflistp,
							PIN_FLD_CONTEXT_INFO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID,
							context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER,
							context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
							"PCM_OP_SUBSCRIPTION_CANCEL_DISCOUNT input flist", cancel_disc_iflistp);

						PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CANCEL_DISCOUNT, 0, cancel_disc_iflistp,
							&cancel_disc_oflistp, ebufp);

						if (PIN_ERR_IS_ERR(ebufp))
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_CANCEL_OFFER, 0, 0, 0);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" input flist ", cancel_disc_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" Error in cancel discount", ebufp);
							PIN_FLIST_DESTROY_EX(&cancel_disc_iflistp, NULL);
							PIN_FLIST_DESTROY_EX(&cancel_disc_oflistp, NULL);
							PIN_FLIST_DESTROY_EX(&prod_array_flistp, NULL);
							PIN_FLIST_DESTROY_EX(&disc_array_flistp, NULL);
							goto cleanup;
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
						" PCM_OP_SUBSCRIPTION_CANCEL_DISCOUNT output flist ", cancel_disc_oflistp);

						PIN_FLIST_DESTROY_EX(&cancel_disc_iflistp, NULL);
						PIN_FLIST_DESTROY_EX(&cancel_disc_oflistp, NULL);
					}
				}

				if(prod_array_flistp && PIN_FLIST_ELEM_COUNT(prod_array_flistp, PIN_FLD_PRODUCTS, ebufp) > 0)
				{
					/*Traverse disctinct products array and call PCM_OP_SUBSCRIPTION_CANCEL_PRODUCT */
					prod_elemid = 0;
					prod_cookie = NULL;
					while ((prod_elem_flistp = PIN_FLIST_ELEM_GET_NEXT(prod_array_flistp, PIN_FLD_PRODUCTS,
						&prod_elemid, 1, &prod_cookie, ebufp)) != (pin_flist_t *)NULL)
					{

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"prod_elem_flistp", prod_elem_flistp);

						/*Input flist for PCM_OP_SUBSCRIPTION_CANCEL_PRODUCT*/
						cancel_prod_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, cancel_prod_iflistp,
							PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, cancel_prod_iflistp,
							PIN_FLD_SERVICE_OBJ, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, cancel_prod_iflistp,
							PIN_FLD_PROGRAM_NAME, ebufp);
						PIN_FLIST_FLD_SET(cancel_prod_iflistp, PIN_FLD_END_T, (void *)&now_t, ebufp);
						PIN_FLIST_ELEM_COPY(prod_array_flistp, PIN_FLD_PRODUCTS,
							prod_elemid, cancel_prod_iflistp, PIN_FLD_PRODUCTS, 0, ebufp);

						context_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_prod_iflistp,
							PIN_FLD_CONTEXT_INFO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID,
							context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER,
							context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer:"
							"PCM_OP_SUBSCRIPTION_CANCEL_PRODUCT input flist", cancel_prod_iflistp);

						PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CANCEL_PRODUCT, 0, cancel_prod_iflistp,
							&cancel_prod_oflistp, ebufp);

						if (PIN_ERR_IS_ERR(ebufp))
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_CANCEL_OFFER, 0, 0, 0);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" input flist ", cancel_prod_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" Error in cancel product", ebufp);
							PIN_FLIST_DESTROY_EX(&cancel_prod_iflistp, NULL);
							PIN_FLIST_DESTROY_EX(&cancel_prod_oflistp, NULL);
							PIN_FLIST_DESTROY_EX(&prod_array_flistp, NULL);
							PIN_FLIST_DESTROY_EX(&disc_array_flistp, NULL);
							goto cleanup;
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
						" PCM_OP_SUBSCRIPTION_CANCEL_PRODUCT output flist ", cancel_prod_iflistp);

						PIN_FLIST_DESTROY_EX(&cancel_prod_iflistp, NULL);
						PIN_FLIST_DESTROY_EX(&cancel_prod_oflistp, NULL);
					}
				}
				if(package_flags && *package_flags == 1)
				{
					PIN_FLIST_DESTROY_EX(&prod_array_flistp, NULL);
					PIN_FLIST_DESTROY_EX(&disc_array_flistp, NULL);
				}
				else
				{
					/*Traverse disctinct deal obj and call PCM_OP_SUBSCRIPTION_CANCEL_DEAL*/		
					deal_elemid = 0;
					deal_cookie = NULL;
					while ((deal_elem_flistp = PIN_FLIST_ELEM_GET_NEXT(deal_flistp, PIN_FLD_DEALS, 
						&deal_elemid, 1, &deal_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
						"prod_elem_flistp output", prod_elem_flistp);

						cancel_dealpdp = PIN_FLIST_FLD_GET(deal_elem_flistp, PIN_FLD_DEAL_OBJ, 1, ebufp);
						service_objpdp = PIN_FLIST_FLD_GET(deal_elem_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
						/*Input flist for PCM_OP_SUBSCRIPTION_CANCEL_DEAL*/
						cancel_deal_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, cancel_deal_iflistp, 
							PIN_FLD_POID, ebufp);
							
						if(!PIN_POID_IS_NULL(service_objpdp))
						{
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, cancel_deal_iflistp,
								PIN_FLD_SERVICE_OBJ, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(cancel_deal_iflistp, PIN_FLD_SERVICE_OBJ, NULL, ebufp);
						}
							
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, cancel_deal_iflistp, 
							PIN_FLD_PROGRAM_NAME, ebufp);

						deal_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_deal_iflistp, 
							PIN_FLD_DEAL_INFO, ebufp);
						PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID, deal_info_flistp, 
							PIN_FLD_PACKAGE_ID, ebufp);
						if(!PIN_POID_IS_NULL(cancel_dealpdp))
						{
							PIN_FLIST_FLD_SET(deal_info_flistp, PIN_FLD_DEAL_OBJ, 
								cancel_dealpdp, ebufp);
						}
						context_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_deal_iflistp, 
							PIN_FLD_CONTEXT_INFO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, 
							PIN_FLD_CORRELATION_ID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
							context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

						if(end_t != 0)
						{
							PIN_FLIST_FLD_SET(cancel_deal_iflistp, PIN_FLD_END_T, 
								(void *)&end_t, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(cancel_deal_iflistp, PIN_FLD_END_T, 
								(void *)&now_t, ebufp);
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer: "
							"PCM_OP_SUBSCRIPTION_CANCEL_DEAL input flist", cancel_deal_iflistp);

						PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CANCEL_DEAL, 0, cancel_deal_iflistp, 
							&cancel_deal_oflistp, ebufp);

						if (PIN_ERR_IS_ERR(ebufp))
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_CANCEL_OFFER, 0, 0, 0);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" input flist ", cancel_deal_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
								" Error in cancel deal", ebufp);
							PIN_FLIST_DESTROY_EX(&cancel_deal_iflistp, NULL);
                                                        PIN_FLIST_DESTROY_EX(&cancel_deal_oflistp, NULL);
							goto cleanup;
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
							" PCM_OP_SUBSCRIPTION_CANCEL_DEAL output flist ", cancel_deal_oflistp);

						PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp, cancel_deal_oflistp, 
							PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);

						PIN_FLIST_DESTROY_EX(&cancel_deal_iflistp, NULL);
						PIN_FLIST_DESTROY_EX(&cancel_deal_oflistp, NULL);
					}
					PIN_FLIST_DESTROY_EX(&deal_flistp, NULL);
				}
								
				if (!PIN_POID_IS_NULL(pur_bundle_pdp) && 
						!PIN_POID_IS_NULL(actual_plan_pdp) &&
						!PIN_POID_COMPARE(pur_bundle_pdp, actual_plan_pdp, 0, ebufp))
				{
					/*Cancel Purchased Bundle by calling PCM_OP_SUBSCRIPTION_SET_BUNDLE opcode*/
					cancel_pur_bundle_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
						cancel_pur_bundle_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
						cancel_pur_bundle_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

					bundle_info_flistp = PIN_FLIST_ELEM_ADD(cancel_pur_bundle_iflistp, PIN_FLD_BUNDLE_INFO, 1, ebufp);

					PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_POID, pur_bundle_pdp, ebufp);

					if(end_t != 0)
					{
						PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_VALID_TO, (void *)&end_t, ebufp);
					}
					/* SIT - C400171354-792
					else
					{
						PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_VALID_TO, (void *)&now_t, ebufp);
					}
					*/
					PIN_FLIST_FLD_SET(bundle_info_flistp, PIN_FLD_STATUS, &bundle_status, ebufp);
					context_info_flistp = PIN_FLIST_SUBSTR_ADD(cancel_pur_bundle_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_cust_cancel_offer: PCM_OP_SUBSCRIPTION_SET_BUNDLE input", cancel_pur_bundle_iflistp);

					PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SET_BUNDLE, 0, cancel_pur_bundle_iflistp, &cancel_pur_bundle_oflistp, ebufp);
					
					PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_iflistp, NULL);
					
					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
							" input flist ", cancel_pur_bundle_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SET_BUNDLE:"
							" Error while cancelling /purchased_bundle object", ebufp);
						PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_oflistp, NULL);
						goto cleanup;
					}

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_cust_cancel_offer: PCM_OP_SUBSCRIPTION_SET_BUNDLE output", cancel_pur_bundle_oflistp);

					PIN_FLIST_ELEM_SET(cancel_offer_rdata_flistp, cancel_pur_bundle_oflistp, PIN_FLD_RESULTS_DATA, 
							PIN_ELEMID_ASSIGN, ebufp);
				}
			}
		}
		
		PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&get_pur_bundle_oflistp, NULL);
		PIN_FLIST_DESTROY_EX(&get_pur_bundle_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_iflistp, NULL);
		//PIN_FLIST_DESTROY_EX(&rd_rflistp, NULL);

		/*Prepare flists for notification*/
		if(cancel_offer_rdata_flistp != NULL &&
			((PIN_FLIST_ELEM_COUNT(cancel_offer_rdata_flistp, PIN_FLD_RESULTS_DATA, ebufp) > 0) ))
		{

			common_notification_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO,
				common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN,
				common_notification_flistp, PIN_FLD_MSISDN, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,
				common_notification_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

			package_info_flistp = PIN_FLIST_ELEM_ADD(common_notification_flistp,
				PIN_FLD_PACKAGE_INFO, package_elemid, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_NAME,
				package_info_flistp, PIN_FLD_NAME, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_PACKAGE_ID,
				package_info_flistp, PIN_FLD_PACKAGE_ID, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_UNIQUE_ID,
				package_info_flistp, PIN_FLD_UNIQUE_ID, ebufp);
			PIN_FLIST_FLD_COPY(package_flistp, PIN_FLD_VALID_TO_STR,
				package_info_flistp, PIN_FLD_VALID_TO_STR, ebufp);
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_CANCEL_OFFER, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				" Error in cancel offer", ebufp);
			goto cleanup;
		}
	}

	if(package_counter == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        TAB_ERR_CODE_CANCEL_PACKAGE_ARRAY_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
                        "Package Array is not passed in request", ebufp);
                goto cleanup;

        }

	notify_flistp = PIN_FLIST_CREATE(ebufp);
	temp_input_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_FLIST_FLD_COPY(notify_flistp, PIN_FLD_IN_FLIST, *out_flistpp, PIN_FLD_IN_FLIST, ebufp);

	if(cancel_offer_rdata_flistp != NULL)
	{
		PIN_FLIST_SUBSTR_SET(notify_flistp, cancel_offer_rdata_flistp, PIN_FLD_OUT_FLIST, ebufp);
		PIN_FLIST_FLD_COPY(notify_flistp, PIN_FLD_OUT_FLIST, *out_flistpp, PIN_FLD_OUT_FLIST, ebufp);
	}

	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CANCEL_OFFERS, -1, ebufp);
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_FLIST_FLD_COPY(notify_flistp, TAB_FLD_NOTIFICATION, *out_flistpp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer:"
		" fm_tab_cust_cancel_offer_notification input flist ", notify_flistp);

	/* Call function post hook opcode */
	fm_tab_cust_pol_post_cancel_offer(ctxp, enrich_canel_offer_flistp, &posthook_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
			" fm_tab_cust_pol_post_cancel_offer input flist ", enrich_canel_offer_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
			" fm_tab_cust_pol_post_cancel_offer error", ebufp);
		goto cleanup;
	}
	
	if(notify_flag == TAB_NOTIFY_ENABLE)
	{
		/* Call function to enrich notification details */
		fm_tab_cust_cancel_offer_notification(ctxp, notify_flistp, db_no, &notify_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer:"
				" fm_tab_cust_cancel_offer_notification input flist ", notify_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer: "
				" fm_tab_cust_cancel_offer_notification error", ebufp);
			goto cleanup;
		}

		if (notify_oflistp)
		{
			if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
					PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
			}
			else
			{
				PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_purchased_offerings_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_pur_bundle_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_canel_offer_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&deal_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&disc_array_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&prod_array_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&cancel_offer_rdata_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_pur_bundle_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_purchased_offerings_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&set_prodinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&set_discinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&cancel_pur_bundle_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rd_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&posthook_rflistp, NULL);
	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_cancel_offer output flist", *out_flistpp);
	return;
}

/**
 * We use this function to generate
 * custom notification on cancel offer.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_cust_cancel_offer_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_offer_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_offer_notification: "
		"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CANCEL_OFFER input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CANCEL_OFFER, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_offer_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_offer_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CANCEL_OFFER output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_cancel_offer_notification output flist", *r_flistpp);
	return;
}

void
fm_tab_cust_get_to_cancel_bundle_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	int32			status = 3;
	 
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_to_cancel_bundle_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_to_cancel_bundle_details:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_to_cancel_bundle_details input", i_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
    	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
    	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &status, ebufp);

	if ((PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_FROM, 1, ebufp) != NULL)
			&& (PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALID_TO, 1, ebufp) != NULL))
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 != V3 and F4 = V4 and F5 = V5 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_FROM, args_flistp, PIN_FLD_VALID_FROM, ebufp);
		
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_VALID_TO, args_flistp, PIN_FLD_VALID_TO, ebufp);
	}
	else
	{
		vp =  (void *)"select X from /purchased_bundle where F1 = V1 and F2 = V2 and F3 != V3 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}

	res_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(res_flistp, PIN_FLD_VALID_TO, NULL, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_get_to_cancel_bundle_details input flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_to_cancel_bundle_details input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_to_cancel_bundle_details: Error in getting purchased bundle object", ebufp);
	}
	
	PIN_FLIST_DESTROY_EX(&search_flistp, NULL);
	*r_flistpp = r_flistp;
	
	return;
}

static void
fm_tab_cust_pol_post_cancel_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*rflistp = NULL;
	pin_flist_t		*hook_iflistp = NULL;
	pin_errbuf_t    local_ebuf = {0} ;
	pin_errbuf_t    *local_ebufp = &local_ebuf;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_post_cancel_offer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_post_cancel_offer:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_pol_post_cancel_offer: "
		"input flist", i_flistp);

	hook_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_post_cancel_offer:"
		" TAB_OP_CUST_POL_POST_CANCEL_OFFER input flist ", hook_iflistp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_POST_CANCEL_OFFER, 0, hook_iflistp, &rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_pol_post_cancel_offer:"
			" input flist ", hook_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_pol_post_cancel_offer:"
			" Error in TAB_OP_CUST_POL_POST_CANCEL_OFFER", ebufp);
		*r_flistpp = PIN_FLIST_COPY(rflistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_offer_notification:"
		" TAB_OP_CUST_POL_POST_CANCEL_OFFER output flist ", rflistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&hook_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rflistp, NULL);

	return;
}
