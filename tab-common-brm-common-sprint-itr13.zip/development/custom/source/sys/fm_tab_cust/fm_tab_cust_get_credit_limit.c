/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 28/02/2022 | Piyush Suryavanshi	| 					| Wrapper for credit limit fetch.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_CREDIT_LIMIT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/pymt.h"
#include "ops/bill.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include <stdlib.h>
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_cust_get_credit_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_credit_limit(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);
	
static void
fm_tab_cust_get_credit_limit_prepare_output(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t 	*credit_limit_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);
	
static void
fm_tab_cust_get_credit_limit_event(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp);

extern pin_flist_t*
fm_tab_utils_common_prep_simple_search_flist(
        char                   *template,
        field_t                 args_struct[],
        int                     n_args,
        field_t                 result_struct[],
        int                     n_results,
        int64                   db_no,
        int                     flags,
        pin_errbuf_t            *ebufp);

/********************************************************************
 *
 * New opcode TAB_OP_CUST_GET_CREDIT_LIMIT is implemented get the 
 * credit limit of the account
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains get credit limit info
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 ********************************************************************/
/*************************InputFlist********************************
  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
  0 PIN_FLD_ACCOUNT_NO      STR [0] "CINT_ACC003"
  0 PIN_FLD_MSISDN          STR [0] "0902022002"
  0 TAB_FLD_CL_TYPE         INT [0] 0
  0 TAB_FLD_SERV_DETAILS    STR [0] "SMS"
  0 PIN_FLD_EXTERNAL_USER   STR [0] ""
  0 PIN_FLD_CORRELATION_ID    STR [0] "er12
 **********************************************************************/

void
op_tab_cust_get_credit_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_credit_limit:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_get_credit_limit function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_GET_CREDIT_LIMIT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_credit_limit bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_credit_limit input flist", in_flistp);

	/*r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_TRANS_ID, r_flistp,PIN_FLD_TRANS_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME, r_flistp,PIN_FLD_USER_NAME,ebufp);
        */
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
        fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp= r_flistp;
		return;
	}

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_validate_and_normalize_input:"
				"flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_credit_limit: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_credit_limit:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_cust_get_credit_limit(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_credit_limit:"
				"fm_tab_cust_get_credit_limit flist", enrich_iflistp);						
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_credit_limit error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_CREDIT_LIMIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_CREDIT_LIMIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_CREDIT_LIMIT, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
     
    *ret_flistpp = r_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_credit_limit output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/***********************************************************
 * fm_tab_cust_get_credit_limit()
 * This function is used for get the credit limit based on
 * credit limit type.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param db_no,Database number
 * @param ebufp The error buffer.
 * @returns a void.
 ***********************************************************/
static void
fm_tab_cust_get_credit_limit(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_credit_limit input flistp", in_flistp);

	PIN_ERRBUF_CLEAR(ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit:"
				" in_flistp", in_flistp);
		return;
	}
	
	int 		cl_type=0;
	
	pin_flist_t 	*pre_get_cl_output_flistp=NULL;
	pin_flist_t 	*post_get_cl_input_flistp=NULL;
	pin_flist_t	*credit_limit_output_flistp=NULL;
	char		 	*serv_details=NULL;
	pin_flist_t 	*post_hook_return_flistp=NULL;
	pin_flist_t		*post_return_flistp=NULL;
	pin_flist_t		*read_object_flistp=NULL;
	pin_errbuf_t	local_ebuf = {0};
	pin_errbuf_t	*local_ebufp = &local_ebuf;
	pin_flist_t 	*output_flistp = NULL;
	pin_flist_t 	*credit_limit_input_flistp = NULL;

	char 		*serv_detailsp=NULL;
	char 		*acct_nop=NULL;
	char 		*msisdnp=NULL;
	poid_t 		*account_pdp=NULL;
	
	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit:"
			"account number/msisdn is not passed", ebufp);
		return;
	}

	if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE , 1, ebufp)!=NULL)
		cl_type = *(int*)PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE , 1, ebufp);

	if( cl_type && !((cl_type == TAB_CL_TYPE_DOMESTIC) || (cl_type == TAB_CL_TYPE_IR_BUDGET) ||
				(cl_type == TAB_CL_TYPE_SERVICE_WISE) ))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_CL_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_credit_limit: Error Invalid credit limit type passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_credit_limit: input flist", in_flistp);
		goto cleanup;
	}
	
	serv_details = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SERV_DETAILS, 1, ebufp);
	if(cl_type && (cl_type == TAB_CL_TYPE_SERVICE_WISE) && (serv_details == NULL || strlen(serv_details) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERV_DETAILS_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_credit_limit: Error TAB_FLD_SERV_DETAILS- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_credit_limit: input flist", in_flistp);
		goto cleanup;
	}
			
	if(serv_details && !((strcmp(serv_details, TAB_SERVICE_VOICE) == 0) || (strcmp(serv_details, TAB_SERVICE_SMS) == 0) ||
		(strcmp(serv_details, TAB_SERVICE_DATA) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_SERV_DETAILS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_credit_limit: Error Invalid service details passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_credit_limit: input flist", in_flistp);
		goto cleanup;
	}
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	
	fm_tab_utils_common_read_object(ctxp,account_pdp,&read_object_flistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object:",account_pdp);
		goto cleanup;
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL: " "input Flist", in_flistp);
	PCM_OP( ctxp, TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL, 0, in_flistp, &output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL: " "output Flist", output_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL:", output_flistp);
		*out_flistpp=PIN_FLIST_COPY(output_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(output_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
		
	/******************************************************************
	 * Credit limit input flist creation.
	 ******************************************************************/

	credit_limit_input_flistp = PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,credit_limit_input_flistp,PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID,credit_limit_input_flistp,PIN_FLD_PROGRAM_NAME, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ,credit_limit_input_flistp,PIN_FLD_BAL_GRP_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CL_TYPE ,credit_limit_input_flistp,TAB_FLD_CL_TYPE,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SERV_DETAILS ,credit_limit_input_flistp,TAB_FLD_SERV_DETAILS,ebufp);
	PIN_FLIST_FLD_COPY(read_object_flistp, PIN_FLD_CURRENCY,credit_limit_input_flistp,PIN_FLD_RESOURCE_ID,ebufp);
	
	PIN_FLIST_DESTROY_EX(&read_object_flistp, NULL);

	if (cl_type==TAB_CL_TYPE_DOMESTIC || cl_type==TAB_CL_TYPE_IR_BUDGET)
	{							

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_credit_limit : TAB_OP_CUST_POL_PRE_GET_CL: "
				"input Flist", credit_limit_input_flistp);
		PCM_OP( ctxp, TAB_OP_CUST_POL_PRE_GET_CL, 0, credit_limit_input_flistp, &pre_get_cl_output_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_PRE_GET_CL: "
				"output Flist", pre_get_cl_output_flistp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit :TAB_OP_CUST_POL_PRE_GET_CL error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit: TAB_OP_CUST_POL_PRE_GET_CL:"
					" in_flistp", credit_limit_input_flistp);
			*out_flistpp= PIN_FLIST_COPY(pre_get_cl_output_flistp,local_ebufp);
			PIN_ERR_CLEAR_ERR(local_ebufp);
			goto cleanup;
		}		

	}
	else if (cl_type==TAB_CL_TYPE_SERVICE_WISE)
	{
		if ((serv_detailsp=PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_SERV_DETAILS,1,ebufp))!=NULL)
		{
			
			if (strcmp(serv_detailsp,"Voice")==0 || strcmp(serv_detailsp,"Data")==0 || strcmp(serv_detailsp,"SMS")==0)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_credit_limit : TAB_OP_CUST_POL_PRE_GET_CL. : "
						"input Flist", credit_limit_input_flistp);
				PCM_OP( ctxp, TAB_OP_CUST_POL_PRE_GET_CL , 0, credit_limit_input_flistp, &pre_get_cl_output_flistp, ebufp );
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_PRE_GET_CL. : "
						"output Flist", pre_get_cl_output_flistp);

				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit :TAB_OP_CUST_POL_PRE_GET_CL.  error", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit: TAB_OP_CUST_POL_PRE_GET_CL. :"
							" in_flistp", credit_limit_input_flistp);
					*out_flistpp= PIN_FLIST_COPY(pre_get_cl_output_flistp,local_ebufp);
					PIN_ERR_CLEAR_ERR(local_ebufp);
					goto cleanup;
				}				
			}
		}
	}
	else
	{
		pre_get_cl_output_flistp = PIN_FLIST_COPY(credit_limit_input_flistp, ebufp);
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_credit_limit : PCM_OP_BILL_GET_LIMIT: "
								"input Flist", credit_limit_input_flistp);
	PCM_OP( ctxp, PCM_OP_BILL_GET_LIMIT , 0, pre_get_cl_output_flistp, &credit_limit_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_BILL_GET_LIMIT: "
								"output Flist", credit_limit_output_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit :PCM_OP_BILL_GET_LIMIT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit: PCM_OP_BILL_GET_LIMIT:"
				" in_flistp", pre_get_cl_output_flistp);
		*out_flistpp= PIN_FLIST_COPY(credit_limit_output_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}


	fm_tab_cust_get_credit_limit_prepare_output(ctxp,in_flistp,credit_limit_output_flistp,&post_hook_return_flistp,db_no,ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit : fm_tab_cust_get_credit_limit_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit: fm_tab_cust_get_credit_limit_prepare_output:"
				" in_flistp", pre_get_cl_output_flistp);
		goto cleanup;
	}
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_credit_limit : TAB_OP_CUST_POL_POST_GET_CL: "
			"input Flist", post_hook_return_flistp);
	PCM_OP( ctxp, TAB_OP_CUST_POL_POST_GET_CL, 0, post_hook_return_flistp,&post_return_flistp,ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_POST_GET_CL: "
			"output Flist", post_return_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit : TAB_OP_CUST_POL_POST_GET_CL error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit: TAB_OP_CUST_POL_POST_GET_CL:"
				" in_flistp", post_hook_return_flistp);
		*out_flistpp=PIN_FLIST_COPY(post_return_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}
	else
	{
		*out_flistpp=PIN_FLIST_COPY(post_return_flistp,ebufp);
	}
	
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&credit_limit_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_get_cl_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_hook_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&pre_get_cl_output_flistp, NULL);
	return;
}

/*******************************************************************
 * This	function is	to create the output response of get credit limit
 * search opcode.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/
static void
fm_tab_cust_get_credit_limit_prepare_output(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t 	*credit_limit_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_credit_limit_prepare_output input", in_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_credit_limit_prepare_output limit out flistp", credit_limit_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit_prepare_output:"
				" input	flist",	in_flistp);
		return;
	}

	pin_flist_t *balances_flistp=NULL;
	pin_flist_t *limit_flistp=NULL;
	pin_flist_t *temp_limit_flistp=NULL;
	pin_flist_t *return_temp_limit_flistp=NULL;
	pin_flist_t *event_flistp=NULL;
	pin_flist_t *threshold_flistp=NULL;

	int		elem_limit = 0 ;
	int 		elem_thre=0;
	int		elem_limit_balance=0;	

	pin_cookie_t	cookie_limit = NULL;
	pin_cookie_t	cookie_thre = NULL;
	pin_cookie_t	cookie_limit_balance= NULL;
	
	time_t 		valid_from=0;
	time_t 		valid_to=0;
	
	char 		*valid_fromp=NULL;
	char 		*valid_top=NULL;


	/******************************************************************
	 * Global Flist	return_flistp
	 ******************************************************************/
	pin_flist_t	*return_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,	return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp,	PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CL_TYPE, return_flistp,	TAB_FLD_CL_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SERV_DETAILS, return_flistp,	TAB_FLD_SERV_DETAILS, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, return_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);

	/******************************************************************
	 * Traverse	Item to	get	the	events and add it in return	Flist
	 ******************************************************************/

	while ((balances_flistp	= PIN_FLIST_ELEM_GET_NEXT(credit_limit_flistp, PIN_FLD_BALANCES,
					&elem_limit_balance,	1, &cookie_limit_balance, ebufp)) !=	(pin_flist_t*)NULL)
	{
		elem_limit=0;
		cookie_limit = NULL;

		/******************************************************************
		 * Traverse	credit limit add it in return	Flist
		 ******************************************************************/
		while ((limit_flistp =	PIN_FLIST_ELEM_GET_NEXT(balances_flistp,
						PIN_FLD_LIMIT,	&elem_limit, 1,	&cookie_limit, ebufp)) != (pin_flist_t*)NULL)
		{
		
			elem_thre=0;
			cookie_thre=NULL;
			/******************************************************************
			 * Traverse	threshold and remove amount from Flist
			 ******************************************************************/
			while ((threshold_flistp =	PIN_FLIST_ELEM_GET_NEXT(limit_flistp,
							PIN_FLD_THRESHOLDS,	&elem_thre, 1,	&cookie_thre, ebufp)) != (pin_flist_t*)NULL)
			{
				if(PIN_FLIST_FLD_GET(threshold_flistp,PIN_FLD_AMOUNT,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(threshold_flistp,PIN_FLD_AMOUNT,ebufp);				
			}
						
			PIN_FLIST_ELEM_COPY(limit_flistp, PIN_FLD_THRESHOLDS,0,return_flistp,PIN_FLD_THRESHOLDS,0, ebufp);			
			PIN_FLIST_FLD_COPY(limit_flistp, PIN_FLD_CREDIT_LIMIT, return_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
		}
		
		elem_limit=0;
		cookie_limit = NULL;
		
		/******************************************************************
		 * Traverse	temp credit limit add	it in return Flist
		 ******************************************************************/
		while ((temp_limit_flistp = PIN_FLIST_ELEM_GET_NEXT(balances_flistp,
						PIN_FLD_TEMP_LIMIT, &elem_limit, 1, &cookie_limit,	ebufp))	!= (pin_flist_t*)NULL)
		{
			
			return_temp_limit_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_TEMP_LIMIT,elem_limit,ebufp);
			
			valid_from =*(time_t*)PIN_FLIST_FLD_GET(temp_limit_flistp,PIN_FLD_VALID_FROM,0,	ebufp);
			valid_to = *(time_t*)PIN_FLIST_FLD_GET(temp_limit_flistp,PIN_FLD_VALID_TO,0,	ebufp);
			
			valid_fromp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&valid_from,ebufp);
			PIN_FLIST_FLD_PUT(return_temp_limit_flistp, TAB_FLD_START_T_STR, valid_fromp, ebufp);

			valid_top= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&valid_to,ebufp);
			PIN_FLIST_FLD_PUT(return_temp_limit_flistp, TAB_FLD_END_T_STR, valid_top, ebufp);

			PIN_FLIST_FLD_COPY(temp_limit_flistp, PIN_FLD_CREDIT_LIMIT, return_temp_limit_flistp,PIN_FLD_CREDIT_LIMIT, ebufp);
		}		
	}
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_credit_limit_prepare_output input flist",credit_limit_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_credit_limit_prepare_output: ", ebufp);
		goto cleanup;
	}	
	
	fm_tab_cust_get_credit_limit_event(ctxp,in_flistp,&return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_credit_limit_event input flist",credit_limit_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_credit_limit_event: ", ebufp);
		goto cleanup;
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	
	*out_flistpp= PIN_FLIST_COPY(return_flistp,ebufp);
	
	PIN_FLIST_DESTROY_EX(&credit_limit_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&event_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&temp_limit_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&return_flistp,NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_get_credit_limit_prepare_output output flist",*out_flistpp );
	return;
}


static void
fm_tab_cust_get_credit_limit_event(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp)
{

	poid_t	*account_pdp=NULL;
	field_t	args_struct[3];
	field_t	result_struct[0];
	
	int	n_args = 3;
	int	n_results = 0;
	
	char 	*template= "select X from /tab_event_modify_credit_limit where  F1 = V1 and F2 like V2 order by F3 desc ";
	
	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*result_flistp=NULL;

	int 		flags=0;
	int		opcode_result= 0;
	
	char 		*created_tp=NULL;
	time_t 		created_t=0;
	
	poid_t 		*srchp=NULL;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_credit_limit_event input flistp", in_flistp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit_event	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_credit_limit_event:"
				" in_flistp", in_flistp);
		return;
	}

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[0].fld_value = account_pdp;

	srchp = PIN_POID_CREATE(db_no, "/tab_event_modify_credit_limit", -1, ebufp);

	args_struct[1].fld_name = PIN_FLD_POID;
	args_struct[1].fld_value = srchp;
	
	args_struct[2].fld_name = PIN_FLD_CREATED_T;
	args_struct[2].fld_value = NULL;	

	search_input_flistp = (pin_flist_t *)fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_bill_get_details bill search", 1, ebufp);
			
	PIN_POID_DESTROY(srchp,NULL);	
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	
	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_credit_limit_event"
				"error search bill failed", ebufp);
		goto cleanup;
	}

	/*if (!PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_credit_limit_event"
				"error event not found", ebufp);
		goto cleanup;
	}*/

	if ((result_flistp= PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS,0,1,ebufp))!=NULL)
	{
		created_t = *(time_t*)PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_CREATED_T,0,ebufp);
		created_tp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&created_t,ebufp);
		PIN_FLIST_FLD_PUT(*out_flistpp, TAB_FLD_EFFECTIVE_T_STR, created_tp, ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_CHANNEL,*out_flistpp,PIN_FLD_CHANNEL,ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_USER_NAME,*out_flistpp,PIN_FLD_USER_NAME,ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_DESCR,*out_flistpp,PIN_FLD_DESCR,ebufp);

	}
	
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	 

	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_credit_limit_event output flist", *out_flistpp);
	
	return;
}
