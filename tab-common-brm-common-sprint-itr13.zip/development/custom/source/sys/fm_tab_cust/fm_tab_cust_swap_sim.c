/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Nov/2021 | Rahul Honnaiah		| 			| New opcode implementation to
 *                                               			| swap IMSI.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_SWAP_SIM operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_swap_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_swap_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static int32
fm_tab_cust_swap_sim_update(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	char			*source_imsi,
	char			*destination_imsi,
	int32			svc_elemid,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_CUST_SWAP_SIM is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, TAB_FLD_SOURCE_IMSI
 *                  and TAB_FLD_DESTINATION_IMSI .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID               POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN             STR [0] "981999999"
 * 0 TAB_FLD_SOURCE_IMSI        STR [0] "666666"
 * 0 TAB_FLD_DESTINATION_IMSI   STR [0] "777777"
 * 0 PIN_FLD_CORRELATION_ID     STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 *
 */

void
op_tab_cust_swap_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]="";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_swap_sim function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_SWAP_SIM) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_swap_sim bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_swap_sim input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_SWAPIMSI;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_SWAPIMSI)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_SWAPIMSI, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_swap_sim:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_swap_sim(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_swap_sim error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_SWAP_SIM", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_SWAPIMSI;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_SWAPIMSI)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_SWAPIMSI, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		r_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_swap_sim output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to update the service information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_swap_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*service_in_flistp = NULL;
	pin_flist_t		*service_out_flistp = NULL;
	pin_flist_t		*temp_alias_flistp = NULL;
	pin_flist_t		*service_alias_flistp = NULL;

	poid_t			*svc_pdp = NULL;
	pin_cookie_t		svc_cookie = NULL;
	int32			svc_elemid = 0;
	int32			match_source_imsi = 0;
	int32			match_destination_imsi = 0;
	int32			dest_rec_id = 0;

	char			*source_imsi = NULL;
	char			*msisdn = NULL;
	char			*destination_imsi = NULL;
	char			*namep = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_swap_sim: input flist", in_flistp);
	svc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 0, ebufp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_swap_sim: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Error PIN_FLD_MSISDN-Input is missing", ebufp);
		goto cleanup;
	}
	source_imsi = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SOURCE_IMSI, 1, ebufp);
	if ((source_imsi == NULL || strlen(source_imsi) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SOURCE_IMSI, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Error TAB_FLD_SOURCE_IMSI - Input is missing", ebufp);
		goto cleanup;
	}
	destination_imsi = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_DESTINATION_IMSI, 1, ebufp);
	if ((destination_imsi == NULL || strlen(destination_imsi) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DESTINATION_IMSI, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Error TAB_FLD_DESTINATION_IMSI - Input is missing", ebufp);
		goto cleanup;
	}

	/* Read the service object for POID validation */
	service_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(service_in_flistp, PIN_FLD_POID, svc_pdp, ebufp);
	service_alias_flistp = PIN_FLIST_ELEM_ADD(service_in_flistp, PIN_FLD_ALIAS_LIST, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(service_alias_flistp, PIN_FLD_NAME, NULL, ebufp);

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /service 4190005 166
	 * 0 PIN_FLD_ALIAS_LIST    ARRAY [*] allocated 20, used 1
	 * */
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_swap_sim: Service Read Input", service_in_flistp);

	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, service_in_flistp, &service_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_DM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERVICE_NOT_FOUND, PIN_FLD_POID, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Service Read Input", service_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Service Read error", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_swap_sim:"
			" Service Read Output", service_out_flistp);
		svc_elemid = 0;
		svc_cookie = NULL;
		while ((temp_alias_flistp = PIN_FLIST_ELEM_GET_NEXT(service_out_flistp,
			PIN_FLD_ALIAS_LIST, &svc_elemid, 1, &svc_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_swap_sim: temp_alias_flistp flist", temp_alias_flistp);
			namep = PIN_FLIST_FLD_GET(temp_alias_flistp, PIN_FLD_NAME, 1, ebufp);
			/* Check for Source IMSI */
			if (namep && strcmp(namep, source_imsi) == 0 && svc_elemid == 1)
			{
				match_source_imsi = 1;
			}
			/* Check for Destination IMSI */
			if (namep && strcmp(namep, destination_imsi) == 0 && svc_elemid != 0 && svc_elemid != 1)
			{
				match_destination_imsi = 1;
				dest_rec_id = svc_elemid;
			}
		}
	}
	if(match_source_imsi == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_SOURCE_IMSI, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Invalid TAB_FLD_SOURCE_IMSI passed in the Input", ebufp);
		goto cleanup;
	}
	if(match_destination_imsi == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_DESTINATION_IMSI, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim: Invalid TAB_FLD_DESTINATION_IMSI passed in the Input", ebufp);
		goto cleanup;
	
	}
	/* To update dummy values for both rec_ids of IMSI */	
	if(!fm_tab_cust_swap_sim_update(ctxp, in_flistp, TAB_TEMP_SWAP_IMSI_1, TAB_TEMP_SWAP_IMSI_2, dest_rec_id,db_no, ebufp) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_swap_sim:"
		" fm_tab_cust_swap_sim_update output flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_swap_sim: "
		"fm_tab_cust_swap_sim_update error for temp imsi", ebufp);
		goto cleanup;	
	}
	/* To update exact imsi data for both rec_ids of IMSI */
	if( !fm_tab_cust_swap_sim_update(ctxp, in_flistp, destination_imsi, source_imsi, dest_rec_id,db_no, ebufp) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_swap_sim:"
		" fm_tab_cust_swap_sim_update output flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_swap_sim: "
		"fm_tab_cust_swap_sim_update error while swaping", ebufp);
		goto cleanup;	
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&service_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, NULL);
	return;
}

/**
 * We use this function to update the service info 
 * by calling opcode PCM_OP_CUST_UPDATE_SERVICE
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return boolean value true or false.
 */
static int32
fm_tab_cust_swap_sim_update(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	char			*source_imsi,
	char			*destination_imsi,
	int32			svc_elemid,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*acc_pdp = NULL;
	poid_t			*svc_pdp = NULL;

	pin_flist_t		*update_in_flistp = NULL;
	pin_flist_t		*update_out_flistp = NULL;
	pin_flist_t		*alias_flistp = NULL;
	pin_flist_t		*serv_array_flistp = NULL;
	pin_flist_t		*sub_flistp = NULL;

	int32			status = PIN_BOOLEAN_TRUE;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_swap_sim_update function entry error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		return status;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_swap_sim_update:"
		" input flist ", in_flistp);

	svc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
	acc_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	update_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(update_in_flistp, PIN_FLD_POID, (void *)acc_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, update_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);

	serv_array_flistp = PIN_FLIST_ELEM_ADD(update_in_flistp, PIN_FLD_SERVICES, 1, ebufp);
	PIN_FLIST_FLD_SET(serv_array_flistp, PIN_FLD_POID, (void *)svc_pdp, ebufp);

	alias_flistp = PIN_FLIST_ELEM_ADD(serv_array_flistp, PIN_FLD_ALIAS_LIST, 1, ebufp);
	PIN_FLIST_FLD_SET(alias_flistp, PIN_FLD_NAME, source_imsi, ebufp);

	alias_flistp = PIN_FLIST_ELEM_ADD(serv_array_flistp, PIN_FLD_ALIAS_LIST, svc_elemid, ebufp);
	PIN_FLIST_FLD_SET(alias_flistp, PIN_FLD_NAME, destination_imsi, ebufp);

	sub_flistp = PIN_FLIST_SUBSTR_ADD(update_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 4190005 166
	 * 0 PIN_FLD_PROGRAM_NAME    STR [0] "manage msisdn_sim"
	 * 0 PIN_FLD_SERVICES      ARRAY [1] allocated 20, used 3
	 * 1     PIN_FLD_POID           POID [0] 0.0.0.1 /service/telco/gsm/telephony 4188597 1
	 * 1     PIN_FLD_ALIAS_LIST    ARRAY [0] allocated 20, used 1
	 * 2         PIN_FLD_NAME            STR [0] "23122020016"
	 * 1     PIN_FLD_ALIAS_LIST    ARRAY [1] allocated 20, used 1
	 * 2         PIN_FLD_NAME            STR [0] "2312202000016"
	 * */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_swap_sim_update:"
		" CUST_UPDATE_SERVICES input flist ", update_in_flistp);

	PCM_OP(ctxp, PCM_OP_CUST_UPDATE_SERVICES, 0, update_in_flistp, &update_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim_update:"
			" input flist ", update_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_swap_sim_update:"
			" Error in Update Service: ", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_swap_sim_update:"
		" CUST_UPDATE_SERVICES output flist ", update_out_flistp);

	/*******************************************************************
	 *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&update_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_in_flistp, NULL);
	return status;
}
