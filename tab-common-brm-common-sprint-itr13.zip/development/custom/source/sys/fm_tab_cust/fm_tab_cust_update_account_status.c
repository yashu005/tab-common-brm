/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 20/Dec/2021 | Dandi Madhavi		| 			| New opcode implementation to
 *                                               			| update the account status
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_UPDATE_ACCOUNT_STATUS operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_update_account_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_update_account_status(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_update_account_status_notification(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             *o_flistp,
        int64                   db_no,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_UPDATE_ACCOUNT_STATUS is implemented 
 * to update the staus of the accounts
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNTS, PIN_FLD_STATUS
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "mall_acct1"
 * 0 PIN_FLD_LASTSTAT_CMNT   STR [0] “Customer Initiated”
 * 0 PIN_FLD_STATUS         ENUM [0] 1
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"

 */

void
op_tab_cust_update_account_status(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;
	pin_flist_t		*i_flistp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_update_account_status function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_UPDATE_ACCOUNT_STATUS) {
	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_account_status input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_ACCOUNT_STATUS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_ACCOUNT_STATUS)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_UPDATE_ACCOUNT_STATUS,ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if(!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status:"
				"input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_account_status:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		i_flistp = PIN_FLIST_COPY(enrich_iflistp, ebufp);
		fm_tab_cust_update_account_status(ctxp, flags, i_flistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status:"
				"input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_account_status error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_account_status input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_account_status: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
			cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_UPDATE_ACCOUNT_STATUS", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_ACCOUNT_STATUS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_ACCOUNT_STATUS)
		{
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_CODE,log_msg,ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_UPDATE_ACCOUNT_STATUS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		 if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
                             PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&i_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_account_status output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to modify the profile information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_update_account_status(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*account_poidp = NULL;
	int32			*acct_status = NULL;
	pin_flist_t		*update_acctstatus_iflistp = NULL;
	pin_flist_t		*hook_set_status_iflistp = NULL;
	char			db_no_str[10];
	char			*acct_no = NULL;
	pin_flist_t             *notify_oflistp = NULL;
	pin_flist_t		*r_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_account_status: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_account_status function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_account_status: input flist", in_flistp);

	/*validating input arguments*/
	acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if ((acct_no == NULL || strlen(acct_no) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
			"Error PIN_FLD_ACCOUNT_NO-Input is missing", ebufp);
		goto cleanup;
	}

	acct_status = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_STATUS, 1, ebufp);
	if (acct_status == NULL || *acct_status <= 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_update_account_status: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_STATUS_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_account_status: Error PIN_FLD_STATUS-Input is missing", ebufp);
		goto cleanup;
	}

	account_poidp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 0, ebufp);

	/*Input flist for TAB_OP_CUST_POL_UPDATE_ACCOUNT_STATUS
	 * 0 PIN_FLD_POID              POID [0] 0.0.0.1 /account 18793534 0
	 * 0 PIN_FLD_LASTSTAT_CMNT      STR [0] “Customer Initiated”
	 * 0 PIN_FLD_STATUS            ENUM [0] 10002
	 * 0 PIN_FLD_CORRELATION_ID     STR [0] "er2345"
	 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
	 * */

	update_acctstatus_iflistp = PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_FLD_SET(update_acctstatus_iflistp, PIN_FLD_POID, account_poidp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LASTSTAT_CMNT, update_acctstatus_iflistp, PIN_FLD_LASTSTAT_CMNT, ebufp); 
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STATUS, update_acctstatus_iflistp, PIN_FLD_STATUS, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, update_acctstatus_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, update_acctstatus_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, update_acctstatus_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/*Add source database*/
	memset(db_no_str, '\0', sizeof(db_no_str));
	snprintf(db_no_str, sizeof(db_no_str), "%d", db_no);

	if(db_no_str != NULL)
	{
		PIN_FLIST_FLD_SET(update_acctstatus_iflistp, PIN_FLD_SRC_DATABASE, db_no_str, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_update_account_status:"
		"TAB_OP_CUST_POL_UPDATE_ACCOUNT_STATUS input flist", update_acctstatus_iflistp);

	/*Calling TAB_OP_CUST_POL_UPDATE_ACCOUNT_STATUS Policy opcode to update account status as per BU's*/
	PCM_OP(ctxp, TAB_OP_CUST_POL_UPDATE_ACCOUNT_STATUS, 0, update_acctstatus_iflistp, &hook_set_status_iflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_update_account_status:"
			"Hook opcode Input flist", update_acctstatus_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_update_account_status:" 
			"Hook opcode input flist error", ebufp);
		PIN_FLIST_DESTROY_EX (&update_acctstatus_iflistp, NULL);
		*ret_flistpp = hook_set_status_iflistp;
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_update_account_status:Hook Opcode"
		"output flist", hook_set_status_iflistp);
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	/*Call function to enrich notification details*/
	fm_tab_cust_update_account_status_notification(ctxp,in_flistp,hook_set_status_iflistp,
			db_no,&notify_oflistp,ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status:"
			" fm_tab_cust_update_account_status_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status: "
			" fm_tab_cust_update_account_status_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	/*******************************************************************
	Memory Cleanup
	*******************************************************************/
	PIN_FLIST_DESTROY_EX (&update_acctstatus_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&hook_set_status_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	return;

}



/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_UPDATE_ACCOUNT_STATUS for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_cust_update_account_status_notification(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_flist_t             *o_flistp,
	int64                   db_no,
	pin_flist_t             **r_flistpp,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *enrich_notify_flistp = NULL;
	pin_flist_t             *notify_iflistp = NULL;
	pin_flist_t             *notify_flistp = NULL;
	poid_t                  *notify_pdp = NULL;
	time_t                  current_time = pin_virtual_time((time_t *)NULL);
	time_t                  change_date =0;
	pin_flist_t             *temp_flistp = NULL;
	pin_flist_t             *notify_out_flistp = NULL;
	char                    log_msg1[512]="";


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_update_account_status_notification"
			"input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_account_status_notification"
			"function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_account_status_notification: "
		"input flist", i_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_account_status_notification: "
		"output flist", o_flistp);

	change_date = current_time;
	sprintf(log_msg1, "%ld", change_date);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg1);


	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_UPDATE_ACCOUNT_STATUS, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	
	char *change_date_str = (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&change_date,ebufp);
	PIN_FLIST_FLD_SET(notify_flistp, TAB_FLD_EVENT_DATE, change_date_str, ebufp);
	free(change_date_str);

        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STATUS, notify_flistp, PIN_FLD_STATUS, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LASTSTAT_CMNT, notify_flistp, PIN_FLD_REASON_CODE, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_update_account_status_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_UPDATE_ACCOUNT_STATUS input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_UPDATE_ACCOUNT_STATUS, 0,
			notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_update_account_status_notification:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_update_account_status_notification:"
				" Error in Notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_update_account_status_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_UPDATE_ACCOUNT_STATUS output flist ", enrich_notify_flistp);


cleanup:
	/******************************************************************
	  Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_update_account_status_notification output flist", *r_flistpp);

	return;
}

