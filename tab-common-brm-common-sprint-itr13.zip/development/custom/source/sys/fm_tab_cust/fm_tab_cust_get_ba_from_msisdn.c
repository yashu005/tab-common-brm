/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  |24/Dec/2021 | Akshay Gund        |       	        | New opcode implementation
 *                                                      	| to get BA details from MSISDN
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_BA_FROM_MSISDN operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_pymt.h"
EXPORT_OP void
op_tab_cust_get_ba_from_msisdn(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_ba_from_msisdn(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/* Extern functions */

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_CUST_GET_BA_FROM_MSISDN is implemented to get BA details from msisdn
 *
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN,PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 * */

void
op_tab_cust_get_ba_from_msisdn(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp=NULL;

	int64			db_no=0;
	int32			status=PIN_BOOLEAN_TRUE;
	char			log_msg[512]= "";
	int32			error_clear_flag=1;
	int32			cerror_code=0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_get_ba_from_msisdn function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		return;
	}
	*ret_flistpp = NULL;
	/****************************
	 * Insanity check.
	 ***************************/
	if(opcode != TAB_OP_CUST_GET_BA_FROM_MSISDN) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn bad opcode error",
			ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		return;
	}

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}

	fm_tab_cust_get_ba_from_msisdn(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp); 
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_ba_from_msisdn output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;


cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn:"
				" Error while geting details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_BA_FROM_MSISDN;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_BA_FROM_MSISDN)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_BA_FROM_MSISDN, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_fnf output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to get parent information.
 * If account have parent details then PIN_FLD_PAYINFO_TYPE
 * and other information is returned in output flist
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 * *
 *  */

static void
fm_tab_cust_get_ba_from_msisdn(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*bill_grp_inp_flistp=NULL;
	pin_flist_t		*bill_grp_out_flistp=NULL;
	pin_flist_t		*context_info_flsitp=NULL;
	pin_flist_t		*parent_readobj_flistp=NULL;
	pin_flist_t		*parent_readobj_out_flistp=NULL;
	pin_flist_t		*acc_billinfo_inp_flistp=NULL;
	pin_flist_t		*acc_billinfo_out_flistp=NULL;
	pin_flist_t		*final_res_flistp=NULL;
	pin_flist_t		*billinfo_flistp=NULL;

	poid_t			*parent_pdp=NULL;
	int32			*paytypep=0;
	int32			status=PIN_BOOLEAN_TRUE;
	char                    *msisdn = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_ba_from_msisdn function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_ba_from_msisdn in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_ba_from_msisdn: input flist", in_flistp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if((msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_get_ba_from_msisdn: Error PIN_FLD_MSISDN - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn:"
				"input flist", in_flistp);
		goto cleanup;
	}


	/***************************************************************
	  Call opcode PCM_OP_BILL_GROUP_GET_PARENT to get PIN_FLD_PARENT 
	 ****************************************************************/

	bill_grp_inp_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_OBJ,bill_grp_inp_flistp,PIN_FLD_POID, ebufp);
	context_info_flsitp=PIN_FLIST_SUBSTR_ADD(bill_grp_inp_flistp, PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_info_flsitp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_info_flsitp,PIN_FLD_EXTERNAL_USER,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_ba_from_msisdn:"
			"input flist :bill_grp_inp_flistp",bill_grp_inp_flistp );

	PCM_OP(ctxp,PCM_OP_BILL_GROUP_GET_PARENT,0, bill_grp_inp_flistp, &bill_grp_out_flistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		status= TAB_FAIL;
		PIN_FLIST_FLD_SET(final_res_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_ba_from_msisdn input flist:"
				"bill_grp_inp_flistp",bill_grp_inp_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_ba_from_msisdn: Error in getting service object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_ba_from_msisdn: "
				"return flist :bill_grp_out_flistp", bill_grp_out_flistp);
	}
	PIN_FLIST_DESTROY_EX(&bill_grp_inp_flistp, NULL);

	/****************************************************
	  Check if parent field is null or not.
	 *****************************************************/
	parent_pdp= PIN_FLIST_FLD_GET(bill_grp_out_flistp,PIN_FLD_PARENT,1,ebufp);

	if(!PIN_POID_IS_NULL(parent_pdp))
	{
		parent_readobj_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(bill_grp_out_flistp, PIN_FLD_PARENT, parent_readobj_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_SET(parent_readobj_flistp, PIN_FLD_CUSTOMER_SEGMENT_LIST, NULL, ebufp);
		PIN_FLIST_FLD_SET(parent_readobj_flistp, PIN_FLD_GL_SEGMENT, NULL, ebufp);
		PIN_FLIST_FLD_SET(parent_readobj_flistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);
		PIN_FLIST_FLD_SET(parent_readobj_flistp, PIN_FLD_BUSINESS_TYPE, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_OBJ for parent details: input flist", parent_readobj_flistp);

		/****************************************************
		  Call PCM_OP_READ_OBJ opcode to get parent information.
		 *****************************************************/
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, parent_readobj_flistp, &parent_readobj_out_flistp, ebufp);
		PIN_FLIST_DESTROY_EX (&parent_readobj_flistp, NULL);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			status= TAB_FAIL;
			PIN_FLIST_FLD_SET(final_res_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ for parent details:"
					"input flist", parent_readobj_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ for parent details:" 
					"Error while reading account obj.", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_OBJ for parent details:"
					"output flist", parent_readobj_out_flistp);
		}
	}

	else
	{
		status= TAB_FAIL;
		PIN_FLIST_FLD_SET(final_res_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_PARENT_DATA_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn:"
				"No parent information found", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_ba_from_msisdn parent_readobj_flistp", parent_readobj_flistp);
		goto cleanup;
	}

	/*******************************************
	  Prepare output flist final_res_flistp 
	 ********************************************/
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, final_res_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MSISDN,final_res_flistp,PIN_FLD_MSISDN,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,final_res_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,final_res_flistp,PIN_FLD_EXTERNAL_USER,ebufp);
	PIN_FLIST_FLD_COPY(parent_readobj_out_flistp,PIN_FLD_CUSTOMER_SEGMENT_LIST,
			final_res_flistp,PIN_FLD_CUSTOMER_SEGMENT_LIST,ebufp);
	PIN_FLIST_FLD_COPY(parent_readobj_out_flistp,PIN_FLD_GL_SEGMENT,final_res_flistp,PIN_FLD_GL_SEGMENT,ebufp);
	PIN_FLIST_FLD_COPY(parent_readobj_out_flistp,PIN_FLD_ACCOUNT_NO,final_res_flistp,TAB_FLD_PARENT_ACT_NO,ebufp);
	PIN_FLIST_FLD_COPY(parent_readobj_out_flistp,PIN_FLD_BUSINESS_TYPE,final_res_flistp,PIN_FLD_BUSINESS_TYPE,ebufp);

	/****************************************************************************
	  Calling PCM_OP_BAL_GET_ACCT_BILLINFO opcode to get PIN_FLD_PAYINFO_TYPE field
	 *****************************************************************************/

	acc_billinfo_inp_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(parent_readobj_out_flistp, PIN_FLD_POID, acc_billinfo_inp_flistp, PIN_FLD_POID, ebufp);
	context_info_flsitp=PIN_FLIST_SUBSTR_ADD(acc_billinfo_inp_flistp, PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_info_flsitp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_info_flsitp,PIN_FLD_EXTERNAL_USER,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_BAL_GET_ACCT_BILLINFO: input flist", acc_billinfo_inp_flistp);

	PCM_OP(ctxp, PCM_OP_BAL_GET_ACCT_BILLINFO, 0, acc_billinfo_inp_flistp, &acc_billinfo_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX (&acc_billinfo_inp_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_BAL_GET_ACCT_BILLINFO: "
			"output flist acc_billinfo_out_flistp", acc_billinfo_out_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		status= TAB_FAIL;
		PIN_FLIST_FLD_SET(final_res_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn:acc_billinfo_inp_flistp ",
				acc_billinfo_inp_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_BILLING_ACC_INFO,0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_ba_from_msisdn:"
				"Error while getting Account Billinfo: ", ebufp);
		goto cleanup;
	}
	else
	{
		billinfo_flistp = PIN_FLIST_ELEM_GET(acc_billinfo_out_flistp, PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 0,ebufp);		
		paytypep = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);
		if (*paytypep == PIN_PAY_TYPE_PREPAID)
		{
			PIN_FLIST_FLD_SET(final_res_flistp, PIN_FLD_PAYINFO_TYPE, TAB_PAYINFO_PREPAID, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_SET(final_res_flistp, PIN_FLD_PAYINFO_TYPE, TAB_PAYINFO_POSTPAID, ebufp);
		}
		status= TAB_SUCCESS;
		PIN_FLIST_FLD_SET(final_res_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		*ret_flistpp= PIN_FLIST_COPY(final_res_flistp, ebufp);
	}

cleanup:

	PIN_FLIST_DESTROY_EX(&acc_billinfo_out_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&parent_readobj_out_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&bill_grp_out_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&final_res_flistp,NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_get_ba_from_msisdn output flist", *ret_flistpp);
	return;
}
