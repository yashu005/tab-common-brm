/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 21/Feb/2022 | Dandi Madhavi		| 			| New opcode implementation to
 *                          		             			| cancel Budget Limit
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_CANCEL_BUDGET_LIMIT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_cust_cancel_budget_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_cancel_budget_limit(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


static void
fm_tab_cust_cancel_budget_limit_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);


/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_create_limit_event(
    pcm_context_t        *ctxp,
    int64            db_no,
    poid_t            *event_pdp,
    pin_flist_t        *in_flistp,
    pin_flist_t        **out_flistpp,
    pin_errbuf_t        *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_CANCEL_BUDGET_LIMIT is implemented to
 * cancel the budget control / service level credit limit 
 * for the provided Account Number/MSISDN
 * 
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNT,
 * PIN_FLD_CHANNEL, PIN_FLD_USER_NAME, TAB_FLD_CL_TYPE
 * and TAB_FLD_SERV_DETAILS
 *
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO             STR [0] "CN-0999009"
 * 0 PIN_FLD_MSISDN    			 	    STR [0] "91909990099"
 * 0 TAB_FLD_SERV_DETAILS           STR [0] "SMS"
 * 0 PIN_FLD_CHANNEL                STR [0] "Ch001"
 * 0 PIN_FLD_USER_NAME              STR [0] "User1"
 * 0 TAB_FLD_CL_TYPE                INT [0] 0
 * 0 PIN_FLD_CORRELATION_ID         STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER          STR [0] "CRM"
 *
 */

void
op_tab_cust_cancel_budget_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_cancel_budget_limit function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_CANCEL_BUDGET_LIMIT) {

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_cancel_budget_limit input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			 &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_BUDGET_LIMIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_BUDGET_LIMIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_BUDGET_LIMIT, ebufp);
		}
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_cancel_budget_limit input flist",in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_budget_limit:"
			"fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_cancel_budget_limit(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_cancel_budget_limit input flist",in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_cancel_budget_limit input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_CANCEL_BUDGET_LIMIT", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			"input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
				"Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CANCEL_BUDGET_LIMIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CANCEL_BUDGET_LIMIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CANCEL_BUDGET_LIMIT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_cancel_budget_limit output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to modify the profile information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_cancel_budget_limit(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*hook_cancel_budget_flistp = NULL;
	int32			*cl_type = NULL;
	char			*serv_details = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	char                    *msisdn = NULL;
	pin_errbuf_t		local_ebuf = {0};
	pin_errbuf_t		*local_ebufp = &local_ebuf;
	poid_t            *event_pdp=NULL;
    pin_flist_t        *result_flistp = NULL;
    int32                   error_code = 0;
    pin_flist_t        *event_rflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_budget_limit:"
		"input flist", in_flistp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"Error PIN_FLD_MSISDN is missing", ebufp);
		goto cleanup;
	}

	cl_type = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE , 1, ebufp);
	if( cl_type && !((*cl_type == TAB_CL_TYPE_DOMESTIC) || (*cl_type == TAB_CL_TYPE_IR_BUDGET) ||
		(*cl_type == TAB_CL_TYPE_SERVICE_WISE)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_CL_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit: Error Invalid credit limit type passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_budget_limit: input flist", in_flistp);
		goto cleanup;
	}
	if(cl_type == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_CL_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit: Error TAB_FLD_CL_TYPE- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_budget_limit: input flist", in_flistp);
		goto cleanup;
	}

	serv_details = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SERV_DETAILS, 1, ebufp);
	if((*cl_type == TAB_CL_TYPE_SERVICE_WISE ) && (serv_details == NULL || strlen(serv_details) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERV_DETAILS_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit: Error TAB_FLD_SERV_DETAILS- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_budget_limit: input flist", in_flistp);
		goto cleanup;
	}
	if(serv_details && !((strcmp(serv_details, TAB_SERVICE_VOICE) == 0) || 
		(strcmp(serv_details, TAB_SERVICE_SMS) == 0) ||
			(strcmp(serv_details, TAB_SERVICE_DATA) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_SERV_DETAILS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_cancel_budget_limit: Error Invalid service details passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_budget_limit: input flist", in_flistp);
		goto cleanup;
	}

	/*Calling Policy Opcode*/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_budget_limit:Hook input flist", in_flistp);
	PCM_OP(ctxp,TAB_OP_CUST_POL_CANCEL_BUDGET_LIMIT,0, in_flistp,&hook_cancel_budget_flistp,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"Hook opcode  flist", in_flistp);
		error_code = (ebufp)->pin_err;
        PIN_ERRBUF_CLEAR(ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "Hook opcode:Return flist", *ret_flistpp);
        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                error_code, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_cancel_budget_limit:"
			"Hook opcode flist error", ebufp);
		PIN_FLIST_DESTROY_EX(ret_flistpp, NULL);
		*ret_flistpp = PIN_FLIST_COPY(hook_cancel_budget_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_budget_limit:Hook return flist", 
		hook_cancel_budget_flistp);
	if(hook_cancel_budget_flistp)
    {
        PIN_FLIST_FLD_COPY(hook_cancel_budget_flistp, PIN_FLD_RESOURCE_ID, in_flistp,
            PIN_FLD_RESOURCE_ID, ebufp);
        if((result_flistp = PIN_FLIST_ELEM_GET(hook_cancel_budget_flistp, PIN_FLD_RESULTS,
            PIN_ELEMID_ANY, 1, ebufp ))!= NULL)
        {
            event_pdp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID, 1, ebufp);
            /*Calling util_function to create event using CREATE_OBJ*/
            fm_tab_utils_common_create_limit_event(ctxp, db_no, event_pdp, in_flistp, &event_rflistp, ebufp);
            if (PIN_ERR_IS_ERR(ebufp))
            {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event"
                        "error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event:",
                        in_flistp);
                goto cleanup;
            }
        }
    }
    else
    {
        pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_API_CANCEL_BUDGET_LIMIT, 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_cust_cancel_budget_limit: Error hook opcode flist ", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_cancel_budget_limit: input flist", in_flistp);
        goto cleanup;
    }
	/*Call function to enrich notification details*/
	fm_tab_cust_cancel_budget_limit_notification(ctxp, in_flistp,hook_cancel_budget_flistp, db_no,
			&notify_oflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses:"
			" fm_tab_cust_cancel_budget_limit_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_addresses: "
			" fm_tab_cust_cancel_budget_limit_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:

	/******************************************************************
	  Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&hook_cancel_budget_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&notify_oflistp, NULL);
	return;
}



/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_CANCEL_BUDGET_LIMIT for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_cust_cancel_budget_limit_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_cancel_budget_limit"
			"prepare_notification:input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_notify_cancel_budget_limit"
			"prepare_notification function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_budget_limit_notification: "
		"input flist", i_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_cancel_budget_limit_notification: "
		"output flist", o_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CANCEL_BUDGET_LIMIT, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CL_TYPE, notify_flistp, TAB_FLD_CL_TYPE, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_budget_limit_notification:"
		"TAB_OP_NOTIFY_POL_ENRICH_CANCEL_BUDGET_LIMIT input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CANCEL_BUDGET_LIMIT, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_budget_limit_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_cancel_budget_limit_notification:"
			" Error in Notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_cancel_budget_limit_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CANCEL_BUDGET_LIMIT output flist ", enrich_notify_flistp);


cleanup:
	/******************************************************************
	  Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_cancel_budget_limit_notification output flist", *r_flistpp);

	return;
}

