/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       	| Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  | 13/Dec/2021 | Dandi Madhavi		| 					| New opcode implementation to delete group member
 * 2  | 21/Mar/2022 | Shubha Bhardwaj	| 					| added notification changes and validations
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_DELETE_GROUP_MEMBER operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_cust_delete_group_member(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_delete_group_member(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_delete_group_member_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);
	
extern int64
fm_tab_utils_common_compare_db_no(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	int64                   db_no,
	pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_CUST_DELETE_GROUP_MEMBER is implemented to manage 
 * delete a member from Group
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNTS, PIN_FLD_MEMBERS
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID		POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO		STR [0] "202120211289"
 * 0 PIN_FLD_MEMBERS		ARRAY [1]  
 * 1 	PIN_FLD_ACCOUNT_NO	STR [0] "0.0.0.1-18578834"
 * 1    PIN_FLD_MSISDN		STR [0] "68748927495"
 * 0 PIN_FLD_CORRELATION_ID	STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER	STR [0] "CRM"
 *
 */

void
op_tab_cust_delete_group_member(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	char			*acct_no = NULL;	
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_cust_delete_group_member function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_DELETE_GROUP_MEMBER) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_delete_group_member bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_delete_group_member input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}



	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_DELETE_GROUP_MEMBER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_DELETE_GROUP_MEMBER)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_DELETE_GROUP_MEMBER, ebufp);
		}
        fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		
		/* Validate the input arguments */
		acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
		if ((acct_no == NULL || strlen(acct_no) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PARENT_ACCT_NO_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_delete_group_member: Error PIN_FLD_ACCOUNT_NO-Input is missing", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_ACCT_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_delete_group_member: "
			"fm_tab_utils_common_validate_and_normalize_input error: input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_delete_group_member(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_delete_group_member error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
        
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_delete_group_member: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_CUST_DELETE_GROUP_MEMBER", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_DELETE_GROUP_MEMBER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_DELETE_GROUP_MEMBER)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_DELETE_GROUP_MEMBER, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_delete_group_member output flist", *ret_flistpp);

	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to modify the profile information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_cust_delete_group_member(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t             *second_validate_rflistp = NULL;
	pin_flist_t             *delete_member_iflistp = NULL;
	pin_flist_t             *delete_member_rflistp = NULL;
	pin_flist_t             *delete_member_enrich_flistp = NULL;
	pin_flist_t				*notify_oflistp = NULL;
	poid_t                  *grp_obj = NULL;
	pin_flist_t             *mem_flistp = NULL;
	poid_t                  *child_accpoidp  = NULL;
	pin_flist_t             *arg_flistp = NULL;
	pin_flist_t             *arg_flistp2 = NULL;
	pin_flist_t             *members_flistp = NULL;
	pin_flist_t             *paytype_iflistp = NULL;
    pin_flist_t             *paytype_rflistp = NULL;
    pin_flist_t             *billinfo_flistp= NULL;
	pin_cookie_t		cookie = NULL;
	int32                   elem_id = 0;
	int32                   *pay_type = NULL;
	int32                   error_code = 0;
	pin_flist_t             *grp_members_flistp =NULL;
	pin_flist_t		*second_validate_iflistp = NULL;	
	pin_flist_t		*second_validate_msisdn_iflistp = NULL;
	char			*child_accno = NULL;
	char			*child_msisdn = NULL;
	poid_t                  *a_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_delete_group_member function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member: input flist", in_flistp);

	/* Validate the input arguments */
	mem_flistp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MEMBERS, 1, ebufp);
	if (mem_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GRP_MEMBERS_ARRAY_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_delete_group_member: Error PIN_FLD_MEMBERS-Input is missing", ebufp);
		goto cleanup;
	}

	grp_obj=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_GROUP_OBJ, 0, ebufp);
	if(!PIN_POID_IS_NULL(grp_obj))
	{
		/********To get group obj's of members account**********/
		elem_id = 0;
		cookie = NULL;

		while(in_flistp && (grp_members_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp,
						PIN_FLD_MEMBERS,&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			if ((PIN_FLIST_FLD_GET(grp_members_flistp,PIN_FLD_ACCOUNT_NO,1,ebufp))!=NULL)
			{
				child_accno = PIN_FLIST_FLD_GET(grp_members_flistp, PIN_FLD_ACCOUNT_NO, 0, ebufp);
			}
			if ((PIN_FLIST_FLD_GET(grp_members_flistp,PIN_FLD_MSISDN,1,ebufp))!=NULL)
			{

				child_msisdn = PIN_FLIST_FLD_GET(grp_members_flistp, PIN_FLD_MSISDN, 0, ebufp);
			}
			if(cm_fm_is_multi_db() && fm_tab_utils_common_compare_db_no(ctxp, grp_members_flistp, db_no, ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_ACCT_DB_NO_MS,0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_delete_group_member:"
						"child account exists in different schema", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_cust_delete_group_member input flist", in_flistp);
				goto cleanup;
			}

			if ((child_accno == NULL || strlen(child_accno) == 0) && (child_msisdn == NULL || strlen(child_msisdn) == 0))
			{

				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_CHILD_ACCT_MSISDN_MISSING, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_cust_delete_group_member: Error PIN_FLD_ACCOUNT_NO and MSISDN - Input is missing", ebufp);
				goto cleanup;
			}
			else
			{
				/*Input Flist for the function
				  0 PIN_FLD_POID               POID [0] 0.0.0.1 /account -1 0
				  0 PIN_FLD_ACCOUNT_NO          STR [0] "0.0.0.1-18578834"
				  0 PIN_FLD_MSISDN		STR [0] "678900123"*/

				if (child_accno  && strlen(child_accno) != 0)
				{

					second_validate_iflistp = PIN_FLIST_CREATE(ebufp);
					a_pdp = PIN_POID_CREATE(db_no, "/account", -1, ebufp);
					PIN_FLIST_FLD_PUT(second_validate_iflistp, PIN_FLD_POID, (void *)a_pdp, ebufp);
					PIN_FLIST_FLD_SET(second_validate_iflistp, PIN_FLD_ACCOUNT_NO, child_accno, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member:childAcc i/p flist",
							second_validate_iflistp);

					//validating child account poid*
					fm_tab_utils_common_validate_and_normalize_input(ctxp, second_validate_iflistp, 
							&second_validate_rflistp,db_no,ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Child Account validation",second_validate_iflistp);
						pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_CHILD_ACCT_NOT_FOUND, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member Error:"
								"PIN_FLD_ACCOUNT_NO under MEMBERS Array is not found in BRM", ebufp);
						goto cleanup;
					}
				}
				if (child_msisdn && strlen(child_msisdn) != 0)
				{
					second_validate_msisdn_iflistp = PIN_FLIST_CREATE(ebufp);
					a_pdp = PIN_POID_CREATE(db_no, "/account", -1, ebufp);
					PIN_FLIST_FLD_PUT(second_validate_msisdn_iflistp, PIN_FLD_POID, (void *)a_pdp, ebufp);
					PIN_FLIST_FLD_SET(second_validate_msisdn_iflistp, PIN_FLD_MSISDN, child_msisdn, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member:childMsisdn i/p flist",
							second_validate_msisdn_iflistp);

					PIN_FLIST_DESTROY_EX (&second_validate_rflistp, NULL);
					//validating child msisdn poid
					fm_tab_utils_common_validate_and_normalize_input(ctxp, second_validate_msisdn_iflistp, 
							&second_validate_rflistp,db_no,ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Child Msisdn validation",second_validate_msisdn_iflistp);
						pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_MSISDN_NOT_FOUND, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member Error:"
								"PIN_FLD_MSISDN under MEMBERS Array is not found in BRM", ebufp);
						goto cleanup;
					}
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member:"
						"Validation output flist", second_validate_rflistp);

				child_accpoidp = PIN_FLIST_FLD_GET(second_validate_rflistp, PIN_FLD_POID, 0, ebufp);

				/* calling PCM_OP_BAL_GET_ACCT_BILLINFO to get PayType */
				paytype_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(paytype_iflistp, PIN_FLD_POID, child_accpoidp, ebufp);

				arg_flistp2 = PIN_FLIST_SUBSTR_ADD(paytype_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,arg_flistp2,
						PIN_FLD_CORRELATION_ID,ebufp);
				PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, arg_flistp2,
						PIN_FLD_EXTERNAL_USER, ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Get Pay_type from PCM_OP_BAL_GET_ACCT_BILLINFO:"
						"input flist", paytype_iflistp);
				/*Call PCM_OP_BAL_GET_ACCT_BILLINFO*/
				PCM_OP (ctxp, PCM_OP_BAL_GET_ACCT_BILLINFO, 0, paytype_iflistp, &paytype_rflistp, ebufp);
				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ACCT_BILLINFO"
							" input flist ",paytype_iflistp );
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_ADD_GROUP_MEMBER , 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ACCT_BILLINFO:"
							" Error while fetching member paytype", ebufp);
					goto cleanup;
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Get Pay_type from PCM_OP_BAL_GET_ACCT_BILLINFO:"
						"return flist", paytype_rflistp);

				if (paytype_rflistp && (billinfo_flistp=PIN_FLIST_ELEM_GET(paytype_rflistp,
								PIN_FLD_BILLINFO,PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					pay_type = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
					if(*pay_type == PIN_PAY_TYPE_SUBORD)
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_delete_group_member:"
								"input flist", in_flistp);
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_INVALID_ACCOUNT_PAYTYPE, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member:"
								"Subord paytype found for the given account",ebufp);
						goto cleanup;
					}
					else
					{	

						/*calling PCM_OP_BILL_GROUP_DELETE_MEMBER
						 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /group/billing 18660995 1
						 * 0     PIN_FLD_MEMBERS    ARRAY [0]
						 * 1       PIN_FLD_OBJECT           POID [0] 0.0.0.1 /account 18578834 0
						 * 0 PIN_FLD_CONTEXT_INFO      SUBSTRUCT [0]
						 * 1 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
						 * 1 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"*/

						delete_member_iflistp = PIN_FLIST_CREATE(ebufp);

						PIN_FLIST_FLD_SET(delete_member_iflistp, PIN_FLD_POID, grp_obj, ebufp);
						members_flistp = PIN_FLIST_ELEM_ADD(delete_member_iflistp, PIN_FLD_MEMBERS, 0, ebufp);
						PIN_FLIST_FLD_SET(members_flistp, PIN_FLD_OBJECT,child_accpoidp , ebufp);

						arg_flistp = PIN_FLIST_SUBSTR_ADD(delete_member_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
						PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_CORRELATION_ID,arg_flistp, PIN_FLD_CORRELATION_ID, ebufp);
						PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, arg_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Enrich DELETE Group Billing Member input flist", delete_member_iflistp );

						PCM_OP (ctxp, TAB_OP_CUST_POL_ENRICH_DELETE_GROUP_MEMBER, 0, delete_member_iflistp, &delete_member_enrich_flistp, ebufp);
						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,":TAB_OP_CUST_POL_ENRICH_DELETE_GROUP_MEMBER"
									" input flist ",delete_member_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_ENRICH_DELETE_GROUP_MEMBER:"
									" Error while deleteing group member", ebufp);
							error_code = (ebufp)->pin_err;
							PIN_ERRBUF_CLEAR(ebufp);
							*ret_flistpp= PIN_FLIST_COPY(delete_member_enrich_flistp, ebufp);
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									error_code, 0, 0, 0);

							goto cleanup;
						}

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"DELETE Group Billing Member input flist", delete_member_enrich_flistp);
						/*********Call PCM_OP_BILL_GROUP_DELETE_MEMBER **********/
						PCM_OP (ctxp, PCM_OP_BILL_GROUP_DELETE_MEMBER, 0, delete_member_enrich_flistp, &delete_member_rflistp, ebufp);
						if(PIN_ERR_IS_ERR(ebufp))
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									TAB_ERR_CODE_API_DELETE_GROUP_MEMBER , 0, 0, 0);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,":PCM_OP_BILL_GROUP_DELETE_MEMBER"
									" input flist ",delete_member_enrich_flistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_GROUP_DELETE_MEMBER:"
									" Error while deleteing group member", ebufp);
							goto cleanup;
						}
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "DELETE Group Billing Member return flist",
								delete_member_rflistp);

						members_flistp = PIN_FLIST_ELEM_ADD(*ret_flistpp, PIN_FLD_MEMBERS, elem_id, ebufp);
						if (child_accno  && strlen(child_accno) != 0)
						{
							PIN_FLIST_FLD_SET(members_flistp, PIN_FLD_ACCOUNT_NO, child_accno, ebufp);
						}
						if (child_msisdn && strlen(child_msisdn) != 0)
						{
							PIN_FLIST_FLD_SET(members_flistp, PIN_FLD_MSISDN, child_msisdn, ebufp);
						}
					}  
				}
			}
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_POID_NULL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_grp_billing_members:"
				"Group Account_poid is NULL for the given Account Number", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_delete_group_member output flist", *ret_flistpp);

	
	/*Call function to enrich notification details*/
	fm_tab_cust_delete_group_member_notification(ctxp, in_flistp,delete_member_rflistp, db_no,
			&notify_oflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member:"
			" fm_tab_cust_delete_group_member_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member: "
			" fm_tab_cust_delete_group_member_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_delete_group_member output flist", *ret_flistpp);
	
	/*******************************************************************
	 *          *  Memory Cleanup
	 *******************************************************************/
cleanup:

	PIN_FLIST_DESTROY_EX (&delete_member_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&delete_member_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&delete_member_enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&second_validate_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&second_validate_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&second_validate_msisdn_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX (&paytype_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&paytype_rflistp, NULL);
	return;

}


/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_DELETE_GROUP_MEMBER for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_cust_delete_group_member_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*msisdn_flistp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member_notification"
			"prepare_notification:input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_delete_group_member_notification"
			"prepare_notification function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member_notification: "
		"input flist", i_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_delete_group_member_notification: "
		"output flist", o_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	
	msisdn_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_MEMBERS, PIN_ELEMID_ANY, 1, ebufp);
	
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_DELETE_GROUP_MEMBER, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(msisdn_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_delete_group_member_notification:"
		"TAB_OP_NOTIFY_POL_ENRICH_DELETE_GROUP_MEMBER input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_DELETE_GROUP_MEMBER, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_delete_group_member_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_delete_group_member_notification:"
			" Error in Notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_delete_group_member_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_DELETE_GROUP_MEMBER output flist ", enrich_notify_flistp);


cleanup:
	/******************************************************************
	  Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_cust_delete_group_member_notification output flist", *r_flistpp);

	return;
}
