/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 17/02/2022 | Piyush Suryavanshi	| 			| Wrapper for credit limit modification.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_MODIFY_CREDIT_LIMIT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "ops/bill.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include <stdlib.h>
#include "pin_currency.h"
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_cust_modify_credit_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_modify_credit_limit(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

static void
fm_tab_cust_modify_cl_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/********************************************************************
 *
 * New opcode TAB_OP_CUST_MODIFY_CREDIT_LIMIT is implemented to modify
 * credit limit on account
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains credit limit info
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 ********************************************************************/
/*************************InputFlist********************************
	0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
	0 PIN_FLD_ACCOUNT_NO      STR [0] "CINT_ACC003"
	0 PIN_FLD_MSISDN      STR [0] "0902022002"
	0 PIN_FLD_RESOURCE_ID INT [0] 764
	0 PIN_FLD_CREDIT_LIMIT DECIMAL [0] 152
	0 PIN_FLD_THRESHOLDS ARRAY [0]
	1 PIN_FLD_THRESHOLD INT [0] 90
	0 TAB_FLD_ABSOLUTE_FLAG STR [0] "Y"
	0 PIN_FLD_CHANNEL STR [0] "Ch001"
	0 PIN_FLD_USER_NAME STR [0] "User1"
	0 PIN_FLD_DESCR STR [0] "Modify_cl"
	0 TAB_FLD_CL_TYPE INT [0] 0
	0 TAB_FLD_SERV_DETAILS STR [0] "SMS"
	0 TAB_FLD_TEMP_CL_FLAG INT [0] 1
	0 TAB_FLD_EXPIRY_T_STR STR [0] ""
	0 PIN_FLD_CORRELATION_ID      STR [0] "e122r234153232"
	0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 **********************************************************************/

void
op_tab_cust_modify_credit_limit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_modify_credit_limit:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_modify_credit_limit function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_MODIFY_CREDIT_LIMIT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_modify_credit_limit bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_modify_credit_limit input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_TRANS_ID, r_flistp,PIN_FLD_TRANS_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME, r_flistp,PIN_FLD_USER_NAME,ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_modify_credit_limit:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MODIFY_CREDIT_LIMIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MODIFY_CREDIT_LIMIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MODIFY_CREDIT_LIMIT, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{

		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_validate_and_normalize_input:"
					"flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_modify_credit_limit:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_modify_credit_limit(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
					"flist", enrich_iflistp);						
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_modify_credit_limit: Error while Opening transaction",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_modify_credit_limit:"
				"flist", in_flistp);		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_CUST_MODIFY_CREDIT_LIMIT", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MODIFY_CREDIT_LIMIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MODIFY_CREDIT_LIMIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MODIFY_CREDIT_LIMIT, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if(PIN_FLIST_ELEM_COUNT(r_flistp,TAB_FLD_NOTIFICATION,ebufp))
		{
			PIN_FLIST_ELEM_DROP(r_flistp,TAB_FLD_NOTIFICATION,PIN_ELEMID_ANY,ebufp);
		}

	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_modify_credit_limit output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/***********************************************************
 * fm_tab_cust_modify_credit_limit()
 * This function is used for modify the credit limit based on
 * credit limit type.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param db_no,Database number
 * @param ebufp The error buffer.
 * @returns a void.
 ***********************************************************/
static void
fm_tab_cust_modify_credit_limit(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_modify_credit_limit input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" in_flistp", in_flistp);
		return;
	}

	int 		cl_type=0;
	int32 		*resource_id=NULL;
	int 		currency=0;
	int		temp_cl_flag=0;
	char 		*absolute_flagp=NULL;
	poid_t 		*account_pdp=NULL;
	
	pin_flist_t 	*credit_limit_input_flistp=NULL;
	pin_flist_t 	*read_object_flistp=NULL;
	pin_flist_t 	*balance_flistp=NULL;
	pin_flist_t 	*pre_modify_cl_output_flistp=NULL;
	pin_flist_t 	*post_modify_cl_input_flistp=NULL;
	pin_flist_t 	*post_modify_cl_output_flistp=NULL;
	pin_flist_t	*credit_limit_output_flistp=NULL;
	pin_flist_t	*result_flistp=NULL;
	pin_flist_t	*limit_flistp=NULL;
	pin_flist_t 	*pol_limit_flistp=NULL;
	pin_flist_t	*temp_limit_flistp=NULL;
	pin_flist_t 	*get_credit_out_limit=NULL;
	pin_flist_t 	*balance_limit_flistp=NULL;
	pin_flist_t 	*balance_temp_limit_flistp=NULL;
	pin_flist_t 	*rbillinfo_flistp=NULL;
	pin_flist_t *get_credit_limit=NULL;
	pin_flist_t 	*enrich_resp_flistp=NULL;
	pin_flist_t 	*output_flistp=NULL;
	pin_errbuf_t	local_ebuf = {0};
	pin_errbuf_t	*local_ebufp = &local_ebuf;
	pin_flist_t		*enrich_return_flistp=NULL;

	poid_t 		*event_pdp=NULL;

	pin_decimal_t 	*credit_limitp= (pin_decimal_t *)NULL;
	pin_decimal_t 	*current_credit_limitp= pbo_decimal_from_str("0",ebufp);
	pin_decimal_t	*zero= pbo_decimal_from_str("0",ebufp);
	pin_decimal_t 	*new_credit_limitp= (pin_decimal_t *)NULL;

	char		*acct_nop = NULL;
	char		*msisdnp = NULL;
	char		*serv_details = NULL;
	char 		*input_expiry_date=NULL;
	char		*expiry_date=NULL;
	
	time_t 		end_date=0;
	time_t 		valid_to=0;
	int		*cl_typep = NULL;
	int 		pay_type=0;
	
	int 		elem_bal=0;
	pin_cookie_t 	cookie_bal=NULL;
	
	char		log_msg[512]= "";
	pin_flist_t    *event_rflistp = NULL;	

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
			"account number/msisdn is not passed", ebufp);
		pbo_decimal_destroy(&current_credit_limitp);
		return;
	}

	resource_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID,1,ebufp);
	if(resource_id == NULL || *resource_id == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_RESRC_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
			"Error ResourcId is missing in request", ebufp);
		goto cleanup;
	}
	sprintf(log_msg,"ResourceId %ld",*resource_id);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	if (!((*resource_id == PIN_CURRENCY_MYR) || (*resource_id == PIN_CURRENCY_THB) ||
		(*resource_id == PIN_CURRENCY_PKR)))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_RESRC_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
			"Error Invalid ResourceId provided other than MYR, THB & PKR", ebufp);
		goto cleanup;
	}

	cl_typep = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE , 1, ebufp);
	if( cl_typep && !((*cl_typep == TAB_CL_TYPE_DOMESTIC) || (*cl_typep == TAB_CL_TYPE_IR_BUDGET) ||
		(*cl_typep == TAB_CL_TYPE_SERVICE_WISE) || (*cl_typep == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_CL_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_modify_credit_limit: Error Invalid credit limit type passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		goto cleanup;
	}

	serv_details = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SERV_DETAILS, 1, ebufp);
	if(cl_typep && (*cl_typep == TAB_CL_TYPE_SERVICE_WISE) && (serv_details == NULL || strlen(serv_details) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERV_DETAILS_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_modify_credit_limit: Error TAB_FLD_SERV_DETAILS- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		goto cleanup;
	}
	if(serv_details && !((strcmp(serv_details, TAB_SERVICE_VOICE) == 0) || (strcmp(serv_details, TAB_SERVICE_SMS) == 0) ||
		(strcmp(serv_details, TAB_SERVICE_DATA) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_SERV_DETAILS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_modify_credit_limit: Error Invalid service details passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		goto cleanup;
	}

	absolute_flagp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_ABSOLUTE_FLAG, 1, ebufp);
	if (absolute_flagp && !(strcmp(absolute_flagp, "N") == 0 || strcmp(absolute_flagp, "Y") == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ABSOLUTE_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_modify_credit_limit: Error Invalid service details passed in request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit: input flist", in_flistp);
		goto cleanup;
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_TEMP_CL_FLAG,1,ebufp) != NULL)
	{	
		temp_cl_flag = *(int64*)PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_TEMP_CL_FLAG,1,ebufp);
	}

	if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_TEMP_CL_FLAG,1,ebufp) != NULL && *cl_typep != 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_FLAG_NOT_APPLICABLE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"Temp CL Flag is not required for NCR resource", ebufp);
		goto cleanup;
	}

	if (temp_cl_flag!=1 && temp_cl_flag!=0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_INVALID_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
		"Invalid temporary credit limit flag", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
		" input flist ", in_flistp);
		goto cleanup;
	}

	input_expiry_date = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_EXPIRY_T_STR, 1, ebufp);

	if (temp_cl_flag==1 && (input_expiry_date == NULL || strlen(input_expiry_date) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_EXPIRY_DATE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
		"expiry date is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
		" input flist ", in_flistp);
		goto cleanup;
	}

	if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE,1,ebufp)!=NULL )
	{
		cl_type=*(int*)PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CL_TYPE,0,ebufp);
	}

	if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CREDIT_LIMIT,1,ebufp)==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_CREDIT_LIMIT_NOT_PRESENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"credit limit not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", in_flistp);
		goto cleanup;
	}		
	if (cl_type==0 && !(input_expiry_date == NULL || strlen(input_expiry_date) == 0) && (temp_cl_flag !=1))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"temp flag is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", in_flistp);
		goto cleanup;
	}

	if(cl_type==3 && PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SERV_DETAILS,1,ebufp)==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SERVICE_DETAILS_NOT_PRESENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"service details not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", in_flistp);
		goto cleanup;
	}
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	/*******************************************************************
	 * get the pay type details
	 *******************************************************************/
	fm_tab_utils_common_get_billinfo(ctxp,account_pdp,0,&rbillinfo_flistp,db_no,ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		goto cleanup;
	}

	pay_type = *(int *)PIN_FLIST_FLD_GET(rbillinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if(pay_type == 10000)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_PAYTYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_billinfo:"
			"Error: Prepaid account found", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo:"
			" input flist ", in_flistp);
		goto cleanup;
	}

	fm_tab_utils_common_read_object(ctxp, account_pdp, &read_object_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object:",account_pdp);
		goto cleanup;
	}

	currency=*(int64*)PIN_FLIST_FLD_GET(read_object_flistp, PIN_FLD_CURRENCY,0,ebufp);


	/******************************************************************
	 * Currency comparision and throw error
	 ******************************************************************/

	if(currency != *resource_id)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_CURRENCY_MISMATCH, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"currency mismatch", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", in_flistp);
		goto cleanup;
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL: " "input Flist", in_flistp);
	PCM_OP( ctxp, TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL, 0, in_flistp, &output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL: " "output Flist", output_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_BAL_GRP_MODIFY_CL:", balance_flistp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp=PIN_FLIST_COPY(output_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(output_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(output_flistp, PIN_FLD_RESOURCE_ID, in_flistp, PIN_FLD_RESOURCE_ID, ebufp);	
	//get the current credit limit.
	get_credit_limit = PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_credit_limit, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, get_credit_limit, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, get_credit_limit, PIN_FLD_RESOURCE_ID, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : PCM_OP_BILL_GET_LIMIT: "
		"input Flist", get_credit_limit);

	PCM_OP( ctxp, PCM_OP_BILL_GET_LIMIT, 0, get_credit_limit, &get_credit_out_limit, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_BILL_GET_LIMIT: " "output Flist", get_credit_out_limit);
	
	PIN_FLIST_DESTROY_EX(&get_credit_limit, NULL);				
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_GET_LIMIT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_GET_LIMIT:", balance_flistp);
		goto cleanup;
	}
	
	if (PIN_FLIST_ELEM_COUNT(get_credit_out_limit, PIN_FLD_BALANCES,ebufp))
	{
		balance_flistp = PIN_FLIST_ELEM_GET(get_credit_out_limit, PIN_FLD_BALANCES, *resource_id, 1, ebufp );	
		balance_limit_flistp = PIN_FLIST_ELEM_GET(balance_flistp, PIN_FLD_LIMIT, PIN_ELEMID_ANY, 1, ebufp );
		PIN_FLIST_FLD_COPY(balance_limit_flistp, PIN_FLD_CREDIT_LIMIT,in_flistp, TAB_FLD_OLD_CREDIT_LIMIT, ebufp);
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_CL_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
			"get credit limit failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
			" input flist ", in_flistp);
		goto cleanup;
	}	

	
	/******************************************************************
	 * Credit limit input flist creation.
	 ******************************************************************/

	credit_limit_input_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, credit_limit_input_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, credit_limit_input_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, credit_limit_input_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, credit_limit_input_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	credit_limitp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CREDIT_LIMIT, 1, ebufp);

	if(!temp_cl_flag)
	{
		limit_flistp = PIN_FLIST_ELEM_ADD(credit_limit_input_flistp, PIN_FLD_LIMIT, *resource_id, ebufp);
		PIN_FLIST_ELEM_COPY(in_flistp, PIN_FLD_THRESHOLDS, 0, limit_flistp, PIN_FLD_THRESHOLDS, 0, ebufp);
	}
	
	//This subscruct to be used to populate the input flist to BU hooks.
	PIN_FLIST_SUBSTR_SET(credit_limit_input_flistp, in_flistp, PIN_FLD_IN_FLIST, ebufp);

	//This subscruct to be used to populate the PCM_OP_BILL_GET_LIMIT output flist to BU hooks.
	if(get_credit_out_limit != NULL)
	{
		PIN_FLIST_SUBSTR_SET(credit_limit_input_flistp, get_credit_out_limit, PIN_FLD_DATA, ebufp);
	}

	if (cl_type == 0)
	{

		if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp) == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_CURRENCY_NOT_PRESENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit:"
				"currency not present", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", in_flistp);
			goto cleanup;
		}

		if (temp_cl_flag == 1)
		{
			end_date = fm_tab_utils_common_convert_date_to_timestamp(ctxp, input_expiry_date, ebufp);

			sprintf(log_msg,"End Date %ld",end_date);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			if (strcmp(absolute_flagp,"Y") == 0)
			{
				//get valid current temp credit limit.
				if(PIN_FLIST_ELEM_COUNT(balance_flistp, PIN_FLD_TEMP_LIMIT, ebufp))
				{
					while ((balance_temp_limit_flistp = PIN_FLIST_ELEM_GET_NEXT(balance_flistp, 
						PIN_FLD_TEMP_LIMIT, &elem_bal, 1, &cookie_bal, ebufp)) != (pin_flist_t*)NULL)
					{
						valid_to = *(time_t*)PIN_FLIST_FLD_GET(balance_temp_limit_flistp, 
							PIN_FLD_VALID_TO,1,ebufp);
						
						sprintf(log_msg,"Valid to %ld",valid_to);
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
						
						if (valid_to >= end_date)
						{
							pbo_decimal_destroy(&current_credit_limitp);
							current_credit_limitp = (pin_decimal_t *)PIN_FLIST_FLD_GET(balance_temp_limit_flistp, 
								PIN_FLD_CREDIT_LIMIT,1,ebufp);
						}
					}
				}
			}
			new_credit_limitp = pbo_decimal_add(credit_limitp, current_credit_limitp, ebufp);
			temp_limit_flistp = PIN_FLIST_ELEM_ADD(credit_limit_input_flistp, PIN_FLD_TEMP_LIMIT, 0, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, temp_limit_flistp, PIN_FLD_RESOURCE_ID, ebufp);
			PIN_FLIST_FLD_SET(temp_limit_flistp, PIN_FLD_CREDIT_LIMIT, new_credit_limitp, ebufp);

			PIN_FLIST_FLD_SET(temp_limit_flistp, PIN_FLD_VALID_TO, (void*)&end_date, ebufp);
			//PIN_FLIST_ELEM_DROP(credit_limit_input_flistp, PIN_FLD_LIMIT,*resource_id,ebufp);
		}
		else
		{
			if (strcmp(absolute_flagp,"N") == 0)
			{
				pbo_decimal_destroy(&current_credit_limitp);
				current_credit_limitp = (pin_decimal_t *)PIN_FLIST_FLD_GET(balance_limit_flistp, PIN_FLD_CREDIT_LIMIT, 1, ebufp);
			}
			new_credit_limitp = pbo_decimal_add(credit_limitp, current_credit_limitp, ebufp);
		}

		if(PIN_FLIST_ELEM_COUNT(credit_limit_input_flistp, PIN_FLD_LIMIT, ebufp))
		{
			PIN_FLIST_FLD_SET(limit_flistp, PIN_FLD_CREDIT_LIMIT, new_credit_limitp, ebufp);
		}
		else if(PIN_FLIST_ELEM_COUNT(credit_limit_input_flistp, PIN_FLD_TEMP_LIMIT, ebufp))
		{
			PIN_FLIST_FLD_SET(temp_limit_flistp, PIN_FLD_CREDIT_LIMIT, new_credit_limitp, ebufp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : TAB_OP_CUST_POL_PRE_MODIFY_CL: "
			"input Flist", credit_limit_input_flistp);

		PCM_OP( ctxp, TAB_OP_CUST_POL_PRE_MODIFY_CL, 0, credit_limit_input_flistp, &pre_modify_cl_output_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_PRE_MODIFY_CL: "
			"output Flist", pre_modify_cl_output_flistp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit :"
				"TAB_OP_CUST_POL_PRE_MODIFY_CL error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit: TAB_OP_CUST_POL_PRE_MODIFY_CL:"
				" in_flistp", credit_limit_input_flistp);
			PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
			*out_flistpp = PIN_FLIST_COPY(pre_modify_cl_output_flistp,local_ebufp);
			PIN_ERR_CLEAR_ERR(local_ebufp);
			goto cleanup;
		}
	}
	else if (cl_type == 1 || cl_type == 2)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL: "
			"input Flist", credit_limit_input_flistp);
		PCM_OP( ctxp, TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL, 0, credit_limit_input_flistp, 
			&pre_modify_cl_output_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL: "
			"output Flist", pre_modify_cl_output_flistp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit :"
				"TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit: TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL:"
				" in_flistp", credit_limit_input_flistp);
			PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
			*out_flistpp = PIN_FLIST_COPY(pre_modify_cl_output_flistp,local_ebufp);
			PIN_ERR_CLEAR_ERR(local_ebufp);
			goto cleanup;
		}

		if (strcmp(absolute_flagp,"N") == 0)
		{
			pbo_decimal_destroy(&current_credit_limitp);
			current_credit_limitp = (pin_decimal_t *)PIN_FLIST_FLD_GET(balance_limit_flistp, PIN_FLD_CREDIT_LIMIT, 1, ebufp);
		}

		new_credit_limitp = pbo_decimal_add(credit_limitp, current_credit_limitp, ebufp);

		PIN_FLIST_FLD_SET(limit_flistp, PIN_FLD_CREDIT_LIMIT, new_credit_limitp, ebufp);

		if((pol_limit_flistp = PIN_FLIST_ELEM_GET(pre_modify_cl_output_flistp, PIN_FLD_LIMIT, 
			PIN_ELEMID_ANY, 1, ebufp ))!= NULL)
		{
			PIN_FLIST_FLD_SET(pol_limit_flistp, PIN_FLD_CREDIT_LIMIT,new_credit_limitp, ebufp);
		}

	}
	else if (cl_type==3)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL: "
			"input Flist", credit_limit_input_flistp);
		PCM_OP( ctxp, TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL, 0, credit_limit_input_flistp, 
			&pre_modify_cl_output_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL: "
			"output Flist", pre_modify_cl_output_flistp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit :"
				"TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit: TAB_OP_CUST_POL_PRE_NCR_MODIFY_CL:"
				" in_flistp", credit_limit_input_flistp);
			PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
			*out_flistpp=PIN_FLIST_COPY(pre_modify_cl_output_flistp,local_ebufp);
			PIN_ERR_CLEAR_ERR(local_ebufp);
			goto cleanup;
		}

		new_credit_limitp = pbo_decimal_add(credit_limitp, current_credit_limitp, ebufp);
		PIN_FLIST_FLD_SET(limit_flistp, PIN_FLD_CREDIT_LIMIT,new_credit_limitp, ebufp);
		
		if((pol_limit_flistp = PIN_FLIST_ELEM_GET(pre_modify_cl_output_flistp, PIN_FLD_LIMIT, 
			PIN_ELEMID_ANY, 1, ebufp ))!= NULL)
		{
			PIN_FLIST_FLD_SET(pol_limit_flistp, PIN_FLD_CREDIT_LIMIT, new_credit_limitp, ebufp);
		}
	}

	/*******PCM_OP_BILL_SET_LIMIT_AND_CR************************
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 2222704 0
	  0 PIN_FLD_PROGRAM_NAME    STR [0] "er123453241"
	  0 PIN_FLD_LIMIT         ARRAY [764] allocated 20, used 1
	  1     PIN_FLD_CREDIT_LIMIT DECIMAL [0] 52
	 ***********************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : PCM_OP_BILL_SET_LIMIT_AND_CR: "
		"input Flist", pre_modify_cl_output_flistp);
	PCM_OP( ctxp, PCM_OP_BILL_SET_LIMIT_AND_CR, 0, pre_modify_cl_output_flistp, &credit_limit_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_BILL_SET_LIMIT_AND_CR: "
		"output Flist", credit_limit_output_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit :PCM_OP_BILL_SET_LIMIT_AND_CR error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit: PCM_OP_BILL_SET_LIMIT_AND_CR:"
			" in_flistp", pre_modify_cl_output_flistp);
		goto cleanup;
	}


	if((result_flistp = PIN_FLIST_ELEM_GET(credit_limit_output_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp ))!= NULL)
	{
		event_pdp =PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID,1,ebufp);

		/*calling util_function to create an event using CREATE_OBJ*/
		fm_tab_utils_common_create_limit_event(ctxp, db_no, event_pdp, in_flistp, &event_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_create_limit_event:",in_flistp);
			goto cleanup;
		}
	}

	post_modify_cl_input_flistp = PIN_FLIST_COPY(credit_limit_output_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : TAB_OP_CUST_POL_POST_MODIFY_CL,: "
			"input Flist", credit_limit_output_flistp);
	PCM_OP( ctxp, TAB_OP_CUST_POL_POST_MODIFY_CL,0, post_modify_cl_input_flistp, &post_modify_cl_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_POST_MODIFY_CL,: "
			"output Flist", post_modify_cl_output_flistp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_CL_TYPE_IS_NOT_PRESENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_credit_limit"
				"error TAB_OP_CUST_POL_POST_MODIFY_CL", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_credit_limit:"
				" input flist ", post_modify_cl_input_flistp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp=PIN_FLIST_COPY(post_modify_cl_output_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}	
	
	enrich_resp_flistp=PIN_FLIST_COPY(*out_flistpp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_credit_limit : TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL,: "
			"input Flist", enrich_resp_flistp);
	PCM_OP( ctxp, TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL,0, enrich_resp_flistp,&enrich_return_flistp, ebufp );
	PIN_FLIST_DESTROY_EX(&enrich_resp_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL: input",enrich_resp_flistp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp= PIN_FLIST_COPY(enrich_return_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_CUST_POL_ENRICH_RESP_MODIFY_CL,: "
			"output Flist", enrich_return_flistp);
	fm_tab_cust_modify_cl_enrich_notification(ctxp,in_flistp,db_no,credit_limit_output_flistp,out_flistpp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_cl_enrich_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_modify_cl_enrich_notification:",in_flistp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	
	if(pbo_decimal_compare(current_credit_limitp, zero, ebufp) == 0)
	{
		pbo_decimal_destroy(&current_credit_limitp);
	}
	pbo_decimal_destroy(&zero);
	PIN_FLIST_DESTROY_EX(&credit_limit_output_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&post_modify_cl_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_credit_limit, NULL);
	PIN_FLIST_DESTROY_EX(&get_credit_out_limit, NULL);
	PIN_FLIST_DESTROY_EX(&read_object_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rbillinfo_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&credit_limit_input_flistp, NULL);
	pbo_decimal_destroy(&new_credit_limitp);
	PIN_FLIST_DESTROY_EX(&post_modify_cl_output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&pre_modify_cl_output_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_modify_credit_limit output flist", *out_flistpp);
	return;
}


/***********************************************************
 * fm_tab_cust_modify_cl_enrich_notification()
 * This function is used to send the notification details 
 * in the hook opcode 
 * @param in_flistp, Input Flist
 * @param db_no,Database number
 * @param OOB opcode outflist
 * @param ret_flistpp, retured flist after the execution.
 * @param ebufp The error buffer.
 * @returns a void.
 ***********************************************************/

static void
fm_tab_cust_modify_cl_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t 	*notify_out_flistp=NULL;
	poid_t			*notify_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_modify_cl_enrich_notification: "
				"input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_modify_cl_enrich_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_modify_cl_enrich_notification: "
			"input flist", i_flistp);

	notify_out_flistp =PIN_FLIST_CREATE(ebufp);
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_FLIST_ELEM_SET(notify_out_flistp, o_flistp, PIN_FLD_RESULTS_DATA,0, ebufp);
	PIN_FLIST_CONCAT(notify_out_flistp,*r_flistpp,ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);


	// Create Notification Flist
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_MODIFY_CL_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CREDIT_LIMIT,notify_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_OLD_CREDIT_LIMIT,notify_flistp, TAB_FLD_OLD_CREDIT_LIMIT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR,notify_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CREATED_T_STR,notify_flistp, TAB_FLD_CREATED_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_RESOURCE_ID,notify_flistp, PIN_FLD_RESOURCE_ID, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_cl_enrich_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_MODIFY_CL_NOTIFICATION input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MODIFY_CL_NOTIFICATION, 0,
			notify_iflistp, &enrich_notify_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MODIFY_CL_NOTFIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_modify_cl_enrich_notification:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_modify_cl_enrich_notification:"
				" Error in Notification", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_modify_cl_enrich_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_MODIFY_CL_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{			
		if ( ( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_out_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_modify_cl_enrich_notification output flist", *r_flistpp);
	return;
}

