/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 3-Jan-2022    | Akshay Gund 	|               | New opcode TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_cust_update_invoice_preference(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

//static functions 
static void
fm_tab_cust_update_invoice_preference(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_pol_update_invoice_pref_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		**opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);


extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   status,
        poid_t                  *account_pdp,
        char                    *opcode_name,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern int32
fm_tab_utils_common_trans_open(
        pcm_context_t           *ctxp,
        poid_t                  *pdp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE operation.
 *************************************************************************/
void
op_tab_cust_update_invoice_preference(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_update_invoice_preference function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_invoice_preference input flist", in_flistp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_invoice_preference bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_invoice_preference input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_INVOICE_PREFERENCE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_INVOICE_PREFERENCE)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_INVOICE_PREFERENCE, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
					" input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_update_invoice_preference:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_cust_update_invoice_preference(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_update_invoice_preference error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference"
						": enrich_iflistp", enrich_iflistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_cust_update_invoice_preference:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_cust_update_invoice_preference: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_CUST_UDPATE_INVOICE_PREFERENCE", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_update_invoice_preference:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_INVOICE_PREFERENCE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_INVOICE_PREFERENCE )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_INVOICE_PREFERENCE, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_update_invoice_preference output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/********************************************
 * We use this function to update invoice preference of account.
 * It will call notification function to notify SMS/mail.
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/
 
static void fm_tab_cust_update_invoice_preference(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*update_acc_prof_flistp = NULL;
	pin_flist_t	*hook_update_acc_prof_flistp = NULL;
	pin_flist_t	*update_customer_oflistp = NULL;
	pin_flist_t	*notify_oflistp = NULL;
	pin_flist_t	*context_info_flsitp=NULL;

	char		db_no_str[10];
	char		*acct_no = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_update_invoice_preference function entry error", ebufp);
	 	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_update_invoice_preference in_flistp", in_flistp);
		return;
		}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_cust_update_invoice_preference input flist", in_flistp);

	acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if ((acct_no == NULL || strlen(acct_no) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_update_invoice_preference:Error PIN_FLD_ACCOUNT_NO-Input is missing", ebufp);
		goto cleanup;
	}

	update_acc_prof_flistp = PIN_FLIST_COPY(in_flistp, ebufp);

	/*Add source database*/
	memset(db_no_str, '\0', sizeof(db_no_str));
	snprintf(db_no_str, sizeof(db_no_str), "%d", db_no);

	if(db_no_str != NULL)
	{
		PIN_FLIST_FLD_SET(update_acc_prof_flistp, PIN_FLD_SRC_DATABASE, db_no_str, ebufp);
	}

	context_info_flsitp=PIN_FLIST_SUBSTR_ADD(update_acc_prof_flistp, PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flsitp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flsitp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_FLIST_ELEM_DROP(update_acc_prof_flistp, PIN_FLD_CORRELATION_ID, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_ELEM_DROP(update_acc_prof_flistp, PIN_FLD_EXTERNAL_USER, PIN_ELEMID_ANY, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_cust_update_invoice_preference: TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE"
		       	"	input flist", update_acc_prof_flistp);

	PCM_OP(ctxp, TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE, 0, update_acc_prof_flistp, &hook_update_acc_prof_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_update_invoice_preference: TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE "
				"Hook opcode prepare Input flist", update_acc_prof_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_cust_update_invoice_preference: TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE "
				"Hook opcode prepare input flist error", ebufp);
		*out_flistpp = hook_update_acc_prof_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_update_invoice_preference: TAB_OP_CUST_POL_UPDATE_ACCOUNT_PROFILE "
				"output flist", hook_update_acc_prof_flistp);

	if(hook_update_acc_prof_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_update_invoice_preference: PCM_OP_CUST_UPDATE_CUSTOMER "
					"input flist ", hook_update_acc_prof_flistp);

		PCM_OP(ctxp, PCM_OP_CUST_UPDATE_CUSTOMER, 0, hook_update_acc_prof_flistp, &update_customer_oflistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_UPDATE_CUSTOMER, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference:"
					" input flist ", hook_update_acc_prof_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference:"
					" Error in update customer", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_cust_update_invoice_preference: PCM_OP_CUST_UPDATE_CUSTOMER"
			       	"	output flist ", update_customer_oflistp);
	}


	/*Call notification function to notify */
	
	fm_tab_cust_pol_update_invoice_pref_notify(ctxp, in_flistp, db_no, update_customer_oflistp, out_flistpp, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_UPDATE_INVOICE_PREFERENCE, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference:"
				" fm_tab_cust_pol_update_invoice_pref_notify input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_update_invoice_preference: "
				" fm_tab_cust_pol_update_invoice_pref_notify error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&update_acc_prof_flistp, NULL);
	//PIN_FLIST_DESTROY_EX(&hook_update_acc_prof_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_update_invoice_preference output flist", *out_flistpp);
	return;
}


/********************************************
 * We use this function to call notification opcode
 * It will create notification entry in Kafka queue.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

static void
fm_tab_cust_pol_update_invoice_pref_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		**opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_update_invoice_pref_notify error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_pol_update_invoice_pref_notify:"
				" input flist", i_flistp);
		return;
	}		

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_pol_update_invoice_pref_notify: "
			"input flist", i_flistp);

	notify_flistp= PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_SUBSTR_SET(notify_flistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
        PIN_FLIST_SUBSTR_SET(notify_flistp, *opresp_flistpp, PIN_FLD_OUT_FLIST, ebufp);

	out_flistp = PIN_FLIST_FLD_GET(notify_flistp, PIN_FLD_OUT_FLIST, 1, ebufp);
	PIN_FLIST_SUBSTR_PUT(out_flistp, results_flistp, PIN_FLD_RESULTS_DATA, ebufp);	

	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_UPDATE_INVOICE_PREFERENCE, -1, ebufp);
	common_notification_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO,
			common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_update_invoice_pref_notify:"
			" TAB_OP_NOTIFY_POL_ENRICH_UPDATE_INVOICE_PREFERENCE input flist ", notify_flistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_UPDATE_INVOICE_PREFERENCE, 0, notify_flistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_cust_pol_update_invoice_pref_notify:"
				" input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_cust_pol_update_invoice_pref_notify:"
				" Error in update invoice notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_pol_update_invoice_pref_notify:"
			" TAB_OP_NOTIFY_POL_ENRICH_UPDATE_INVOICE_PREFERENCE output flist ", enrich_notify_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 *******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_cust_pol_update_invoice_pref_notify output flist", *r_flistpp);
	return;
}

