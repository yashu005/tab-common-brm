/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date        | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  | 20/Dec/2021 | Ruhi Bhatnagar    |       	        | New opcode implementation
 *                                                      	| to get the account from id.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_CUST_GET_ACCOUNT_FROM_ID operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "pin_inv.h"


EXPORT_OP void
op_tab_cust_get_account_from_id(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_account_from_id(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_cust_get_account_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*i_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/****************************************************************
  External Routines Refered.
 *****************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t			*ctxp,
	pin_flist_t			*i_flistp,
	pin_errbuf_t			*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_service_from_accountpdp(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 * New opcode TAB_OP_CUST_GET_ACCOUNT_FROM_ID is implemented to
 * account details from ID.

 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_IDENTIFICATION_CODE, TAB_FLD_IDENTIFICATION_TYPE, PIN_FLD_CUSTOMER_ID.
 * @param ret_flistpp The output flist with account information.
 * @param ebufp The error buffer.
 * @return nothing.
 *	
 * Sample Input Flist
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_IDENTIFICATION_CODE   STR [0] "4444598879"
 * 0 TAB_FLD_IDENTIFICATION_TYPE   STR [0] "4444598879"
 * 0 PIN_FLD_CUSTOMER_ID           STR [0] "12345"
 * 0 PIN_FLD_CORRELATION_ID        STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER         STR [0] "CRM"
 **/

void
op_tab_cust_get_account_from_id(
	cm_nap_connection_t	*connp,
	int32			opcode,		
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;

	int64			db_no=0;
	int32			cerror_code=0;
	int32			error_clear_flag=1;
	char			log_msg[512]="";
	int32			status=PIN_BOOLEAN_TRUE;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_account_from_id:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_cust_get_account_from_id:function entry error",
			ebufp);
		return;
	}
	*ret_flistpp=NULL;

	/*******************************************************************
		Insanity check.
	 *******************************************************************/

	if(opcode!=TAB_OP_CUST_GET_ACCOUNT_FROM_ID)	
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_account_from_id bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	  Check for the input flist details
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_account_from_id: input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id: input flist ", 
			in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no: Error getting" 
			"database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_db_no: "
			"Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*******************************************************************
	  Call main function
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_account_from_id: return flist", r_flistp);
	
	fm_tab_cust_get_account_from_id(ctxp, flags, in_flistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id: input flist", 
			in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_cust_get_account_from_id error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id: input flist", 
			in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id:"
			"Error while getting accounts from ID", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_ACCOUNT_FROM_ID;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_GET_ACCOUNT_FROM_ID, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code,&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_ACCOUNT_FROM_ID)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,
				TAB_ERR_DESCR_API_GET_ACCOUNT_FROM_ID, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;

		/******************************************************************
		  Prepare Return Flist
		 ******************************************************************/

		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_get_account_from_id: output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get account information.
 * *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
**/
static void
fm_tab_cust_get_account_from_id(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*hook_rflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	char			*iden_type = NULL;
	char			*iden_code = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id input flist", 
			in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id function entry error", 
			ebufp);
		return;
	}
	PIN_ERR_CLEAR_ERR(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_from_id input flist", in_flistp);

	/******************************************************************
	  Validate the input arguments
	*******************************************************************/

	iden_code = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_IDENTIFICATION_CODE, 1, ebufp);
	iden_type = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_IDENTIFICATION_TYPE, 1, ebufp);
	
	if (iden_type == NULL || strlen(iden_type) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_IDENTIFICATION_TYPE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"input flist",in_flistp );
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_details: "
			"Mandatory field identification type missing in the input", ebufp);
		goto cleanup;
	}

	if(iden_code == NULL || strlen(iden_code) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_IDENTIFICATION_NUM_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"input flist",in_flistp );
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_details: "
			"Mandatory field identification code missing in the input", ebufp);
		goto cleanup;
	}	

	/**********************************************************************
	  Call TAB_OP_CUST_POL_GET_ACCOUNT_FROM_ID and check for return flist 
	  If return flist is null then perform search on 
	  /profile/tab_customer_details. This allows BU to have their own custom 
	  profile class names having these field. In such case Wrapper code 
	  shall not perform search.
	***********************************************************************/

	PCM_OP(ctxp, TAB_OP_CUST_POL_GET_ACCOUNT_FROM_ID, 0, in_flistp, &hook_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_cust_get_account_from_id Hook opcode error",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id Hook opcode error", 
			ebufp);
		goto cleanup;
	}

	if(hook_rflistp == NULL)
	{
		fm_tab_cust_get_account_details(ctxp, flags, in_flistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_from_id input flist",
				in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_from_id error", ebufp);
			goto cleanup;
		}
		PIN_FLIST_CONCAT(*ret_flistpp, r_flistp, ebufp);
	}
	else
	{
		PIN_FLIST_CONCAT(*ret_flistpp, hook_rflistp, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_from_id return flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX (&hook_rflistp, NULL);	
	
cleanup:

        /******************************************************************
          Clean up.
         ******************************************************************/
	return;
}

static void
fm_tab_cust_get_account_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64                   db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*customercare_info_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*account_readobj_iflistp = NULL;
	pin_flist_t		*account_readobj_rflistp = NULL;
	pin_flist_t		*final_result_flistp = NULL;
	pin_flist_t		*resultsinfo_flistp = NULL;
	pin_flist_t		*accounts_flistp = NULL;
	pin_flist_t		*account_billinfo_iflistp = NULL;
	pin_flist_t		*account_billinfo_rflistp = NULL;
	pin_flist_t		*account_billinfo_flistp = NULL;
	pin_flist_t		*res_billinfo_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*search_msisdn_r_flistp = NULL;
	pin_flist_t		*msisdn_result_flistp = NULL;
	pin_flist_t		*alias_flistp = NULL;
	void			*vp = NULL;
	pin_cookie_t		input_member_cookie = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 256;
	int32			input_member_elemid = 0;
	int32			*paytypep = 0;
	char			*customerId =NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details: input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details: "
			" function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_details: input flist", i_flistp);

	/******************************************************************
	  Creating input flist for PCM_OP_SEARCH.
	 *******************************************************************/

	srchp = PIN_POID_CREATE(db_no, "/search",-1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	customerId = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CUSTOMER_ID, 1, ebufp);
	if (customerId == NULL || strlen(customerId) == 0)
	{
		vp =  (void *)"select X from /profile/tab_customer_details where  F1 = V1 and F2 = V2";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}
	else
	{
		vp =  (void *)"select X from /profile/tab_customer_details where  F1 = V1 and F2 = V2 and F3 = V3";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	}

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	customercare_info_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_CUSTOMER_CARE_INFO, 0, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_IDENTIFICATION_CODE, customercare_info_flistp,
		PIN_FLD_IDENTIFICATION_CODE, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	customercare_info_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_CUSTOMER_CARE_INFO, 0, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_IDENTIFICATION_TYPE, customercare_info_flistp,
		TAB_FLD_IDENTIFICATION_TYPE, ebufp);

	if((customerId != NULL && strlen(customerId) != 0))
	{
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
		customercare_info_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_CUSTOMER_CARE_INFO, 
			0, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CUSTOMER_ID, customercare_info_flistp, 
			PIN_FLD_CUSTOMER_ID, ebufp);
	}

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_details: input flist", search_flistp);

	/******************************************************************
	  PCM_OP_SEARCH opcode call.
	 ******************************************************************/

	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_details input flist", 
			search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_details: "
			"Error in getting account object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_cust_get_account_details: return flist", 
			r_flistp);
		res_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if(res_flistp == NULL)
		{	
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE, 
				TAB_ERR_CODE_INVALID_IDEN_NUM_AND_IDEN_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_cust_get_account_details: "
				"Error Invalid Identification Code / Identification Type passed", ebufp);
			goto cleanup;
		}
	}

	/******************************************************************
	  Creating flist for final result output.
	******************************************************************/
	final_result_flistp = PIN_FLIST_CREATE(ebufp);

	/***************************************************************************************************
			Looping through PIN_FLD_RESULTS to get PIN_FLD_ACCOUNT_OBJ and call PCM_OP_READ_OBJ to get
			return flist and To get billinfo details by calling PCM_OP_BAL_GET_ACCT_BILLINFO.
	*****************************************************************************************************/
	while ((resultsinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(r_flistp, PIN_FLD_RESULTS,&input_member_elemid, 1, 
		&input_member_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		account_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(resultsinfo_flistp, PIN_FLD_ACCOUNT_OBJ, account_readobj_iflistp,
			PIN_FLD_POID, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_OBJ: input flist", account_readobj_iflistp);

		/******************************************************************
		  PCM_OP_READ_OBJ opcode call
		 ******************************************************************/

		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, account_readobj_iflistp, &account_readobj_rflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ: input flist",
				account_readobj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_OBJ: "
					"Error while reading account obj.", ebufp);
			goto cleanup;
		}
		PIN_FLIST_DESTROY_EX (&account_readobj_iflistp, NULL);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_OBJ:output flist", account_readobj_rflistp);
		if(account_readobj_rflistp != NULL)
		{
			accounts_flistp = PIN_FLIST_ELEM_ADD(final_result_flistp, PIN_FLD_ACCOUNTS,
				input_member_elemid, ebufp);
			PIN_FLIST_FLD_COPY(account_readobj_rflistp, PIN_FLD_CUSTOMER_SEGMENT_LIST,
				accounts_flistp,PIN_FLD_CUSTOMER_SEGMENT_LIST, ebufp);
			PIN_FLIST_FLD_COPY(account_readobj_rflistp, PIN_FLD_GL_SEGMENT,
				accounts_flistp, PIN_FLD_GL_SEGMENT, ebufp);
			PIN_FLIST_FLD_COPY(account_readobj_rflistp, PIN_FLD_STATUS,
				accounts_flistp, PIN_FLD_STATUS, ebufp);
			PIN_FLIST_FLD_COPY(account_readobj_rflistp, PIN_FLD_ACCOUNT_NO, 
				accounts_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
			PIN_FLIST_FLD_COPY(account_readobj_rflistp, PIN_FLD_BUSINESS_TYPE,
				accounts_flistp, PIN_FLD_BUSINESS_TYPE, ebufp);
		}
		
		/********************************************************************************
		  PCM_OP_BAL_GET_ACCT_BILLINFO opcode call
		  0 PIN_FLD_POID        		POID [0] 0.0.0.1 /account 14435750
		  0 PIN_FLD_CONTEXT_INFO      	SUBSTRUCT [0]
		  1 PIN_FLD_CORRELATION_ID      	STR [0] "er2345"
		  1 PIN_FLD_EXTERNAL_USER      	STR [0] "CRM"     
		 ********************************************************************************/

		account_billinfo_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(resultsinfo_flistp, PIN_FLD_ACCOUNT_OBJ, account_billinfo_iflistp, 
			PIN_FLD_POID, ebufp); 
		account_billinfo_flistp = PIN_FLIST_SUBSTR_ADD(account_billinfo_iflistp, 
			PIN_FLD_CONTEXT_INFO, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp,PIN_FLD_CORRELATION_ID, account_billinfo_flistp,
			PIN_FLD_CORRELATION_ID,ebufp);
		PIN_FLIST_FLD_COPY(i_flistp,PIN_FLD_EXTERNAL_USER, account_billinfo_flistp, 
			PIN_FLD_EXTERNAL_USER, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_BAL_GET_ACCT_BILLINFO: "
			"input flist", account_billinfo_iflistp);

		/******************************************************************
		  PCM_OP_BAL_GET_ACCT_BILLINFO opcode call
		 ******************************************************************/	
		
		PCM_OP(ctxp, PCM_OP_BAL_GET_ACCT_BILLINFO, 0, account_billinfo_iflistp, 
			&account_billinfo_rflistp, ebufp);
	
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details: "
				"input flist", account_billinfo_iflistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE, 
				TAB_ERR_CODE_GET_BILLING_ACC_INFO,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details:" 
				"Error while getting Account Billinfo: ", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_BAL_GET_ACCT_BILLINFO: "
			"return flist", account_billinfo_rflistp);

		if(account_billinfo_rflistp && (res_billinfo_flistp=PIN_FLIST_ELEM_GET(account_billinfo_rflistp, 
			PIN_FLD_BILLINFO, PIN_ELEMID_ANY, 1, ebufp)) != NULL)   
		{

			paytypep = PIN_FLIST_FLD_GET(res_billinfo_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);
			PIN_FLIST_FLD_SET(accounts_flistp,PIN_FLD_PAY_TYPE,paytypep,ebufp);
			if (*paytypep == PIN_PAY_TYPE_PREPAID)
			{
				PIN_FLIST_FLD_SET(accounts_flistp,PIN_FLD_PAYINFO_TYPE,TAB_PAYINFO_PREPAID,
					ebufp);
			}
			else
			{
				PIN_FLIST_FLD_SET(accounts_flistp,PIN_FLD_PAYINFO_TYPE,TAB_PAYINFO_POSTPAID,
					ebufp);
			}
			fm_tab_utils_common_get_service_from_accountpdp(ctxp,account_billinfo_rflistp,
				&search_msisdn_r_flistp,db_no,ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details: "
						"input flist", account_billinfo_rflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_details:"
						"Error while getting Account poid from service: ", ebufp);
				goto cleanup;
			}

			if ( search_msisdn_r_flistp !=NULL )
			{
				msisdn_result_flistp = PIN_FLIST_ELEM_GET(search_msisdn_r_flistp,
					PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
				alias_flistp = PIN_FLIST_ELEM_GET(msisdn_result_flistp,
					PIN_FLD_ALIAS_LIST,0,1,ebufp);

				if(alias_flistp!=NULL)
				{
					PIN_FLIST_FLD_COPY( alias_flistp,PIN_FLD_NAME,accounts_flistp,
						PIN_FLD_MSISDN,ebufp );
				}
			}
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_cust_get_account_details return flist",
		final_result_flistp);
	
cleanup:

	/******************************************************************
	  Clean up.
	******************************************************************/

	PIN_FLIST_DESTROY_EX (&account_billinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&account_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&account_billinfo_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&search_msisdn_r_flistp, NULL);
	*r_flistpp = final_result_flistp;	
	return;
}
