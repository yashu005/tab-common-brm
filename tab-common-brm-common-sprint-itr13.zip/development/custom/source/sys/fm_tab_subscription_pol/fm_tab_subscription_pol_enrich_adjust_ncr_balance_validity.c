/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 05-JAN-2022   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_subscription.h"
#include "fm_bill_utils.h"
#define FILE_SOURCE_ID "fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_pol_enrich_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void 
fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY operation.
 *************************************************************************/
void
op_tab_subscription_pol_enrich_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	
	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
				" error from input flist", in_flistp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Opcode Check
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	 * Debug Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
			" input flist", in_flistp);
	
	fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity(ctxp, in_flistp, &r_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
				"Error input flist", in_flistp);
		return ;
	}
	
	*ret_flistpp = r_flistp;
	
	/***********************************************************
	 * Debug Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
			" output flist", *ret_flistpp);
	return;
	
}

void 
fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t            	*r_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	
	/***********************************************************
	 * Insanity Check
	 ***********************************************************/	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_pol_enrich_adjust_ncr_balance_validity error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
			" input flist", in_flistp);
		return ;
	}
	
	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
			" input flist", in_flistp);
	

	/*******************************************************************
	 *Creation of Return FLIST
	 *******************************************************************/
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	results_flistp = PIN_FLIST_ELEM_ADD(r_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STRING_ID, results_flistp, PIN_FLD_STRING_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STR_VERSION, results_flistp, PIN_FLD_STR_VERSION, ebufp);

	
	/***********************************************************
	 * Debug: Output Flist
	 ***********************************************************/	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_pol_enrich_adjust_ncr_balance_validity :"
			" output flist", r_flistp);
			
	*out_flistpp = r_flistp;
	
	return;
	
}
	
