/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 21-DEC-2021   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "fm_bill_utils.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#define FILE_SOURCE_ID "fm_tab_subscription_pol_enrich_extend_prepaid_validity.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_pol_enrich_extend_prepaid_validity(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
	

 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                          POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN                    STR [0] "981999999"
 * 0 PIN_FLD_TRANS_ID                STR [0] "test1111"
 * 0 PIN_FLD_CHARGE_AMT        STR [0] 25
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY operation.
 *************************************************************************/
void
op_tab_subscription_pol_enrich_extend_prepaid_validity(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pin_flist_t             *r_flistp = NULL;
	time_t					*validitydate_tp = NULL;
	int32					days_i = 5;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_pol_enrich_extend_prepaid_validity error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_pol_enrich_extend_prepaid_validity opcode error",ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_sub_pol_enrich_extend_prepaid_validity :"
			" input flist", in_flistp);
	
	/***********************************************************
  	 * Debug: Input Flist
	 ***********************************************************/	
	validitydate_tp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
	fm_utils_add_n_days(5,validitydate_tp);

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_VALIDITY_IN_DAYS, &days_i, ebufp);
	PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, validitydate_tp, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_sub_pol_enrich_extend_prepaid_validity :"
			" output flist", r_flistp);
	
	*ret_flistpp = r_flistp;
	
	return;
	
}
