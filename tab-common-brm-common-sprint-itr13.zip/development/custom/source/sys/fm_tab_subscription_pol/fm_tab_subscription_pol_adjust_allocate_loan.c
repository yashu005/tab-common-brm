/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 21-DEC-2021   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_POL_ADJUST_ALLOCATE_LOAN operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "fm_bill_utils.h"

#define FILE_SOURCE_ID "fm_tab_subscription_pol_allocate_loan.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_pol_adjust_allocate_loan(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_pol_adjust_allocate_loan(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
	

 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_POL_ADJUST_ALLOCATE_LOAN is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_POL_ADJUST_ALLOCATE_LOAN operation.
 *************************************************************************/
void
op_tab_subscription_pol_adjust_allocate_loan(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t				*r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_pol_adjust_allocate_loan error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_POL_ADJUST_ALLOCATE_LOAN) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_pol_adjust_allocate_loan opcode error",ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_subscription_pol_adjust_allocate_loan :"
			" input flist", in_flistp);
	
	fm_tab_subscription_pol_adjust_allocate_loan(ctxp, in_flistp, &r_flistp, ebufp);
	
	*ret_flistpp = r_flistp;
	
	return;
	
}

void
fm_tab_subscription_pol_adjust_allocate_loan(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_pol_adjust_allocate_loan error",ebufp);
		return ;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_pol_adjust_allocate_loan :"
			" input flist", in_flistp);
			
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_pol_adjust_allocate_loan :"
			" output flist", r_flistp);
	
	*out_flistpp = r_flistp;
	
	return;
}