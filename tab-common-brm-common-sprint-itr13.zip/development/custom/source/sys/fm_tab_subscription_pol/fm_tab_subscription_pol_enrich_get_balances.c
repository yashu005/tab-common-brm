/*******************************************************************************
 *
 *	This material is the confidential property of Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 * Change History
 *
 * No | Date       | Programmer  		| Req/bug/Gap   			| Change details
 *
 * 1  | 24/12/2021 | Piyush Suryavanshi |							| Opcode TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES introduced.
 *
 **************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "fm_bal.h"
#include "pin_price.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_subscription_pol_enrich_get_balances(
	cm_nap_connection_t	*connp,
	int		opcode,
	int		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp);

static void
fm_tab_op_sub_pol_enrich_get_balances(
	pcm_context_t	*ctxp,
	int32		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp);


static void
fm_tab_sub_pol_get_balances_offering_details(
	pcm_context_t 	*ctxp,
	poid_t         	*grantor_objp,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp);

/**********************************************************************************
 * The policy opcode TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES
 * formats the output recived from the prepare output opcode
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp the input flist
 * @param ret_flistpp the output flist
 * @param ebufp The error buffer.
 * @return nothing.
 ***********************************************************************************/
void
op_tab_subscription_pol_enrich_get_balances(
	cm_nap_connection_t 	*connp,
	int		opcode,
	int		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_get_balances: function entry error", ebufp);
		return;
	}

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_get_balances: opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_tab_subscription_pol_enrich_get_balances: input flist", in_flistp);

	/***********************************************************
	 * Prep the return flist.
	 ***********************************************************/
	fm_tab_op_sub_pol_enrich_get_balances(ctxp, flags, in_flistp, ret_flistpp, ebufp);

	/***********************************************************
	 * Results.
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_pol_enrich_get_balances: error", ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_tab_subscription_pol_enrich_get_balances: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
 * fm_tab_op_sub_pol_enrich_get_balances()
 * copies input flist to output flist
 * @param ctxp The context pointer.
 * @param flags The opcode flags.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The output flist .
 * @param ebufp The error buffer.
 * @return nothing.
 *
 ***********************************************************************/
static void
fm_tab_op_sub_pol_enrich_get_balances(
	pcm_context_t	*ctxp,
	int32		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_op_sub_pol_enrich_get_balances in_flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_op_sub_pol_enrich_get_balances: function entry error", ebufp);
		return;
	}

	pin_flist_t	*offering_flistp=NULL;

	poid_t *grantor_objp = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,1, ebufp);


	/******************************************************************
	 * call function to get the offering details.
	 ******************************************************************/
	if(grantor_objp!=NULL)
	{
		fm_tab_sub_pol_get_balances_offering_details(ctxp,grantor_objp,&offering_flistp,ebufp);

		if( PIN_ERR_IS_ERR( ebufp ))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_op_sub_pol_enrich_get_balances ",in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_op_sub_pol_enrich_get_balances: "
					"error", ebufp);
			goto cleanup;
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_op_sub_pol_enrich_get_balances: return flist", offering_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*ret_flistpp = offering_flistp;

	return;
}

static void
fm_tab_sub_pol_get_balances_offering_details(
	pcm_context_t 	*ctxp,
	poid_t        	*grantor_objp,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_sub_pol_get_balances_offering_details input poid", grantor_objp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_pol_get_balances_offering_details error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_pol_get_balances_offering_details:"
				" grantor_objp", grantor_objp);
		return;
	}

	pin_flist_t 	*read_grantor_oflistp=NULL;
	pin_flist_t	*read_prod_flistp=NULL;
	pin_flist_t	*read_prod_oflistp= NULL;
	pin_flist_t	*read_plan_oflistp= NULL;
	pin_flist_t *read_deal_oflistp= NULL;
	pin_flist_t	*return_package_flistp= PIN_FLIST_CREATE(ebufp);
	
	int64 		package_id=0;
	char		*plan_objp = NULL;
	char		*product_objp = NULL;
	char		*descr =NULL;
	char 		*plan_desr=NULL;
	char 		*plan_name=NULL;
	char 		*product_descr=NULL;
	char 		*granter_typep=NULL;
	char        *bundle_namep=NULL;
	poid_t      *deal_objp = NULL;
	
	fm_tab_utils_common_read_object(ctxp,grantor_objp,&read_grantor_oflistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_sub_pol_get_balances_offering_details read grantor input", read_grantor_oflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_sub_pol_get_balances_offering_details: read grantor", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_sub_pol_get_balances_offering_details read grantor output", read_grantor_oflistp);

	granter_typep = (char *)PIN_POID_GET_TYPE(grantor_objp);
	if (((strcmp(granter_typep, PIN_OBJ_TYPE_DISCOUNT) == 0)) ||
			((strcmp(granter_typep, PIN_OBJ_TYPE_PRODUCT) == 0)))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_pol_get_balances_offering_details: grantor is product/discount");
		/*** If the input poid is product or discount, return only offer name ***/
		if ((product_descr = PIN_FLIST_FLD_GET(read_grantor_oflistp, PIN_FLD_NAME, 1, ebufp))!=NULL)
		{
			PIN_FLIST_FLD_SET(return_package_flistp, PIN_FLD_OFFER_NAME, product_descr, ebufp);
		}
		goto cleanup;
	}

	/******************************************************************
	 * Prepare the output flist for package id,unique id
	 * order type and  offer name
	 ******************************************************************/

	if (PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_PACKAGE_ID,1,ebufp)!=0)
	{
		PIN_FLIST_FLD_COPY(read_grantor_oflistp,PIN_FLD_PACKAGE_ID,return_package_flistp,PIN_FLD_PACKAGE_ID,ebufp);
	}

	if ((descr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DESCR,1,ebufp))!=NULL)
	{
		PIN_FLIST_FLD_SET(return_package_flistp,PIN_FLD_UNIQUE_ID,(char*)descr,ebufp);
	}

	if ((plan_objp = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_PLAN_OBJ,1,ebufp))!=NULL && PIN_POID_GET_ID(plan_objp) )
	{
		plan_objp = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_PLAN_OBJ,1,ebufp);

		fm_tab_utils_common_read_object(ctxp,plan_objp,&read_plan_oflistp,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_sub_pol_get_balances_offering_details read plan input", read_grantor_oflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_sub_pol_get_balances_offering_details: read plan output", ebufp);
			goto cleanup;
		}

		if ((plan_desr = PIN_FLIST_FLD_GET(read_plan_oflistp,PIN_FLD_DESCR,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_SET(return_package_flistp,PIN_FLD_ORDER_TYPE,plan_desr,ebufp);
		}

		if ((plan_name = PIN_FLIST_FLD_GET(read_plan_oflistp,PIN_FLD_NAME,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_SET(return_package_flistp,PIN_FLD_PROD_NAME,plan_name,ebufp);
		}
	}
	
	if(PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_PRODUCT_OBJ,1,ebufp)!=NULL)
		product_objp = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_PRODUCT_OBJ,1,ebufp);
	else if (PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DISCOUNT_OBJ,1,ebufp)!=NULL)
		product_objp = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DISCOUNT_OBJ,1,ebufp);

	if (PIN_POID_GET_ID(product_objp))
	{
		read_prod_flistp= PIN_FLIST_CREATE(ebufp);
	
		PIN_FLIST_FLD_SET(read_prod_flistp,PIN_FLD_POID,product_objp,ebufp);
		PIN_FLIST_FLD_SET(read_prod_flistp,PIN_FLD_NAME,NULL,ebufp);
		PIN_FLIST_FLD_SET(read_prod_flistp,PIN_FLD_DESCR,NULL,ebufp);
		PCM_OP(ctxp,PCM_OP_READ_FLDS,0,read_prod_flistp,&read_prod_oflistp,ebufp);

		PIN_FLIST_DESTROY_EX(&read_prod_flistp, NULL);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_sub_pol_get_balances_offering_details read product input", read_prod_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_sub_pol_get_balances_offering_details: read product output", ebufp);
			goto cleanup;
		}
		
		if ((product_descr = PIN_FLIST_FLD_GET(read_prod_oflistp,PIN_FLD_NAME,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_SET(return_package_flistp,PIN_FLD_OFFER_NAME,product_descr,ebufp);
		}
	}
		
	if ((product_descr = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_NAME,1,ebufp))!=NULL)
	{
		PIN_FLIST_FLD_SET(return_package_flistp,PIN_FLD_OFFER_NAME,product_descr,ebufp);
	}
	
	if ((deal_objp = PIN_FLIST_FLD_GET(read_grantor_oflistp,PIN_FLD_DEAL_OBJ,0,ebufp))!=NULL && PIN_POID_GET_ID(deal_objp))
        {
        	fm_tab_utils_common_read_object(ctxp,deal_objp,&read_deal_oflistp,ebufp);

                if (PIN_ERR_IS_ERR(ebufp))
                {
                	PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
                                                "fm_tab_sub_pol_get_balances_offering_details read deal input", deal_objp);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                                "fm_tab_sub_pol_get_balances_offering_details: read plan output", ebufp);
                        goto cleanup;
                }

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_sub_pol_get_balances_offering_details deal oflist", read_deal_oflistp);
                
                if ((bundle_namep = PIN_FLIST_FLD_GET(read_deal_oflistp,PIN_FLD_NAME,0,ebufp))!=NULL)
                {
                	PIN_FLIST_FLD_SET(return_package_flistp,TAB_FLD_BUNDLE_NAME,bundle_namep,ebufp);
                }
                PIN_FLIST_DESTROY_EX(&read_deal_oflistp, NULL);
	}
	
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*out_flistpp= return_package_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_sub_pol_get_balances_offering_details output flist", *out_flistpp);

	return;
}
