/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#ifndef lint
static const char Sccs_id[] = "@(#)$Id: fm_tab_subscription_pol_config.c /cgbubrm_1.0.0.collections/6 2021/11/08 11:34:14 praghura Exp $";
#endif

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_subscription_pol_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_subscription_pol_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_SUBSCRIPTION_POL_UPDATE_SERVICE_STATUS, "op_tab_subscription_pol_update_service_status", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES ,		"op_tab_subscription_pol_enrich_get_balances",	CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_HIDE_ATTRIBUTE_GET_BALANCES ,	"op_tab_subscription_pol_enrich_hide_attribute_get_balances",	CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX, "op_tab_sub_pol_enrich_recharge_tax", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY, "op_tab_sub_pol_enrich_recharge_offer_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_PREP_PURCHASE_OFFER, "op_tab_sub_pol_enrich_recharge_prep_purchase_offer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE, "op_tab_sub_pol_enrich_reverse_recharge", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT, "op_tab_sub_pol_recharge_validate_input", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY, "op_tab_subscription_pol_enrich_extend_prepaid_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_BALANCE_VALIDITY, "op_tab_subscription_pol_enrich_adjust_balance_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ADJUST_ALLOCATE_LOAN, "op_tab_subscription_pol_adjust_allocate_loan", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY, "op_tab_subscription_pol_enrich_adjust_ncr_balance_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BILL_DEBIT, "op_tab_subscription_pol_enrich_adjust_ncr_bill_debit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN , "op_tab_subscription_pol_enrich_request_loan", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT,      "op_tab_subscription_pol_allocate_loan_amount", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_VALIDATE_BALANCE_TRANSFER, "op_tab_subscription_pol_validate_balance_transfer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER, "op_tab_subscription_pol_enrich_balance_transfer", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER_SVC_VALIDITY, "op_tab_subscription_pol_enrich_balance_transfer_svc_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_ELIGIBLE_LOANS, "op_tab_subscription_pol_enrich_eligible_loans", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_LOAN_DETAILS, "op_tab_subscription_pol_enrich_get_loan_details", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_GET_SHARING_GROUPS,"op_tab_subscription_pol_get_sharing_groups",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_BAL_TRANSFER_DENOMINATION , "op_tab_subscription_pol_enrich_bal_transfer_denomination", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_LOAN_UPDT_SVC_VALIDITY , "op_tab_subscription_pol_loan_updt_svc_validity", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL , "op_tab_subscription_pol_recharge_recurring_renewal", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL , "op_tab_subscription_pol_bal_transfer_recurring_renewal", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_RESULTS , "op_tab_subscription_pol_enrich_adjust_ncr_balance_validity_results", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER_RESULTS , "op_tab_subscription_pol_enrich_balance_transfer_results", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_RESULTS , "op_tab_subscription_pol_enrich_recharge_results", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_PYMT_TOPUP , "op_tab_subscription_pol_enrich_pymt_topup", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE_RESULTS , "op_tab_subscription_pol_enrich_reverse_recharge_results", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN_RESULTS , "op_tab_subscription_pol_enrich_request_loan_results", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_RECORD , "op_tab_subscription_pol_enrich_recharge_record", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_CONVERT_ALLOWANCE, "op_tab_subscription_pol_convert_allowance", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_PRE_UPDATE_SERVICE, "op_tab_subscription_pol_pre_update_service", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_POL_RECHARGE_PREV_BALANCE, "op_tab_subscription_pol_recharge_prev_balance", CM_FM_OP_OVERRIDABLE },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_subscription_pol_config_func()
{
  return ((void *) (fm_tab_subscription_pol_config));
}
#endif
