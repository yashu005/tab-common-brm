/*******************************************************************************
 *
 *	This material is the confidential property of Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 * Change History
 *
 * No | Date       | Programmer  | Req/bug/Gap   			| Change details
 *
 * 1  | 10/01/2022 | Akshay Gund	|				| Opcode TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO 
 * 		                                                             introduced.
 *																 
 **************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO operation. 
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "ops/collections.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_collections_pol_enrich_replace_scenario(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_collections_pol_enrich_replace_scenario(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

/**********************************************************************************
 * The policy opcode TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO 
 * copies the input flist to output flist
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp the input flist 
 * @param ret_flistpp the output flist 
 * @param ebufp The error buffer.
 * @return nothing.
 ***********************************************************************************/   
void
op_tab_collections_pol_enrich_replace_scenario(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_pol_enrich_replace_scenario: function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_pol_enrich_replace_scenario: input flist", in_flistp);

		return;
	}

	/***********************************************************
	 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM,
				PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_pol_enrich_replace_scenario: opcode error", ebufp);
		return;
	}

	/***********************************************************
	 * Debug: What we got.
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_tab_collections_pol_enrich_replace_scenario: input flist", in_flistp);

	/***********************************************************
	 * Prep the return flist.
	 ***********************************************************/
	fm_tab_collections_pol_enrich_replace_scenario(ctxp, flags, in_flistp, ret_flistpp, ebufp);

	/***********************************************************
	 * Results.
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_collections_pol_enrich_replace_scenario: error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_tab_collections_pol_enrich_replace_scenario: output flist", *ret_flistpp);
	return;
}

/**********************************************************************
 * fm_tab_collections_pol_enrich_replace_scenario() 
 * copies input flist to output flist
 * @param ctxp The context pointer.
 * @param flags The opcode flags.
 * @param in_flistp in the input flist.
 * @param ret_flistpp The output flist .
 * @param ebufp The error buffer.
 * @return nothing.
 *
 **********************************************************************/
	static void
fm_tab_collections_pol_enrich_replace_scenario(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{

	pin_flist_t		*replace_sceanrio_iflistp=NULL;
	pin_flist_t		*replace_sceanrio_oflistp=NULL;
	pin_flist_t		*scenario_info_flistp=NULL;
	pin_flist_t		*context_info_flistp=NULL;


			
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_pol_enrich_replace_scenario: function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_collections_pol_enrich_replace_scenario: input flist", in_flistp);
		return;
	}
	 PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"in_flistp for fm_tab_collections_pol_enrich_replace_scenario:",in_flistp);

	scenario_info_flistp=PIN_FLIST_CREATE(ebufp);
	context_info_flistp=PIN_FLIST_CREATE(ebufp);
	scenario_info_flistp=PIN_FLIST_SUBSTR_GET(in_flistp, PIN_FLD_REPLACE_SCENARIO_INFO,1,ebufp);
	context_info_flistp=PIN_FLIST_SUBSTR_GET(in_flistp, PIN_FLD_CONTEXT_INFO,1,ebufp);
	replace_sceanrio_iflistp=PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,replace_sceanrio_iflistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILLINFO_OBJ,replace_sceanrio_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME,replace_sceanrio_iflistp,PIN_FLD_PROGRAM_NAME,ebufp);

	PIN_FLIST_SUBSTR_PUT(replace_sceanrio_iflistp,scenario_info_flistp,PIN_FLD_REPLACE_SCENARIO_INFO,ebufp);
	PIN_FLIST_SUBSTR_PUT(replace_sceanrio_iflistp,context_info_flistp,PIN_FLD_CONTEXT_INFO,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_pol_enrich_replace_scenario: PCM_OP_COLLECTIONS_REPLACE_SCENARIO "
				"input flist", replace_sceanrio_iflistp);

	PCM_OP(ctxp, PCM_OP_COLLECTIONS_REPLACE_SCENARIO , 0, replace_sceanrio_iflistp, &replace_sceanrio_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_COLLECTIONS_REPLACE_SCENARIO, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_pol_enrich_replace_scenario: PCM_OP_COLLECTIONS_REPLACE_SCENARIO"
					"Input flist", replace_sceanrio_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_collections_pol_enrich_replace_scenario: PCM_OP_COLLECTIONS_REPLACE_SCENARIO "
				"input flist error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_collections_pol_enrich_replace_scenario: PCM_OP_COLLECTIONS_REPLACE_SCENARIO "
				"output flist", replace_sceanrio_oflistp);

	*ret_flistpp=replace_sceanrio_oflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_collections_pol_enrich_replace_scenario: return flist", *ret_flistpp);

	return;
cleanup:
	        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_collections_pol_enrich_replace_scenario: return flist", *ret_flistpp);

}
