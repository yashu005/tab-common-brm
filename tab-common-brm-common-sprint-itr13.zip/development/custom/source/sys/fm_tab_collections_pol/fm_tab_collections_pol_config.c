/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_collections_pol_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_collections_pol_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_COLLECTIONS_POL_ENRICH_UPDATE_EXEMPTION, "op_tab_collections_pol_enrich_update_exemption", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_ENRICH_REPLACE_SCENARIO, "op_tab_collections_pol_enrich_replace_scenario", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_UPDATE_EXEMPTION_ACTIONS,"op_tab_collections_pol_update_exemption_actions", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_UPDATE_SERVICE_STATUS,"op_tab_collections_pol_update_service_status", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_INSTALLMENT ,"op_tab_collections_pol_freeze_create_installment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_UNFREEZE_CANCEL_INSTALLMENT ,"op_tab_collections_pol_unfreeze_cancel_installment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_VALIDATE_CREATE_INSTALLMENT ,"op_tab_collections_pol_validate_create_installment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_FREEZE_CREATE_PROMISE_TO_PAY ,"op_tab_collections_pol_freeze_create_promise_to_pay", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_ENRICH_GET_PROFILE ,"op_tab_collections_pol_enrich_get_profile", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_ENRICH_GET_INSTALLMENT ,"op_tab_collections_pol_enrich_get_installment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_COLLECTIONS_POL_ENRICH_CREATE_PROMISE_TO_PAY ,"op_tab_collections_pol_enrich_create_promise_to_pay", CM_FM_OP_OVERRIDABLE },
	
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_collections_pol_config_func()
{
  return ((void *) (fm_tab_collections_pol_config));
}
#endif
