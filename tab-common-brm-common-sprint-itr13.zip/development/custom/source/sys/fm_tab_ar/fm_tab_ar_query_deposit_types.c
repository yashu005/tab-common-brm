/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  |7-Apr-2022  | Akshay Gund        |       	        | New opcode to get details of query 
 *								 deposite types
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_QUERY_DEPOSIT_TYPES operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "ops/deposit.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_ar_query_deposit_types(
		cm_nap_connection_t	*connp,
		int32			opcode,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		pin_errbuf_t		*ebufp);

static void
fm_tab_ar_query_deposit_types(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

static void
fm_tab_ar_get_deposite_details(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_rate_plan_details(
		pcm_context_t		*ctxp,
		pin_flist_t		*i_flistp,
		pin_flist_t		**r_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
		
/**
 *
 * New opcode TAB_OP_AR_QUERY_DEPOSIT_TYPES is implemented to get BA details from msisdn
 *
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN,PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 * */

void
op_tab_ar_query_deposit_types(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;

	int64			db_no=0;
	int32			status=PIN_BOOLEAN_TRUE;
	char			log_msg[512]= "";
	int32			error_clear_flag=1;
	int32			cerror_code=0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_query_deposit_types function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types in_flistp", in_flistp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_query_deposit_type input flist :",in_flistp);

	*ret_flistpp = NULL;
	/****************************
	 * Insanity check.
	 ***************************/
	if(opcode != TAB_OP_AR_QUERY_DEPOSIT_TYPES) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types bad opcode error",
			ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types in_flistp", in_flistp);
		return;
	}

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types in_flistp", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}


	fm_tab_ar_query_deposit_types(ctxp, flags, in_flistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types in_flistp", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_query_deposit_types output flist", *ret_flistpp);

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_query_deposit_types:"
				" Error while geting details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types in_flistp", in_flistp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_DEPOSIT_TYPES;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_DEPOSIT_TYPES)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_DEPOSIT_TYPES, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	
	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_cust_manage_fnf output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get query deposit types.
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 * *
 *  */

static void
fm_tab_ar_query_deposit_types(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_spec_iflistp=NULL;
	pin_flist_t		*get_deposit_oflistp=NULL;
	pin_flist_t		*return_flistp=NULL;
	pin_flist_t		*res_flistp=NULL;
	pin_flist_t		*deposit_list_flistp=NULL;
	pin_flist_t		*get_deposit_dtl_iflistp=NULL;
	pin_flist_t		*get_deposit_dtl_oflistp=NULL;
	pin_flist_t		*search_flistp=NULL;
	pin_flist_t             *result_flistp = NULL;
	pin_flist_t             *args_flistp = NULL;
	pin_flist_t             *r_flistp = NULL;
	void                    *vp = NULL;
	poid_t                  *srchp = NULL;
	int32                   s_flags = 0;


	poid_t			*deposit_spec_pdp=NULL;
	char			*fld_name=NULL;
	char			*deposit_status=NULL;
	pin_cookie_t	dep_spec_cookie=NULL;
	int32			dep_spec_elemid=0;
	int32			draft_flag=0;
	time_t			*end_date=NULL;
	char			*end_date_strp=NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_query_deposit_types function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_query_deposit_types: input flist", in_flistp);


	/***************************************************************
	  Check the existance of TAB_FLD_STATUS and PIN_FLD_NAME 
	  If present then set to input flistp of PCM_OP_DEPOSIT_GET_SPECIFICATION 
	  0 PIN_FLD_POID                  POID [0] 0.0.0.1 /deposit_specification -1 0
	  0 PIN_FLD_NAME               STR [0] "Deposit_Spec_Roaming"
	  0 PIN_FLD_STATUS_STR           STR [0] “Active”

	  If not then just pass POID to get all available specifications
	 ****************************************************************/

	get_spec_iflistp=PIN_FLIST_CREATE(ebufp);

	deposit_spec_pdp = PIN_POID_CREATE(db_no, "/deposit_specification", -1, ebufp);
	PIN_FLIST_FLD_PUT(get_spec_iflistp,PIN_FLD_POID,deposit_spec_pdp,ebufp);


	fld_name=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME,1,ebufp);
	if(fld_name != NULL && strlen(fld_name) != 0)
	{
		srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
		search_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
		vp =  (void *)"select X from /deposit_specification where F1 = V1 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NAME, args_flistp, PIN_FLD_NAME, ebufp);

		PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

		PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_ar_query_deposit_types output flist", r_flistp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_query_deposit_types input flist", search_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_query_deposit_types :"
					" Error in getting product object", ebufp);
		}
		else
		{
			return_flistp=PIN_FLIST_CREATE(ebufp);
			get_deposit_dtl_iflistp=PIN_FLIST_CREATE(ebufp);

			result_flistp=PIN_FLIST_ELEM_GET(r_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_ar_query_deposit_types result_flistp", result_flistp);

			if(result_flistp != NULL)
			{
				PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,get_deposit_dtl_iflistp,PIN_FLD_POID,ebufp);
				PIN_FLIST_FLD_COPY(result_flistp,PIN_FLD_PRODUCT_OBJ,get_deposit_dtl_iflistp,
						PIN_FLD_PRODUCT_OBJ,ebufp);

				fm_tab_ar_get_deposite_details(ctxp,flags,get_deposit_dtl_iflistp,
						&get_deposit_dtl_oflistp,db_no,ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types error", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types "
							"in_flistp", in_flistp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Output flist of "
							" fm_tab_ar_get_deposite_details ",get_deposit_dtl_oflistp);
					deposit_list_flistp=PIN_FLIST_ELEM_ADD(return_flistp,
                                                TAB_FLD_DEPOSIT_INFO,dep_spec_elemid, ebufp);

					PIN_FLIST_FLD_COPY(result_flistp,PIN_FLD_DESCR,deposit_list_flistp,PIN_FLD_DESCR, ebufp);
					PIN_FLIST_FLD_COPY(result_flistp,PIN_FLD_NAME,deposit_list_flistp,PIN_FLD_NAME, ebufp);
					PIN_FLIST_FLD_COPY(result_flistp,PIN_FLD_CREDIT_LIMIT_FLAG,deposit_list_flistp,
							PIN_FLD_CREDIT_LIMIT_FLAG,ebufp);
					end_date=PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_END_T,1,ebufp);
					if(end_date!= NULL)
					{
						end_date_strp= fm_tab_utils_common_convert_timestamp_to_date(ctxp,
								end_date, ebufp);
						PIN_FLIST_FLD_PUT(deposit_list_flistp, TAB_FLD_END_T_STR,
								end_date_strp, ebufp);
					}
					PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_NAME,
							deposit_list_flistp,TAB_FLD_OFFER_NAME,ebufp);
					PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_AMOUNT,
							deposit_list_flistp,PIN_FLD_AMOUNT,ebufp);

					if((PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_DRAFT_FLAG,1,ebufp))!=NULL)
					{
						draft_flag=*(int*)PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_DRAFT_FLAG,1,ebufp);

						if(draft_flag==1)
						{
							PIN_FLIST_FLD_SET(deposit_list_flistp, PIN_FLD_STATUS_STR,TAB_AR_DRAFT_DEPOSIT, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(deposit_list_flistp, PIN_FLD_STATUS_STR,TAB_AR_NON_DRAFT_DEPOSIT, ebufp);
						}
					}
				}

			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_NO_DEPOSIT_SPEC_FOR_INPUT_NAME, 0, 0, 0);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types input flist:"
						"",get_spec_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types: "
						" Error in getting service object", ebufp);
				goto cleanup;
			}

			PIN_FLIST_CONCAT(*ret_flistpp,return_flistp,ebufp);
			goto cleanup;
		}
	}

	deposit_status=PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_STATUS,1,ebufp);
	if(deposit_status!= NULL && strlen(deposit_status) != 0)
	{
		if (strcmp(deposit_status,TAB_AR_DRAFT_DEPOSIT)== 0)
		{
			draft_flag=1;
		}
		else
		{
			draft_flag=0;
		}
	
		PIN_FLIST_FLD_SET(get_spec_iflistp,PIN_FLD_DRAFT_FLAG,(void *)&draft_flag,ebufp);
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_query_deposit_types:"
			"input flist :get_spec_iflistp",get_spec_iflistp);

	PCM_OP(ctxp,PCM_OP_DEPOSIT_GET_SPECIFICATION ,0, get_spec_iflistp, &get_deposit_oflistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_query_deposit_types:"
			"output flist :get_deposit_oflistp",get_deposit_oflistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DEPOSIT_TYPES, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types input flist:"
				"",get_spec_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types: "
				" Error in getting service object", ebufp);
		goto cleanup;
	}


	/*
	 * 0 PIN_FLD_DEPOSIT_LIST ARRAY [0] allocated 20, used 16
	 1     PIN_FLD_DESCR           STR [0] "Local Security Deposit"
	 1     PIN_FLD_NAME            STR [0] "Local Security Deposit"
	 1     TAB_FLD_END_T_STR  STR [0] “02-APR-2023 00:00:00”
	 1     TAB_FLD_OFFER_NAME STR [0] “CO_Deposit1”
	 1    PIN_FLD_AMOUNT DECIMAL [0] 100
	 1     PIN_FLD_CREDIT_LIMIT_FLAG    INT [0] 0
	 */

	if (get_deposit_oflistp !=NULL)
	{
		res_flistp = PIN_FLIST_ELEM_GET(get_deposit_oflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);

		return_flistp=PIN_FLIST_CREATE(ebufp);
		get_deposit_dtl_iflistp=PIN_FLIST_CREATE(ebufp);

		if(res_flistp == NULL)
		{
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,get_deposit_dtl_iflistp,PIN_FLD_POID,ebufp);
			PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_PRODUCT_OBJ,get_deposit_dtl_iflistp,
					PIN_FLD_PRODUCT_OBJ,ebufp);

			fm_tab_ar_get_deposite_details(ctxp,flags,get_deposit_dtl_iflistp,
					&get_deposit_dtl_oflistp,db_no,ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types "
						"in_flistp", in_flistp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Output flist of "
					       " fm_tab_ar_get_deposite_details ",get_deposit_dtl_oflistp);
				deposit_list_flistp=PIN_FLIST_ELEM_ADD(return_flistp,
                                                TAB_FLD_DEPOSIT_INFO,dep_spec_elemid, ebufp);

				PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_DESCR,deposit_list_flistp,PIN_FLD_DESCR, ebufp);
				PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_NAME,deposit_list_flistp,PIN_FLD_NAME, ebufp);
				PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_CREDIT_LIMIT_FLAG,deposit_list_flistp,
                                                        PIN_FLD_CREDIT_LIMIT_FLAG,ebufp);
				end_date=PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_END_T,1,ebufp);
				if(end_date!= NULL)
				{
					end_date_strp= fm_tab_utils_common_convert_timestamp_to_date(ctxp,
							end_date, ebufp);
					PIN_FLIST_FLD_PUT(deposit_list_flistp, TAB_FLD_END_T_STR,
							end_date_strp, ebufp);
				}
				PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_NAME,
						deposit_list_flistp,TAB_FLD_OFFER_NAME,ebufp);
				PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_AMOUNT,
						deposit_list_flistp,PIN_FLD_AMOUNT,ebufp);
			}
		}
		else
		{

			while((res_flistp= PIN_FLIST_ELEM_GET_NEXT(get_deposit_oflistp, PIN_FLD_RESULTS,
					&dep_spec_elemid, 1, &dep_spec_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"res_flistp",res_flistp);
				deposit_list_flistp=PIN_FLIST_ELEM_ADD(return_flistp,
					       	TAB_FLD_DEPOSIT_INFO,dep_spec_elemid, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,get_deposit_dtl_iflistp,
						PIN_FLD_POID,ebufp);
				PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_PRODUCT_OBJ,get_deposit_dtl_iflistp,
						PIN_FLD_PRODUCT_OBJ, ebufp);

				fm_tab_ar_get_deposite_details(ctxp,flags,get_deposit_dtl_iflistp,
						&get_deposit_dtl_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_query_deposit_types "
							"error", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_query_deposit_types "
							"in_flistp", in_flistp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Output flist of "
							" fm_tab_ar_get_deposite_details ",get_deposit_dtl_oflistp);
					PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_DESCR,deposit_list_flistp,PIN_FLD_DESCR,ebufp);
					PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_NAME,deposit_list_flistp,PIN_FLD_NAME,ebufp);
					PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_CREDIT_LIMIT_FLAG,deposit_list_flistp,
							PIN_FLD_CREDIT_LIMIT_FLAG,ebufp);
					end_date=PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_END_T,1,ebufp);
					if(end_date!= NULL)
					{
						end_date_strp= fm_tab_utils_common_convert_timestamp_to_date(ctxp,
								end_date, ebufp);
						PIN_FLIST_FLD_PUT(deposit_list_flistp, TAB_FLD_END_T_STR,
								end_date_strp, ebufp);
					}
					PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_NAME,deposit_list_flistp,
							TAB_FLD_OFFER_NAME,ebufp);
					PIN_FLIST_FLD_COPY(get_deposit_dtl_oflistp,PIN_FLD_AMOUNT,deposit_list_flistp,
							PIN_FLD_AMOUNT,ebufp);

					if((PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_DRAFT_FLAG,1,ebufp))!=NULL)
					{
						draft_flag=*(int*)PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_DRAFT_FLAG,1,ebufp);

						if(draft_flag==1)
						{
							PIN_FLIST_FLD_SET(deposit_list_flistp, PIN_FLD_STATUS_STR,TAB_AR_DRAFT_DEPOSIT, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(deposit_list_flistp, PIN_FLD_STATUS_STR,TAB_AR_NON_DRAFT_DEPOSIT, ebufp);
						}
					}
				}
			}
		}
	}
	PIN_FLIST_CONCAT(*ret_flistpp,return_flistp,ebufp);
		
cleanup:
	PIN_FLIST_DESTROY_EX(&get_spec_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&get_deposit_dtl_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&get_deposit_dtl_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_flistp,NULL);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_query_deposit_types output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get details of
 * deposit list for given product obj
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 * *
 *  */

static void
fm_tab_ar_get_deposite_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*read_rate_obj_iflistp=NULL;
	pin_flist_t		*read_rate_obj_oflistp=NULL;
	pin_flist_t		*read_prod_obj_iflistp=NULL;
	pin_flist_t		*bal_impacts_flistp=NULL;
	pin_flist_t		*date_ranges_flistip=NULL;
	pin_flist_t		*search_oflist=NULL;
	pin_flist_t		*read_prod_obj_oflistp=NULL;
	pin_flist_t		*return_flistp=NULL;
	pin_flist_t		*deposit_list_flistp=NULL;
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*search_res_flistp=NULL;
	pin_flist_t		*quantity_tiers_flistp=NULL;

	pin_decimal_t		*fixed_amount=NULL;
	pin_decimal_t		*scaled_amount=NULL;
	pin_decimal_t		*final_amount=NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposite_details error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposite_details :"
				" input flist", in_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_deposite_details input flist", in_flistp);

	deposit_list_flistp=PIN_FLIST_CREATE(ebufp);
	return_flistp=PIN_FLIST_CREATE(ebufp);
	read_prod_obj_iflistp=PIN_FLIST_CREATE(ebufp);

	deposit_list_flistp=PIN_FLIST_ELEM_ADD(return_flistp, PIN_FLD_DEPOSIT_INFO,0,ebufp);

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PRODUCT_OBJ,read_prod_obj_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(read_prod_obj_iflistp,PIN_FLD_NAME,NULL,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS: input flist", read_prod_obj_iflistp);

	/* Call for PCM_OP_READ_FLDS to read product object */
	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_prod_obj_iflistp, &read_prod_obj_oflistp,ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS for product obj: "
				" input flist ", read_prod_obj_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS for product obj:"
				" Error while reading product object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_FLDS for product obj:"
			       " return flist", read_prod_obj_iflistp);
		PIN_FLIST_FLD_COPY(read_prod_obj_oflistp,PIN_FLD_NAME,
				deposit_list_flistp,PIN_FLD_NAME,ebufp);
	}

	//Call util func to get rate_plan details on basis on product obj 

	search_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PRODUCT_OBJ,search_flistp, PIN_FLD_POID, ebufp);

	fm_tab_utils_common_get_rate_plan_details(ctxp,search_flistp, &search_oflist, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_query_deposit_types "
				" search rate_plan obj input flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_query_deposit_types: "
			       " Error in getting rate_plan object", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_query_deposit_types"
			       " search of rate_plan output flist", search_oflist);

		//search_res_flistp=PIN_FLIST_CREATE(ebufp);
		//date_ranges_flistip=PIN_FLIST_CREATE(ebufp);

		search_res_flistp=PIN_FLIST_ELEM_GET(search_oflist,PIN_FLD_RESULTS,PIN_ELEMID_ANY,0,ebufp);
		date_ranges_flistip=PIN_FLIST_ELEM_GET(search_res_flistp,
				PIN_FLD_DATE_RANGES,PIN_ELEMID_ANY,0,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_query_deposit_types "
			       " date_ranges_flistip",date_ranges_flistip);
		read_rate_obj_iflistp=PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(date_ranges_flistip,PIN_FLD_RATE_OBJ,
				read_rate_obj_iflistp, PIN_FLD_POID, ebufp);
		quantity_tiers_flistp=PIN_FLIST_ELEM_ADD(read_rate_obj_iflistp,PIN_FLD_QUANTITY_TIERS,0,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS of rate obj: "
				" input flist", read_rate_obj_iflistp);

		/* Call for PCM_OP_READ_FLDS to read product object */
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_rate_obj_iflistp, &read_rate_obj_oflistp,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS rate obj : "
					" input flist ", read_rate_obj_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
					" Error while reading rate object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_FLDS: rate object"
					" return flist", read_rate_obj_oflistp);
			//bal_impacts_flistp=PIN_FLIST_CREATE(ebufp);
			quantity_tiers_flistp=PIN_FLIST_ELEM_GET(read_rate_obj_oflistp,
					PIN_FLD_QUANTITY_TIERS,PIN_ELEMID_ANY,0,ebufp);
			bal_impacts_flistp=PIN_FLIST_ELEM_GET(quantity_tiers_flistp,
					PIN_FLD_BAL_IMPACTS,PIN_ELEMID_ANY,0,ebufp);

			fixed_amount=PIN_FLIST_FLD_GET(bal_impacts_flistp,PIN_FLD_FIXED_AMOUNT,0,ebufp);
			scaled_amount=PIN_FLIST_FLD_GET(bal_impacts_flistp,PIN_FLD_SCALED_AMOUNT,0,ebufp);
			if(!(pbo_decimal_is_null(fixed_amount, ebufp)) && !(pbo_decimal_is_null(scaled_amount, ebufp)))
			{
				final_amount=pbo_decimal_add(fixed_amount,scaled_amount,ebufp);
				PIN_FLIST_FLD_SET(deposit_list_flistp,PIN_FLD_AMOUNT,final_amount,ebufp);
			}	
		}
	}
	*ret_flistpp=deposit_list_flistp;

cleanup:
	//PIN_FLIST_DESTROY_EX(&date_ranges_flistip,NULL);
	PIN_FLIST_DESTROY_EX(&read_rate_obj_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_rate_obj_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_prod_obj_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_prod_obj_oflistp,NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_query_deposit_types output flist", *ret_flistpp);
	return;

}
