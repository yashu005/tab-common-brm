/*******************************************************************************
 *
 *	 This material is the confidential property of Telenor/Oracle Corporation or its
 *	 licensors and may be used, reproduced, stored or transmitted only in
 *	 accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 31-JAN-2022		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_ADJUSTMENT operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "pin_bill.h"
#include "pin_pymt.h"
#include "ops/ar.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_ar_make_adjustment(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_make_adjustment(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_make_adjustment_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_execute_acc_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_execute_bill_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_execute_item_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_perform_adj_wlds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_get_bill_items(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	int			status,
	int			children,
	pin_errbuf_t		*ebufp);

/*Extern Functions*/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_bill_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_AR_MAKE_ADJUSTMENT operation.
 *************************************************************************/
void
op_tab_ar_make_adjustment(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*enrich_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";
	poid_t			*account_pdp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_adjustment function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_ADJUSTMENT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_adjustment bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_adjustment input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, r_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_ADJUSTMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_ADJUSTMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_ADJUSTMENT, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_adjustment(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_adjustment error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_adjustment:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_adjustment: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_MAKE_ADJUSTMENT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_adjustment:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_ADJUSTMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_ADJUSTMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_ADJUSTMENT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_adjustment output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to purchase
 * product and discount offerings.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_ar_make_adjustment(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*temp_input_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*acc_adjustment_iflistp = NULL;
	pin_flist_t		*acc_adjustment_oflistp = NULL;
	pin_flist_t		*adj_wflds_iflistp = NULL;
	pin_flist_t		*adj_wflds_oflistp = NULL;
	pin_flist_t		*adj_results_flistp = NULL;
	pin_flist_t		*bill_adjustment_iflistp = NULL;
	pin_flist_t		*bill_adjustment_oflistp = NULL;
	pin_flist_t		*validate_adj_fields_iflistp = NULL;
	pin_flist_t		*validate_adj_fields_oflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*billinfo_details_iflistp = NULL;
	pin_flist_t		*billinfo_details_oflistp = NULL;
	pin_flist_t		*billinfo_rflds_iflistp = NULL;
	pin_flist_t		*billinfo_rflds_oflistp = NULL;
	pin_flist_t		*get_bill_details_iflistp = NULL;
	pin_flist_t		*get_bill_details_oflistp = NULL;
	pin_flist_t		*bill_results_flistp = NULL;
	pin_flist_t		*get_bill_items_iflistp = NULL;
	pin_flist_t		*get_bill_items_oflistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*event_read_flds_iflistp = NULL;
	pin_flist_t		*event_read_flds_oflistp = NULL;
	pin_flist_t		*make_adj_rdata_flistp = NULL;
	pin_flist_t		*post_make_adj_iflistp = NULL;
	pin_flist_t		*post_make_adj_oflistp = NULL;
	pin_flist_t 		*enrich_resp_flistp=NULL;
	pin_flist_t 		*enrich_not_out_flistp=NULL;
	pin_flist_t 		*notify_out_flistp=NULL;
	poid_t			*notify_pdp = NULL;
	char			*trans_idp = NULL;
	char			*bill_nop = NULL;
	char			*msisdnp = NULL;
	char			*input_item_typep = NULL;
	char			*account_nop = NULL;
	char			*created_strp = NULL;
	int			children = 0;
	int			get_billinfo_flag = 0;
	int			bill_adjustment = 0;
	int32			errorCode = 0;
	int32			status = PIN_ITEM_STATUS_OPEN;
	int32			*pay_type = NULL;
	int32			*resultp = NULL;
	time_t			*created_t = NULL;
	int32                   *flags = NULL;

	pin_decimal_t		*amountp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_adjustment function entry error", ebufp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_ar_make_adjustment input flist", in_flistp);
		
	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);

	/*Check for account number or MSISDN*/
	if((account_nop == NULL || strlen(account_nop ) == 0) 
		&& (msisdnp == NULL || strlen(msisdnp) == 0) && (bill_nop == NULL || strlen(bill_nop) == 0)) 
    {
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	/*Check for mandatory trans id field*/	
	trans_idp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if(((trans_idp && strlen(trans_idp) == 0)) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			"Transaction ID is missing in request", ebufp);
		goto cleanup;
	}

	/*Check for mandatory amount field*/	
	amountp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp);

	if((pbo_decimal_is_null(amountp, ebufp)) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			"Amount is missing in request", ebufp);
		goto cleanup;
	}

	flags = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_FLAGS, 1, ebufp);
	if(flags && !(*flags == TAB_AR_NO_TAX || *flags == TAB_AR_WITH_TAX))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_TAX_FLAG, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			"Inavlid tax flags passed in request", ebufp);
		goto cleanup;

	}

	/*Bill number is mandatory if item type is passed*/
	input_item_typep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ITEM_TYPE, 1, ebufp);
	
	if((bill_nop == NULL) && 
		(input_item_typep && strlen(input_item_typep) != 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILL_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			"Bill number is missing in request", ebufp);
		goto cleanup;
	}

	/*Policy hook for BU specific field validation*/
	validate_adj_fields_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

	make_adj_rdata_flistp = PIN_FLIST_CREATE(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		" TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT input flist ", validate_adj_fields_iflistp);

	PCM_OP(ctxp, TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT, 0, validate_adj_fields_iflistp, 
		&validate_adj_fields_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			"TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT input flist ", validate_adj_fields_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" Error in calling TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT", ebufp);
		*out_flistpp = validate_adj_fields_oflistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		" TAB_OP_AR_POL_VALIDATE_MAKE_ADJUSTMENT output flist ", validate_adj_fields_oflistp);

	/*Frame input fields for notification*/
	common_notification_flistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
		common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
		common_notification_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, 
		common_notification_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, 
		common_notification_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, 
		common_notification_flistp, PIN_FLD_TRANS_ID, ebufp);

	/*Get billinfo details*/
	
	if(msisdnp && strlen(msisdnp) != 0)
	{
		billinfo_details_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
		fm_tab_utils_common_get_billinfo_details(ctxp, billinfo_details_iflistp,
			&billinfo_details_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" input flist ", billinfo_details_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"fm_tab_utils_common_get_billinfo_details output flist", billinfo_details_oflistp);
			get_billinfo_flag = 1;
		}
	}
	else if(account_nop && strlen(account_nop) != 0 && get_billinfo_flag == 0)
	{
		billinfo_details_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
		fm_tab_utils_common_get_owner_billinfo_details(ctxp, billinfo_details_iflistp,
			&billinfo_details_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" input flist ", billinfo_details_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"fm_tab_utils_common_get_owner_billinfo_details output flist", billinfo_details_oflistp);

			if (billinfo_details_oflistp && (billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_oflistp, 
				PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				/*Throw TAB_ERR_CODE_INVALID_ADJ_PAY_TYPE validation error if the pay type is PIN_PAY_TYPE_PREPAID*/
				pay_type = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

				if(pay_type && (*pay_type == PIN_PAY_TYPE_PREPAID))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
						"fm_tab_ar_make_adjustment: billinfo input flist", billinfo_details_iflistp);
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_INVALID_ADJ_PAY_TYPE, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
						"Subord billinfo found for the given account number", ebufp);
					goto cleanup;

				}
			}
		}
	}

	if (billinfo_details_oflistp && (billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_oflistp, 
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		pay_type = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

		if(pay_type && (*pay_type == PIN_PAY_TYPE_PREPAID))
		{
			billinfo_rflds_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_AR_BILLINFO_OBJ, billinfo_rflds_iflistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_SET(billinfo_rflds_iflistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
			PIN_FLIST_FLD_SET(billinfo_rflds_iflistp, PIN_FLD_PAY_TYPE, NULL, ebufp);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_ar_make_adjustment: PCM_OP_READ_FLDS input flist", billinfo_rflds_iflistp);
			PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, billinfo_rflds_iflistp, &billinfo_rflds_oflistp, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
					" PCM_OP_READ_FLDS input flist ", billinfo_rflds_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
					" Error while calling the opcode", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
					"PCM_OP_READ_FLDS output flist", billinfo_rflds_oflistp);
			}
		}
	}

	/*Perform Account/Service Level Adjustment if bill no is not passed*/
	if((PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp) == NULL))
	{
		acc_adjustment_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
		fm_tab_ar_pol_execute_acc_adj(ctxp, acc_adjustment_iflistp, &acc_adjustment_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_MAKE_ADJUSTMENT, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_acc_adj:"
				" input flist ", acc_adjustment_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_acc_adj:"
				" Error while performing account adjustment", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"fm_tab_ar_pol_execute_acc_adj output flist", acc_adjustment_oflistp);

			PIN_FLIST_ELEM_SET(make_adj_rdata_flistp, 
				acc_adjustment_oflistp, PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);
		}
	}

	/*Perform Bill Level Adjustment if the bill no is passed*/
	if(bill_nop)
	{
		/*Search for AR bill object*/
		get_bill_details_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
			get_bill_details_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, 
			get_bill_details_iflistp, PIN_FLD_BILL_NO, ebufp);
		fm_tab_utils_common_get_bill_details(ctxp, get_bill_details_iflistp, &get_bill_details_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
				" input flist ", get_bill_details_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
				" Error while getting ar bill object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"fm_tab_utils_common_get_bill_details output flist", get_bill_details_oflistp);

			if(get_bill_details_oflistp != NULL && (bill_results_flistp = 
				PIN_FLIST_ELEM_GET(get_bill_details_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				/*Call PCM_OP_AR_GET_BILL_ITEMS to perform item level adjustment 
				  if item type is passed in input*/

				if(input_item_typep && strlen(input_item_typep) != 0)
				{
					get_bill_items_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

					PIN_FLIST_FLD_COPY(bill_results_flistp, PIN_FLD_AR_BILLINFO_OBJ, 
						get_bill_items_iflistp, PIN_FLD_AR_BILLINFO_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(bill_results_flistp, PIN_FLD_POID, 
						get_bill_items_iflistp, PIN_FLD_BILL_OBJ, ebufp);

					children = 1;
					fm_tab_ar_pol_get_bill_items(ctxp, get_bill_items_iflistp, 
						&get_bill_items_oflistp, db_no, status, children, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						errorCode = ebufp->pin_err;

						if(errorCode == TAB_ERR_CODE_INVALID_ITEM_TYPE)
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_INVALID_ITEM_TYPE, 0, 0, 0);
						}
						else
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_MAKE_ADJUSTMENT, 0, 0, 0);
						}
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_bill_items:"
							" input flist ", get_bill_items_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_bill_items:"
							" Error while performing item adjustment", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
							"fm_tab_ar_pol_get_bill_items output flist", get_bill_items_oflistp);

						PIN_FLIST_ELEM_SET(make_adj_rdata_flistp, get_bill_items_oflistp, 
							PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);
					}
				}
				else
				{
					/*Perform bill adjustment if there is no item type passed in input*/
					bill_adjustment_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
					PIN_FLIST_FLD_COPY(bill_results_flistp, PIN_FLD_POID, 
						bill_adjustment_iflistp, PIN_FLD_POID, ebufp);
					fm_tab_ar_pol_execute_bill_adj(ctxp, bill_adjustment_iflistp, &bill_adjustment_oflistp, db_no, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_MAKE_ADJUSTMENT, 0, 0, 0);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj:"
							" input flist ", bill_adjustment_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj:"
							" Error while performing bill adjustment", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
							"fm_tab_ar_pol_execute_bill_adj output flist", bill_adjustment_oflistp);

						if(bill_adjustment_oflistp != NULL)
						{
							resultp = PIN_FLIST_FLD_GET(bill_adjustment_oflistp, PIN_FLD_RESULT, 1, ebufp);
							if(resultp && *resultp == PIN_RESULT_FAIL)
							{
								/*if the bill due is zero and cannot be adjusted*/
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									TAB_ERR_CODE_BILL_ADJ_FAIL, 0, 0, 0);
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj:"
									" input flist ", bill_adjustment_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
									"The bill due is Zero, cannot be adjusted", ebufp);
								goto cleanup;
							}

							PIN_FLIST_ELEM_SET(make_adj_rdata_flistp, bill_adjustment_oflistp, 
								PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);
						}

						bill_adjustment = 1;

					}
				}
			}
			else
			{	
				/*if bill no is not present in BRM DB*/
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_bill_details:"
					"Bill not found in BRM DB", ebufp);
				goto cleanup;
			}
		}
	}

	/*Perform Write fields on TAB_FLD_ADJUSTMENT_INFO array*/
	if((acc_adjustment_oflistp != NULL && (adj_results_flistp = PIN_FLIST_ELEM_GET(acc_adjustment_oflistp,	
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL) || 
	(bill_adjustment_oflistp != NULL && (adj_results_flistp = PIN_FLIST_ELEM_GET(bill_adjustment_oflistp,  
	     	PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL) || 
	(get_bill_items_oflistp != NULL && (adj_results_flistp = PIN_FLIST_ELEM_GET(get_bill_items_oflistp,	 
	    	PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL))
	{
		event_read_flds_iflistp = PIN_FLIST_CREATE(ebufp);

		if (bill_adjustment == 1)
		{
			PIN_FLIST_FLD_COPY(adj_results_flistp, PIN_FLD_EVENT_OBJ, 
				event_read_flds_iflistp, PIN_FLD_POID, ebufp);
		}
		else
		{

			PIN_FLIST_FLD_COPY(adj_results_flistp, PIN_FLD_POID, 
				event_read_flds_iflistp, PIN_FLD_POID, ebufp);
		}

		PIN_FLIST_FLD_SET(event_read_flds_iflistp, PIN_FLD_CREATED_T, NULL, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_adjustment: Read event flds input flist", event_read_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, event_read_flds_iflistp, &event_read_flds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" input flist ", event_read_flds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
				" Error while reading event flds", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"Read event flds output flist", event_read_flds_oflistp);

			if(event_read_flds_oflistp != NULL)
			{
				created_t = PIN_FLIST_FLD_GET(event_read_flds_oflistp, 
					PIN_FLD_CREATED_T, 1, ebufp);
				if(created_t != NULL)
				{
					created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
						created_t, ebufp);
					PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_START_CREATION_DATE, 
						created_strp, ebufp);
				}
			}
		}

		adj_wflds_iflistp = PIN_FLIST_COPY(adj_results_flistp, ebufp);
		if (bill_adjustment == 1)
		{
			PIN_FLIST_FLD_COPY(adj_results_flistp, PIN_FLD_EVENT_OBJ, 
				adj_wflds_iflistp, PIN_FLD_POID, ebufp);
		}
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, 
			adj_wflds_iflistp, PIN_FLD_USER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, 
			adj_wflds_iflistp, PIN_FLD_TRANS_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION, 
			adj_wflds_iflistp, PIN_FLD_LOCATION, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_GLACCOUNT, 
			adj_wflds_iflistp, PIN_FLD_GLACCOUNT, ebufp);
		fm_tab_ar_pol_perform_adj_wlds(ctxp, adj_wflds_iflistp, &adj_wflds_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_TRANSID, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_adj_wlds:"
				" input flist ", adj_wflds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_adj_wlds:"
				" Error while executing wflds on event adjustment object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment: "
				"fm_tab_ar_pol_execute_acc_adj output flist", acc_adjustment_oflistp);
		}
	}

	/*Policy hook for BU specific post validation*/
	post_make_adj_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_CONCAT(post_make_adj_iflistp, make_adj_rdata_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		"  TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT input flist ", post_make_adj_iflistp);

	PCM_OP(ctxp,  TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT, 0, post_make_adj_iflistp, 
			&post_make_adj_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			"TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT input flist ", post_make_adj_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment:"
			" Error in calling TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT", ebufp);
		*out_flistpp = post_make_adj_oflistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		" TAB_OP_AR_POL_POST_MAKE_ADJUSTMENT output flist ", post_make_adj_oflistp);


	notify_flistp = PIN_FLIST_CREATE(ebufp);
	temp_input_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_flistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);



	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_ADJUSTMENT, -1, ebufp);
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		" fm_tab_ar_make_adjustment_notification input flist ", notify_flistp);



	enrich_resp_flistp=PIN_FLIST_COPY(*out_flistpp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment : TAB_OP_AR_POL_ENRICH_RESP_MAKE_ADJUSTMENT,: "
			"input Flist", enrich_resp_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_ENRICH_RESP_MAKE_ADJUSTMENT,0, enrich_resp_flistp,out_flistpp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment : TAB_OP_AR_POL_ENRICH_RESP_MAKE_ADJUSTMENT,: "
			"output Flist", *out_flistpp);


	if(make_adj_rdata_flistp != NULL)
	{		
		notify_out_flistp =PIN_FLIST_CREATE(ebufp);
		enrich_not_out_flistp=PIN_FLIST_COPY(*out_flistpp,ebufp);
		//PIN_FLIST_ELEM_SET(notify_out_flistp, make_adj_rdata_flistp, PIN_FLD_RESULTS_DATA,0, ebufp);
		PIN_FLIST_CONCAT(enrich_not_out_flistp,make_adj_rdata_flistp,ebufp);
		PIN_FLIST_SUBSTR_SET(notify_flistp, enrich_not_out_flistp, PIN_FLD_OUT_FLIST, ebufp);
	}

	// Call function to enrich notification details
	fm_tab_ar_make_adjustment_notification(ctxp, notify_flistp, db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			" fm_tab_ar_make_adjustment_notification input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment: "
			" fm_tab_ar_make_adjustment_notification error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment:"
		" fm_tab_ar_make_adjustment_notification output flist ", notify_oflistp);

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acc_adjustment_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acc_adjustment_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&adj_wflds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&adj_wflds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_adjustment_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_adjustment_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_rflds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_rflds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_items_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&event_read_flds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&event_read_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&validate_adj_fields_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&validate_adj_fields_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_make_adj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_make_adj_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&make_adj_rdata_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_resp_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_not_out_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_adjustment output flist", *out_flistpp);
	return;
}

/**
 * We use this function to perform
 * get bills items and execute bill
 * adjustment.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_ar_pol_get_bill_items(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	int			status,
	int			children,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*get_bill_items_iflistp = NULL;
	pin_flist_t		*get_bill_items_oflistp = NULL;
	pin_flist_t		*bill_items_results_flistp = NULL;
	pin_flist_t		*item_adjustment_iflistp = NULL;
	pin_flist_t		*item_adjustment_oflistp = NULL;
	int			item_found = 0;
	int32			results_elemid = 0;
	poid_t			*item_serv_pdp = NULL;
	poid_t			*input_serv_pdp = NULL;
	char			*input_item_typep = NULL;
	char			*get_bill_item_typep = NULL;
	pin_cookie_t		results_cookie = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_bill_items error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_bill_items:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_get_bill_items input", i_flistp);

	input_item_typep = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ITEM_TYPE, 1, ebufp);
	input_serv_pdp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);

	get_bill_items_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, get_bill_items_iflistp, PIN_FLD_POID, ebufp);

	if(children == 1)
	{
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AR_BILLINFO_OBJ, 
			get_bill_items_iflistp, PIN_FLD_AR_BILLINFO_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BILL_OBJ, 
			get_bill_items_iflistp, PIN_FLD_BILL_OBJ, ebufp);
	}

	if(children == 0)
	{
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
			get_bill_items_iflistp, PIN_FLD_BILLINFO_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AR_BILLINFO_OBJ, 
			get_bill_items_iflistp, PIN_FLD_AR_BILLINFO_OBJ, ebufp);
	}

	PIN_FLIST_FLD_SET(get_bill_items_iflistp, PIN_FLD_STATUS, &status, ebufp);
	PIN_FLIST_FLD_SET(get_bill_items_iflistp, PIN_FLD_INCLUDE_CHILDREN , &children, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_get_bill_items: PCM_OP_AR_GET_BILL_ITEMS input flist", get_bill_items_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_GET_BILL_ITEMS, 0, get_bill_items_iflistp, &get_bill_items_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_bill_items:"
			" PCM_OP_AR_GET_BILL_ITEMS input flist ", get_bill_items_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_GET_BILL_ITEMS:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_pol_get_bill_items: PCM_OP_AR_GET_BILL_ITEMS output flist", get_bill_items_oflistp);

		results_elemid = 0;
		results_cookie = NULL;
		while ((bill_items_results_flistp = PIN_FLIST_ELEM_GET_NEXT(get_bill_items_oflistp, PIN_FLD_RESULTS,
			&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			item_serv_pdp = PIN_FLIST_FLD_GET(bill_items_results_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
			get_bill_item_typep = PIN_FLIST_FLD_GET(bill_items_results_flistp, PIN_FLD_NAME, 1, ebufp);

			if(!PIN_POID_IS_NULL(input_serv_pdp) && !PIN_POID_IS_NULL(item_serv_pdp) &&
				!PIN_POID_COMPARE(input_serv_pdp, item_serv_pdp, 0, ebufp) && 
				get_bill_item_typep && input_item_typep && 
				strstr(input_item_typep, get_bill_item_typep) != NULL)
			{
				item_adjustment_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
				PIN_FLIST_FLD_COPY(bill_items_results_flistp, PIN_FLD_POID, 
					item_adjustment_iflistp, PIN_FLD_POID, ebufp);
				fm_tab_ar_pol_execute_item_adj(ctxp, item_adjustment_iflistp, 
					&item_adjustment_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_MAKE_ADJUSTMENT, 0, 0, 0);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj:"
						" input flist ", item_adjustment_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj:"
						" Error while performing item adjustment", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_get_bill_items: "
						"fm_tab_ar_pol_execute_item_adj output flist", item_adjustment_oflistp);
				}
				item_found = 1;
				break;
			}
		}
	}

	if(item_found == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ITEM_TYPE, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj:"
			" input flist ", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment:"
			"Invalid item type passed in request", ebufp);
		goto cleanup;
	}

	*r_flistpp = item_adjustment_oflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_bill_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_bill_items_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&item_adjustment_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_get_bill_items output flist", *r_flistpp);

	return;
}

/**
 * We use this function to perform
 * wlfds on event adjustment object.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_ar_pol_perform_adj_wlds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*adjustment_wflds_iflistp = NULL;
	pin_flist_t		*adjustment_wflds_oflistp = NULL;
	pin_flist_t		*adjustment_info_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_adj_wlds error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_adj_wlds:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_perform_adj_wlds input", i_flistp);

	adjustment_wflds_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, adjustment_wflds_iflistp, PIN_FLD_POID, ebufp);

	adjustment_info_flistp = PIN_FLIST_ELEM_ADD(adjustment_wflds_iflistp, 
		TAB_FLD_ADJUSTMENT_INFO, 0, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, 
		adjustment_info_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LOCATION, 
		adjustment_info_flistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_GLACCOUNT, 
		adjustment_info_flistp, PIN_FLD_GLACCOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_USER_NAME, 
		adjustment_info_flistp, PIN_FLD_USER_NAME, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_perform_adj_wlds: "
		"PCM_OP_WRITE_FLDS input flist", adjustment_wflds_iflistp);
	PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 32, adjustment_wflds_iflistp, &adjustment_wflds_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_adj_wlds:"
			" PCM_OP_WRITE_FLDS input flist ", adjustment_wflds_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_perform_adj_wlds: "
			"PCM_OP_WRITE_FLDS output flist", adjustment_wflds_oflistp);
	}

	*r_flistpp = adjustment_wflds_oflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&adjustment_wflds_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_perform_adj_wlds output flist", *r_flistpp);

	return;
}

/**
 * We use this function to call
 * item level adjustment.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_ar_pol_execute_item_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*item_adjustment_iflistp = NULL;
	pin_flist_t		*item_adjustment_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_item_adj input", i_flistp);

	item_adjustment_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
		item_adjustment_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, 
		item_adjustment_iflistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_FLAGS, 
		item_adjustment_iflistp, PIN_FLD_FLAGS, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, 
		item_adjustment_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR, 
		item_adjustment_iflistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STRING_ID, 
		item_adjustment_iflistp, PIN_FLD_REASON_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STR_VERSION, 
		item_adjustment_iflistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(item_adjustment_iflistp, 
		PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, 
		context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, 
		context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_item_adj: "
		"PCM_OP_AR_ITEM_ADJUSTMENT input flist", item_adjustment_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_ITEM_ADJUSTMENT, 0, item_adjustment_iflistp, &item_adjustment_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_item_adj:"
			" PCM_OP_AR_ITEM_ADJUSTMENT input flist ", item_adjustment_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_ITEM_ADJUSTMENT:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_item_adj: "
			"PCM_OP_AR_ITEM_ADJUSTMENT output flist", item_adjustment_oflistp);
	}

	*r_flistpp = item_adjustment_oflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&item_adjustment_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_item_adj output flist", *r_flistpp);

	return;
}


/**
 * We use this function to call
 * bill adjustment.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_ar_pol_execute_bill_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*bill_adjustment_iflistp = NULL;
	pin_flist_t		*bill_adjustment_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	char			*bill_descrp = "Bill Adjustment";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_bill_adj input", i_flistp);

	bill_adjustment_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
		bill_adjustment_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, 
		bill_adjustment_iflistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_FLAGS, 
		bill_adjustment_iflistp, PIN_FLD_FLAGS, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, 
		bill_adjustment_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	if(PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_DESCR, 1, ebufp) != NULL)
	{
		PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR, 
			bill_adjustment_iflistp, PIN_FLD_DESCR, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(bill_adjustment_iflistp, PIN_FLD_DESCR, bill_descrp, ebufp);
	}
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STRING_ID, 
		bill_adjustment_iflistp, PIN_FLD_REASON_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STR_VERSION, 
		bill_adjustment_iflistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(bill_adjustment_iflistp, 
		PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, 
		context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, 
		context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_bill_adj: "
		"PCM_OP_AR_BILL_ADJUSTMENT input flist", bill_adjustment_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_BILL_ADJUSTMENT, 0, bill_adjustment_iflistp, &bill_adjustment_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_bill_adj:"
			" PCM_OP_AR_BILL_ADJUSTMENT input flist ", bill_adjustment_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_BILL_ADJUSTMENT:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_bill_adj: "
			"PCM_OP_AR_BILL_ADJUSTMENT output flist", bill_adjustment_oflistp);
	}

	*r_flistpp = bill_adjustment_oflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&bill_adjustment_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_bill_adj output flist", *r_flistpp);

	return;
}

/**
 * We use this function to call
 * account adjustment.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_ar_pol_execute_acc_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*acc_adjustment_iflistp = NULL;
	pin_flist_t		*acc_adjustment_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_acc_adj error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_acc_adj:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_acc_adj input", i_flistp);

	acc_adjustment_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, 
		acc_adjustment_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, 
		acc_adjustment_iflistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_FLAGS, 
		acc_adjustment_iflistp, PIN_FLD_FLAGS, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, 
		acc_adjustment_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BAL_GRP_OBJ, 
		acc_adjustment_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, 
		acc_adjustment_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR, 
		acc_adjustment_iflistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STRING_ID, 
		acc_adjustment_iflistp, PIN_FLD_STRING_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_STR_VERSION, 
		acc_adjustment_iflistp, PIN_FLD_STR_VERSION, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(acc_adjustment_iflistp, 
		PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, 
		context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, 
		context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_acc_adj: "
		"PCM_OP_AR_ACCOUNT_ADJUSTMENT input flist", acc_adjustment_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_ACCOUNT_ADJUSTMENT, 0, acc_adjustment_iflistp, &acc_adjustment_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_execute_acc_adj:"
			" PCM_OP_AR_ACCOUNT_ADJUSTMENT input flist ", acc_adjustment_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_ACCOUNT_ADJUSTMENT:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_execute_acc_adj: "
			"PCM_OP_AR_ACCOUNT_ADJUSTMENT output flist", acc_adjustment_oflistp);
	}

	*r_flistpp = acc_adjustment_oflistp;

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&acc_adjustment_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_execute_acc_adj output flist", *r_flistpp);

	return;
}

/**
 * We use this function to generate
 * custom notification on make adjustment.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void
fm_tab_ar_make_adjustment_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_adjustment_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_adjustment_notification: "
		"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_ADJUSTMENT input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MAKE_ADJUSTMENT, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_adjustment_notification:"
			" Error in change offer notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_adjustment_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_ADJUSTMENT output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_adjustment_notification output flist", *r_flistpp);
	return;
}
