/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 03-FEB-2022   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_GET_INVOICE_PAYMENT operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/ar.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "tab_utils_common.h"
#define FILE_SOURCE_ID "fm_tab_ar_get_invoice_payment.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_ar_get_invoice_payment(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void 
fm_tab_ar_get_invoice_payment(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);

void 
fm_tab_get_billdetails_from_billno(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
void 
fm_tab_get_bill_items_from_billobj(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
void 
fm_tab_get_aritems_from_itemobj(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void 
fm_tab_get_item_payment_transid(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);

 /**************************************************************************
 *
 * New opcode TAB_OP_AR_GET_INVOICE_PAYMENT is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_AR_GET_INVOICE_PAYMENT operation.
 *************************************************************************/
void
op_tab_ar_get_invoice_payment(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t				*r_flistp = NULL;
	int64					db_no = 0;
	int32					error_clear_flag = 1;
	int32					cerror_code = 0;
	int32					status = 1;
	char					log_msg[256] = "";
	pin_flist_t                *enrich_iflistp = NULL;

	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_invoice_payment  error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);
	
	/***********************************************************
	 * Debug Input
	 ***********************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "op_tab_ar_get_invoice_payment: Input FLIST", in_flistp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_AR_GET_INVOICE_PAYMENT) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_invoice_payment  opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	 *Get DB NO
	 ***********************************************************/
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
        	PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	/* Common_input_validation */
    fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "op_tab_ar_get_invoice_payment input flist", in_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_invoice_payment: "
            "fm_tab_utils_common_validate_and_normalize_input error", ebufp);
        status = TAB_FAIL;
        goto cleanup;
    }
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_invoice_payment:"
        " fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);
 
    /*call Main Fucntion*/
	fm_tab_ar_get_invoice_payment(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_invoice_payment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_invoice_payment error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}
	
cleanup:	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_invoice_payment:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_invoice_payment:"
			" Error while getting invoice payments", ebufp);
        
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_INVOICE_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
            PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_INVOICE_PAYMENT, ebufp);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_INVOICE_PAYMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_INVOICE_PAYMENT, ebufp);
		}
	}
	else
    {
        status = TAB_SUCCESS;
        /*Prepare Return Flist*/
        PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
    }
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX (&enrich_iflistp, NULL);
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_invoice_payment output flist", *ret_flistpp);
    return;
}

void fm_tab_ar_get_invoice_payment(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*r_flistp = NULL;
	pin_flist_t			*billdetails_flistp = NULL;
	pin_flist_t			*billitemssrch_flistp = NULL;
	pin_flist_t			*billitem_flistp = NULL;
	pin_flist_t			*aritem_out_flistp = NULL;
	pin_flist_t			*transferinto_flistp = NULL;
	pin_flist_t			*newaritem_flistp = NULL;
	pin_flist_t			*newtransferinto_flistp = NULL;
	pin_flist_t			*transid_flistp = NULL;
	poid_t				*item_pdp = NULL;
	char				*billno_strp = NULL;
	char				*newdate_strp = NULL;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	time_t				*newtime_tmstp = NULL;
	char                *msisdn = NULL;
    char                *account_no = NULL;
	
	/*******************************************
	 * Insanity Check
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);
	
	/*******************************************
	 *Debug Input Flist
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_ar_get_invoice_payment: Input FLIST", in_flistp);
	
	/*******************************************
	 * Mandatory Fields Check
	 *******************************************/
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
    account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
    if ((account_no == NULL || strlen(account_no) == 0) &&
        ( msisdn == NULL || strlen(msisdn) == 0))
    {
        pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_invoice_payment:"
            "Error PIN_FLD_ACCOUNT_NO/PIN_FLD_MSISDN - Input is missing", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_invoice_payment input flist", in_flistp);
        goto cleanup;
    }
	billno_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 0, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment error getting the bill no",ebufp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment error getting the bill no",ebufp);
		goto cleanup;
	}
	
	if (billno_strp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment: Error getting the Bill NO", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment: Error getting the Bill NO input flist", in_flistp);
		goto cleanup;
	}
	
	fm_tab_get_billdetails_from_billno (ctxp, in_flistp, &billdetails_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_get_service_from_msisdn: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_service_from_msisdn:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 *Return FLIST Preparation
	 *******************************************/
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_NAME, r_flistp, PIN_FLD_NAME, ebufp);
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_ACCOUNT_OBJ, r_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_BILL_NO, r_flistp, PIN_FLD_BILL_NO, ebufp);
	newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(billdetails_flistp, PIN_FLD_START_T, 1, ebufp),ebufp);
	PIN_FLIST_FLD_PUT(r_flistp, TAB_FLD_BILL_START_T_STR, newdate_strp, ebufp);
	newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(billdetails_flistp, PIN_FLD_END_T, 1, ebufp),ebufp);
	PIN_FLIST_FLD_PUT(r_flistp, TAB_FLD_BILL_END_T_STR, newdate_strp, ebufp);
	newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(billdetails_flistp, PIN_FLD_DUE_T, 1, ebufp),ebufp);
	PIN_FLIST_FLD_PUT(r_flistp, TAB_FLD_DUE_T_STR, newdate_strp, ebufp);
	
	newtime_tmstp = PIN_FLIST_FLD_GET(billdetails_flistp, PIN_FLD_CLOSED_T, 1, ebufp);
	
	
	if (*newtime_tmstp > 0)
	{
		newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(billdetails_flistp, PIN_FLD_CLOSED_T, 1, ebufp),ebufp);
		PIN_FLIST_FLD_PUT(r_flistp, TAB_FLD_CLOSED_T_STR, newdate_strp, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_CLOSED_T_STR, "", ebufp);
	}
	
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_DUE, r_flistp, PIN_FLD_DUE, ebufp);
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_TOTAL_DUE, r_flistp, PIN_FLD_TOTAL_DUE, ebufp);
	
	/*******************************************
	 * Set the Bill Object from the Bill Details
	 * to the input flist
	 *******************************************/
	PIN_FLIST_FLD_COPY(billdetails_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_AR_BILL_OBJ, ebufp);
	
	/*******************************************
	 * Get the Bill Item Poids
	 *******************************************/
	fm_tab_get_bill_items_from_billobj(ctxp, in_flistp, &billitemssrch_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_invoice_payment:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 *Debug the output flist for getting items of bill
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_ar_get_invoice_payment: Item Search Output Flist", in_flistp);
	
	
	/*******************************************
	 * Loop to each results of billitem search
	 * get their item details
	 *******************************************/
	while ((billitem_flistp = PIN_FLIST_ELEM_GET_NEXT(billitemssrch_flistp, PIN_FLD_RESULTS,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		fm_tab_get_aritems_from_itemobj(ctxp, billitem_flistp, &aritem_out_flistp,db_no, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_invoice_payment: Error in getting tab_order object", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_invoice_payment:"
				" input flist", in_flistp);
			goto cleanup;
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_invoice_payment:"
				" item_search results flist", billitem_flistp);
		
		
		newaritem_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_NAME, newaritem_flistp, PIN_FLD_NAME, ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_ITEM_TOTAL, newaritem_flistp, PIN_FLD_ITEM_TOTAL, ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_DUE, newaritem_flistp, PIN_FLD_DUE, ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_RECVD, newaritem_flistp, PIN_FLD_RECVD, ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_ADJUSTED, newaritem_flistp, PIN_FLD_ADJUSTED, ebufp);
		PIN_FLIST_FLD_COPY(aritem_out_flistp, PIN_FLD_ACCOUNT_NO, newaritem_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_invoice_payment:"
				" new AR Item flist", newaritem_flistp);
		
		if ((transferinto_flistp=PIN_FLIST_ELEM_GET (aritem_out_flistp, PIN_FLD_TRANSFERS_INTO, 0, 1, ebufp )) != NULL)
		{
			newtransferinto_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(transferinto_flistp, PIN_FLD_NAME, newtransferinto_flistp, PIN_FLD_NAME, ebufp);
			if ((item_pdp = PIN_FLIST_FLD_GET(transferinto_flistp, PIN_FLD_POID, 1, ebufp)) != NULL)
			{
				if (strcmp(PIN_POID_GET_TYPE(item_pdp),"/item/payment") == 0)
				{
					fm_tab_get_item_payment_transid(ctxp, transferinto_flistp, &transid_flistp, db_no, ebufp);
					PIN_FLIST_FLD_COPY(transid_flistp, PIN_FLD_TRANS_ID, newtransferinto_flistp, PIN_FLD_TRANS_ID, ebufp);
				}
			}
			
			PIN_FLIST_FLD_COPY(transferinto_flistp, PIN_FLD_ITEM_TOTAL, newtransferinto_flistp, PIN_FLD_ITEM_TOTAL, ebufp);
			PIN_FLIST_FLD_COPY(transferinto_flistp, PIN_FLD_ALLOCATED, newtransferinto_flistp, PIN_FLD_ALLOCATED, ebufp);
			newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(transferinto_flistp, PIN_FLD_CREATED_T, 1, ebufp),ebufp);
			PIN_FLIST_FLD_PUT(newtransferinto_flistp, TAB_FLD_CREATED_T_STR, newdate_strp, ebufp);
			newdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(transferinto_flistp, PIN_FLD_EFFECTIVE_T, 1, ebufp),ebufp);
			PIN_FLIST_FLD_PUT(newtransferinto_flistp, TAB_FLD_ALLOC_DATE_STR, newdate_strp, ebufp);
			PIN_FLIST_FLD_COPY(transferinto_flistp, PIN_FLD_ACCOUNT_NO, newtransferinto_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_invoice_payment:"
				" new Transfer Into flist", newaritem_flistp);
			
			PIN_FLIST_ELEM_SET(newaritem_flistp, newtransferinto_flistp, PIN_FLD_TRANSFERS_INTO, 0, ebufp);
			
		}
		
		PIN_FLIST_ELEM_SET(r_flistp, newaritem_flistp, PIN_FLD_ITEMS, elem_id , ebufp);		
	}
	
	cleanup:
	
	*out_flistpp =r_flistp;
	
	PIN_FLIST_DESTROY_EX(&billdetails_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&newaritem_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&newtransferinto_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&transid_flistp, ebufp);
	
	
	PIN_FLIST_DESTROY_EX(&billitemssrch_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billitem_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&aritem_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&transid_flistp, ebufp);
	return;
}

void 
fm_tab_get_billdetails_from_billno(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*srch_pdp = NULL;
	poid_t				*parentbill_pdp  = NULL;
	char				*template_str = NULL;
	int32				s_flags = 256;
	
	/*******************************************
	 * Insanity Check
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment error",ebufp);
		return ;
	}
	
	/*******************************************
	 *Debug Input Flist
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_based_from_billno: Input FLIST", in_flistp);
	
	/*******************************************
	 * Generation of Dummy Poids
	 *******************************************/
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	parentbill_pdp  = PIN_POID_CREATE(db_no, "/bill", 0, ebufp);
	
	/*******************************************
	 * Search Input FLIST Generation
	 *******************************************/
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /bill where  F1 = V1 and F2 = V2 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, args_flistp, PIN_FLD_BILL_NO, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, parentbill_pdp, ebufp);
	PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	
	/*******************************************
	 * Debug Search Input FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_based_from_billno: Search Input Flist", search_in_flistp);
	
	/*******************************************
	 * Execution of PCM_OP_SEARCH
	 *******************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	
	/*******************************************
	 * Validation if there is an Error 
	 * on PCM_OP_SEARCH Execution
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_billdetails_from_billno: Error in Searching Bill Details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_billdetails_from_billno:"
			" Error in Searching Bill Details input flist", search_in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Checking if there is any result
	 *******************************************/
	if (PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp) <= 0) 
	{	
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_billdetails_from_billno: Error there are no results", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_billdetails_from_billno:"
			" Error there are no results input flist", search_in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Debug Search Output FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_based_from_billno: Search Output Flist", search_out_flistp);
			
	
	/*******************************************
	 * Pulling the Results array 0
	 *******************************************/
	result_flistp = PIN_FLIST_ELEM_GET (search_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp );
	
	/*******************************************
	 * Checking if there is an error
	 * Getting the PIN_FLD_RESULTS Array 0
	 *******************************************/
	if (result_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_NOT_FOUND, PIN_FLD_RESULTS, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_billdetails_from_billno: Error in getting the bill details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_billdetails_from_billno:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Debug Results FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_based_from_billno: Result", result_flistp);
	
	/*******************************************
	 * Setting the output Flist
	 *******************************************/ 
	r_flistp = PIN_FLIST_COPY(result_flistp, ebufp);
	
	
	/*******************************************
	 * Cleaning up
	 *******************************************/
	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return; 
}

void 
fm_tab_get_bill_items_from_billobj(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*srch_pdp = NULL;
	char				*template_str = NULL;
	int32				s_flags = 256;
	pin_decimal_t       *item_total = pbo_decimal_from_str("0.00", ebufp);
	
	/*******************************************
	 * Insanity Check
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_bill_items_from_billobj error",ebufp);
		return ;
	}
	
	/*******************************************
	 *Debug Input Flist
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Input FLIST", in_flistp);
	
	/*******************************************
	 * Generation of Dummy Poids
	 *******************************************/
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	
	/*******************************************
	 * Search Input FLIST Generation
	 *******************************************/
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /item where  F1 = V1 and F2 != V2";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AR_BILL_OBJ, args_flistp, PIN_FLD_AR_BILL_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_ITEM_TOTAL, item_total, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);
	
	/*******************************************
	 * Debug Search Input FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Search Input Flist", search_in_flistp);
	
	/*******************************************
	 * Execution of PCM_OP_SEARCH
	 *******************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	/*******************************************
	 * Validation if there is an Error 
	 * on PCM_OP_SEARCH Execution
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_bill_items_from_billobj: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_bill_items_from_billobj:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	
	/*******************************************
	 * Debug Search Output FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Search Output Flist", search_out_flistp);
	
	r_flistp = PIN_FLIST_COPY(search_out_flistp, ebufp);
	/*******************************************
	 * Cleaning up
	 *******************************************/
	cleanup:
	
	/*******************************************
	 * Setting the output Flist
	 *******************************************/
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return; 
	
}

void 
fm_tab_get_aritems_from_itemobj(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*aritem_out_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_invoice_payment error",ebufp);
		return ;
	}
	
	/*******************************************
	 *Debug Input Flist
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_aritems_from_itemobj: Input FLIST", in_flistp);
	
	/*******************************************
	 * Execution of PCM_OP_SEARCH
	 *******************************************/
	PCM_OP(ctxp, PCM_OP_AR_GET_ITEMS, 0, in_flistp, &aritem_out_flistp, ebufp);
	
	/*******************************************
	 * Validation if there is an Error 
	 * on PCM_OP_AR_GET_ITEMS Execution
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_aritems_from_itemobj: Error in executing PCM_OP_AR_GET_ITEMS", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_aritems_from_itemobj:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Pulling the Results array 0
	 *******************************************/
	result_flistp = PIN_FLIST_ELEM_GET (aritem_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp );
	
	/*******************************************
	 * Checking if there is an error
	 * Getting the PIN_FLD_RESULTS Array 0
	 *******************************************/
	if (result_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_aritems_from_itemobj: Error in getting the bill details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_aritems_from_itemobj:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Debug Results FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_aritems_from_itemobj: Result", result_flistp);
	
	/*******************************************
	 * Setting the output Flist
	 *******************************************/
	r_flistp = PIN_FLIST_COPY(result_flistp, ebufp);
	
	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&aritem_out_flistp, ebufp);
	
	return;
}

void 
fm_tab_get_item_payment_transid(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*payment_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*srch_pdp = NULL;
	poid_t				*event_pdp = NULL;
	char				*template_str = NULL;
	int32				s_flags = 256;
	
	/*******************************************
	 * Insanity Check
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_bill_items_from_billobj error",ebufp);
		return;
	}
	
	/*******************************************
	 *Debug Input Flist
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Input FLIST", in_flistp);
	
	/*******************************************
	 * Generation of Dummy Poids
	 *******************************************/
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	event_pdp = PIN_POID_CREATE(db_no, "/event/billing/payment/%", 0, ebufp);
	
	/*******************************************
	 * Search Input FLIST Generation
	 *******************************************/
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /event where  F1 = V1 and F2.TYPE like V2";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_ITEM_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, event_pdp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	args_flistp = PIN_FLIST_SUBSTR_ADD (args_flistp, PIN_FLD_PAYMENT, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_TRANS_ID, NULL, ebufp);
	/*******************************************
	 * Debug Search Input FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Search Input Flist", search_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	
	/*******************************************
	 * Validation if there is an Error 
	 * on PCM_OP_SEARCH Execution
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_bill_items_from_billobj: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_bill_items_from_billobj:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Checking if there is any result
	 *******************************************/
	if (PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp) <= 0) 
	{	
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_bill_items_from_billobj: Error in getting the bill details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_bill_items_from_billobj:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	/*******************************************
	 * Debug Search Output FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_items_from_billobj: Search Output Flist", search_out_flistp);
			
	if ((result_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp )) != NULL)
	{
		payment_flistp = PIN_FLIST_SUBSTR_GET(result_flistp, PIN_FLD_PAYMENT, 1, ebufp );
	}
	
	/*******************************************
	 * Setting the output Flist
	 *******************************************/
	r_flistp = PIN_FLIST_COPY(payment_flistp, ebufp);
	
	/*******************************************
	 * Cleaning up
	 *******************************************/
	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return; 
}
