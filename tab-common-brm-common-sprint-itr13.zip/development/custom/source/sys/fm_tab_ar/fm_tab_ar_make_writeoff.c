/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 17-Jan-2022   | Ruhi Bhatnagar 	|               | New opcode TAB_OP_AR_MAKE_WRITEOFF
 *                  								| to make writeoff fields.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_WRITEOFF operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_pymt.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_ar_make_writeoff(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_ar_make_writeoff(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_make_writeoff_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/*** Extern Function ***/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
        pcm_context_t           *ctxp,
        poid_t                  *pdp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   status,
        poid_t                  *account_pdp,
        char                    *opcode_name,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_get_billinfo (
        pcm_context_t           *ctxp,
        poid_t                  *acc_pdp,
        int32                   active_flag,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**************************************************************************
 * Main routine for the TAB_OP_AR_MAKE_WRITEOFF operation.
 *************************************************************************/
/**
 * *
 * New opcode TAB_OP_AR_MAKE_WRITEOFF is implemented to
 * make Writeoff flds
 * 
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 * 
 * Sample Input Flist
 * 0 PIN_FLD_POID           	POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      	STR [0] "CN-0999009"
 * 0 PIN_FLD_USER_NAME      	STR [0] "EXTERNAL_ID1"
 * 0 PIN_FLD_TRANS_ID        	STR [0] “9011”
 * 0 PIN_FLD_DESCR     		STR [0] "Approved for writeoff"
 * 0 PIN_FLD_FLAGS          	INT [0] 0
 * 0 PIN_FLD_CORRELATION_ID  	STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   	STR [0] "CRM"
 *
 **/

void
op_tab_ar_make_writeoff(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	char			*tran_id = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_writeoff function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_WRITEOFF) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_writeoff bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_writeoff input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, r_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE, 
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:" 
			"Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:input flist",
			in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,cerror_code, 
			&r_flistp, db_no,ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	
	/* Validate the input arguments */
	tran_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	if(tran_id == NULL || strlen(tran_id) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_writeoff: Error PIN_FLD_TRANS_ID is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_writeoff input flist", in_flistp);
		status = TAB_FAIL;
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail: input flist",
			in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:"
			"Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_WRITEOFF;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);


		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_WRITEOFF)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_MAKE_WRITEOFF, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp,in_flistp,&enrich_iflistp,
			db_no,ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize"				"input:input flist",in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_writeoff:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_writeoff(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_writeoff error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:" 
				"enrich_iflistp", enrich_iflistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_writeoff:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_writeoff: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_MAKE_WRITEOFF", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_writeoff:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_WRITEOFF;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_WRITEOFF )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_MAKE_WRITEOFF,
			      	ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_writeoff output flist", *ret_flistpp);
	return;
}

/********************************************
 * We use this function
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void fm_tab_ar_make_writeoff(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t		*acct_writeoff_iflistp = NULL;
	pin_flist_t		*acct_writeoff_rflistp = NULL;
	pin_flist_t		*contextinfo_iflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*resultsinfo_flistp = NULL;
	pin_flist_t		*wflds_iflistp = NULL;
	pin_flist_t		*wflds_rflistp = NULL;
	pin_flist_t		*winfo_flistp = NULL;
	pin_flist_t		*notify_oflistp=NULL;

	poid_t			*billinfo_pdp = NULL;
	int32			input_member_elemid = 0;
	pin_cookie_t		input_member_cookie = NULL;
	const char		*poid_typep     = NULL;
	int32			member_elemid = 0;
	pin_cookie_t		member_cookie = NULL;
	char			*acct_no = NULL;
	poid_t			*acct_obj = NULL;
	int32           active_flag = 0;
	int32           paytype_i = 0;
   	pin_flist_t     *billinfo_flistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff fn entry error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_writeoff in_flistp", in_flistp);
	
	/* Validate the input arguments */
	acct_no =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((acct_no == NULL || strlen(acct_no) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:"
				"account number is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_writeoff: input flist", in_flistp);
		goto cleanup;
	}
	acct_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);
	/*SUBORD paytype checking*/
	fm_tab_utils_common_get_billinfo(ctxp, acct_obj, active_flag, &billinfo_flistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute input flist", in_flistp);
		goto cleanup;
	}
	paytype_i = *(int *)PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (paytype_i == PIN_PAY_TYPE_SUBORD)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
				"Error Subord Paytype found for the given account", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
				"Error SubordPaytype  input flist", billinfo_flistp);
		goto cleanup;
	}
	
	acct_writeoff_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, acct_writeoff_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME,acct_writeoff_iflistp,PIN_FLD_PROGRAM_NAME,
		ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, acct_writeoff_iflistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, acct_writeoff_iflistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, acct_writeoff_iflistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FLAGS, acct_writeoff_iflistp, PIN_FLD_FLAGS, ebufp);
	contextinfo_iflistp = PIN_FLIST_SUBSTR_ADD(acct_writeoff_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, contextinfo_iflistp, 
		PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, contextinfo_iflistp, 
		PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_AR_ACCOUNT_WRITEOFF in_flistp", 
		acct_writeoff_iflistp);

	PCM_OP(ctxp, PCM_OP_AR_ACCOUNT_WRITEOFF, 0, acct_writeoff_iflistp, &acct_writeoff_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff: input flist",
		     	acct_writeoff_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		       	TAB_ERR_CODE_API_MAKE_WRITEOFF,0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:"
	      		"Error while account writeoff",ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_AR_ACCOUNT_WRITEOFF r_flist",acct_writeoff_rflistp);
	
	input_member_elemid = 0;
	input_member_cookie = NULL;
	while ((results_flistp = PIN_FLIST_ELEM_GET_NEXT(acct_writeoff_rflistp, PIN_FLD_RESULTS,
		&input_member_elemid, 1, &input_member_cookie, ebufp)) != (pin_flist_t *)NULL)	
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"results_flistp", results_flistp);
		member_elemid = 0;
		member_cookie = NULL;
		while ((resultsinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(results_flistp, PIN_FLD_RESULTS,
			&member_elemid, 1, &member_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"resultsinfo_flistp", resultsinfo_flistp);

			billinfo_pdp = PIN_FLIST_FLD_GET(resultsinfo_flistp, PIN_FLD_POID, 1, ebufp);
			poid_typep = PIN_POID_GET_TYPE(billinfo_pdp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, poid_typep);
		
			if(poid_typep && (strcmp(poid_typep,"/event/billing/writeoff/billinfo") == 0 ))
			{
				wflds_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(wflds_iflistp, PIN_FLD_POID, billinfo_pdp, ebufp);
				winfo_flistp = PIN_FLIST_ELEM_ADD(wflds_iflistp,
					TAB_FLD_WRITEOFF_INFO, 0, ebufp);
				PIN_FLIST_FLD_COPY(acct_writeoff_iflistp, PIN_FLD_USER_NAME, 
					winfo_flistp, PIN_FLD_USER_NAME, ebufp);
				PIN_FLIST_FLD_COPY(acct_writeoff_iflistp, PIN_FLD_TRANS_ID, 
					winfo_flistp, PIN_FLD_TRANS_ID, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_WRITE_FLDS input flist",
			      		wflds_iflistp);
	
				PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 32, wflds_iflistp, &wflds_rflistp, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_MAKE_WRITEOFF, 0, 0, 0);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS"
						" input flist", wflds_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS:" 
						"Error while writing poid", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_WRITE_FLDS"
						" output flist",wflds_rflistp);
				}
			}
		}
		PIN_FLIST_DESTROY_EX(&wflds_iflistp, NULL);
	}

	if((results_flistp = PIN_FLIST_ELEM_GET(acct_writeoff_rflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 
		1, ebufp)) == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff: results flist",
		      	results_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
	      	TAB_ERR_CODE_API_MAKE_WRITEOFF,	0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:"
			"Error while making account writeoff",ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_writeoff:"
		" fm_tab_ar_pol_make_writeoff_notify input flist ", in_flistp);
	// Call function to enrich notification details
	fm_tab_ar_pol_make_writeoff_notify(ctxp, in_flistp, db_no,acct_writeoff_rflistp,*out_flistpp, 
		&notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_WRITEOFF, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff:"
			" fm_tab_ar_pol_make_writeoff_notify input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_writeoff: "
			" fm_tab_ar_pol_make_writeoff_notify error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_writeoff:"
		" fm_tab_ar_pol_make_writeoff_notify output flist ", notify_oflistp);

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	/******************************************************************
	 * Clean up.
	 ******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&acct_writeoff_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acct_writeoff_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&wflds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&wflds_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_writeoff output flist", *out_flistpp);
	return;
}

/********************************************
 * We use this function to call notification opcode
 * It will create notification entry in Kafka queue.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void
fm_tab_ar_pol_make_writeoff_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*make_writeoff_oflistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*res_data_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_writeoff_notify error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_writeoff_notify:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_make_writeoff_notify: "
		"input flist", i_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	temp_flistp = PIN_FLIST_COPY(make_writeoff_oflistp, ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	if(opresp_flistpp != NULL)
	{
		res_data_flistp = PIN_FLIST_COPY(opresp_flistpp, ebufp);
		PIN_FLIST_ELEM_PUT(notify_out_flistp, res_data_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	else
	{
		PIN_FLIST_ELEM_SET(notify_out_flistp, NULL, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_WRITEOFF, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_writeoff_notify:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_WRITEOFF input flist ", notify_iflistp);

	PCM_OP(ctxp,TAB_OP_NOTIFY_POL_ENRICH_MAKE_WRITEOFF,0,notify_iflistp,&enrich_notify_flistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_writeoff_notify:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_writeoff_notify:"
			" Error in update invoice notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_writeoff_notify:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_WRITEOFF output flist ", enrich_notify_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 *******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_make_writeoff_notify output flist", *r_flistpp);
	return;
}
