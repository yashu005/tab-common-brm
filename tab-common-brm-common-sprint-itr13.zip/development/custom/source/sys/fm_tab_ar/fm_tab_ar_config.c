/*******************************************************************************
* Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
* 
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_ar_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_ar_config[] = {
	/* opcode as a int32, function name (as a string) */
	{ TAB_OP_AR_GET_PAYMENT, "op_tab_ar_get_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_PAYMENT,		"op_tab_ar_make_payment" },
	{ TAB_OP_AR_GET_ADJUSTMENT, "op_tab_ar_get_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_ADJUSTMENT, "op_tab_ar_make_adjustment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_INVOICE_PAYMENT, "op_tab_ar_get_invoice_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_PAYMENT_REVERSAL, "op_tab_ar_get_payment_reversal" ,CM_FM_OP_OVERRIDABLE },
    { TAB_OP_AR_UPDATE_PAYTYPE, "op_tab_ar_update_paytype", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_PAYMENT_REVERSAL, "op_tab_ar_make_payment_reversal" ,CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_UPDATE_PAYMENT_TERM, "op_tab_ar_update_payment_term" ,CM_FM_OP_OVERRIDABLE },
    { TAB_OP_AR_MAKE_CORP_PAYMENT, "op_tab_ar_make_corp_payment", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_WRITEOFF, "op_tab_ar_make_writeoff", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_SETTLEMENT, "op_tab_ar_make_settlement", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_WRITEOFF, "op_tab_ar_get_writeoff", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_REFUND, "op_tab_ar_make_refund", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_REFUND, "op_tab_ar_get_refund", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_DISPUTE, "op_tab_ar_make_dispute",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_DISPUTE, "op_tab_ar_get_dispute",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_GET_DEPOSIT, "op_tab_ar_get_deposit",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_MAKE_DEPOSIT, "op_tab_ar_make_deposit",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_RELEASE_DEPOSIT , "op_tab_ar_release_deposit", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_AR_QUERY_DEPOSIT_TYPES,"op_tab_ar_query_deposit_types",CM_FM_OP_OVERRIDABLE},
  { 0,    (char *)0 }

};

#ifdef MSDOS
void *
fm_tab_ar_config_func()
{
  return ((void *) (fm_tab_ar_config));
}
#endif
