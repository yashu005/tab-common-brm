/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 25/Mar/2022 | Piyush Suryavanshi	| 			| Wrapper for payment
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_CORP_PAYMENT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include <stdlib.h>
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_ar_make_corp_payment(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_make_corp_payment(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_update_event_payment(
	pcm_context_t 		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		*payment_output_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_enrich_corp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t 		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_corp_apply_payment(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	int64		db_no,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp);
	
extern int fm_tab_utils_common_call_opcode(
	pcm_context_t     	*ctxp,
	u_int               	opcode,
	u_int               	flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**ret_flistpp,
	char			*log_info,
	int			set_error,
	pin_errbuf_t            *ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			error_clear_flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_account_details(
	pcm_context_t		*ctxp,
	char			*account_no,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_search_bill_no(
        pcm_context_t   *ctxp,
        pin_flist_t     *in_flistp,
        pin_flist_t     **out_flistpp,
        int64           db_no,
        pin_errbuf_t    *ebufp);	

extern int64
fm_tab_utils_common_compare_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_AR_MAKE_CORP_PAYMENT is implemented apply
 * payment on account
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains payment info
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 */

void
op_tab_ar_make_corp_payment(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*trans_order_oflistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_corp_payment:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_make_corp_payment function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_CORP_PAYMENT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_corp_payment bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_corp_payment input flist", in_flistp);
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		//PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{

		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_validate_and_normalize_input:"
					"flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_corp_payment:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_corp_payment(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_corp_payment:"
					"flist", enrich_iflistp);						
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_corp_payment error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_corp_payment: Error while Opening transaction",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_corp_payment:"
				"flist", in_flistp);		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_AR_MAKE_CORP_PAYMENT", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if(PIN_FLIST_ELEM_COUNT(r_flistp,TAB_FLD_NOTIFICATION,ebufp))
		{
			PIN_FLIST_ELEM_DROP(r_flistp,TAB_FLD_NOTIFICATION,PIN_ELEMID_ANY,ebufp);
		}
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_corp_payment output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&trans_order_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/*******************************************************
 * We use this function to apply payment on the account
 * account level, bill level, service level, item level
 * update event and fire notification.
 *
 * @param ctxp The context pointer.
 * @param flags opcode flag.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param db_no Database number.
 * @return flistp.
 *******************************************************/

static void
fm_tab_ar_make_corp_payment(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_corp_payment input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t	*pay_input_flistp=NULL;
	pin_flist_t 	*payment_flistp=NULL;
	pin_flist_t 	*payment_output_flistp=NULL;
	pin_flist_t 	*policy_input_flistp=NULL;	
	char		*acct_nop = NULL;	
	char		*trans_id=NULL;
	pin_flist_t 	*distribution_flistp=NULL;
	
	int 		elem_dis=0;
	pin_cookie_t	cookie_dis=NULL;
	char		*acct_no = NULL;
	
	/* Validate the input arguments */
	acct_no =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((acct_no == NULL || strlen(acct_no) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				"account number is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_corp_payment: input flist", in_flistp);
		goto cleanup;
	}
	
	if (!PIN_FLIST_ELEM_COUNT(in_flistp, TAB_FLD_DISTRIBUTION,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DISTRIUBTION_LIST_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
			"Payment distribution list is missing", ebufp);
		return;		
	}

	trans_id =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
			
	if((trans_id == NULL || strlen(trans_id ) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
			"transaction id is not passed", ebufp);
		return;
	}
	
	while ((distribution_flistp	= PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_DISTRIBUTION,
					&elem_dis,	1, &cookie_dis, ebufp)) !=	(pin_flist_t*)NULL)
	{	
		acct_nop =  PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
								
		if(PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_AMOUNT, 1, ebufp)== NULL) 
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				"amount field is missing", ebufp);
			return;
		}
		
		if((acct_nop == NULL || strlen(acct_nop ) == 0)) 
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment:"
				"account number is not passed", ebufp);
			return;
		}	
	}
	
	/*******************************************************************
	 * Call apply payment
	 *******************************************************************/

	fm_tab_ar_corp_apply_payment(ctxp,in_flistp,db_no, &pay_input_flistp, ebufp);

	/*******************************************************************
	 *Policy call for payment validation
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_corp_payment : TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT: "
			"input Flist", pay_input_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT, 0, pay_input_flistp, &payment_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT: "
			"output Flist", payment_flistp);
			
	PIN_FLIST_DESTROY_EX(&pay_input_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment :TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment: TAB_OP_AR_POL_VALIDATE_CORP_PAYMENT:"
				" in_flistp", in_flistp);
		*out_flistpp=payment_flistp;
		goto cleanup;
	}

	/*******************************************************************
	 *Payment opcode call
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_corp_payment : PCM_OP_PYMT_COLLECT: "
			"input Flist", payment_flistp);
	PCM_OP( ctxp, PCM_OP_PYMT_COLLECT, 0, payment_flistp, &payment_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_corp_payment : PCM_OP_PYMT_COLLECT: "
			"output Flist", payment_output_flistp);

	PIN_FLIST_DESTROY_EX(&payment_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(payment_output_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCOUNT_PAYMENT_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_corp_apply_payment"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_corp_apply_payment:"
				" input flist ", payment_flistp);
		goto cleanup;
	}

	/*******************************************************************
	 *Event update function call
	 *******************************************************************/
	
	fm_tab_ar_update_event_payment(ctxp,in_flistp,payment_output_flistp,out_flistpp,db_no,ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
				" in_flistp", policy_input_flistp);
		goto cleanup;
	}	

	fm_tab_ar_enrich_corp_notification(ctxp, in_flistp,db_no,payment_output_flistp,out_flistpp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment : fm_tab_ar_enrich_corp_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_corp_payment : fm_tab_ar_enrich_corp_notification:"
				" in_flistp", in_flistp);
		goto cleanup;
	}
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, *out_flistpp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, *out_flistpp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, *out_flistpp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, *out_flistpp	,PIN_FLD_TRANS_ID,ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	
	PIN_FLIST_DESTROY_EX(&pay_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_output_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_corp_payment output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * We use this function to update payment event to capture all the
 * input related details
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param payment output flist. 
 * @return flistp.
 * @param ebufp The error buffer.
 *******************************************************************/

static void
fm_tab_ar_update_event_payment(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		*payment_output_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_update_event_payment input flistp", in_flistp);
			
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_update_event_payment payment_output_flistp", payment_output_flistp);			

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*update_event_input_flistp = PIN_FLIST_CREATE(ebufp);
	pin_flist_t 	*update_event_output_flistp=NULL;
	pin_flist_t 	*payment_flistp =PIN_FLIST_CREATE(ebufp);;
	pin_flist_t		*distribution_flistp=NULL;
	pin_flist_t		*result_flistp=NULL;
	pin_flist_t		*output_post_payment_flistp=NULL;
	pin_flist_t		*add_distr_flistp=NULL;	
	pin_flist_t 	*return_dist_flistp=NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp=NULL;
	poid_t			*res_account_pdp=NULL;
	int 			elem_dis=0;
	int 			elem_res=0;
	int        		flag=0;
	pin_cookie_t 	cookie_res=NULL;
	pin_cookie_t 	cookie_dis=NULL;

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME,payment_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_PAY_T_STR,payment_flistp, TAB_FLD_PAY_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BRANCH_NO,payment_flistp, PIN_FLD_BRANCH_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DEALER_CODE,payment_flistp, PIN_FLD_DEALER_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DEALER_NAME,payment_flistp, PIN_FLD_DEALER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_EXTERN_TRANS_ID,payment_flistp, TAB_FLD_EXTERN_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_PAY_MODE,payment_flistp, TAB_FLD_PAY_MODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BANK_CODE,payment_flistp, PIN_FLD_BANK_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_BANK_BRNCH_CODE,payment_flistp, TAB_FLD_BANK_BRNCH_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BANK_ACCOUNT,payment_flistp, PIN_FLD_BANK_ACCOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CARD_NUM,payment_flistp, TAB_FLD_CARD_NUM, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CARD_TYPE,payment_flistp, TAB_FLD_CARD_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CARD_EXPIRATION,payment_flistp, TAB_FLD_CARD_EXPIRATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CHECK_NO,payment_flistp, PIN_FLD_CHECK_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CHANNEL_ID_STR,payment_flistp, TAB_FLD_CHANNEL_ID_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CHECK_ISSUE_T_STR,payment_flistp, TAB_FLD_CHECK_ISSUE_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CHECK_AMOUNT,payment_flistp, TAB_FLD_CHECK_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_LOCATION,payment_flistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_GL_GRP_CODE,payment_flistp, TAB_FLD_GL_GRP_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DESCR,payment_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_CORP_PYMT_KEY,payment_flistp, TAB_FLD_CORP_PYMT_KEY, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,TAB_FLD_ERCPT_METHOD,payment_flistp, TAB_FLD_ERCPT_METHOD, ebufp);
	
	
	add_distr_flistp = PIN_FLIST_CREATE(ebufp);
	while ((distribution_flistp	= PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_DISTRIBUTION,
					&elem_dis,	1, &cookie_dis, ebufp)) !=	(pin_flist_t*)NULL)
	{
		elem_res=0;
		cookie_res=NULL;
		
		account_pdp=PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_ACCOUNT_OBJ, 1,ebufp);
		return_dist_flistp=PIN_FLIST_ELEM_ADD(add_distr_flistp,TAB_FLD_DISTRIBUTION,elem_dis,ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_ACCOUNT_NO,return_dist_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_BILL_NO,return_dist_flistp, PIN_FLD_BILL_NO, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_AMOUNT,return_dist_flistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_TRANS_ID,return_dist_flistp, PIN_FLD_TRANS_ID, ebufp);			
		PIN_FLIST_FLD_SET(return_dist_flistp, TAB_FLD_STATUS, FAILURE,ebufp);

		PIN_FLIST_FLD_COPY(distribution_flistp,TAB_FLD_WHT_CERT,payment_flistp,TAB_FLD_WHT_CERT,ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp,TAB_FLD_WHT_AMOUNT,payment_flistp,TAB_FLD_WHT_AMOUNT,ebufp);
		PIN_FLIST_ELEM_SET(update_event_input_flistp,payment_flistp,TAB_FLD_PAYMENT_INFO,0,ebufp);
		flag=0;
		
		while ((result_flistp	= PIN_FLIST_ELEM_GET_NEXT(payment_output_flistp, PIN_FLD_RESULTS,
					&elem_res,	1, &cookie_res, ebufp)) !=	(pin_flist_t*)NULL)
		{									
						
			PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID,update_event_input_flistp, PIN_FLD_POID, ebufp);			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_event_payment: "
					"Input Flist", update_event_input_flistp);
						
			PCM_OP( ctxp,PCM_OP_WRITE_FLDS,32, update_event_input_flistp, &update_event_output_flistp, ebufp );
			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_event_payment: "
					"output Flist", update_event_output_flistp);
					
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
						" in_flistp", update_event_input_flistp);
				goto cleanup;
			}

			res_account_pdp=PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_ACCOUNT_OBJ, 1,ebufp);
			
			if(!PIN_POID_COMPARE(res_account_pdp,account_pdp,0,ebufp))
			{
			
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_ar_update_event_payment payment_output_flistp", payment_output_flistp);						
				
				PIN_FLIST_FLD_SET(return_dist_flistp, TAB_FLD_STATUS, SUCCESS, ebufp);
				flag=1;
			}

			PIN_FLIST_DESTROY_EX(&update_event_output_flistp, NULL);
		}
		
		if(!flag)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCOUNT_PAYMENT_FAILED, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_event_payment"
			"payment failed for one of the account", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
			" input flist ", payment_flistp);
			goto cleanup;
		}
	}
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(add_distr_flistp, TAB_FLD_DISTRIBUTION, r_flistp, TAB_FLD_DISTRIBUTION, ebufp);
	
	/*******************************************************************
	 *Policy opcode call for post payment
	 *******************************************************************/			
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_corp_payment : TAB_OP_AR_POL_POST_CORP_PAYMENT: "
			"input Flist", payment_output_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_POST_CORP_PAYMENT, 0, payment_output_flistp, &output_post_payment_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_corp_payment : TAB_OP_AR_POL_POST_CORP_PAYMENT: "
			"output Flist", output_post_payment_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_AR_POL_POST_CORP_PAYMENT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_AR_POL_POST_CORP_PAYMENT:"
				" in_flistp", update_event_input_flistp);
		*out_flistpp=output_post_payment_flistp;
		goto cleanup;
	}
	
	*out_flistpp = r_flistp;

	PIN_FLIST_DESTROY_EX(&payment_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_event_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_event_output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&add_distr_flistp, NULL);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_update_event_payment output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * We use this function to create payment input flist
 * account level, service level, bill level, item level
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no Database number.
 * @return flistp.
 * @param ebufp The error buffer.
 *******************************************************************/

static void
fm_tab_ar_corp_apply_payment(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	int64		db_no,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_corp_apply_payment frame input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_corp_apply_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_corp_apply_payment:"
				" in_flistp", in_flistp);
		return;
	}

	poid_t 		*account_pdp= NULL;
	
	pin_flist_t 	*payment_input_flistp=NULL;
	pin_flist_t 	*charges_flistp=NULL;
	pin_flist_t 	*bills_flistp=NULL;
	pin_flist_t 	*bill_out_flistpp=NULL;
	pin_flist_t 	*bill_result_flistp=NULL;
	pin_flist_t 	*reason_code_flistp=NULL;
	pin_flist_t 	*distribution_flistp=NULL;
	pin_flist_t 	*account_result_flistp=NULL;
	pin_flist_t 			*r_dist_flistp=NULL;
	
	int		currency=0;
	int 		zero=0;
	int 		payment_type=10011;
	int64 		flags=16777216;
	
	int 		elem_dis=0;
	pin_cookie_t 	cookie_dis=NULL;
	char		new_trans_id[255];
	char		*trans_id=NULL;
	char 		*account_no=NULL;             

	/*******************************************************************
	 *payment input flist prepration.
	 *******************************************************************/
	payment_input_flistp = PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,payment_input_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR,payment_input_flistp, PIN_FLD_DESCR, ebufp);
	
	while ((distribution_flistp	= PIN_FLIST_ELEM_GET_NEXT(in_flistp, TAB_FLD_DISTRIBUTION,
					&elem_dis,	1, &cookie_dis, ebufp)) !=	(pin_flist_t*)NULL)
	{
		
		account_no = PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_ACCOUNT_NO,1,ebufp);
		if(cm_fm_is_multi_db() && fm_tab_utils_common_compare_db_no(ctxp, distribution_flistp, db_no, ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_DB_NO_MS,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_corp_apply_payment :"
				"child account exists in different schema", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_corp_apply_payment input flist", in_flistp);
			goto cleanup;
		}
		
		fm_tab_utils_common_get_account_details(ctxp,account_no,&r_dist_flistp,db_no,ebufp);	

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object error", ebufp);
			PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object:",account_pdp);
			goto cleanup;
		}

		account_result_flistp=PIN_FLIST_ELEM_GET(r_dist_flistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
		
		if (account_result_flistp==NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NOT_FOUND,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_corp_apply_payment :"
			"account does not exist", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_corp_apply_payment input flist", in_flistp);		
			goto cleanup;
		}
		
		account_pdp = PIN_FLIST_FLD_GET(account_result_flistp, PIN_FLD_POID,0,ebufp);

		PIN_FLIST_FLD_SET(distribution_flistp, PIN_FLD_ACCOUNT_OBJ,account_pdp, ebufp);
		currency=*(int*)PIN_FLIST_FLD_GET(account_result_flistp,PIN_FLD_CURRENCY,0,ebufp);
		trans_id = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_TRANS_ID,0,ebufp);
				
		if(trans_id != NULL)
		{
			memset(new_trans_id, '\0', sizeof(new_trans_id));
			strcpy(new_trans_id, trans_id);
			strcat(new_trans_id, "_");
			strcat(new_trans_id, account_no);		
		}

		PIN_FLIST_FLD_SET(distribution_flistp, PIN_FLD_TRANS_ID,(void*)new_trans_id,ebufp);
		
		charges_flistp=PIN_FLIST_ELEM_ADD(payment_input_flistp,PIN_FLD_CHARGES,elem_dis,ebufp);
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_ACCOUNT_OBJ,account_pdp, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_AMOUNT,charges_flistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_COMMAND,(void*)&zero,ebufp);
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_FLAGS,(void*)&flags,ebufp);
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_CURRENCY,(void*)&currency,ebufp);	
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_PAY_TYPE,(void*)&payment_type,ebufp);
		PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_TRANS_ID,(void*)new_trans_id,ebufp);

		/*******************************************************************
		 *reason id and reason code
		 *******************************************************************/
		if(PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_STRING_ID,1,ebufp)!=NULL &&
				PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_VERSION_ID,1,ebufp)!=NULL)
		{
			reason_code_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_PAYMENT_REASONS,0,ebufp);

			PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_VERSION_ID,reason_code_flistp,PIN_FLD_REASON_ID, ebufp);
			PIN_FLIST_FLD_COPY(distribution_flistp,PIN_FLD_STRING_ID,reason_code_flistp,PIN_FLD_REASON_DOMAIN_ID, ebufp);
		}

		/*******************************************************************
		 *Bill level and item level payment validation
		 *******************************************************************/
		 
		if(PIN_FLIST_FLD_GET(distribution_flistp, PIN_FLD_BILL_NO,1,ebufp)!=NULL)
		{
			/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
			0 PIN_FLD_FLAGS           INT [0] 0
			0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 = V2 "
			0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
			1     PIN_FLD_BILL_NO         STR [0] "B1-23"
			0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
			1     PIN_FLD_PARENT         POID [0] 0.0.0.0  0 0
			0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 0*/
			
			fm_tab_utils_common_search_bill_no(ctxp,distribution_flistp,&bill_out_flistpp,db_no,ebufp);

			if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(bill_out_flistpp,PIN_FLD_RESULTS,ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no:"
						" in_flistp", in_flistp);
				goto cleanup;
			}

			bill_result_flistp=PIN_FLIST_ELEM_GET(bill_out_flistpp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
				
			bills_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_BILLS,0,ebufp);
			PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_BILL_NO,bills_flistp, PIN_FLD_BILL_NO, ebufp);
			PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_AMOUNT,bills_flistp, PIN_FLD_AMOUNT, ebufp);
			PIN_FLIST_FLD_COPY(bill_result_flistp, PIN_FLD_POID,bills_flistp, PIN_FLD_POID, ebufp);	
		}
	}
	
	//setting any account poid in main flist just for routing.
	PIN_FLIST_FLD_SET(payment_input_flistp, PIN_FLD_POID,account_pdp, ebufp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCOUNT_VALIDATE_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_corp_apply_payment :"
				"failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_corp_apply_payment input flist", in_flistp);		
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp=PIN_FLIST_COPY(payment_input_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&payment_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_out_flistpp, NULL);
	PIN_FLIST_DESTROY_EX(&r_dist_flistp, NULL);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_corp_apply_payment frame flist output flist", *out_flistpp);
	return;
}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the payload structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION for
 *  enrichment and return notification flist
 *************************************************************/

static void
fm_tab_ar_enrich_corp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t	*enrich_notify_flistp = NULL;
	pin_flist_t	*notify_tflistp = NULL;
	pin_flist_t	*notify_flistp = NULL;
	poid_t		*notify_pdp = NULL;
	pin_flist_t *distribution_flistp=NULL;
	pin_flist_t *notification_dis_flistp=NULL;
	
	int 			elem_dis=0;
	pin_cookie_t	cookie_dis=NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_enrich_corp_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_enrich_corp_notification: "
			"input flist", i_flistp);

	notify_flistp =PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_POID, ebufp); 


	notify_tflistp = PIN_FLIST_CREATE(ebufp);

	// Create Notification Flist
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_CORP_PAYMENT_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_tflistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_tflistp, PIN_FLD_ACCOUNT_NO, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_flistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, o_flistp, PIN_FLD_OUT_FLIST, ebufp);

	while ((distribution_flistp	= PIN_FLIST_ELEM_GET_NEXT(i_flistp, TAB_FLD_DISTRIBUTION,
					&elem_dis,	1, &cookie_dis, ebufp)) !=	(pin_flist_t*)NULL)
	{
		notification_dis_flistp=PIN_FLIST_ELEM_ADD(notify_tflistp,TAB_FLD_DISTRIBUTION,elem_dis,ebufp);	
		PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_ACCOUNT_NO,notification_dis_flistp,PIN_FLD_ACCOUNT_NO, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp, TAB_FLD_PAY_T_STR,notification_dis_flistp,TAB_FLD_PAY_T_STR, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_AMOUNT,notification_dis_flistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_TRANS_ID,notification_dis_flistp, PIN_FLD_TRANS_ID, ebufp);
		PIN_FLIST_FLD_COPY(distribution_flistp, PIN_FLD_DESCR,notification_dis_flistp, PIN_FLD_DESCR, ebufp);
	}
	
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_tflistp, TAB_FLD_NOTIFICATION, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_enrich_corp_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_CORP_PAYMENT_NOTIFICATION input flist ", notify_flistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CORP_PAYMENT_NOTIFICATION, 0,
			notify_flistp, &enrich_notify_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PAYMENT_NOTFIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_enrich_corp_notification:"
				" input flist ", notify_tflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_enrich_corp_notification:"
				" Error in Notification", ebufp);
		*r_flistpp=enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_enrich_corp_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_CORP_PAYMENT_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_tflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_enrich_corp_notification output flist", *r_flistpp);
	return;
}
