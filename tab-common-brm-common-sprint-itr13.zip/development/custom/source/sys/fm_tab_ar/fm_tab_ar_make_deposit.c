/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 10/Apr/2022 | Rahul Honnaiah		| 			| New opcode implementation to
 *                                               			| make deposit.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_DEPOSIT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "ops/deposit.h"
#include "pin_pymt.h"

EXPORT_OP void
op_tab_ar_make_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_make_deposit(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static int32
fm_tab_ar_make_deposit_create(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_make_deposit_update_evt(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_notify_make_deposit_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t         	*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_depositspec_name (
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 *
 * New opcode TAB_OP_AR_MAKE_DEPOSIT is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, TAB_FLD_NEW_MSISDN, TAB_FLD_OLD_IMSI
 *                  TAB_FLD_NEW_IMSI and PIN_FLD_ACTION.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO	STR [0] "Account123"
 * 0 PIN_FLD_MSISDN	STR [0] "665473645390"
 * 0 PIN_FLD_NAME	STR [0] "Roam_Deposit"
 * 0 PIN_FLD_DEPOSIT_AMOUNT	DECIMAL [0] 1000.0
 * 0 PIN_FLD_PAYMENT	Substurct [0]
 * 1     PIN_FLD_AMOUNT	DECIMAL [0] 1000.0
 * 1     TAB_FLD_CHANNEL_ID_STR	STR [0] "Ch101"
 * 1     TAB_FLD_PAY_T_STR	STR [0] "01-JAN-2022 09:09:00"
 * 1     PIN_FLD_BRANCH_NO	STR [0] "Branch"
 * 1     PIN_FLD_DEALER_CODE	STR [0] "Dealer001"
 * 1     PIN_FLD_DEALER_NAME	STR [0] "Dealer-central"
 * 1     TAB_FLD_EXTERN_TRANS_ID	STR [0] "DepositRef12"
 * 1     TAB_FLD_PAY_MODE	STR [0] "Cash"
 * 1     PIN_FLD_BANK_CODE	STR [0] "001"
 * 1     PIN_FLD_BANK_ACCOUNT	STR [0] "9889000"
 * 1     TAB_FLD_CARD_NUM	STR [0] "1234567800990099"
 * 1     TAB_FLD_CARD_TYPE	STR [0] "Visa"
 * 1     PIN_FLD_CHECK_NO	STR [0] "001"
 * 1     TAB_FLD_CHECK_ISSUE_T_STR	STR [0] "01-Jan-2022 00:09:09"
 * 1     PIN_FLD_RECEIPT_NO	STR [0] "Trans_pay_001"
 * 1     PIN_FLD_STRING_ID	INT [0] 1
 * 1     PIN_FLD_VERSION_ID	INT [0] 100
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "221221_001022"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "POS"
 * 
 */

void
op_tab_ar_make_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	pin_flist_t		*payment_flistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_deposit function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_DEPOSIT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_deposit bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_deposit input flist", in_flistp);

	//To do get db no

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEPOSIT_AMOUNT, r_flistp, PIN_FLD_DEPOSIT_AMOUNT, ebufp);
	payment_flistp = PIN_FLIST_SUBSTR_GET(in_flistp, PIN_FLD_PAYMENT, 1, ebufp);
	if(payment_flistp)
	{
		PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_RECEIPT_NO, r_flistp, PIN_FLD_RECEIPT_NO, ebufp);
	}
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_DEPOSIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_DEPOSIT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_DEPOSIT, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_deposit:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_deposit(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			" input flist", enrich_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_MAKE_DEPOSIT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_DEPOSIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_DEPOSIT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_DEPOSIT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_deposit output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to charge the deposit for a given customer.
 * validate the input
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_ar_make_deposit(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*msisdn = NULL;
	char			*deposit_spec_name = NULL;
	char			*acct_no = NULL;
	char			*receipt_no = NULL;
	pin_decimal_t		*amountp = NULL;	
	pin_flist_t		*payment_flistp = NULL;
	pin_flist_t		*depositspec_rflistp = NULL;
	pin_flist_t		*deposit_details_flistp = NULL;
	pin_flist_t		*update_rflistp = NULL;
	pin_flist_t 		*enrich_resp_flistp=NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_deposit: input flist", in_flistp);
	msisdn =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	acct_no =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	/* Validate the input arguments */
	if((acct_no == NULL || strlen(acct_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
			"account number/msisdn is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
		goto cleanup;
	}

	deposit_spec_name = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);
	if ((deposit_spec_name == NULL || strlen(deposit_spec_name) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DEPOSITNAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit: Error PIN_FLD_NAME- Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
		goto cleanup;
	}

	fm_tab_utils_common_get_depositspec_name(ctxp, in_flistp, &depositspec_rflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_depositspec_name: "
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_depositspec_name:"
			"Error while getting deposit specification obj: ", ebufp);
		goto cleanup;
	}

	if(depositspec_rflistp != NULL && (deposit_details_flistp = PIN_FLIST_ELEM_GET(depositspec_rflistp,
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_FLIST_FLD_COPY(deposit_details_flistp, PIN_FLD_POID, 
			in_flistp, PIN_FLD_DEPOSIT_SPEC_OBJ, ebufp);
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_DEPOSITNAME, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit: Error deposit specifiaction not found in DB", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
		goto cleanup;
	}
	payment_flistp = PIN_FLIST_SUBSTR_GET(in_flistp, PIN_FLD_PAYMENT, 1, ebufp);
	if(payment_flistp)
	{
		receipt_no = PIN_FLIST_FLD_GET(payment_flistp, PIN_FLD_RECEIPT_NO, 1, ebufp);
		if ((receipt_no == NULL || strlen(receipt_no) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_deposit: Error PIN_FLD_RECEIPT_NO- Input is missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
			goto cleanup;
		}

		amountp = PIN_FLIST_FLD_GET(payment_flistp, PIN_FLD_AMOUNT, 1, ebufp);
		if((pbo_decimal_is_null(amountp, ebufp)) ||
			(PIN_FLIST_FLD_GET(payment_flistp, PIN_FLD_AMOUNT, 1, ebufp) == NULL))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_deposit:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
				"Amount is missing in request", ebufp);
			goto cleanup;
		}

		if(PIN_FLIST_FLD_GET(payment_flistp, PIN_FLD_STRING_ID, 1, ebufp) == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_STRINGID_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_deposit: Error PIN_FLD_STRING_ID - Input is missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
			goto cleanup;
		}

		if(PIN_FLIST_FLD_GET(payment_flistp, PIN_FLD_VERSION_ID, 1, ebufp) == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_STRINGVER_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_deposit: Error PIN_FLD_VERSION_ID- Input is missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: input flist", in_flistp);
			goto cleanup;

		}
	}

	if( !fm_tab_ar_make_deposit_create(ctxp, in_flistp, &update_rflistp, db_no, ebufp) )
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit:"
		" fm_tab_ar_make_deposit_create output flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_deposit: "
		"fm_tab_ar_make_deposit_create error", ebufp);
		goto cleanup;	
	}


	enrich_resp_flistp=PIN_FLIST_COPY(*ret_flistpp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT,: "
			"input Flist", enrich_resp_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT,0, enrich_resp_flistp,ret_flistpp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT,: "
			"output Flist", *ret_flistpp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
		" TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT input flist ", enrich_resp_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit: "
		" TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_DEPOSIT error", ebufp);
		goto cleanup;
	}

	// Call function to enrich notification details
	fm_tab_notify_make_deposit_prepare_notification(ctxp, in_flistp, update_rflistp, db_no, 
			ret_flistpp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit:"
		" notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit: "
		" notification error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit:"
		" notification output flist ", *ret_flistpp);


cleanup:
	PIN_FLIST_DESTROY_EX(&depositspec_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_resp_flistp,NULL);
	return;
}

/**
 * We use this function to charge the deposit for a given customer
 * by calling opcode PCM_OP_DEPOSIT_PURCHASE_DEPOSIT
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return boolean value true or false.
 */
static int32
fm_tab_ar_make_deposit_create(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*deposit_in_flistp = NULL;
	pin_flist_t		*deposit_out_flistp = NULL;
	pin_flist_t		*sub_flistp = NULL;
	pin_flist_t		*payment_sub_iflistp = NULL;
	pin_flist_t		*payment_flistp = NULL;
	pin_flist_t		*pur_deposit_in_flistp = NULL;
	pin_flist_t		*pur_deposit_out_flistp = NULL;
	pin_flist_t		*deposit_evt_flistp = NULL;
	pin_flist_t		*temp_evt_flistp = NULL;
	pin_flist_t		*update_evt_oflistp = NULL;

	poid_t			*purchase_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			pay_type = PIN_PAY_TYPE_CASH;
	int                     payment_flag = 0;
	pin_cookie_t            deposit_cookie = NULL;
        int32                   deposit_elemid = 0;
	int32			match_found = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit_create function entry error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		return status;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit_create:"
		" input flist ", in_flistp);

	deposit_in_flistp = PIN_FLIST_CREATE(ebufp);
	purchase_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_PURCHASED_DEPOSIT, -1, ebufp);
        PIN_FLIST_FLD_PUT(deposit_in_flistp, PIN_FLD_POID, purchase_pdp, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, deposit_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, deposit_in_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEPOSIT_SPEC_OBJ, deposit_in_flistp, PIN_FLD_DEPOSIT_SPEC_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEPOSIT_AMOUNT, deposit_in_flistp, PIN_FLD_DEPOSIT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, deposit_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_SET(deposit_in_flistp, PIN_FLD_PAYMENT_FLAGS, &payment_flag, ebufp);

	payment_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_PAYMENT, PIN_ELEMID_ANY, 1, ebufp);
	if(payment_flistp)
	{
		payment_sub_iflistp = PIN_FLIST_SUBSTR_ADD(deposit_in_flistp, PIN_FLD_PAYMENT, ebufp);
		PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_AMOUNT, payment_sub_iflistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_RECEIPT_NO, payment_sub_iflistp, PIN_FLD_RECEIPT_NO, ebufp);
		PIN_FLIST_FLD_SET(payment_sub_iflistp, PIN_FLD_PAY_TYPE, (void *)&pay_type, ebufp);
	}

	sub_flistp = PIN_FLIST_SUBSTR_ADD(deposit_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, sub_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, sub_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /purchased_deposit -1 0
	 * 0 PIN_FLD_PROGRAM_NAME STR [0] "221221_001022|POS"
	 * 0 PIN_FLD_ACCOUNT_OBJ POID [0] 0.0.0.1 /account 4200128 0
	 * 0 PIN_FLD_SERVICE_OBJ    POID [0] 0.0.0.1 /service/telco/gsm 4200480 7
	 * 0 PIN_FLD_DEPOSIT_SPEC_OBJ    POID [0] 0.0.0.1 /deposit_specification 4191258 7
	 * 0 PIN_FLD_DEPOSIT_AMOUNT               DECIMAL [0] 1000.0
	 * 0 PIN_FLD_PAYMENT           SUBSTRUCT [0]
	 * 1     PIN_FLD_AMOUNT DECIMAL [0] 1000.0
	 * 1     PIN_FLD_RECEIPT_NO	STR [0] "Trans_pay_001"
	 * 1     PIN_FLD_PAY_TYPE       ENUM [0] 10011
	 * 0 PIN_FLD_PAYMENT_FLAGS INT [0] 0
	 * 0 PIN_FLD_CONTEXT_INFO      SUBSTR [0] allocated 20, used 3
	 * 1     PIN_FLD_CORRELATION_ID         STR [0] "corr_id"
	 * 1     PIN_FLD_EXTERNAL_USER          STR [0] "extern_user"
	 * */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit_create:"
		" DEPOSIT_PURCHASE_DEPOSIT input flist ", deposit_in_flistp);

	PCM_OP(ctxp, PCM_OP_DEPOSIT_PURCHASE_DEPOSIT, 0, deposit_in_flistp, &deposit_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_create:"
			" input flist ", deposit_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_create:"
				" Error in purchase deposit: ", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit_create:"
		" DEPOSIT_PURCHASE_DEPOSIT output flist ", deposit_out_flistp);

	/* Read the purchased_deposit to retreive events poid */
	pur_deposit_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(deposit_out_flistp, PIN_FLD_POID, pur_deposit_in_flistp, PIN_FLD_POID, ebufp);
	deposit_evt_flistp = PIN_FLIST_ELEM_ADD(pur_deposit_in_flistp, PIN_FLD_EVENTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(deposit_evt_flistp, PIN_FLD_EVENT_OBJ, NULL, ebufp);

	/* Sample Input Flist *
	 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /purchased_deposit 4204605 0
	 * 0 PIN_FLD_EVENTS    ARRAY [*] allocated 20, used 1
	 * 1     PIN_FLD_EVENT_OBJ      POID [0] NULL
	 * */
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_deposit_create: PURCHASE_DEPOSIT Read Input", pur_deposit_in_flistp);

	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, pur_deposit_in_flistp, &pur_deposit_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_DM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_DEPOSIT, PIN_FLD_POID, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit_create: PURCHASE_DEPOSIT Read Input", pur_deposit_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_deposit_create: PURCHASE_DEPOSIT Read error", ebufp);
		status = PIN_BOOLEAN_FALSE;
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_deposit_create:"
			" PURCHASE_DEPOSIT Read Output", pur_deposit_out_flistp);

		deposit_elemid = 0;
		deposit_cookie = NULL;
		while ((temp_evt_flistp = PIN_FLIST_ELEM_GET_NEXT(pur_deposit_out_flistp,
			PIN_FLD_EVENTS, &deposit_elemid, 1, &deposit_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_ar_make_deposit_create: temp_evt_flistp flist", temp_evt_flistp);
			PIN_FLIST_ELEM_COPY(pur_deposit_out_flistp, PIN_FLD_EVENTS, deposit_elemid, 
                        	in_flistp, PIN_FLD_EVENTS, deposit_elemid, ebufp);
			match_found = 1;
			break;
		}
		if(match_found == 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_DM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_MAKE_DEPOSIT, PIN_FLD_POID, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_deposit_create: PURCHASE_DEPOSIT Input", pur_deposit_in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_deposit_create: PURCHASE_DEPOSIT match not found", ebufp);
			status = PIN_BOOLEAN_FALSE;
			goto cleanup;
		}

		/*******************************************************************
		 *Event update function call
		 *******************************************************************/
		fm_tab_ar_make_deposit_update_evt(ctxp, in_flistp, &update_evt_oflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt:"
				" in_flistp", in_flistp);
			status = PIN_BOOLEAN_FALSE;
			goto cleanup;
		}

	}
	/*******************************************************************
	 *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&pur_deposit_in_flistp, NULL);
        PIN_FLIST_DESTROY_EX(&pur_deposit_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_evt_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&deposit_in_flistp, NULL);
	*ret_flistpp = deposit_out_flistp;
	return status;
}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_MAKE_DEPOSIT for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_notify_make_deposit_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*payment_in_flistp = NULL;
	time_t			currenttime_tmst = 0;
        char			*effective_strp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_make_deposit_prepare_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_make_deposit_prepare_notification: "
			"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp =PIN_FLIST_COPY(*r_flistpp, ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);
		
	// Create Notification Flists
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_DEPOSIT, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DEPOSIT_AMOUNT, notify_flistp, PIN_FLD_DEPOSIT_AMOUNT, ebufp);

	currenttime_tmst = pin_virtual_time(NULL);
        effective_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, &currenttime_tmst,ebufp);
        PIN_FLIST_FLD_SET(notify_flistp, TAB_FLD_EVENT_DATE, effective_strp, ebufp);
	free(effective_strp);

	payment_in_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_PAYMENT, PIN_ELEMID_ANY, 1, ebufp);
	if(payment_in_flistp)
	{
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_RECEIPT_NO, notify_flistp, PIN_FLD_RECEIPT_NO, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_CHANNEL_ID_STR, notify_flistp, TAB_FLD_CHANNEL_ID_STR, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_PAY_T_STR, notify_flistp, TAB_FLD_PAY_T_STR, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_BRANCH_NO, notify_flistp, PIN_FLD_BRANCH_NO, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_DEALER_CODE, notify_flistp, PIN_FLD_DEALER_CODE, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_DEALER_NAME, notify_flistp, PIN_FLD_DEALER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_PAY_MODE, notify_flistp, TAB_FLD_PAY_MODE, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_BANK_CODE, notify_flistp, PIN_FLD_BANK_CODE, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_BANK_ACCOUNT, notify_flistp, PIN_FLD_BANK_ACCOUNT, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_CARD_NUM, notify_flistp, TAB_FLD_CARD_NUM, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_CARD_TYPE, notify_flistp, TAB_FLD_CARD_TYPE, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_CHECK_NO, notify_flistp, PIN_FLD_CHECK_NO, ebufp);
		PIN_FLIST_FLD_COPY(payment_in_flistp, TAB_FLD_CHECK_ISSUE_T_STR, notify_flistp, TAB_FLD_CHECK_ISSUE_T_STR, ebufp);
	}

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_make_deposit_prepare_notification:"
		" pol input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MAKE_DEPOSIT, 0,
		notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_make_deposit_prepare_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_make_deposit_prepare_notification:"
			" Error in Notification", ebufp);
		goto cleanup;
	}

	if (enrich_notify_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_make_deposit_prepare_notification:"
		" pol output flist ", enrich_notify_flistp);

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	
	return;
}

/*******************************************************************
 * We use this function to update payment event to capture all the
 * input related details
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @return flistp.
 * @param ebufp The error buffer.
 *******************************************************************/
static void
fm_tab_ar_make_deposit_update_evt(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*result_payment_flistp = NULL;
	pin_flist_t		*update_event_input_flistp = NULL;
	pin_flist_t		*update_event_output_flistp = NULL;
	pin_flist_t		*payment_flistp = NULL;
	pin_flist_t		*payment_in_flistp = NULL;
	pin_flist_t		*pymt_flistp = NULL;
	char				*channel_id_str = NULL;
	char            	*pay_t_str = NULL;
	char            	*branch_no = NULL;
	char            	*dealer_code = NULL;
	char            	*dealer_name = NULL;
	char            	*ext_trans_id = NULL;
	char            	*pay_mode = NULL;
	char            	*bank_code = NULL;
	char            	*bank_account = NULL;
	char            	*card_num = NULL;
	char            	*card_type = NULL;
	char            	*card_expiration = NULL;
	char            	*check_no = NULL;
	char            	*check_issue_str = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt:"
			" in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_deposit_update_evt input flistp", in_flistp);

	result_payment_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_EVENTS,
		PIN_ELEMID_ANY, 1, ebufp);
	payment_in_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_PAYMENT, PIN_ELEMID_ANY, 1, ebufp);
	channel_id_str = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_CHANNEL_ID_STR, 1, ebufp);
	pay_t_str = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_PAY_T_STR, 1, ebufp);
	branch_no = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_BRANCH_NO, 1, ebufp);
	dealer_code = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_DEALER_CODE, 1, ebufp);
	dealer_name = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_DEALER_NAME, 1, ebufp);
	ext_trans_id = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_EXTERN_TRANS_ID, 1, ebufp);
	pay_mode = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_PAY_MODE, 1, ebufp);
	bank_code = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_BANK_CODE, 1, ebufp);
	bank_account = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_BANK_ACCOUNT, 1, ebufp);
	card_num = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_CARD_NUM, 1, ebufp);
	card_type = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_CARD_TYPE, 1, ebufp);
	card_expiration = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_CARD_EXPIRATION, 1, ebufp);
	check_no = PIN_FLIST_FLD_GET(payment_in_flistp, PIN_FLD_CHECK_NO, 1, ebufp);
	check_issue_str = PIN_FLIST_FLD_GET(payment_in_flistp, TAB_FLD_CHECK_ISSUE_T_STR, 1, ebufp);

	update_event_input_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(result_payment_flistp, PIN_FLD_EVENT_OBJ, update_event_input_flistp, PIN_FLD_POID, ebufp);

	if(payment_in_flistp && ((channel_id_str != NULL && strlen(channel_id_str) != 0) || 
	    (pay_t_str != NULL && strlen(pay_t_str) != 0) || (branch_no != NULL && strlen(branch_no) != 0) ||
		(dealer_code != NULL && strlen(dealer_code) != 0) || (dealer_name != NULL && strlen(dealer_name) != 0) ||
		   (ext_trans_id != NULL && strlen(ext_trans_id) != 0) || (pay_mode != NULL && strlen(pay_mode) != 0) || 
		     (bank_code != NULL && strlen(bank_code) != 0) || (bank_account != NULL && strlen(bank_account) != 0) ||
		       (card_num != NULL && strlen(card_num) != 0) || (card_type != NULL && strlen(card_type) != 0) ||
		        (card_expiration != NULL && strlen(card_expiration) != 0) || (check_no != NULL && strlen(check_no) != 0) ||
		        	(check_issue_str != NULL && strlen(check_issue_str) != 0)))
	{
		payment_flistp = PIN_FLIST_ELEM_ADD(update_event_input_flistp, TAB_FLD_PAYMENT_INFO, 0, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CHANNEL_ID_STR,channel_id_str, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_PAY_T_STR,pay_t_str, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_BRANCH_NO,branch_no, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_DEALER_CODE,dealer_code, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_DEALER_NAME,dealer_name, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_EXTERN_TRANS_ID,ext_trans_id, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_PAY_MODE,pay_mode, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_BANK_CODE,bank_code, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_BANK_ACCOUNT,bank_account, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CARD_NUM,card_num, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CARD_TYPE,card_type, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CARD_EXPIRATION,card_expiration, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_CHECK_NO,check_no, ebufp);
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CHECK_ISSUE_T_STR, check_issue_str,ebufp);
	}

	// To Update trans_id with receipt_no. Redundant code can be removed after MP7
	pymt_flistp = PIN_FLIST_SUBSTR_ADD(update_event_input_flistp, PIN_FLD_PAYMENT, ebufp);
	PIN_FLIST_FLD_COPY(payment_in_flistp, PIN_FLD_RECEIPT_NO, pymt_flistp, PIN_FLD_TRANS_ID, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit_update_evt: "
		"Input Flist", update_event_input_flistp);

	PCM_OP( ctxp, PCM_OP_WRITE_FLDS, 32, update_event_input_flistp, &update_event_output_flistp, ebufp );

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_deposit_update_evt:"
			" in_flistp", update_event_input_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_deposit_update_evt: "
		"output Flist", update_event_output_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&update_event_input_flistp, NULL);
	*out_flistpp = update_event_output_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_deposit_update_evt output flist", *out_flistpp);
	return;
}
