/*******************************************************************************
 *
 *	 This material is the confidential property of Telenor/Oracle Corporation or its
 *	 licensors and may be used, reproduced, stored or transmitted only in
 *	 accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 7-March-2022		| Akshay Gund		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_SETTLEMENT operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "pin_bill.h"
#include "pin_pymt.h"
#include "ops/ar.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_ar_make_settlement(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_make_settlement(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_make_settlement_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_AR_MAKE_SETTLEMENT operation.
 *************************************************************************/
void
op_tab_ar_make_settlement(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp=connp->dm_ctx;
	pin_flist_t		*r_flistp=NULL;
	poid_t			*account_pdp=NULL;
	int32			status=PIN_BOOLEAN_TRUE;
	int32			tab_order_flag=0;
	int32			error_clear_flag=1;
	int32			cerror_code=0;
	char			log_msg[512]="";
	int64			db_no=0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_settlement function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_SETTLEMENT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_settlement bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_settlement input flist", in_flistp);


	/*******************************************************************
	 * Prepare output flist 
	 *******************************************************************/

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, r_flistp, PIN_FLD_BILL_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp,PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, r_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_DISPUTE_REF_ID, r_flistp, TAB_FLD_DISPUTE_REF_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 *in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_SETTLEMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_SETTLEMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_SETTLEMENT, ebufp);
		}
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* call main function */
		fm_tab_ar_make_settlement(ctxp, in_flistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_settlement error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_settlement:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_settlement: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_MAKE_SETTLEMENT", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_settlement:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_SETTLEMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_SETTLEMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_SETTLEMENT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_settlement output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to make settlement
 * for given account or bill.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_ar_make_settlement(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_flistp=NULL;
	pin_flist_t		*args_flistp=NULL;
	pin_flist_t		*search_iflistp=NULL;
	pin_flist_t		*settlement_results_flistp=NULL;
	pin_flist_t		*settlement_wflds_oflistp=NULL;
	pin_flist_t		*notify_oflistp=NULL;
	pin_flist_t		*settlement_wflds_iflistp=NULL;
	pin_flist_t		*settlements_info_flistp=NULL;
	pin_flist_t		*srch_res_flistp=NULL;
	pin_flist_t		*context_flistp=NULL;
	pin_flist_t		*bill_settle_oflistp=NULL;
	pin_flist_t		*post_bill_settle_iflistp=NULL;
	pin_flist_t             *post_bill_settle_oflistp=NULL;
    pin_flist_t             *bill_settle_iflistp=NULL;
	pin_flist_t		*results_flistp=NULL;
	pin_flist_t		*search_rflistp=NULL;
	poid_t			*bill_pdp=NULL;
	poid_t			*enrich_account_pdp=NULL;
	poid_t                  *srchp=NULL;
	poid_t                  *parent_pdp = NULL;
	char			*bill_nop=NULL;
	char			*msisdnp=NULL;
	char			*account_nop=NULL;
	pin_decimal_t		*amountp=NULL;
	int32			*resultp=NULL;
	char			*settlement_code=NULL;
	void			*vp=NULL;
	int32			s_flags=256;
	int32           error_code = 0;
	char			*corr_id=NULL;
	char			*extern_user=NULL;
	char			prog_name[255];
	char			*dispute_idescr=NULL;
	void			*dispute_descr=NULL;
	pin_decimal_t		*dispute_amt=pbo_decimal_from_str("0",ebufp);



	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_settlement function entry error", ebufp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_ar_make_settlement input flist", in_flistp);

	/*Check for mandatory fields*/
	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if((account_nop == NULL || strlen(account_nop) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				"account number/msisdn is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_settlement: input flist", in_flistp);
		goto cleanup;
	}

	/*Check for mandatory amount field*/	
	amountp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp);

	if((pbo_decimal_is_null(amountp, ebufp)) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_settlement:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			"Amount is missing in request", ebufp);
		goto cleanup;
	}

	bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);

	if(bill_nop == NULL || strlen(bill_nop) == 0) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILL_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_settlement:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			"Bill number is missing in request", ebufp);
		goto cleanup;
	}

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_REASON_DOMAIN_ID, 1, ebufp) == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_REASON_CODE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_settlement:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				"Reason domain id is missing in request", ebufp);
		goto cleanup;
	}

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_REASON_ID, 1, ebufp) == NULL)	
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_STRINGVER_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_settlement:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				"Reason id is missing in request", ebufp);
		goto cleanup;
	}

	settlement_code=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_TRANS_ID, 1, ebufp);
	if(settlement_code == NULL || strlen(settlement_code) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_settlement:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				"settlement code is missing in request", ebufp);
		goto cleanup;
	}


	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	if(( msisdnp != NULL && (strlen(msisdnp) !=0)) || (account_nop && (strlen(account_nop)!=0) ))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_flistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_settlement:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_flistp);

		enrich_account_pdp=PIN_FLIST_FLD_GET(enrich_flistp,PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	}

	/* Create search template to get bill poid */
	search_iflistp = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	if ((bill_nop != NULL) && (strlen(bill_nop) != 0))
	{
		vp =  (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3 ";
		PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	}
	if((bill_nop != NULL) && (!PIN_POID_IS_NULL(enrich_account_pdp)))
	{
		vp =  (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3 and F4 = V4 ";
		PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_COPY(enrich_flistp, PIN_FLD_ACCOUNT_OBJ,args_flistp,PIN_FLD_ACCOUNT_OBJ, ebufp);
	}
	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILL_NO,args_flistp,PIN_FLD_BILL_NO,ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,dispute_amt,ebufp);

	parent_pdp =  PIN_POID_FROM_STR("0.0.0.0  0 0", NULL, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, (void *)parent_pdp, ebufp);

	srch_res_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL, ebufp);

	/***************Perform the search*************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
		"Search input flist ", search_iflistp);

	PCM_OP (ctxp, PCM_OP_SEARCH, 0, search_iflistp, &search_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			" input flist ", search_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_BILL_DETAILS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			"No bill information is available for given input", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_settlement Search:"
			"return flist", search_rflistp);

	results_flistp=PIN_FLIST_ELEM_GET(search_rflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	if (results_flistp == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			" input flist ", search_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_DISPUTED_AMOUNT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
			"No bill with disputed amount found for given input", ebufp);
		goto cleanup;
	}

	bill_pdp = PIN_FLIST_FLD_GET(results_flistp,PIN_FLD_POID,1,ebufp);
	
	bill_settle_iflistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(bill_settle_iflistp,PIN_FLD_POID,bill_pdp,ebufp);   
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AMOUNT,bill_settle_iflistp,PIN_FLD_AMOUNT,ebufp);
	dispute_idescr=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_DESCR,1,ebufp);
	if(dispute_idescr != NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DESCR,bill_settle_iflistp,PIN_FLD_DESCR,ebufp);
	}
	else
	{
		dispute_descr=(void *)"Dispute description not provided in input";
		PIN_FLIST_FLD_SET(bill_settle_iflistp,PIN_FLD_DESCR,dispute_descr,ebufp);
	}

	corr_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);

	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(bill_settle_iflistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_REASON_DOMAIN_ID,bill_settle_iflistp,PIN_FLD_REASON_DOMAIN_ID,ebufp);;
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_REASON_ID,bill_settle_iflistp,PIN_FLD_REASON_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_FLAGS,bill_settle_iflistp,PIN_FLD_FLAGS,ebufp);

	context_flistp=PIN_FLIST_SUBSTR_ADD(bill_settle_iflistp,PIN_FLD_CONTEXT_INFO,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,context_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,context_flistp,PIN_FLD_EXTERNAL_USER,ebufp);

	//Call OOTB opcode
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_settlement: PCM_OP_AR_BILL_SETTLEMENT "
			"input flist ", bill_settle_iflistp);

	PCM_OP(ctxp, PCM_OP_AR_BILL_SETTLEMENT, 0, bill_settle_iflistp, &bill_settle_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_MAKE_SETTLEMENT, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				" input flist ", bill_settle_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				" Error in update customer", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_settlement: PCM_OP_AR_BILL_SETTLEMENT"
			" output flist ", bill_settle_oflistp);
        
	post_bill_settle_iflistp= PIN_FLIST_COPY(bill_settle_oflistp, ebufp);
        
	PCM_OP(ctxp, TAB_OP_AR_POL_POST_MAKE_SETTLEMENT, 0, post_bill_settle_iflistp, &post_bill_settle_oflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				" TAB_OP_AR_POL_POST_MAKE_SETTLEMENT input flist ", post_bill_settle_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				" Error in update customer", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp= PIN_FLIST_COPY(post_bill_settle_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (bill_settle_oflistp != NULL)
	{

		resultp= PIN_FLIST_FLD_GET(bill_settle_oflistp,PIN_FLD_RESULT,1,ebufp);
		if(resultp && *resultp == PIN_RESULT_FAIL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_MAKE_SETTLEMENT, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
					" input flist ", bill_settle_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
					" Error in update customer", ebufp);
			goto cleanup;
		}
		settlement_results_flistp=PIN_FLIST_ELEM_GET(bill_settle_oflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);

		settlement_wflds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(settlement_results_flistp, PIN_FLD_EVENT_OBJ, settlement_wflds_iflistp, PIN_FLD_POID, ebufp);

		settlements_info_flistp = PIN_FLIST_ELEM_ADD(settlement_wflds_iflistp,TAB_FLD_SETTLEMENTS, 0, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME,settlements_info_flistp, PIN_FLD_USER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_DISPUTE_REF_ID,settlements_info_flistp, TAB_FLD_DISPUTE_REF_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID,settlements_info_flistp, PIN_FLD_TRANS_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION,settlements_info_flistp, PIN_FLD_LOCATION, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CODE,settlements_info_flistp, PIN_FLD_CODE, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_ar_make_settlement: PCM_OP_WRITE_FLDS input flist", settlement_wflds_iflistp);
		PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 32, settlement_wflds_iflistp, &settlement_wflds_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
					" PCM_OP_WRITE_FLDS input flist ", settlement_wflds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS:"
					" Error while calling the opcode", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_settlement: "
					"PCM_OP_WRITE_FLDS output flist", settlement_wflds_oflistp);
		}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_settlement:"
			" fm_tab_ar_pol_make_settlement_notify input flist ", in_flistp);

	// Call function to enrich notification details
	fm_tab_ar_pol_make_settlement_notify(ctxp, in_flistp, db_no, bill_settle_oflistp,*out_flistpp, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		 pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_SETTLEMENT, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement:"
				" fm_tab_ar_pol_make_settlement_notify input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_settlement: "
				" fm_tab_ar_pol_make_settlement_notify error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_settlement:"
			" fm_tab_ar_pol_make_settlement_notify output flist ", notify_oflistp);

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&settlement_wflds_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&settlement_wflds_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&post_bill_settle_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&bill_settle_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&post_bill_settle_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&bill_settle_oflistp,NULL);
	PIN_FLIST_DESTROY_EX(&enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	pbo_decimal_destroy(&dispute_amt);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_settlement output flist", *out_flistpp);
	return;
}

/********************************************
 * We use this function to call notification opcode
 * It will create notification entry in Kafka queue.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void
fm_tab_ar_pol_make_settlement_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*make_settle_oflistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*res_data_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_settlement_notify error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_settlement_notify:"
				" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_make_settlement_notify: "
			"input flist", i_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	temp_flistp = PIN_FLIST_COPY(make_settle_oflistp, ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	if(opresp_flistpp != NULL)
	{
		res_data_flistp = PIN_FLIST_COPY(opresp_flistpp, ebufp);
		PIN_FLIST_ELEM_PUT(notify_out_flistp, res_data_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	else
	{
		PIN_FLIST_ELEM_SET(notify_out_flistp, NULL, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_SETTLEMENT, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_settlement_notify:"
			" TAB_OP_NOTIFY_POL_ENRICH_MAKE_SETTLEMENT input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MAKE_SETTLEMENT, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_settlement_notify:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_settlement_notify:"
				" Error in update invoice notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_settlement_notify:"
			" TAB_OP_NOTIFY_POL_ENRICH_MAKE_SETTLEMENT output flist ", enrich_notify_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 *******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_pol_make_settlement_notify output flist", *r_flistpp);
	return;
}

