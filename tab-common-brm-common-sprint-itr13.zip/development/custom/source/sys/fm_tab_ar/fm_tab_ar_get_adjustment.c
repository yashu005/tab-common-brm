/*************************************************************************************************
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 **************************************************************************************************/
/*************************************************************************************************
 *	Change History
 *		   
 * No | Date		| Programmer		| Req/bug/Gap		   | Change details
 *
 * 1  | 27/Jan/2022 	| Ruhi Bhatnagar	|			   | New opcode implementation to
 * 									     get adjustment.
 *************************************************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "ops/ar.h"
#include "pin_ar.h"
#include "pin_rate.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_ar_get_adjustment(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_adjustment(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_adjustment_transid (
	pcm_context_t    	*ctxp,
	int32            	flags,
	pin_flist_t      	*in_flistp,
	pin_flist_t      	**ret_flistpp,
	int64            	db_no,
	pin_errbuf_t     	*ebufp);


/****************************************************************
 *	*  *  *	 *External Routines Refered.
 ******************************************************************/
extern void
fm_tab_utils_common_get_event_adjustment_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 * 
 * New opcode TAB_OP_AR_GET_ADJUSTMENT is implemented to
 * get adjustment.
 *	  *
 *	@param connp The connection pointer.
 *	@param opcode This opcode.
 *	@param flags The opcode flags.
 *	@param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 *	@param ret_flistpp The output flist with account poid information.
 *	@param ebufp The error buffer.
 *	@return nothing.
 *	
 *	* Sample Input Flist
 *	0 PIN_FLD_POID		POID [0] 0.0.0.1 /account -1 0
 *	0 PIN_FLD_ACCOUNT_NO	STR [0] "CN-0999009"
 *	0 PIN_FLD_MSISDN		STR [0] "9532554008"
 *	0 PIN_FLD_RANGE_START	STR [0] "01-JAN-2022 00:00:51"
 *	0 PIN_FLD_RANGE_END		 STR [0] "01-FEB-2022 00:00:00"
 *	0 PIN_FLD_TRANS_ID	STR [0] "REF-123"
 *
 * */

void
op_tab_ar_get_adjustment (
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	char			log_msg[512]= "";
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int32			status = PIN_BOOLEAN_TRUE;
	int64			db_no= 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment error",ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *	*  *		 * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_AR_GET_ADJUSTMENT) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment BAD opcode error",ebufp);
		return;
	}
	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_ar_get_adjustment input flist", in_flistp);

	
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_db_no: "
			"Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* Common_input_validation */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_ar_get_adjustment(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_adjustment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_adjustment error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
			" Error while getting adjustment", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_ADJUSTMEMT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_ADJUSTMEMT, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_ADJUSTMEMT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_ADJUSTMEMT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_adjustment output flist", *ret_flistpp);
	return;
}

/**
 *	We use this function to get adjustment.
 *	Adjustment array return in output flist
 *	   *
 *	@param ctxp The context pointer.
 *	@param in_flistp in the input flist.
 *	@param ebufp The error buffer.
 *	@return flistp. 
 *	  
 *	*/

void
fm_tab_ar_get_adjustment (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*billinfo_details_iflistp = NULL;
	pin_flist_t		*billinfo_details_rflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*adjustment_details_rflistp = NULL;
	pin_flist_t		*get_adjustment_details_oflistp = NULL;
	pin_flist_t		*adjust_info_flistp = NULL;
	pin_flist_t		*event_misc_flistp = NULL;
	pin_flist_t		*adjustment_info_flistp = NULL;
	pin_flist_t		*bal_impact_flistp = NULL;
	pin_flist_t		*get_item_iflistp = NULL;
	pin_flist_t		*get_item_rflistp = NULL;
	pin_flist_t		*transfer_out_flistp = NULL;
	pin_flist_t		*invoice_flistp = NULL;
	pin_flist_t		*read_billinfo_fld_iflistp = NULL;
	pin_flist_t		*read_billinfo_fld_rflistp = NULL;
	pin_flist_t		*items_iflistp = NULL;
	pin_flist_t		*item_results_flistp = NULL;
	pin_flist_t		*read_billobj_fld_iflistp = NULL;
	pin_flist_t		*read_billobj_fld_rflistp = NULL;
	pin_flist_t		*results_billinfo_flistp = NULL;
	char			*msisdn = NULL;
	char			c_start_t[512] = "";
	char			c_end_t[512] = "";
	char			*account_no = NULL;
	char			*inp_start_date_str=NULL;
	char			*inp_end_date_str=NULL;
	char			*input_cycle_end_date_str=NULL;
	char			*inp_created_date_str = NULL;
	time_t			start_t = 0;
	time_t			end_t = 0;
	time_t			*created_t = NULL;
	time_t                  *cycle_end_t = NULL;
        time_t                  current_time = pin_virtual_time((time_t *)NULL);
	int32			elem_id = 0;
	int32			*impact_typep = NULL;
	int32			*pay_typep = NULL;
	pin_cookie_t		cookie = NULL;
	pin_flist_t             *transfer_out = NULL;
	char			*transid = NULL;
	pin_flist_t		*adjustment_res_flistp = NULL;
	pin_flist_t		*transid_srch_rflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_adjustment: "
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment "
			"function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment input flist", in_flistp);

	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	transid = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if ((account_no == NULL || strlen(account_no) == 0) && 
		( msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:" 
			"Error PIN_FLD_ACCOUNT_NO/PIN_FLD_MSISDN - Input is missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment:"
			 "input flist", in_flistp);
		goto cleanup;
	}
	
	if(((transid != NULL) && (strlen(transid) != 0)))
	{
		fm_tab_ar_get_adjustment_transid(ctxp, flags, in_flistp, &transid_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
					"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
					"Error while doing search with TransId", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_adjustment_transid:"
				"return flist",transid_srch_rflistp);
		adjustment_res_flistp = PIN_FLIST_ELEM_GET(transid_srch_rflistp,PIN_FLD_RESULTS,
				PIN_ELEMID_ANY,1,ebufp);
		if(adjustment_res_flistp == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_adjustment:"
					" input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_TRANSID, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
					"Invalid TransId passed in the request", ebufp);
			goto cleanup;
		}
		PIN_FLIST_FLD_COPY(adjustment_res_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, 
				PIN_FLD_ACCOUNT_OBJ, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_billinfo_details: "
				"input flist", in_flistp);
		/* Call fm_tab_utils_common_get_billinfo_details function */
		fm_tab_utils_common_get_billinfo_details(ctxp, in_flistp, &billinfo_details_rflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
					" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
					" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_billinfo_details:"
					" output flist", billinfo_details_rflistp);
		}
	}
	else if ((msisdn == NULL || strlen(msisdn) == 0) || (account_no == NULL || strlen(account_no) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_owner_billinfo_details:"
			" input flist", in_flistp);

		/* Call fm_tab_utils_common_get_owner_billinfo_details function */
		fm_tab_utils_common_get_owner_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_rflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" Error while getting owner billinfo details", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_owner_billinfo_details:"
				" output flist", billinfo_details_rflistp);	
		}
	}
	else if(((msisdn != NULL) && (strlen(msisdn) != 0)) && ((account_no != NULL) && (strlen(account_no) != 0)))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_billinfo_details: "
			"input flist", in_flistp);	
		/* Call fm_tab_utils_common_get_billinfo_details function */
		fm_tab_utils_common_get_billinfo_details(ctxp, in_flistp, &billinfo_details_rflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_billinfo_details:"
				" output flist", billinfo_details_rflistp);
		}
	}	


	/* Created Final return flist get_adjustment_details_oflistp */
	get_adjustment_details_oflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_adjustment_details_oflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, get_adjustment_details_oflistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, get_adjustment_details_oflistp, PIN_FLD_MSISDN, ebufp);	

	/* Check for pay type */
	if(billinfo_details_rflistp != NULL)
	{
		results_billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_rflistp, PIN_FLD_RESULTS, 
			PIN_ELEMID_ANY, 1, ebufp);
		if(results_billinfo_flistp != NULL)
		{
			pay_typep = PIN_FLIST_FLD_GET(results_billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
			if(pay_typep && (*pay_typep == PIN_PAY_TYPE_PREPAID))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE, 
					 TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Operation cannot be performed for "
					" the Prepaid Paytype", ebufp);
				goto cleanup;
			}
		}
	}

	/* Check for dates ranges for fm_tab_utils_common_get_event_adjustment_details input */
	if((inp_start_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_START, 1, ebufp))!=NULL)
	{
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_start_date_str, ebufp);
	}

	if((inp_end_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_END, 1, ebufp))!=NULL)
	{
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_end_date_str, ebufp);
	}

	if(start_t == 0 && end_t == 0)
	{
		end_t = current_time;
		start_t = end_t-ONEDAY*30;
	}

	else if(end_t == 0 && start_t != 0)
	{
		end_t = start_t+ONEDAY*30;
	}

	else if(start_t == 0 && end_t != 0)
	{
		start_t = end_t-ONEDAY*30;
	}
	else if (start_t != 0 && end_t != 0)
        {
                if (((end_t-start_t)<=ONEDAY*31))
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Validating Start and End Range within 30 days:"
                                "input flist", in_flistp);
                }
                else
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_adjustment:"
                                " input flist", in_flistp);
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_INCORRECT_DATE_RANGE, 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
                                "Start and End Date Range is greater than 30 days", ebufp);
                        goto cleanup;
                }
        }


	sprintf(c_start_t,"%ld",start_t);
	sprintf(c_end_t,"%ld",end_t);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, c_start_t);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, c_end_t);

	PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_VALID_FROM, &start_t, ebufp);
	PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_VALID_TO, &end_t, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_event_adjustment_details"
		" input flist:", in_flistp);

	/* Call fm_tab_utils_common_get_event_adjustment_details function */
	fm_tab_utils_common_get_event_adjustment_details(ctxp, flags, in_flistp, 
			&adjustment_details_rflistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details "
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_event_adjustment_details "
			" Error while getting event adjustment details", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_event_adjustment_details"
			" output flist", adjustment_details_rflistp);
	}
	
	if (adjustment_details_rflistp!=NULL &&
		!PIN_FLIST_ELEM_COUNT(adjustment_details_rflistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_ADJUSTMENT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment:"
			 "Error No Adjustment found for the given request", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment input flist", in_flistp);
		goto cleanup;
	}	
	
	/* Looping through fm_tab_utils_common_get_event_adjustment_details results array */
	elem_id = 0;
	cookie = NULL;
	while((results_flistp = PIN_FLIST_ELEM_GET_NEXT(adjustment_details_rflistp, PIN_FLD_RESULTS, 
					&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		adjust_info_flistp = PIN_FLIST_ELEM_GET(results_flistp, TAB_FLD_ADJUSTMENT_INFO,
                                PIN_ELEMID_ANY, 1, ebufp);
                if(adjust_info_flistp != NULL)
                {
		/* Adding PIN_FLD_ADJUSTMENT_INFO array to get_adjustment_details_oflistp */	
		adjustment_info_flistp = PIN_FLIST_ELEM_ADD(get_adjustment_details_oflistp, 
				TAB_FLD_ADJUSTMENT_INFO,elem_id, ebufp);
			if((created_t = PIN_FLIST_FLD_GET(results_flistp,PIN_FLD_CREATED_T, 1, ebufp))!=NULL)
			{
				inp_created_date_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp,created_t,ebufp);
				if(inp_created_date_str != NULL)
				{
					PIN_FLIST_FLD_PUT(adjustment_info_flistp, TAB_FLD_ADJUSTMENT_DATE, 
							inp_created_date_str, ebufp);
				}
			}
			PIN_FLIST_FLD_COPY(adjust_info_flistp, PIN_FLD_USER_NAME, adjustment_info_flistp, 
					PIN_FLD_USER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(adjust_info_flistp, PIN_FLD_LOCATION, adjustment_info_flistp,
					PIN_FLD_LOCATION, ebufp);
			PIN_FLIST_FLD_COPY(adjust_info_flistp, PIN_FLD_TRANS_ID, adjustment_info_flistp,
					PIN_FLD_TRANS_ID, ebufp);
			PIN_FLIST_FLD_COPY(adjust_info_flistp, PIN_FLD_GLACCOUNT, adjustment_info_flistp,
					PIN_FLD_GLACCOUNT, ebufp);

			PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_DESCR, adjustment_info_flistp, PIN_FLD_DESCR, ebufp);

			event_misc_flistp = PIN_FLIST_ELEM_GET(results_flistp, PIN_FLD_EVENT_MISC_DETAILS, 
					PIN_ELEMID_ANY, 1, ebufp);
			if(event_misc_flistp!= NULL)
			{
				PIN_FLIST_FLD_COPY(event_misc_flistp, PIN_FLD_REASON_DOMAIN_ID, adjustment_info_flistp,
						PIN_FLD_STR_VERSION , ebufp);
				PIN_FLIST_FLD_COPY(event_misc_flistp, PIN_FLD_REASON_ID, adjustment_info_flistp,
						PIN_FLD_STRING_ID, ebufp);
			}

			bal_impact_flistp = PIN_FLIST_ELEM_GET(results_flistp, PIN_FLD_BAL_IMPACTS, 
					PIN_ELEMID_ANY, 1, ebufp);
			if(bal_impact_flistp != NULL)
			{
				PIN_FLIST_FLD_COPY(bal_impact_flistp, PIN_FLD_GL_ID, adjustment_info_flistp, 
						PIN_FLD_GL_ID, ebufp);
				if((impact_typep = PIN_FLIST_FLD_GET(bal_impact_flistp, PIN_FLD_IMPACT_TYPE, 1, ebufp))!=NULL)
				{
					if(impact_typep && (*impact_typep == PIN_IMPACT_TYPE_PRERATED))
					{
						get_item_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(bal_impact_flistp, PIN_FLD_ITEM_OBJ, get_item_iflistp, 
								PIN_FLD_POID, ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_AR_GET_ITEM_DETAIL",
								get_item_iflistp);

						PCM_OP(ctxp,PCM_OP_AR_GET_ITEM_DETAIL,0,get_item_iflistp,&get_item_rflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_GET_ITEM_DETAIL:"
									" input flist ", get_item_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_GET_ITEM_DETAIL:"
									" Error while getting item details", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ITEM_DETAIL: "
									" return flist", get_item_rflistp);
						}				
					}

					if(impact_typep && (*impact_typep == PIN_IMPACT_TYPE_TAX))
					{
						PIN_FLIST_FLD_COPY(bal_impact_flistp, PIN_FLD_AMOUNT, 
								adjustment_info_flistp, PIN_FLD_AMOUNT_TAXED, ebufp); 
					}
				}
				item_results_flistp = PIN_FLIST_ELEM_GET(get_item_rflistp, PIN_FLD_RESULTS, 
						PIN_ELEMID_ANY, 1,ebufp);
				if(item_results_flistp != NULL)
				{
					PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_ITEM_TOTAL, adjustment_info_flistp, 
							PIN_FLD_AMOUNT, ebufp);
					PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_DUE, adjustment_info_flistp,
							PIN_FLD_DUE, ebufp);

					if((transid != NULL) && (transfer_out = PIN_FLIST_ELEM_GET(item_results_flistp,
									PIN_FLD_TRANSFERS_OUT,PIN_ELEMID_ANY, 1, ebufp)) !=NULL)
					{
						/* Adding PIN_FLD_TRANSFERS_OUT array to adjustment_info_flistp */
						transfer_out_flistp = PIN_FLIST_ELEM_ADD(adjustment_info_flistp,
								PIN_FLD_TRANSFERS_OUT, 0, ebufp);

						/* Adding PIN_FLD_INVOICES array to transfer_out_flistp */
						invoice_flistp = PIN_FLIST_ELEM_ADD(transfer_out_flistp,
								PIN_FLD_INVOICES, 0, ebufp);

						read_billinfo_fld_iflistp = PIN_FLIST_CREATE(ebufp);

						PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_BILLINFO_OBJ, 
								read_billinfo_fld_iflistp,PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_BILL_OBJ,
								read_billinfo_fld_iflistp,PIN_FLD_BILL_OBJ, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS: "
								" input flist", read_billinfo_fld_iflistp);

						/* Call for PCM_OP_READ_FLDS to read billinfo object */
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_billinfo_fld_iflistp, 
								&read_billinfo_fld_rflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
									" input flist ", read_billinfo_fld_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
									" Error while reading billinfo object", ebufp);
							goto cleanup;
						}

						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_FLDS: "
									" return flist", read_billinfo_fld_rflistp);
						}

						read_billobj_fld_iflistp = PIN_FLIST_CREATE(ebufp);

						PIN_FLIST_FLD_COPY(read_billinfo_fld_rflistp, PIN_FLD_BILL_OBJ, 
								read_billobj_fld_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(read_billobj_fld_iflistp, PIN_FLD_END_T, NULL, ebufp);
						PIN_FLIST_FLD_SET(read_billobj_fld_iflistp, PIN_FLD_BILL_NO, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS "
								" input flist", read_billobj_fld_iflistp);				
						/* Call for PCM_OP_READ_FLDS to read bill object */
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_billobj_fld_iflistp, 
								&read_billobj_fld_rflistp,ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
									" input flist ", read_billobj_fld_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
									" Error while reading bill object", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS return flist",
									read_billobj_fld_rflistp);
							PIN_FLIST_FLD_COPY(read_billobj_fld_rflistp, PIN_FLD_BILL_NO, 
									invoice_flistp, PIN_FLD_BILL_NO, ebufp);
							if((cycle_end_t = PIN_FLIST_FLD_GET(read_billobj_fld_rflistp, 
											PIN_FLD_END_T, 1, ebufp))!=NULL)
							{
								input_cycle_end_date_str = 
									fm_tab_utils_common_convert_timestamp_to_date
									(ctxp, cycle_end_t, ebufp);
								if(input_cycle_end_date_str != NULL)
								{
									PIN_FLIST_FLD_PUT(invoice_flistp,
											TAB_FLD_CYCLE_END_DATE, 
											input_cycle_end_date_str, ebufp);
								}
							}
						}

						/* Adding PIN_FLD_ITEMS array to invoice_flistp */
						items_iflistp = PIN_FLIST_ELEM_ADD(invoice_flistp, PIN_FLD_ITEMS, 0, ebufp);
						if(items_iflistp != NULL)
						{
							PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_NAME, items_iflistp, 
									PIN_FLD_ITEM_TYPE, ebufp);
							PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_DUE, items_iflistp, 
									PIN_FLD_DUE, ebufp);
							PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_ADJUSTED, 
									items_iflistp, PIN_FLD_ADJUSTED, ebufp);
							PIN_FLIST_FLD_COPY(item_results_flistp, PIN_FLD_ITEM_TOTAL, 
									items_iflistp, PIN_FLD_ITEM_TOTAL, ebufp);
						}
					}
				}
			}
		}
		PIN_FLIST_DESTROY_EX (&get_item_iflistp, NULL);
		PIN_FLIST_DESTROY_EX (&get_item_rflistp, NULL);
		PIN_FLIST_DESTROY_EX (&read_billinfo_fld_iflistp, NULL);
		PIN_FLIST_DESTROY_EX (&read_billinfo_fld_rflistp, NULL);
		PIN_FLIST_DESTROY_EX (&read_billobj_fld_iflistp, NULL);
		PIN_FLIST_DESTROY_EX (&read_billobj_fld_rflistp, NULL);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment return flist", 
			get_adjustment_details_oflistp);
	*ret_flistpp = get_adjustment_details_oflistp;

	cleanup:
	/******************************************************************
	 *		   * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&billinfo_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&billinfo_details_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&get_item_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&get_item_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&read_billinfo_fld_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&read_billinfo_fld_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&read_billobj_fld_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&read_billobj_fld_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&adjustment_details_rflistp, NULL);

	return;	
}

void
fm_tab_ar_get_adjustment_transid (
    pcm_context_t	*ctxp,
    int32            	flags,
    pin_flist_t        	*in_flistp,
    pin_flist_t        	**ret_flistpp,
    int64            	db_no,
    pin_errbuf_t        *ebufp)
{
    pin_flist_t        *transid_srch_iflistp = NULL;
    pin_flist_t        *transid_srch_rflistp = NULL;
    char            	*trans_id =NULL;
    poid_t            	*srchp  = NULL;
    int32            	s_flags = 256;
    void            	*vp = NULL;
    pin_flist_t        	*args_flistp = NULL;
    pin_flist_t        	*srch_res_flistp = NULL;
    pin_flist_t        	*adjustment_flistp=NULL;


    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment_transid:input flist",in_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_ar_get_adjustment_transid function entry error", ebufp);
        return;
    }

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_adjustment_transid:input flist",in_flistp);
    trans_id=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

    /*Sample Search Input Flist
    0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
    0 PIN_FLD_FLAGS           INT [0] 256
    0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/adjustment where F1 = V1"
    0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
    1       TAB_FLD_ADJUSTMENT_INFO  ARRAY [0] allocated 20, used 2
    2           PIN_FLD_TRANS_ID        STR [0] "T1,41,0"
    0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
    1 	PIN_FLD_USER_NAME   STR [0] NULL
    1 	PIN_FLD_LOCATION STR [0] NULL
    1 	PIN_FLD_TRANS_ID  STR [0] NULL
    1 	PIN_FLD_GLACCOUNT  STR [0] NULL
    1   PIN_FLD_POID           POID [0] NULL poid pointer
    1   PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/

    transid_srch_iflistp = PIN_FLIST_CREATE(ebufp);

    srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
    PIN_FLIST_FLD_PUT(transid_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
    PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

    vp =  (void *)"select X from /event/billing/adjustment where F1 = V1";
    PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

    args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
    adjustment_flistp = PIN_FLIST_ELEM_ADD(args_flistp, TAB_FLD_ADJUSTMENT_INFO,0, ebufp);
    PIN_FLIST_FLD_SET(adjustment_flistp, PIN_FLD_TRANS_ID , trans_id, ebufp);

    srch_res_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
    PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
    PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
    PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_USER_NAME, NULL, ebufp);
    PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_LOCATION, NULL, ebufp);
    PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_TRANS_ID, NULL, ebufp);

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment_transid Search:"
        "input flist", transid_srch_iflistp);
    /***************Perform the search*************************/
    PCM_OP (ctxp, PCM_OP_SEARCH, 0, transid_srch_iflistp, &transid_srch_rflistp, ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment_transid:"
            " input flist ", transid_srch_iflistp);
        pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_API_GET_ADJUSTMEMT, 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_adjustment_transid:"
            "Error while doing Search", ebufp);
        goto cleanup;
    }

    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_adjustment_transid Search:"
        "return flist", transid_srch_rflistp);
    *ret_flistpp = transid_srch_rflistp;
    PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
    return;

cleanup:
    /******************************************************************
    *            * Clean up.
    ******************************************************************/
    PIN_FLIST_DESTROY_EX (&transid_srch_rflistp, NULL);
    PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
        "fm_tab_ar_get_adjustment_transid final flist", *ret_flistpp);
    return;
}

