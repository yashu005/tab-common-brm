/*************************************************************************************************
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 **************************************************************************************************/
/*************************************************************************************************
 *  Change History
 *         
 * No | Date        | Programmer                | Req/bug/Gap          | Change details
 *
 * 1  | 22/02/2022 |  Akshay Gund            |                       | New opcode implementation to
 *                                                                     |get ar payment reversal detials

 *************************************************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "ops/ar.h"
#include "pin_ar.h"
#include "pin_bill.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_ar_get_payment_reversal(
		cm_nap_connection_t	*connp,
		int			opcode,
		int			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_payment_reversal(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

/****************************************************************
 *  *  *  *  *External Routines Refered.
 ******************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
		pcm_context_t		*ctxp,
		pin_flist_t		*i_flistp,
		pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_validate_and_normalize_input(
		pcm_context_t		*ctxp,
		pin_flist_t		*in_flistp,
		pin_flist_t		**out_flistp,
		int64			db_no,
		pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_request_set_error(
		pcm_context_t		*ctxp,
		pin_flist_t		*i_flistp,
		int32			flag,
		int32			cerror_code,
		pin_flist_t		**err_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
		pcm_context_t		*ctxp,
		time_t			*input_time_t,
		pin_errbuf_t		*ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
		pcm_context_t		*ctxp,
		char			*str_timestamp,
		pin_errbuf_t		*ebufp);


extern void
fm_tab_utils_common_get_payment_reversal_details(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 * 
 * New opcode TAB_OP_AR_GET_PAYMENT_REVERSAL is implemented to
 * get payment reversal information
 *    *
 *  @param connp The connection pointer.
 *  @param opcode This opcode.
 *  @param flags The opcode flags.
 *  @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 *  @param ret_flistpp The output flist with account poid information.
 *  @param ebufp The error buffer.
 *  @return nothing.
 *  
 *
 * */

void
op_tab_ar_get_payment_reversal (
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp=connp->dm_ctx;
	pin_flist_t			*r_flistp=NULL;
	int32				status=PIN_BOOLEAN_TRUE;
	int32				error_clear_flag=1;
	int32				cerror_code=0;
	char				log_msg[512]="";
	int64				db_no=0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal error",ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *  *  *         * Insanity check.
	 ***********************************************************/
	if(opcode != TAB_OP_AR_GET_PAYMENT_REVERSAL) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal BAD opcode error",ebufp);
		return;
	}
	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_tab_ar_get_payment_reversal input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* call main function */
	fm_tab_ar_get_payment_reversal(ctxp, flags, in_flistp, &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_payment_reversal input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_payment_reversal error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
				" Error while getting Payment", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_PAYMENT_REVERSAL;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PAYMENT_REVERSAL, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_PAYMENT_REVERSAL)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PAYMENT_REVERSAL, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	
	*ret_flistpp=r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_payment_reversal output flist", *ret_flistpp);
	return;
}


/**
 * We use this function to get payment reversal information
 * on basis transaction id or MSISDN or ACCOUNT_NO.
 *     *
 *  @param ctxp The context pointer.
 *  @param in_flistp in the input flist.
 *  @param ebufp The error buffer.
 *  @return flistp. 
 *    
 *  */

void
fm_tab_ar_get_payment_reversal (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*search_inp_flistp=NULL;
	pin_flist_t		*enrich_iflistp=NULL;
	pin_flist_t		*search_rflistp=NULL;
	pin_flist_t		*reversal_flistp=NULL;
	pin_flist_t		*bal_impacts_flistp=NULL;
	pin_flist_t		*res_flistp=NULL;
	pin_flist_t		*reversal_res_flistp=NULL;
	pin_flist_t		*return_flistp=NULL;
	pin_flist_t		*event_read_obj_iflistp=NULL;
	pin_flist_t		*event_read_obj_rflistp=NULL;
	pin_flist_t		*event_reason_flistp=NULL;
	char			*trans_id=NULL;
	char			*account_no=NULL;
	char			*msisdn=NULL;
	char			log_msg[512]="";
	char			log_msg1[512]="";
	char			*inp_start_date_str=NULL;
	char			*inp_end_date_str=NULL;
	time_t			current_time=pin_virtual_time((time_t *)NULL);
	time_t			start_t=0;
	time_t			end_t=0;
	time_t			*created_date=NULL;
	char			*created_date_strp=NULL;
	pin_cookie_t		reversals_cookie=NULL;
	int32			reversals_elemid=0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment_reversal: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_reversal: input flist", in_flistp);

	/*Check for account number or MSISDN*/
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if((account_no == NULL || strlen(account_no ) == 0)
			&& (msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment_reversal:input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
				"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}
	search_inp_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_POID,search_inp_flistp,PIN_FLD_POID,ebufp);	

	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if(trans_id != NULL && strlen(trans_id) != 0)
	{

		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID,search_inp_flistp,PIN_FLD_TRANS_ID,ebufp);
	}
	else if((msisdn != NULL && strlen(msisdn) != 0) || ((account_no != NULL && strlen(account_no) != 0)))
	{
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"op_tab_ar_get_payment_reversal input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_reversal:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);


		/* Check for dates ranges from input */
		inp_start_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_START, 1, ebufp);

		if(inp_start_date_str!=NULL && strlen(inp_start_date_str)!=0)	
		{
			start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_start_date_str, ebufp);
		}

		inp_end_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_END, 1, ebufp);

		if(inp_end_date_str!=NULL && strlen(inp_end_date_str)!=0)
		{
			end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_end_date_str, ebufp);
		}

		if(start_t == 0 && end_t == 0)
		{
			end_t = current_time;
			start_t = end_t-ONEDAY*30;
		}

		else if(end_t == 0 && start_t != 0)
		{
			end_t = start_t+ONEDAY*30;
		}

		else if(start_t == 0 && end_t != 0)
		{
			start_t = end_t-ONEDAY*30;
		}

		if(!((end_t-start_t)<=ONEDAY*90))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment_reversal:"
					" input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INCORRECT_START_END_DATE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
					"Start and End Date Range is greater than 90 days", ebufp);
			goto cleanup;
		}

		sprintf(log_msg,"start_t %ld",start_t);
		sprintf(log_msg1,"current_time %ld",current_time);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg1);

		PIN_FLIST_FLD_COPY(enrich_iflistp,PIN_FLD_ACCOUNT_OBJ,search_inp_flistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_SET(search_inp_flistp, PIN_FLD_START_T, &start_t, ebufp);
		PIN_FLIST_FLD_SET(search_inp_flistp, PIN_FLD_END_T, &end_t, ebufp);

	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_payment_reversal_details"
			" input flist:", search_inp_flistp);

	fm_tab_utils_common_get_payment_reversal_details(ctxp,flags,search_inp_flistp,&search_rflistp,db_no,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_payment_reversal_details"
			" output flist:", search_rflistp);
			
	return_flistp=PIN_FLIST_CREATE(ebufp);

	if((res_flistp = PIN_FLIST_ELEM_GET_NEXT(search_rflistp, PIN_FLD_RESULTS,
					&reversals_elemid, 1, &reversals_cookie, ebufp)) == (pin_flist_t *)NULL)

	{
		if(trans_id != NULL && strlen(trans_id) != 0)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
					"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
					"Error,  No events associated with TransID", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_NO_EVENTS_FOR_TRANS_ID , 0, 0, 0);
			goto cleanup;
		}
		else if(((msisdn != NULL && strlen(msisdn)) != 0) ||(account_no != NULL && strlen(account_no) != 0))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
					"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
					"Error, No events associated with given MSISDN and date range", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_NO_EVENTS_FOR_INPUT, 0, 0, 0);
			goto cleanup;
		}
	}
	else
	{
		reversals_elemid=0;
		reversals_cookie=NULL;

		while((res_flistp= PIN_FLIST_ELEM_GET_NEXT(search_rflistp, PIN_FLD_RESULTS,
						&reversals_elemid, 1, &reversals_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			reversal_flistp=PIN_FLIST_ELEM_ADD(return_flistp, TAB_FLD_REVERSAL_INFO,reversals_elemid, ebufp);
			bal_impacts_flistp=PIN_FLIST_ELEM_GET(res_flistp,PIN_FLD_BAL_IMPACTS,PIN_ELEMID_ANY, 1, ebufp);
			reversal_res_flistp=PIN_FLIST_ELEM_GET(res_flistp,TAB_FLD_REVERSAL_INFO,PIN_ELEMID_ANY,1,ebufp);
			PIN_FLIST_FLD_COPY(reversal_res_flistp,PIN_FLD_PAYMENT_TRANS_ID,reversal_flistp,PIN_FLD_PAYMENT_TRANS_ID,ebufp);
			PIN_FLIST_FLD_COPY(reversal_res_flistp,PIN_FLD_TRANS_ID,reversal_flistp,PIN_FLD_TRANS_ID,ebufp);
			PIN_FLIST_FLD_COPY(reversal_res_flistp,PIN_FLD_USER_NAME,reversal_flistp,PIN_FLD_USER_NAME,ebufp);
			PIN_FLIST_FLD_COPY(reversal_res_flistp,PIN_FLD_LOCATION,reversal_flistp,PIN_FLD_LOCATION,ebufp);
			PIN_FLIST_FLD_COPY(res_flistp,PIN_FLD_DESCR,reversal_flistp,PIN_FLD_DESCR,ebufp);

			PIN_FLIST_FLD_COPY(bal_impacts_flistp,PIN_FLD_AMOUNT,reversal_flistp,PIN_FLD_AMOUNT,ebufp);
			created_date=PIN_FLIST_FLD_GET(res_flistp,PIN_FLD_CREATED_T,1,ebufp);
			if(created_date!= NULL)
			{
				created_date_strp= fm_tab_utils_common_convert_timestamp_to_date(ctxp,
						created_date, ebufp);
				PIN_FLIST_FLD_PUT(reversal_flistp, TAB_FLD_CREATED_T_STR,
						created_date_strp, ebufp);
			}
			event_read_obj_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID,event_read_obj_iflistp, PIN_FLD_POID, ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_reversal:"
					" READ_OBJ input flist:", event_read_obj_iflistp);
			PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, event_read_obj_iflistp, &event_read_obj_rflistp,ebufp);
			PIN_FLIST_DESTROY_EX(&event_read_obj_iflistp, NULL);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_reversal:"
					"READ_OBJ output flist", event_read_obj_rflistp);
			event_reason_flistp = PIN_FLIST_ELEM_GET(event_read_obj_rflistp,PIN_FLD_EVENT_MISC_DETAILS,
					PIN_ELEMID_ANY,1,ebufp);
			if(event_reason_flistp != NULL)
			{	
				PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_ID, reversal_flistp, PIN_FLD_REASON_ID, ebufp);
				PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_DOMAIN_ID, reversal_flistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);
			}
		}
	}

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
				"input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_reversal:"
				"Error, after calling fm_tab_utils_common_get_payment_reversal_details function ", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_PAYMENT_REVERSAL, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	*ret_flistpp=PIN_FLIST_COPY(return_flistp,ebufp);

cleanup:
/******************************************************************
*          * Clean up.
******************************************************************/
	PIN_FLIST_DESTROY_EX (&return_flistp,NULL);
	PIN_FLIST_DESTROY_EX (&res_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_rflistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_inp_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&event_read_obj_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_reversal output flist ",*ret_flistpp);
	return;
}
