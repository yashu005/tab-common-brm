/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date        | Programmer      	| Req/bug/Gap  	 	| Change details
 *
 * 1  | 07/Apr/2022 | Rajashekar    |       	                | New opcode implementation
 *                                                      	| to get the deposit.
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_GET_DEPOSIT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "pin_inv.h"
#include "ops/deposit.h"

EXPORT_OP void
op_tab_ar_get_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_get_deposit(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_prepare_output_resp(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/****************************************************************
  External Routines Refered.
 *****************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_depositspec_name(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_purchased_deposit_pd(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);
/**
 * New opcode TAB_OP_AR_GET_DEPOSIT is implemented to
 * get deposit details from accountno/msisdn.

 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO/PIN_FLD_MSISDN.
 * @param ret_flistpp The output flist with account information.
 * @param ebufp The error buffer.
 * @return nothing.
 *	
 * Sample Input Flist
 * 0 PIN_FLD_POID               POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO		STR [0] "Account123"
 * 0 PIN_FLD_MSISDN		STR [0] "665473645390"
 * 0 PIN_FLD_NAME		STR [0] "Roam_Deposit"
 * 0 PIN_FLD_CORRELATION_ID     STR [0] "221221_001022"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "POS"	
 **/

void
op_tab_ar_get_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int64			db_no=0;
	int32			cerror_code=0;
	int32			error_clear_flag=1;
	char			log_msg[512]="";
	int32			status=PIN_BOOLEAN_TRUE;
	char			*account_no = NULL;
	char			*msisdn =  NULL;
	pin_flist_t		*enrich_iflistp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_deposit:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_deposit:function entry error",ebufp);
		return;
	}
	*ret_flistpp=NULL;

	/*******************************************************************
		Insanity check.
	 *******************************************************************/

	if(opcode!=TAB_OP_AR_GET_DEPOSIT)	
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_deposit bad opcode error",ebufp);
		return;
	}

	/*******************************************************************
	  Check for the input flist details
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_deposit: input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp,in_flistp,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit: input flist ", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_get_db_no:"
			"Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp,in_flistp,error_clear_flag,cerror_code, 
			&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*******************************************************************
	  Call main function
	 *******************************************************************/
	account_no = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1,ebufp);

	if((account_no == NULL || strlen(account_no) == 0) && ( msisdn == NULL || strlen(msisdn) == 0))	
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_deposit input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_deposit:Error AccountNumber/MSISDN is missing", ebufp);
		goto cleanup;	
	}
	else
	{
		/* Common_input_validation */
		fm_tab_utils_common_validate_and_normalize_input(ctxp,in_flistp,&enrich_iflistp,db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_deposit input flist",in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_deposit:"
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_ar_get_deposit:"
			"fm_tab_utils_common_validate_and_normalize_input output flist",enrich_iflistp);     
		/* call main function */
		fm_tab_ar_get_deposit(ctxp,enrich_iflistp,&r_flistp,db_no,ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_ar_get_deposit:return flist",r_flistp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit error",ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:in_flistp",in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}

cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:" 
			"Error while getting deposits", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_CUSTOM_API_GET_DEPOSIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code,&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_CUSTOM_API_GET_DEPOSIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,
				TAB_ERR_DESCR_API_GET_DEPOSIT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;

		/******************************************************************
		  Prepare Return Flist
		******************************************************************/

		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_deposit: output flist", r_flistp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_deposit: output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get deposit information.
 * *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
**/
static void
fm_tab_ar_get_deposit(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*dep_spec_name = NULL;
	pin_flist_t		*get_deposit_specpdp_r_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	poid_t			*dep_spec_pd = NULL;
	pin_flist_t		*acct_obj = NULL;
	poid_t			*search_pdp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*result_flistp = NULL;
	poid_t			*dep_spec_acctpd_pd = NULL;
	pin_flist_t		*dep_get_dep_iflistp = NULL;
	pin_flist_t		*dep_get_dep_rflistp = NULL;
	pin_flist_t		*final_results_flistp = NULL;
	int32			elem_id=0;
	pin_cookie_t		cookie = NULL;
	pin_flist_t		*results_deposit_flistp = NULL;
	pin_flist_t		*deposits_flistp = NULL;
	pin_flist_t		*return_flistp=NULL;
	pin_flist_t		*output_resp_rflistp = NULL;
	pin_flist_t		*depspec_acctobj_flistp = NULL;
	char			log_msg[512]="";
	poid_t			*purchased_deposit_obj = NULL;
	char			*purchased_depo_poid_typep = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit function entry error", ebufp);
		return;
	}

	PIN_ERR_CLEAR_ERR(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_deposit input flist", in_flistp);
	
	/******************************************************************
	  Validate the input arguments
	*******************************************************************/

	dep_get_dep_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME,dep_get_dep_iflistp,PIN_FLD_PROGRAM_NAME,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_OBJ,dep_get_dep_iflistp,PIN_FLD_ACCOUNT_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_SERVICE_OBJ,dep_get_dep_iflistp,PIN_FLD_SERVICE_OBJ,ebufp);

	dep_spec_name = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_NAME, 1, ebufp);

	return_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if (dep_spec_name != NULL && strlen(dep_spec_name) != 0)
	{
		fm_tab_utils_common_get_depositspec_name(ctxp,in_flistp,&get_deposit_specpdp_r_flistp,db_no,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit_specpdp: "
				"input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DEPOSIT,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit_specpdp:"
				"Error while getting deposit specification obj: ", ebufp);
			goto cleanup;
		}

		if ( get_deposit_specpdp_r_flistp != NULL )
		{
			results_flistp = PIN_FLIST_ELEM_GET(get_deposit_specpdp_r_flistp, PIN_FLD_RESULTS,
				PIN_ELEMID_ANY, 1, ebufp);
			if (results_flistp == NULL)
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
					"fm_tab_ar_get_deposit input flist", in_flistp);
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_DEPOSITNAME, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:"
					"Error deposit specification name not found in BRM DB ", ebufp);
				return;
			}
			dep_spec_pd = PIN_FLIST_FLD_GET(results_flistp, PIN_FLD_POID, 1, ebufp);
			acct_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			depspec_acctobj_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(depspec_acctobj_flistp,PIN_FLD_POID,dep_spec_pd,ebufp);
			PIN_FLIST_FLD_SET(depspec_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

			fm_tab_utils_common_get_purchased_deposit_pd(ctxp,depspec_acctobj_flistp,&res_flistp,
				db_no,ebufp);
			result_flistp = PIN_FLIST_ELEM_GET(res_flistp, PIN_FLD_RESULTS,
    				PIN_ELEMID_ANY, 1, ebufp);

			if (result_flistp != NULL)
			{
				dep_spec_acctpd_pd = PIN_FLIST_FLD_GET(result_flistp,PIN_FLD_POID,1,ebufp);
				PIN_FLIST_FLD_SET(dep_get_dep_iflistp,PIN_FLD_POID,dep_spec_acctpd_pd,ebufp);
			}

		}
	}
	else
	{
		/*PCM_OP_DEPOSIT_GET_DEPOSITS*/
		search_pdp = PIN_POID_CREATE(db_no,"/purchased_deposit",-1,ebufp);
		PIN_FLIST_FLD_PUT(dep_get_dep_iflistp,PIN_FLD_POID,(void *)search_pdp,ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_DEPOSIT_GET_DEPOSITS input flist",dep_get_dep_iflistp);

	PCM_OP(ctxp,PCM_OP_DEPOSIT_GET_DEPOSITS,0,dep_get_dep_iflistp,&dep_get_dep_rflistp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_DEPOSIT_GET_DEPOSITS output flist",dep_get_dep_rflistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit: "
			"input flist", dep_get_dep_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_DEPOSIT,0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:"
			"Error while getting get deposits details:", ebufp);
		goto cleanup;
	}
	/* Framing final output flist*/
	results_deposit_flistp = PIN_FLIST_ELEM_GET(dep_get_dep_rflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);

	if( results_deposit_flistp != NULL )
	{
		elem_id=0;
		cookie=NULL;
		while((final_results_flistp = PIN_FLIST_ELEM_GET_NEXT(dep_get_dep_rflistp,PIN_FLD_RESULTS,
			&elem_id,1,&cookie,ebufp)) != (pin_flist_t *)NULL)
		{
			deposits_flistp = PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_DEPOSITS,elem_id,ebufp);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "inside while");
			fm_tab_ar_prepare_output_resp(ctxp,final_results_flistp,
				&output_resp_rflistp,db_no,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_prepare_output_resp's output",
				output_resp_rflistp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_NAME,deposits_flistp,PIN_FLD_NAME,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,TAB_FLD_CREATED_T_STR,deposits_flistp,
				TAB_FLD_CREATED_T_STR,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_DEPOSIT_AMOUNT,deposits_flistp,
				PIN_FLD_DEPOSIT_AMOUNT,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_RECVD,deposits_flistp,PIN_FLD_RECVD,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_BALANCE_AMOUNT,deposits_flistp,
				PIN_FLD_BALANCE_AMOUNT,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,TAB_FLD_END_T_STR,deposits_flistp,
				TAB_FLD_END_T_STR,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_TRANS_ID,deposits_flistp,
				PIN_FLD_TRANS_ID,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_REASON_DOMAIN_ID,deposits_flistp,
				PIN_FLD_REASON_DOMAIN_ID,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_REASON_ID,deposits_flistp,
				PIN_FLD_REASON_ID,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_prepare_output_resp flist",return_flistp);
		}
	}
	else
	{
		purchased_deposit_obj = PIN_FLIST_FLD_GET(dep_get_dep_rflistp,PIN_FLD_POID,1,ebufp);
		purchased_depo_poid_typep = (char *)PIN_POID_GET_TYPE(purchased_deposit_obj);
		sprintf(log_msg,"purchased_depo_poid_typep%s",purchased_depo_poid_typep);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);
		if(purchased_deposit_obj != NULL && ((strcmp(purchased_depo_poid_typep,"/purchased_deposit") == 0 )))
		{
			deposits_flistp = PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_DEPOSITS,0,ebufp);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "inside else");
			fm_tab_ar_prepare_output_resp(ctxp,dep_get_dep_rflistp,
					&output_resp_rflistp,db_no,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_prepare_output_resp's output",
					output_resp_rflistp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_NAME,deposits_flistp,PIN_FLD_NAME,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,TAB_FLD_CREATED_T_STR,deposits_flistp,
					TAB_FLD_CREATED_T_STR,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_DEPOSIT_AMOUNT,deposits_flistp,
					PIN_FLD_DEPOSIT_AMOUNT,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_RECVD,deposits_flistp,PIN_FLD_RECVD,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_BALANCE_AMOUNT,deposits_flistp,
					PIN_FLD_BALANCE_AMOUNT,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,TAB_FLD_END_T_STR,deposits_flistp,
					TAB_FLD_END_T_STR,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_TRANS_ID,deposits_flistp,
					PIN_FLD_TRANS_ID,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_REASON_DOMAIN_ID,deposits_flistp,
					PIN_FLD_REASON_DOMAIN_ID,ebufp);
			PIN_FLIST_FLD_COPY(output_resp_rflistp,PIN_FLD_REASON_ID,deposits_flistp,
					PIN_FLD_REASON_ID,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_prepare_output_resp flist", return_flistp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_DEPOSIT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_deposit:"
				"No Desposits found for given AccountNo/MSISDN", ebufp);
			return;
		}
	}
	
cleanup:

        /******************************************************************
          Clean up.
         ******************************************************************/
	PIN_FLIST_DESTROY_EX(&dep_get_dep_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&dep_get_dep_rflistp,NULL);
	PIN_FLIST_DESTROY_EX(&get_deposit_specpdp_r_flistp,NULL);
	*ret_flistpp = return_flistp;
	return;
}

void
fm_tab_ar_prepare_output_resp(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*deposits_flistp = NULL;
	pin_flist_t		*ret_flistp=NULL;
	poid_t			*deposit_spec_obj = NULL;
	pin_flist_t		*read_flds_iflistp = NULL;
	pin_flist_t		*read_flds_rflistp = NULL;
	time_t			*created_t = NULL;
	char			*created_t_str = NULL;
	pin_decimal_t		*amount = NULL;
	pin_decimal_t		*rcvd = NULL;
	pin_decimal_t		*balance_amount = NULL;
	time_t			*val_end_t = NULL;
	pin_flist_t		*event_flistp = NULL;
	poid_t			*cash_obj = NULL;
	pin_flist_t		*read_cash_flds_iflistp = NULL;
	pin_flist_t		*read_cash_flds_rflistp = NULL;
	pin_flist_t		*event_reason_flistp = NULL;
	pin_flist_t		*transid_flistp = NULL;
	char			*trans_id = NULL;
	char			*poid_typep = NULL;
	char			log_msg[512]="";	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_prepare_output_resp error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_prepare_output_resp:"
			"input flist", i_flistp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_prepare_output_resp input", i_flistp);
	
	ret_flistp=PIN_FLIST_CREATE(ebufp);
	//deposits_flistp = PIN_FLIST_CREATE(ebufp);
	deposits_flistp = PIN_FLIST_ELEM_ADD(ret_flistp,PIN_FLD_DEPOSITS,0,ebufp);
	deposit_spec_obj = PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_DEPOSIT_SPEC_OBJ,1, ebufp);

	read_flds_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_SET(read_flds_iflistp,PIN_FLD_POID,deposit_spec_obj,ebufp);
	PIN_FLIST_FLD_SET(read_flds_iflistp,PIN_FLD_NAME,NULL,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS input flist",read_flds_iflistp);

	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_flds_iflistp, &read_flds_rflistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS output flist",read_flds_rflistp);

	if(read_flds_rflistp != NULL)
	{
		PIN_FLIST_FLD_COPY(read_flds_rflistp, PIN_FLD_NAME,deposits_flistp,PIN_FLD_NAME, ebufp);
	}

	created_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CREATED_T, 1, ebufp);
	if( created_t!= NULL)
	{
		created_t_str = (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,created_t,ebufp);
		PIN_FLIST_FLD_SET(deposits_flistp,TAB_FLD_CREATED_T_STR,created_t_str,ebufp);
	}
	amount = PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_DEPOSIT_AMOUNT, 1, ebufp);
	PIN_FLIST_FLD_SET(deposits_flistp,PIN_FLD_DEPOSIT_AMOUNT,amount,ebufp);

	rcvd = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_RECVD, 1, ebufp);
	PIN_FLIST_FLD_SET(deposits_flistp,PIN_FLD_RECVD,rcvd,ebufp);

	balance_amount = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_BALANCE_AMOUNT, 1, ebufp);
	PIN_FLIST_FLD_SET(deposits_flistp,PIN_FLD_BALANCE_AMOUNT,balance_amount,ebufp);

	val_end_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_VALIDITY_END_T , 1, ebufp);

	if(val_end_t != 0)
	{
		char *val_end_t_str= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,val_end_t,ebufp);
		PIN_FLIST_FLD_SET(deposits_flistp, TAB_FLD_END_T_STR, val_end_t_str, ebufp);
	}

	event_flistp = PIN_FLIST_ELEM_GET(i_flistp,PIN_FLD_EVENTS,PIN_ELEMID_ANY,1,ebufp);

	cash_obj = PIN_FLIST_FLD_GET(event_flistp,PIN_FLD_EVENT_OBJ,1,ebufp);
	poid_typep = (char *)PIN_POID_GET_TYPE(cash_obj);
	sprintf(log_msg,"raja%s",poid_typep);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);
	 
	if(cash_obj != NULL && ((strcmp(poid_typep,"/event/billing/payment/cash") == 0 )))
	{
		read_cash_flds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(read_cash_flds_iflistp,PIN_FLD_POID,cash_obj,ebufp);
		PIN_FLIST_FLD_SET(read_cash_flds_iflistp,PIN_FLD_TRANS_ID,NULL,ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS cash flds input flist",
				read_cash_flds_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, read_cash_flds_iflistp, &read_cash_flds_rflistp, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS cash flds o/p flist",
				read_cash_flds_rflistp);
		transid_flistp = PIN_FLIST_ELEM_GET(read_cash_flds_rflistp,
			PIN_FLD_PAYMENT,PIN_ELEMID_ANY, 1, ebufp);
		trans_id = PIN_FLIST_FLD_GET(transid_flistp,PIN_FLD_TRANS_ID,1,ebufp);
		if(trans_id != NULL)
		{
			PIN_FLIST_FLD_SET(deposits_flistp,PIN_FLD_TRANS_ID,trans_id,ebufp);
		}
		event_reason_flistp = PIN_FLIST_ELEM_GET(read_cash_flds_rflistp,
				PIN_FLD_EVENT_MISC_DETAILS,PIN_ELEMID_ANY, 1, ebufp);
		if(event_reason_flistp != NULL)
                {
			PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_ID, deposits_flistp, PIN_FLD_REASON_ID,ebufp);
			PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_DOMAIN_ID, deposits_flistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);
		}
	}
	else 
	{
		PIN_FLIST_FLD_SET(deposits_flistp,PIN_FLD_TRANS_ID,NULL,ebufp);
	}
	PIN_FLIST_DESTROY_EX(&read_flds_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_flds_rflistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_cash_flds_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&read_cash_flds_rflistp,NULL);
	*r_flistpp = deposits_flistp;
	return;
}
