/*******************************************************************************
 *
 *	 This material is the confidential property of Telenor/Oracle Corporation or its
 *	 licensors and may be used, reproduced, stored or transmitted only in
 *	 accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 18-FEB-2022		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_PAYMENT_REVERSAL operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_subscription.h"
#include "pin_bill.h"
#include "pin_pymt.h"
#include "pin_rate.h"
#include "ops/ar.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_ar_make_payment_reversal(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_make_payment_reversal(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_make_payment_reversal_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_execute_acc_adj(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_perform_pymt_reversal_wflds(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/*Extern Functions*/

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_evt_payment_details(
	pcm_context_t		*ctxp,
	char			*trans_id,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_AR_MAKE_PAYMENT_REVERSAL operation.
 *************************************************************************/
void
op_tab_ar_make_payment_reversal(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";
	poid_t			*account_pdp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_make_payment_reversal function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_PAYMENT_REVERSAL) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_payment_reversal bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_payment_reversal input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT_REVERSAL;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT_REVERSAL )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT_REVERSAL, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_payment_reversal(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_payment_reversal error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_payment_reversal:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_make_payment_reversal: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_AR_MAKE_PAYMENT_REVERSAL", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_payment_reversal:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT_REVERSAL;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT_REVERSAL )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT_REVERSAL, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_payment_reversal output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to purchase
 * product and discount offerings.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_ar_make_payment_reversal(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*validate_reversal_flds_oflistp = NULL;
	pin_flist_t		*evt_payment_oflistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*payment_results_flistp = NULL;
	pin_flist_t		*bill_reverse_iflistp = NULL;
	pin_flist_t		*bill_reverse_oflistp = NULL;
	pin_flist_t		*reversals_flistp = NULL;
	pin_flist_t		*reverse_results_flistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*bal_impacts_flistp = NULL;
	pin_flist_t		*payment_reversal_wflds_iflistp = NULL;
	pin_flist_t		*payment_reversal_wflds_oflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*post_pymt_reversal_oflistp = NULL;
	pin_flist_t		*payment_flistp = NULL;
	pin_flist_t		*payment_reversal_rdata_flistp = NULL;
	pin_flist_t 		*enrich_resp_flistp=NULL;
	pin_flist_t 		*enrich_not_out_flistp=NULL;
	int32			*resultp = NULL;
	int32			*impact_typep = NULL;
	int32			bal_impacts_elemid = 0;
	char			*payment_ref_idp = NULL;
	char			*reversal_trans_idp = NULL;
	pin_cookie_t		bal_impacts_cookie = NULL;
	poid_t			*notify_pdp = NULL;
	char			*acct_no = NULL;
	char			*msisdn = NULL;
	pin_errbuf_t		local_ebuf = {0};
    pin_errbuf_t    	*local_ebufp = &local_ebuf;
    pin_flist_t 		*r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_payment_reversal function entry error", ebufp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_ar_make_payment_reversal input flist", in_flistp);
			
	/*Check for mandatory trans id field*/	
	msisdn =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	acct_no =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	if((acct_no == NULL || strlen(acct_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
				"account number/msisdn is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_payment_reversal: input flist", in_flistp);
		goto cleanup;
	}

	/*Check for mandatory trans id field*/	
	payment_ref_idp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAYMENT_TRANS_ID, 1, ebufp);

	if(((payment_ref_idp && strlen(payment_ref_idp) == 0)) || 
			(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAYMENT_TRANS_ID, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PYMT_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
				"Payment Transaction ID is missing in request", ebufp);
		goto cleanup;
	}

	/*Check for mandatory trans id field*/	
	reversal_trans_idp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if(((reversal_trans_idp && strlen(reversal_trans_idp) == 0)) || 
			(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
				"Reversal Transaction ID is missing in request", ebufp);
		goto cleanup;
	}

	/*Policy hook for BU specific field validation*/	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL input flist ", in_flistp);

	PCM_OP(ctxp, TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL, 0, in_flistp, 
			&validate_reversal_flds_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				"TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				" Error in calling TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL", ebufp);
		*out_flistpp = PIN_FLIST_COPY(validate_reversal_flds_oflistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" TAB_OP_AR_POL_VALIDATE_MAKE_PAYMENT_REVERSAL output flist ", validate_reversal_flds_oflistp);

	/*Frame Input flist for Notification*/
	common_notification_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, 
			common_notification_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, 
			common_notification_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, 
			common_notification_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, 
			common_notification_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYMENT_TRANS_ID, 
			common_notification_flistp, PIN_FLD_PAYMENT_TRANS_ID, ebufp);

	/*Get Payment reversal object based on payment transaction id*/
	fm_tab_utils_common_get_evt_payment_details(ctxp, payment_ref_idp,
			&evt_payment_oflistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_evt_payment_details:"
				" Payment Trans ID");
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, payment_ref_idp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_evt_payment_details:"
				" Error while getting event payment object", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal: " 
				"fm_tab_utils_common_get_evt_payment_details output flist", evt_payment_oflistp);
	}

	if (!PIN_FLIST_ELEM_COUNT(evt_payment_oflistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_NO_PAYMENT_TRANSACTION_FOUND, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				"fm_tab_utils_common_get_evt_payment_details input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				" Error in calling fm_tab_utils_common_get_evt_payment_details", ebufp);
		goto cleanup;
	}


	/*Frame Input flist for PCM_OP_BILL_REVERSE*/
	bill_reverse_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
			bill_reverse_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
			bill_reverse_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, 
			bill_reverse_iflistp, PIN_FLD_DESCR, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STR_VERSION, 
			bill_reverse_iflistp, PIN_FLD_STR_VERSION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STRING_ID, 
			bill_reverse_iflistp, PIN_FLD_STRING_ID, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(bill_reverse_iflistp, 
			PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
			context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
			context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if (evt_payment_oflistp && (payment_results_flistp = PIN_FLIST_ELEM_GET(evt_payment_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		if (payment_results_flistp && (payment_flistp = PIN_FLIST_ELEM_GET(payment_results_flistp, 
						PIN_FLD_PAYMENT, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			reversals_flistp = PIN_FLIST_ELEM_ADD(bill_reverse_iflistp, 
					PIN_FLD_REVERSALS, 0, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYMENT_TRANS_ID, 
					reversals_flistp, PIN_FLD_PAYMENT_TRANS_ID, ebufp);
			PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_PAY_TYPE, 
					reversals_flistp, PIN_FLD_PAY_TYPE, ebufp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal: "
			"PCM_OP_BILL_REVERSE input flist", bill_reverse_iflistp);
	PCM_OP(ctxp, PCM_OP_BILL_REVERSE, 0, bill_reverse_iflistp, &bill_reverse_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
			" PCM_OP_BILL_REVERSE input flist ", bill_reverse_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_REVERSE:"
			" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal: " 
			"PCM_OP_BILL_REVERSE output flist", bill_reverse_oflistp);
	}

	if (bill_reverse_oflistp && (reverse_results_flistp = PIN_FLIST_ELEM_GET(bill_reverse_oflistp, 
		PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		if(payment_reversal_rdata_flistp == NULL)
		{
			payment_reversal_rdata_flistp = PIN_FLIST_CREATE(ebufp);
		}
		PIN_FLIST_ELEM_SET(payment_reversal_rdata_flistp, 
				bill_reverse_oflistp, PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);
				
		bal_impacts_elemid = 0;
		bal_impacts_cookie = NULL;
		while ((bal_impacts_flistp = PIN_FLIST_ELEM_GET_NEXT(reverse_results_flistp, PIN_FLD_BAL_IMPACTS,
						&bal_impacts_elemid, 1, &bal_impacts_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			impact_typep = PIN_FLIST_FLD_GET(bal_impacts_flistp, PIN_FLD_IMPACT_TYPE, 1, ebufp);

			if(impact_typep && (*impact_typep == PIN_IMPACT_TYPE_PRERATED))
			{
				PIN_FLIST_FLD_COPY(bal_impacts_flistp, PIN_FLD_AMOUNT, 
						common_notification_flistp, PIN_FLD_AMOUNT, ebufp);
			}
		}

		resultp = PIN_FLIST_FLD_GET(reverse_results_flistp, PIN_FLD_RESULT, 1, ebufp);

		if(resultp && *resultp == 1)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_MAKE_PAYMENT_REVERSAL, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
					" input flist ", bill_reverse_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
					" The payment has already been reversed.", ebufp);
			goto cleanup;
		}
		else
		{
			payment_reversal_wflds_iflistp = PIN_FLIST_COPY(reverse_results_flistp, ebufp);

			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, 
					payment_reversal_wflds_iflistp, PIN_FLD_USER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, 
					payment_reversal_wflds_iflistp, PIN_FLD_TRANS_ID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION, 
					payment_reversal_wflds_iflistp, PIN_FLD_LOCATION, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_GLACCOUNT, 
					payment_reversal_wflds_iflistp, PIN_FLD_GLACCOUNT, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, 
					payment_reversal_wflds_iflistp, PIN_FLD_DESCR, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYMENT_TRANS_ID, 
					payment_reversal_wflds_iflistp, PIN_FLD_PAYMENT_TRANS_ID, ebufp);

			fm_tab_ar_pol_perform_pymt_reversal_wflds(ctxp, payment_reversal_wflds_iflistp, 
					&payment_reversal_wflds_oflistp, db_no, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_INVALID_TRANSID, 0, 0, 0);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_pymt_reversal_wflds:"
						" input flist ", payment_reversal_wflds_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_pymt_reversal_wflds:"
						" Error while executing wflds on event payment reversal object", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal: "
						"fm_tab_ar_pol_perform_pymt_reversal_wflds output flist", payment_reversal_wflds_oflistp);
			}
		}
	}

	/*Policy hook for BU specific - Post payment reversal*/
	if (bill_reverse_oflistp && (reverse_results_flistp = PIN_FLIST_ELEM_GET(bill_reverse_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_FLIST_FLD_COPY(reverse_results_flistp, PIN_FLD_RESULTS, 
				in_flistp, PIN_FLD_RESULTS, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL input flist ", in_flistp);

	PCM_OP(ctxp, TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL, 0, in_flistp, 
			&post_pymt_reversal_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				"TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal:"
				" Error in calling TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL", ebufp);
		*out_flistpp = PIN_FLIST_COPY(post_pymt_reversal_oflistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" TAB_OP_AR_POL_POST_MAKE_PAYMENT_REVERSAL output flist ", post_pymt_reversal_oflistp);

	notify_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, in_flistp, PIN_FLD_IN_FLIST, ebufp);



	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_PAYMENT_REVERSAL, -1, ebufp);
	PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, common_notification_flistp, TAB_FLD_NOTIFICATION, ebufp);
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, r_flistp, PIN_FLD_AMOUNT, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp, PIN_FLD_TRANS_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	enrich_resp_flistp=PIN_FLIST_COPY(r_flistp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal : TAB_OP_AR_POL_ENRICH_RES_MAKE_PAYMENT_REV,: "
			"input Flist", enrich_resp_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_ENRICH_RES_MAKE_PAYMENT_REV,0, enrich_resp_flistp,out_flistpp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal : TAB_OP_AR_POL_ENRICH_RES_MAKE_PAYMENT_REV,: "
			"output Flist", *out_flistpp);
			
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" fm_tab_ar_make_payment_reversal_notification input flist ", notify_flistp);

	if(payment_reversal_rdata_flistp != NULL)
	{	
		enrich_not_out_flistp=PIN_FLIST_COPY(*out_flistpp,ebufp);
		PIN_FLIST_CONCAT(enrich_not_out_flistp,payment_reversal_rdata_flistp,ebufp);
		PIN_FLIST_SUBSTR_SET(notify_flistp,enrich_not_out_flistp, PIN_FLD_OUT_FLIST, ebufp);
	}

	// Call function to enrich notification details
	fm_tab_ar_make_payment_reversal_notification(ctxp, notify_flistp, db_no,out_flistpp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal:"
				" fm_tab_ar_make_payment_reversal_notification input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment_reversal: "
				" fm_tab_ar_make_payment_reversal_notification error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal:"
			" fm_tab_ar_make_payment_reversal_notification output flist", *out_flistpp);


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&evt_payment_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_reverse_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_reverse_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_reversal_wflds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_reversal_wflds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&validate_reversal_flds_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&post_pymt_reversal_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_resp_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_reversal_rdata_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_not_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_payment_reversal output flist", *out_flistpp);
	return;
}

/**
 * We use this function to generate
 * custom notification on make
 * payment reversal.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void
fm_tab_ar_make_payment_reversal_notification(
		pcm_context_t		*ctxp,
		pin_flist_t		*i_flistp,
		int64			db_no,
		pin_flist_t		**r_flistpp,
		pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_ar_make_payment_reversal_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_ar_make_payment_reversal_notification: input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment_reversal_notification: "
			"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_MAKE_PAYMENT_REVERSAL input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MAKE_PAYMENT_REVERSAL, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal_notification:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_make_payment_reversal_notification:"
				" Error in make payment reversal notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment_reversal_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_MAKE_PAYMENT_REVERSAL output flist ", enrich_notify_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	
	if (enrich_notify_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_payment_reversal_notification output flist", *r_flistpp);
	return;
}

/**
 * We use this function to perform
 * wlfds on event payment reversal 
 * object.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

	void
fm_tab_ar_pol_perform_pymt_reversal_wflds(
		pcm_context_t		*ctxp,
		pin_flist_t		*i_flistp,
		pin_flist_t		**r_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp)
{
	pin_flist_t		*pymt_reversal_wflds_iflistp = NULL;
	pin_flist_t		*pymt_reversal_wflds_oflistp = NULL;
	pin_flist_t		*payment_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_ar_pol_perform_pymt_reversal_wflds error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
				"fm_tab_ar_pol_perform_pymt_reversal_wflds: input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_pol_perform_pymt_reversal_wflds input", i_flistp);

	pymt_reversal_wflds_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, pymt_reversal_wflds_iflistp, 
			PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR, pymt_reversal_wflds_iflistp, 
			PIN_FLD_DESCR, ebufp);
	payment_flistp = PIN_FLIST_ELEM_ADD(pymt_reversal_wflds_iflistp, TAB_FLD_REVERSAL_INFO, 
			PIN_ELEMID_ASSIGN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, payment_flistp, 
			PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LOCATION, payment_flistp, 
			PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_GLACCOUNT, payment_flistp, 
			PIN_FLD_GLACCOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_USER_NAME, payment_flistp, 
			PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PAYMENT_TRANS_ID, payment_flistp, 
			PIN_FLD_PAYMENT_TRANS_ID, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_perform_pymt_reversal_wflds: "
			"PCM_OP_WRITE_FLDS input flist", pymt_reversal_wflds_iflistp);
	PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 32, pymt_reversal_wflds_iflistp, &pymt_reversal_wflds_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_perform_pymt_reversal_wflds:"
				" PCM_OP_WRITE_FLDS input flist ", pymt_reversal_wflds_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS:"
				" Error while calling the opcode", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_perform_pymt_reversal_wflds: "
				"PCM_OP_WRITE_FLDS output flist", pymt_reversal_wflds_oflistp);
	}

	*r_flistpp = pymt_reversal_wflds_oflistp;

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&pymt_reversal_wflds_iflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_pol_perform_pymt_reversal_wflds output flist", *r_flistpp);

	return;
}
