/*************************************************************************************************
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
**************************************************************************************************/
/*************************************************************************************************
 *  Change History
 *         
 * No | Date        | Programmer                | Req/bug/Gap          | Change details
 *
 * 1  | 27/Jan/2022 | Madhavi Dandi            |                       | New opcode implementation to
 *                                                                     |get ar payment detials
 
*************************************************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "ops/ar.h"
#include "pin_ar.h"
#include "pin_bill.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_ar_get_payment(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_payment(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_payment_transid(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_payment_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_ar_get_unallocated_payment_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_payment_event_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/****************************************************************
 *  *  *  *  *External Routines Refered.
 ******************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

/**
 * 
 * New opcode TAB_OP_AR_GET_PAYMENT is implemented to
 * get Payment
 *    *
 *  @param connp The connection pointer.
 *  @param opcode This opcode.
 *  @param flags The opcode flags.
 *  @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 *  @param ret_flistpp The output flist with account poid information.
 *  @param ebufp The error buffer.
 *  @return nothing.
 *  
 *  * Sample Input Flist
 *  0 PIN_FLD_POID             POID [0] 0.0.0.1 /account -1 0
 *  0 PIN_FLD_ACCOUNT_NO        STR [0] "CN-0999009"
 *  0 PIN_FLD_MSISN             STR [0] "91909990099"
 *  0 TAB_FLD_START_T_STR       STR [0] "01-Dec-21 00:00:00"
 *  0 TAB_FLD_END_T_STR         STR [0] "31-Dec-21 00:00:00"
 *  0 PIN_FLD_TRANS_ID          STR [0] “Pay9011”
 *  0 TAB_FLD_CHANNEL_ID_STR    STR [0] "1011"
 *  0 TAB_FLD_PAY_MODE          STR [0] "Cash"
 *  0 TAB_FLD_EXTERN_TRANS_ID   STR [0] "Pos_pay1101"
 *  0 TAB_FLD_FLAG_UNALLOC_PYMT INT [0] 0
 *  0 TAB_FLD_FLAG_ALLOC_DET    INT [0] 1
 *  0 PIN_FLD_CORRELATION_ID    STR [0] "er2345"
 *  0 PIN_FLD_EXTERNAL_USER     STR [0] "CRM"
 *
* */

void
op_tab_ar_get_payment (
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t			*r_flistp = NULL;
	int32				status = PIN_BOOLEAN_TRUE;
	pin_flist_t			*enrich_iflistp = NULL;
	int32				error_clear_flag = 1;
	int32				cerror_code = 0;
	char				log_msg[512]= "";
	int64				db_no= 0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment error",ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *  *  *         * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_AR_GET_PAYMENT) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment BAD opcode error",ebufp);
		return;
	}
	/*******************************************************************
 	       * Check for the input flist details
	*******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_ar_get_payment input flist", in_flistp);
	 
	 
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	
	/* Common_input_validation */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_ar_get_payment(ctxp, flags, enrich_iflistp, &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_payment input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_payment error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
			" Error while getting Payment", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PAYMENT, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_PAYMENT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_PAYMENT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX (&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_payment output flist", *ret_flistpp);
	return;
	}


/**
 *  We use this function to get payment found for the given 
 *  MSISDN/ACCOUNT_NO
 *  If account have PAYMENT found then payment details
 *  returned in return array.
 *  @param ctxp The context pointer.
 *  @param in_flistp in the input flist.
 *  @param ebufp The error buffer.
 *  @return flistp. 
 *    
 *  */

void
fm_tab_ar_get_payment (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	char			*trans_id = NULL;
	char			*account_no = NULL;
	char			*msisdn = NULL;
	char			*acct_obj = NULL;
	pin_flist_t		*paytype_iflistp = NULL;
	pin_flist_t		*paytype_rflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	int32			*pay_type = NULL;
	char			*in_start_strp = NULL;
	char			*in_end_strp = NULL;
	char			*payment_mode = NULL;
	char			*channel_id=NULL;
	char			*ext_tranid = NULL;
	pin_flist_t		*payment_srch_rflistp = NULL;
	int			unalloc_pymt_flag = 0;
	pin_flist_t		*custom_res_flistp = NULL;
	pin_cookie_t		cookie = NULL;
	int32			elem_id = 0;
	pin_flist_t		*custom_iflistp = NULL;
	pin_flist_t		*custom_rflistp = NULL;
	pin_flist_t		*results_flistp= NULL;
	poid_t			*item_pdp = NULL;
	pin_flist_t		*unallocpayment_srch_rflistp = NULL;
	pin_cookie_t		event_cookie = NULL;
	int32			event_elem_id = 0;
	pin_flist_t		*event_results_flistp=NULL;
	pin_flist_t		*hook_get_payment_flistp = NULL;
	time_t			*end_t = NULL;
	char			*end_strp = NULL;
	time_t			*bill_end_t = NULL;
	char			*bill_end_strp = NULL;
	pin_flist_t		*items_flistp = NULL;
	pin_flist_t		*transfer_out_flistp = NULL;
	pin_flist_t		*custom_bills_flistp = NULL;
	pin_flist_t		*custom_allocation_flistp = NULL;
	int			alloc_flag = 0;
	pin_flist_t		*transfer_into_flistp = NULL;
	time_t			*created_t = NULL;
	char			*created_strp = NULL;
	pin_flist_t		*payment_flistp = NULL;
	pin_flist_t		*event_flistp = NULL;
	pin_flist_t		*custom_payment_flistp = NULL;
	pin_flist_t		*item_result_flistp = NULL;
	pin_flist_t		*get_item_iflistp = NULL;
	pin_flist_t		*get_item_rflistp = NULL;
	int32			rev_flag = 1;
	pin_flist_t		*payment_res_flistp = NULL;
	time_t			convrt_start_t = 0;
	time_t			convrt_end_t= 0;
	char			log_msg[512]="";
	pin_flist_t		*custom_item_flistp = NULL;
	pin_flist_t		*pay_info_flistp = NULL;
	pin_flist_t		*event_reason_flistp = NULL;
	poid_t			*acct_pdp = NULL;
	char                    *input_start_str = NULL;
	char                    *input_end_str = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment: input flist", in_flistp);

	/*Validating input arguments*/
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if((account_no == NULL || strlen(account_no) == 0) && 
			(msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
				"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	in_start_strp = PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_START_T_STR, 1, ebufp);
	in_end_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_END_T_STR, 1, ebufp);
	payment_mode = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_PAY_MODE, 1, ebufp);
	channel_id = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_CHANNEL_ID_STR, 1, ebufp);
	ext_tranid = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_EXTERN_TRANS_ID, 1, ebufp);
	if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_FLAG_UNALLOC_PYMT, 1, ebufp) != NULL)
	{
		unalloc_pymt_flag = *(int *)PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_FLAG_UNALLOC_PYMT, 1, ebufp);
	}
	if (unalloc_pymt_flag == 0)
	{
		PIN_FLIST_FLD_SET(in_flistp,TAB_FLD_FLAG_UNALLOC_PYMT,&unalloc_pymt_flag, ebufp);
	}

	if (trans_id == NULL)
	{
		/*Checking Paytype*/
		paytype_iflistp = PIN_FLIST_CREATE(ebufp);
		acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
		acct_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
		if(!PIN_POID_IS_NULL(acct_obj))
		{
			PIN_FLIST_FLD_SET(paytype_iflistp, PIN_FLD_POID, acct_obj, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_SET(paytype_iflistp, PIN_FLD_POID, acct_pdp, ebufp);

		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Get Pay_type from PCM_OP_BAL_GET_ACCT_BILLINFO:"
				"input flist", paytype_iflistp);
		/*Call PCM_OP_BAL_GET_ACCT_BILLINFO*/
		PCM_OP (ctxp, PCM_OP_BAL_GET_ACCT_BILLINFO, 0, paytype_iflistp, &paytype_rflistp, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ACCT_BILLINFO"
					"input flist ",paytype_iflistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ACCT_BILLINFO:"
					"Error while fetching paytype", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Get Pay_type from PCM_OP_BAL_GET_ACCT_BILLINFO"
				"return flist", paytype_rflistp);
		if (paytype_rflistp && (billinfo_flistp=PIN_FLIST_ELEM_GET(paytype_rflistp, PIN_FLD_BILLINFO,
						PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			pay_type = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
			if(*pay_type == PIN_PAY_TYPE_PREPAID)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                         TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
                                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Operation cannot be performed for "
                                        " the Prepaid Paytype", ebufp);
                                goto cleanup;

			}
		}
	}

	time_t	current_date = pin_virtual_time((time_t *)NULL);
	if(in_start_strp != NULL)
	{
		convrt_start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, in_start_strp, ebufp);

		sprintf(log_msg, "%ld",convrt_start_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	}
	
	if(in_end_strp != NULL)
	{
		convrt_end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, in_end_strp, ebufp);
	
		sprintf(log_msg, "%ld",convrt_end_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	}

	if(in_start_strp == NULL && in_end_strp == NULL)
	{
		convrt_end_t = current_date;
		sprintf(log_msg, "%ld",convrt_end_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		
		convrt_start_t = convrt_end_t-ONEDAY*30;
		sprintf(log_msg, "%ld",convrt_start_t);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(convrt_end_t != 0)
		{
			char *convrt_end_strp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&convrt_end_t,ebufp);
			PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_END_T_STR, convrt_end_strp, ebufp);
			free(convrt_end_strp);
		}
		if(convrt_start_t != 0)
		{
			char *convrt_start_strp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&convrt_start_t,ebufp);
			PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_START_T_STR, convrt_start_strp, ebufp);
			free(convrt_start_strp);
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment:input flist", in_flistp);

	}
	else if (in_start_strp != NULL && in_end_strp == NULL)
	{
		convrt_end_t=convrt_start_t+ONEDAY*30;
		if(convrt_end_t != 0)
                {
                        char *convrt_end_strp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&convrt_end_t,ebufp);
                        PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_END_T_STR, convrt_end_strp, ebufp);
                        free(convrt_end_strp);
                }
	}
	else if (in_end_strp != NULL && in_start_strp == NULL)
    	{
                convrt_start_t=convrt_end_t-ONEDAY*30;
                if(convrt_start_t != 0)
                {
                        char *convrt_start_strp= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&convrt_start_t,ebufp);
                        PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_START_T_STR, convrt_start_strp, ebufp);
                        free(convrt_start_strp);
                }
    	}
	else if (in_start_strp != NULL && in_end_strp != NULL)
	{
		if (((convrt_end_t-convrt_start_t)<=ONEDAY*90))	
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Validating Start and End Range within 90 days:"
				"input flist", in_flistp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment:"
				" input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INCORRECT_START_END_DATE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
				"Start and End Date Range is greater than 90 days", ebufp);
			goto cleanup;
		}
	}
	else if (( in_start_strp != NULL && in_end_strp == NULL) || (in_start_strp == NULL && in_end_strp != NULL))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment:"
			" input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_START_END_DATE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
			"Start/End Date is Missing in request", ebufp);
		goto cleanup;

	}

	input_start_str=PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_START_T_STR, 1, ebufp);
	input_end_str=PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_END_T_STR, 1, ebufp);
	
	/*With TransId*/
	if(trans_id != NULL && strlen(trans_id) != 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_transid:input flist",in_flistp);
		fm_tab_ar_get_payment_transid(ctxp, flags, in_flistp, &payment_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					"Error while doing search with TransId", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_transid:return flist",payment_srch_rflistp);
		payment_res_flistp = PIN_FLIST_ELEM_GET(payment_srch_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if(payment_res_flistp == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_payment:"
				" input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_TRANSID, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
				"Invalid TransId passed in the request", ebufp);
			goto cleanup;
		}
	}
	else if (((account_no != NULL && strlen(account_no) != 0) || (msisdn != NULL && strlen(msisdn) != 0))
		&& (unalloc_pymt_flag == TAB_UNALLOCATED_FLAG_TRUE))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Unalloacted payment search:input flist",in_flistp);
		/*Unallocated Payment Search*/
		fm_tab_ar_get_unallocated_payment_search(ctxp, flags, in_flistp,
				&unallocpayment_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" Error while doing search", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Unalloacted get payment search:return flist",
				unallocpayment_srch_rflistp);

		if(unallocpayment_srch_rflistp != NULL)
		{
			custom_iflistp = PIN_FLIST_CREATE(ebufp);
			elem_id = 0;
			cookie = NULL;
			while((results_flistp = PIN_FLIST_ELEM_GET_NEXT(unallocpayment_srch_rflistp, PIN_FLD_RESULTS,
							&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_POID, custom_iflistp,PIN_FLD_ITEM_OBJ,
						ebufp);
				fm_tab_ar_get_payment_event_search(ctxp,flags,custom_iflistp,
						&custom_rflistp,db_no,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
							" input flist ", in_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
							" Error while doing search ", ebufp);
					goto cleanup;
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Payment event Search:"
						"return flist", custom_rflistp);
				if (custom_rflistp != NULL)
				{
					payment_srch_rflistp = custom_rflistp;
				}
			}

		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Unallocated payment Event Search:"
				"return flist",payment_srch_rflistp);
	}
	else if(((account_no != NULL && strlen(account_no) != 0) || (msisdn != NULL && strlen(msisdn) != 0)) && 
			(payment_mode != NULL || channel_id != NULL || ext_tranid != NULL))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "External Parameters: input flist", in_flistp);
		PIN_FLIST_FLD_DROP(in_flistp, TAB_FLD_START_T_STR, ebufp);
		PIN_FLIST_FLD_DROP(in_flistp, TAB_FLD_END_T_STR, ebufp);
		/*Payment Search based on Parameter given in Input*/
		fm_tab_ar_get_payment_search(ctxp, flags, in_flistp, &payment_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" Error while doing search", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parameter Based Search:return flist",payment_srch_rflistp);
	}
	else if(((account_no != NULL && strlen(account_no) != 0) || (msisdn != NULL && strlen(msisdn) != 0)) &&
                        (input_start_str != NULL && input_end_str != NULL))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Payment Search with Start and End dates:input flist", in_flistp);
		/*Payment Search based on Parameter given in Input*/
		fm_tab_ar_get_payment_search(ctxp, flags, in_flistp, &payment_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
					" Error while doing search", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parameter Based Search:return flist",payment_srch_rflistp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Payment Events search:return flist",payment_srch_rflistp);
	payment_res_flistp = PIN_FLIST_ELEM_GET(payment_srch_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if(payment_res_flistp != NULL)
	{
		custom_res_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, custom_res_flistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, custom_res_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, custom_res_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, custom_res_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, custom_res_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
		event_elem_id = 0;
		event_cookie = NULL;
		while((event_results_flistp = PIN_FLIST_ELEM_GET_NEXT(payment_srch_rflistp, PIN_FLD_RESULTS,
						&event_elem_id, 1, &event_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Event flist",event_results_flistp);
			get_item_iflistp = PIN_FLIST_CREATE(ebufp);
			item_pdp = PIN_FLIST_FLD_GET(event_results_flistp, PIN_FLD_ITEM_OBJ, 1, ebufp);
			PIN_FLIST_FLD_SET(get_item_iflistp, PIN_FLD_POID, item_pdp, ebufp);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"AR Get ItemDetail:input flist",get_item_iflistp);
			PCM_OP(ctxp,PCM_OP_AR_GET_ITEM_DETAIL,0,get_item_iflistp,&get_item_rflistp,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"AR Get ItemDetail:return flist",get_item_rflistp);
			PIN_FLIST_DESTROY_EX (&get_item_iflistp, NULL);
			if((item_result_flistp = PIN_FLIST_ELEM_GET(get_item_rflistp,PIN_FLD_RESULTS,
							PIN_ELEMID_ANY,1,ebufp)) != NULL)
			{
				custom_payment_flistp = PIN_FLIST_ELEM_ADD(custom_res_flistp,TAB_FLD_PAYMENTS,
						event_elem_id , ebufp);
				event_flistp = PIN_FLIST_ELEM_GET(item_result_flistp,PIN_FLD_EVENTS,PIN_ELEMID_ANY,
						1,ebufp);
				payment_flistp = PIN_FLIST_ELEM_GET(event_flistp,PIN_FLD_PAYMENT, PIN_ELEMID_ANY,
						1, ebufp);
				pay_info_flistp = PIN_FLIST_ELEM_GET(event_flistp, TAB_FLD_PAYMENT_INFO, PIN_ELEMID_ANY,
						1, ebufp);
				if(pay_info_flistp != NULL)
				{
					PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_AMOUNT,custom_payment_flistp,
							PIN_FLD_AMOUNT, ebufp);
					PIN_FLIST_FLD_COPY(item_result_flistp, PIN_FLD_TRANSFERED,custom_payment_flistp,
							PIN_FLD_TRANSFERED, ebufp);
					PIN_FLIST_FLD_COPY(item_result_flistp, PIN_FLD_DUE,custom_payment_flistp,PIN_FLD_DUE,
							ebufp);
					created_t = PIN_FLIST_FLD_GET(item_result_flistp,PIN_FLD_CREATED_T, 1, ebufp);
					if(created_t != NULL && created_t != 0)
					{
						created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,created_t, 
								ebufp);
						PIN_FLIST_FLD_PUT(custom_payment_flistp, TAB_FLD_CREATED_T_STR,created_strp,
								ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(custom_payment_flistp, TAB_FLD_CREATED_T_STR, "", ebufp);
					}
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_USER_NAME,custom_payment_flistp,
							PIN_FLD_USER_NAME, ebufp);
					PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_TRANS_ID, custom_payment_flistp, 
							PIN_FLD_TRANS_ID, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CHANNEL_ID_STR, custom_payment_flistp, 
							TAB_FLD_CHANNEL_ID_STR, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_PAY_T_STR, custom_payment_flistp,
							TAB_FLD_PAY_T_STR, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_BRANCH_NO, custom_payment_flistp, 
							PIN_FLD_BRANCH_NO, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_DEALER_CODE, custom_payment_flistp, 
							PIN_FLD_DEALER_CODE, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_DEALER_NAME, custom_payment_flistp, 
							PIN_FLD_DEALER_NAME, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_EXTERN_TRANS_ID, custom_payment_flistp, 
							TAB_FLD_EXTERN_TRANS_ID, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_PAY_MODE, custom_payment_flistp, 
							TAB_FLD_PAY_MODE, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_BANK_CODE, custom_payment_flistp, 
							PIN_FLD_BANK_CODE, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_BANK_BRNCH_CODE, custom_payment_flistp,
							TAB_FLD_BANK_BRNCH_CODE,ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_BANK_ACCOUNT, custom_payment_flistp, 
							PIN_FLD_BANK_ACCOUNT, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CARD_NUM, custom_payment_flistp,
							TAB_FLD_CARD_NUM, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CARD_TYPE, custom_payment_flistp, 
							TAB_FLD_CARD_TYPE, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CARD_EXPIRATION, custom_payment_flistp, 
							TAB_FLD_CARD_EXPIRATION, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_CHECK_NO, custom_payment_flistp,
							PIN_FLD_CHECK_NO, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CHECK_ISSUE_T_STR,custom_payment_flistp,
							TAB_FLD_CHECK_ISSUE_T_STR,ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, PIN_FLD_LOCATION, custom_payment_flistp, 
							PIN_FLD_LOCATION, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_GL_GRP_CODE, custom_payment_flistp, 
							TAB_FLD_GL_GRP_CODE, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_CORP_PYMT_KEY, custom_payment_flistp, 
							TAB_FLD_CORP_PYMT_KEY, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_WHT_CERT, custom_payment_flistp,
							TAB_FLD_WHT_CERT, ebufp);
					PIN_FLIST_FLD_COPY(pay_info_flistp, TAB_FLD_WHT_AMOUNT, custom_payment_flistp,
							TAB_FLD_WHT_AMOUNT, ebufp);
				}
				PIN_FLIST_FLD_SET(custom_payment_flistp,TAB_FLD_DEPOSIT_TYPE, "",ebufp);
				PIN_FLIST_FLD_COPY(item_result_flistp, PIN_FLD_DESCR, custom_payment_flistp,
						PIN_FLD_DESCR, ebufp);
				transfer_into_flistp = PIN_FLIST_ELEM_GET(item_result_flistp, PIN_FLD_TRANSFERS_INTO,
						PIN_ELEMID_ANY, 1, ebufp);
				if(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_FLAG_ALLOC_DET, 1, ebufp) !=NULL )
				{
					alloc_flag = *(int *)PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_FLAG_ALLOC_DET,1, ebufp);
				}
				if (alloc_flag == 0)
				{
					PIN_FLIST_FLD_SET(in_flistp,TAB_FLD_FLAG_ALLOC_DET,&alloc_flag,ebufp);

				}

				if(transfer_into_flistp != NULL)
				{
					PIN_FLIST_FLD_SET(custom_payment_flistp,TAB_FLD_REVERSAL_FLAG,&rev_flag,ebufp);
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"get_payment:flist", custom_payment_flistp);
				if((alloc_flag == TAB_ALLOCATED_FLAG_TRUE) && (transfer_into_flistp == NULL))
				{
					transfer_out_flistp = PIN_FLIST_ELEM_GET(item_result_flistp,
							PIN_FLD_TRANSFERS_OUT, PIN_ELEMID_ANY, 1, ebufp);

					if (transfer_out_flistp !=  NULL)
					{
						custom_allocation_flistp = PIN_FLIST_ELEM_ADD(custom_payment_flistp,
								TAB_FLD_ALLOCATION_DETAILS,event_elem_id,ebufp);
						custom_bills_flistp = PIN_FLIST_ELEM_ADD(custom_allocation_flistp,
								PIN_FLD_BILLS,event_elem_id,ebufp);

						bill_end_t = PIN_FLIST_FLD_GET(transfer_out_flistp,PIN_FLD_END_T,
								1,ebufp);
						if(bill_end_t != NULL && bill_end_t != 0)
						{
							bill_end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,
									bill_end_t, ebufp);
							PIN_FLIST_FLD_PUT(custom_bills_flistp, TAB_FLD_BILL_END_T_STR,
									bill_end_strp, ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(custom_bills_flistp,TAB_FLD_BILL_END_T_STR,"",
									ebufp);
						}
						PIN_FLIST_FLD_COPY(transfer_out_flistp,PIN_FLD_BILL_NO,custom_bills_flistp,
								PIN_FLD_BILL_NO, ebufp);
						PIN_FLIST_FLD_COPY(transfer_out_flistp,PIN_FLD_AMOUNT,custom_bills_flistp, 
								PIN_FLD_AMOUNT,ebufp);
						end_t = PIN_FLIST_FLD_GET(transfer_out_flistp, PIN_FLD_END_T,1,ebufp);
						if(end_t != NULL)
						{
							end_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,end_t,
									ebufp);
							PIN_FLIST_FLD_PUT(custom_bills_flistp,TAB_FLD_END_T_STR,end_strp,
									ebufp);
						}
						else
						{
							PIN_FLIST_FLD_SET(custom_bills_flistp,TAB_FLD_END_T_STR,"",ebufp);
						}
						items_flistp = PIN_FLIST_ELEM_GET(transfer_out_flistp,PIN_FLD_ITEMS, 
								PIN_ELEMID_ANY, 1, ebufp);
						custom_item_flistp = PIN_FLIST_ELEM_ADD(custom_allocation_flistp,PIN_FLD_ITEMS,
								event_elem_id,ebufp);
						PIN_FLIST_FLD_COPY(items_flistp,PIN_FLD_AMOUNT,custom_item_flistp, 
								PIN_FLD_AMOUNT, ebufp);
						PIN_FLIST_FLD_COPY(items_flistp,PIN_FLD_NAME,custom_item_flistp, 
								PIN_FLD_NAME, ebufp);
						PIN_FLIST_FLD_COPY(items_flistp,PIN_FLD_ACCOUNT_NO,custom_item_flistp, 
								PIN_FLD_ACCOUNT_NO, ebufp);
					}
				}
				event_reason_flistp = PIN_FLIST_ELEM_GET(event_flistp, PIN_FLD_EVENT_MISC_DETAILS,
						PIN_ELEMID_ANY, 1, ebufp);
				if(event_reason_flistp != NULL)
				{	
					PIN_FLIST_FLD_COPY(event_reason_flistp,PIN_FLD_REASON_ID,custom_payment_flistp,
							PIN_FLD_REASON_ID, ebufp);
					PIN_FLIST_FLD_COPY(event_reason_flistp,PIN_FLD_REASON_DOMAIN_ID,custom_payment_flistp,
							PIN_FLD_REASON_DOMAIN_ID, ebufp);
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_get_payment:"
                                                "input flist", in_flistp);
                                /*Calling TAB_OP_AR_POL_GET_PAYMNET Policy opcode*/
                                PCM_OP(ctxp,TAB_OP_AR_POL_GET_PAYMENT,0,custom_res_flistp,
                                                &hook_get_payment_flistp,ebufp);
                                if (PIN_ERR_IS_ERR(ebufp))
                                {
                                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_payment:"
                                                        "Hook opcode  flist", custom_payment_flistp);
                                        pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                                        TAB_ERR_CODE_API_GET_PAYMENT, 0, 0, 0);
                                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_get_payment:"
                                                        "Hook opcode  flist error", ebufp);
                                        *ret_flistpp = hook_get_payment_flistp;
                                        goto cleanup;
                                }
                                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_get_payment:"
                                                "return flist", hook_get_payment_flistp);
			}
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_payment input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_PAYMENT_TRANSACTION_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment:"
			"Error No payment transactions found for the given Account/MSISDN", ebufp);
		goto cleanup;
	}

	*ret_flistpp = hook_get_payment_flistp;


cleanup:
/******************************************************************
*          * Clean up.
******************************************************************/
	PIN_FLIST_DESTROY_EX (&custom_res_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&paytype_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&paytype_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&custom_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&get_item_rflistp, NULL);
	return;

}



void
fm_tab_ar_get_payment_transid (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*transid_srch_iflistp = NULL;
	pin_flist_t		*transid_srch_rflistp = NULL;
	char			*trans_id =NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*payment_flistp=NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_transid:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_payment_transid function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_transid:input flist",in_flistp);
	trans_id=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	
	/*Sample Search Input Flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/payment where F1 = V1"
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 	  PIN_FLD_PAYMENT  SUBSTRUCT [0] allocated 20, used 2
	2     	  PIN_FLD_TRANS_ID        STR [0] "T1,41,0"
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
        1        PIN_FLD_ACCOUNT_OBJ     POID [0] 0.0.0.1 /account 198674 0 1
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1     PIN_FLD_POID           POID [0] NULL poid pointer
	1     PIN_FLD_ITEM_OBJ POID [0] NULL poid pointer
	1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/

	transid_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(transid_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event/billing/payment where F1 = V1";
	PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	payment_flistp = PIN_FLIST_SUBSTR_ADD(args_flistp, PIN_FLD_PAYMENT, ebufp);
	PIN_FLIST_FLD_SET(payment_flistp, PIN_FLD_TRANS_ID , trans_id, ebufp);

	srch_res_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_transid Search:"
		"input flist", transid_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, transid_srch_iflistp, &transid_srch_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_transid:"
			" input flist ", transid_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_transid:"
			"Given paymentRefId is not associated with the given AccountNo/MSISDN", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_transid Search:"
		"return flist", transid_srch_rflistp);
	*ret_flistpp = transid_srch_rflistp;
	PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
	return;

cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&transid_srch_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_payment_transid final flist", *ret_flistpp);
	return;
}


void
fm_tab_ar_get_payment_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*payment_search_iflistp = NULL;
	pin_flist_t		*payment_search_rflistp = NULL;
	char			*acct_obj =NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*payment_flistp=NULL;
	char			*start_t_strp = NULL;
	char			*end_t_strp = NULL;
	time_t			start_t = 0;
	time_t			end_t= 0;
	char			*channel_id = NULL;
	char			*pay_mode = NULL;
	char			*extern_transid = NULL;	
	char			log_msg[512] = "";
	

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_search:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_payment_search function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_search:input flist",in_flistp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	start_t_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_START_T_STR , 1, ebufp); 
	end_t_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_END_T_STR, 1, ebufp); 
	channel_id = PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_CHANNEL_ID_STR , 1, ebufp); 
	pay_mode = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_PAY_MODE, 1, ebufp); 
	extern_transid =PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_EXTERN_TRANS_ID, 1, ebufp); 
	
	/*Sample Search Input Flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] "select X from /event/billing/payment where F1 = V1 and ((F2 >= V2 and F3 <= V3) or F4 =V4 or F5 = V5 or F6= V6)"
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_ACCOUNT_OBJ POID [0] 0.0.0.1 /account 8225338 0
	0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	1 	PIN_FLD_CREATED_T TSTAMP [0] (1628670000) 
	0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	1 	PIN_FLD_CREATED_T TSTAMP [0] (1643212355)  	  
	0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	1 	  PIN_FLD_PAYMENT  SUBSTRUCT [0] allocated 20, used 2
	2     	  TAB_FLD_CHANNEL_ID_STR        STR [0] "1234"
	0 PIN_FLD_ARGS          ARRAY [5] allocated 20, used 1
	1 	  PIN_FLD_PAYMENT  SUBSTRUCT [0] allocated 20, used 2
	2     	  TAB_FLD_PAY_MODE        STR  [0] "1234"
	0 PIN_FLD_ARGS          ARRAY [6] allocated 20, used 1
	1 	  PIN_FLD_PAYMENT  SUBSTRUCT [0] allocated 20, used 2
	2     	  TAB_FLD_EXTERN_TRANS_ID        STR  [0] "1234"
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1   	  PIN_FLD_POID           POID [0] NULL poid pointer
	1     PIN_FLD_ITEM_OBJ POID [0] NULL poid pointer
	1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/
 

	payment_search_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(payment_search_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(payment_search_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event/billing/payment where F1 = V1 and ((F2 >= V2 and F3 <= V3) or F4 =V4 or F5 = V5 or F6 = V6)";
	PIN_FLIST_FLD_SET(payment_search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_obj, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 2, ebufp);
	if(start_t_strp != NULL)
	{
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, start_t_strp, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, &start_t,ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,NULL,ebufp);
	}
	sprintf(log_msg,"%ld",start_t);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 3, ebufp);
	if(end_t_strp != NULL)
	{
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_t_strp, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, &end_t,ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,NULL,ebufp);
	}
	sprintf(log_msg,"%ld",end_t);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 4, ebufp);
	payment_flistp = PIN_FLIST_SUBSTR_ADD(args_flistp, TAB_FLD_PAYMENT_INFO, ebufp);
	if(channel_id != NULL && strlen(channel_id) != 0)
        {
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CHANNEL_ID_STR, channel_id, ebufp);
        }
        else
        {
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_CHANNEL_ID_STR, "", ebufp);
        }
	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 5, ebufp);
	payment_flistp = PIN_FLIST_SUBSTR_ADD(args_flistp, TAB_FLD_PAYMENT_INFO, ebufp);
	if(pay_mode != NULL && strlen(pay_mode) != 0)
	{
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_PAY_MODE, pay_mode,ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(payment_flistp,TAB_FLD_PAY_MODE,"",ebufp);
	}

	args_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_ARGS, 6, ebufp);
	payment_flistp = PIN_FLIST_SUBSTR_ADD(args_flistp,TAB_FLD_PAYMENT_INFO, ebufp);
	if(extern_transid != NULL && strlen(extern_transid) != 0)
	{
		PIN_FLIST_FLD_SET(payment_flistp, TAB_FLD_EXTERN_TRANS_ID,extern_transid,ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(payment_flistp,TAB_FLD_EXTERN_TRANS_ID,"",ebufp);
	}

	srch_res_flistp = PIN_FLIST_ELEM_ADD(payment_search_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_search Search:"
		"input flist", payment_search_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, payment_search_iflistp, &payment_search_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_search:"
			" input flist ", payment_search_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_search:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_search Search:"
		"return flist", payment_search_rflistp);
	*ret_flistpp = payment_search_rflistp;
	PIN_FLIST_DESTROY_EX(&payment_search_iflistp, NULL);
	return;
	

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&payment_search_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&payment_search_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_payment_search final flist", *ret_flistpp);
	return;
}


void
fm_tab_ar_get_unallocated_payment_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*unalloacted_srch_iflistp = NULL;
	pin_flist_t		*unalloacted_srch_rflistp = NULL;
	char			*acct_obj =NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	poid_t			*item_pdp = NULL;
	int			unalloc_status = PIN_ITEM_STATUS_OPEN;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_unallocated_payment_search:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_unallocated_payment_search function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_unallocated_payment_search:input flist",in_flistp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	
	/*Sample Search Input Flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] " select X from /item where F1 = V1 and F2.type = V2 and F3 = V3"
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_ACCOUNT_OBJ POID [0] 0.0.0.1 /account 8225338 0
	0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	1 PIN_FLD_POID  POID [0] 0.0.0.1 /item/payment 1 0  
	0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	1 PIN_FLD_STATUS  ENUM [0] 2	  
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1     PIN_FLD_POID           POID [0] NULL poid pointer
	1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/

	unalloacted_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(unalloacted_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(unalloacted_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /item where F1 = V1 and F2.type = V2 and F3 = V3";
	PIN_FLIST_FLD_SET(unalloacted_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(unalloacted_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_obj, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(unalloacted_srch_iflistp, PIN_FLD_ARGS, 2, ebufp);
	item_pdp = PIN_POID_CREATE(db_no, "/item/payment", -1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, item_pdp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(unalloacted_srch_iflistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STATUS, &unalloc_status, ebufp);


	srch_res_flistp = PIN_FLIST_ELEM_ADD(unalloacted_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_unallocated_payment_search Search:"
		"input flist", unalloacted_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, unalloacted_srch_iflistp, &unalloacted_srch_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_unallocated_payment_search:"
			" input flist ", unalloacted_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_unallocated_payment_search:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_unallocated_payment_search Search:"
		"return flist", unalloacted_srch_rflistp);
	*ret_flistpp = unalloacted_srch_rflistp;
	PIN_FLIST_DESTROY_EX (&unalloacted_srch_iflistp, NULL);
	return;

cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&unalloacted_srch_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&unalloacted_srch_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_payment_transid final flist", *ret_flistpp);
	return;
}


void
fm_tab_ar_get_payment_event_search(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*item_payment_srch_iflistp = NULL;
	pin_flist_t		*item_payment_srch_rflistp = NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	poid_t			*item_pdp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_event_search:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_payment_event_search function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_event_search:input flist",in_flistp);
	item_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ITEM_OBJ, 1, ebufp);

	/*sample search flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/payment where F1 = V1 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_ITEM_OBJ POID [0] 0.0.0.1 /item/payment 30632224 0
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1     PIN_FLD_POID           POID [0] NULL poid pointer
	1     PIN_FLD_ITEM_OBJ POID [0] NULL poid pointer
	1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/
 
	item_payment_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(item_payment_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(item_payment_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event/billing/payment where F1 = V1 ";
	PIN_FLIST_FLD_SET(item_payment_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(item_payment_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ITEM_OBJ, item_pdp, ebufp);

	srch_res_flistp = PIN_FLIST_ELEM_ADD(item_payment_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_payment_event_search Search:"
		"input flist", item_payment_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0,item_payment_srch_iflistp, &item_payment_srch_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_event_search:"
			"input flist ",item_payment_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_payment_event_search:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_payment_event_search Search:"
		"return flist", item_payment_srch_rflistp);
	*ret_flistpp = item_payment_srch_rflistp;
	PIN_FLIST_DESTROY_EX(&item_payment_srch_iflistp, NULL);
	return;

cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&item_payment_srch_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&item_payment_srch_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_payment_transid final flist", *ret_flistpp);
	return;
}

