/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 27/JAN/2022 | Piyush Suryavanshi	| 			| Wrapper for payment
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_PAYMENT operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include <stdlib.h>

EXPORT_OP void
op_tab_ar_make_payment(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_make_payment(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_update_event_payment(
	pcm_context_t 		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t	 	*ebufp);

static void
fm_tab_ar_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t 		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_apply_payment(
	pcm_context_t 		*ctxp,
	pin_flist_t         	*in_flistp,
	int64			db_no,
	pin_flist_t     	**out_flistpp,
	pin_errbuf_t        	*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_search_bill_no(
	pcm_context_t 		*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_search_item_bill_pdp(
	pcm_context_t 		*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_read_object(
	pcm_context_t     	*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t         	**ret_flistpp,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);	

/**
 *
 * New opcode TAB_OP_AR_MAKE_PAYMENT is implemented apply
 * payment on account
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains payment info
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 */

void
op_tab_ar_make_payment(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*trans_order_oflistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_payment:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_make_payment function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_PAYMENT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_payment bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_payment input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{

		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_validate_and_normalize_input:"
					"flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_payment:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_make_payment(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_payment:"
					"flist", enrich_iflistp);						
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_payment error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_payment: Error while Opening transaction",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_payment:"
				"flist", in_flistp);		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_AR_MAKE_PAYMENT", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_PAYMENT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_PAYMENT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_PAYMENT, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if(PIN_FLIST_ELEM_COUNT(r_flistp,TAB_FLD_NOTIFICATION,ebufp))
		{
			PIN_FLIST_ELEM_DROP(r_flistp,TAB_FLD_NOTIFICATION,PIN_ELEMID_ANY,ebufp);
		}
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_payment output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&trans_order_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/*******************************************************
 * We use this function to apply payment on the account
 * account level, bill level, service level, item level
 * update event and fire notification.
 *
 * @param ctxp The context pointer.
 * @param flags opcode flag.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param db_no Database number.
 * @return flistp.
 *******************************************************/

static void
fm_tab_ar_make_payment(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_payment input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t	*pay_input_flistp=NULL;
	pin_flist_t 	*payment_flistp=NULL;
	pin_flist_t 	*payment_output_flistp=NULL;
	pin_flist_t 	*input_post_payment_flistp = NULL;
	pin_flist_t 	*output_post_payment_flistp= NULL;
	pin_flist_t	*result_payment_flistp=NULL;
	pin_flist_t 	*updat_event_output_flistp=NULL;
	pin_flist_t 	*policy_input_flistp=NULL;
	pin_flist_t 	*enrich_resp_flistp=NULL;
	pin_errbuf_t	local_ebuf = {0};
	pin_errbuf_t	*local_ebufp = &local_ebuf; 

	char		*acct_nop = NULL;
	char		*msisdnp = NULL;
	char 		*trans_id=NULL;
	pin_flist_t      *r_flistp = NULL;
	pin_flist_t		*payment_iflistp = NULL;

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
			"account number/msisdn is not passed", ebufp);
		return;
	}

	trans_id =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
			
	if((trans_id == NULL || strlen(trans_id ) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
			"transaction id is not passed", ebufp);
		return;
	}

	if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp)== NULL) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment:"
			"amount field is missing", ebufp);
		return;
	}

	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, r_flistp, PIN_FLD_AMOUNT, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, r_flistp, PIN_FLD_BILL_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp,PIN_FLD_TRANS_ID,ebufp);
		
	/*******************************************************************
	 * Call apply payment
	 *******************************************************************/

	fm_tab_ar_apply_payment(ctxp,in_flistp,db_no, &pay_input_flistp, ebufp);

	/*******************************************************************
	 *Policy call for payment validation
	 *******************************************************************/
	payment_iflistp = PIN_FLIST_COPY(pay_input_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&pay_input_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : TAB_OP_AR_POL_VALIDATE_PAYMENT: "
			"input Flist", payment_iflistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_VALIDATE_PAYMENT, 0, payment_iflistp, &payment_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"TAB_OP_AR_POL_VALIDATE_PAYMENT: "
			"output Flist", payment_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment :TAB_OP_AR_POL_VALIDATE_PAYMENT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment: TAB_OP_AR_POL_VALIDATE_PAYMENT:"
				" in_flistp", in_flistp);
		*out_flistpp=PIN_FLIST_COPY(payment_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);	
		goto cleanup;
	}

	/*******************************************************************
	 *Payment opcode call
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : PCM_OP_PYMT_COLLECT: "
			"input Flist", payment_flistp);
	PCM_OP( ctxp, PCM_OP_PYMT_COLLECT, 0, payment_flistp, &payment_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : PCM_OP_PYMT_COLLECT: "
			"output Flist", payment_output_flistp);

	PIN_FLIST_DESTROY_EX(&payment_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(payment_output_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCOUNT_PAYMENT_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_apply_payment"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_apply_payment:"
				" input flist ", payment_flistp);
		goto cleanup;
	}

	/*******************************************************************
	 *Event update function call
	 *******************************************************************/
	
	policy_input_flistp=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_CONCAT(policy_input_flistp,payment_output_flistp,ebufp);
	
	fm_tab_ar_update_event_payment(ctxp,policy_input_flistp,db_no,&updat_event_output_flistp,ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
				" in_flistp", policy_input_flistp);
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&updat_event_output_flistp, NULL);

	result_payment_flistp=PIN_FLIST_ELEM_GET(payment_output_flistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	input_post_payment_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(result_payment_flistp, PIN_FLD_POID,input_post_payment_flistp, PIN_FLD_POID, ebufp);

	/*******************************************************************
	 *Policy opcode call for post payment
	 *******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_PAYMENT: "
			"input Flist", input_post_payment_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_POST_PAYMENT, 0, input_post_payment_flistp, &output_post_payment_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_PAYMENT: "
			"output Flist", output_post_payment_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_PAYMENT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_PAYMENT:"
				" in_flistp", input_post_payment_flistp);
		*out_flistpp=PIN_FLIST_COPY(output_post_payment_flistp,local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	enrich_resp_flistp=PIN_FLIST_COPY(r_flistp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT,: "
			"input Flist", enrich_resp_flistp);
	PCM_OP( ctxp, TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT,0, enrich_resp_flistp,out_flistpp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT,: "
			"output Flist", *out_flistpp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : TAB_OP_AR_POL_POST_ENRICH_RESP_MAKE_PAYMENT:"
				" in_flistp", enrich_resp_flistp);
		goto cleanup;
	}

	fm_tab_ar_enrich_notification(ctxp, in_flistp,db_no,payment_output_flistp,out_flistpp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : fm_tab_ar_enrich_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_payment : fm_tab_ar_enrich_notification:"
				" in_flistp", in_flistp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&input_post_payment_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&updat_event_output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&output_post_payment_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_resp_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&policy_input_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&payment_iflistp, NULL); 
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_make_payment output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * We use this function to update payment event to capture all the
 * input related details
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @return flistp.
 * @param ebufp The error buffer.
 *******************************************************************/

static void
fm_tab_ar_update_event_payment(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	int64		db_no,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_update_event_payment input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t *result_payment_flistp=NULL;
	pin_flist_t *update_event_input_flistp = PIN_FLIST_CREATE(ebufp);
	pin_flist_t *update_event_output_flistp=NULL;
	pin_flist_t *payment_flistp =NULL;
	
	result_payment_flistp=PIN_FLIST_ELEM_GET(in_flistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	
	PIN_FLIST_FLD_COPY(result_payment_flistp, PIN_FLD_POID,update_event_input_flistp, PIN_FLD_POID, ebufp);
	payment_flistp=PIN_FLIST_ELEM_ADD(update_event_input_flistp,TAB_FLD_PAYMENT_INFO,0,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_USER_NAME,payment_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_PAY_T_STR,payment_flistp, TAB_FLD_PAY_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BRANCH_NO,payment_flistp, PIN_FLD_BRANCH_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEALER_CODE,payment_flistp, PIN_FLD_DEALER_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEALER_NAME,payment_flistp, PIN_FLD_DEALER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EXTERN_TRANS_ID,payment_flistp, TAB_FLD_EXTERN_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_PAY_MODE,payment_flistp, TAB_FLD_PAY_MODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BANK_CODE,payment_flistp, PIN_FLD_BANK_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_BANK_BRNCH_CODE,payment_flistp, TAB_FLD_BANK_BRNCH_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BANK_ACCOUNT,payment_flistp, PIN_FLD_BANK_ACCOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CARD_NUM,payment_flistp, TAB_FLD_CARD_NUM, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CARD_TYPE,payment_flistp, TAB_FLD_CARD_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CARD_EXPIRATION,payment_flistp, TAB_FLD_CARD_EXPIRATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHECK_NO,payment_flistp, PIN_FLD_CHECK_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CHANNEL_ID_STR,payment_flistp, TAB_FLD_CHANNEL_ID_STR, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CHECK_ISSUE_T_STR,payment_flistp, TAB_FLD_CHECK_ISSUE_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CHECK_AMOUNT,payment_flistp, TAB_FLD_CHECK_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION,payment_flistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_GL_GRP_CODE,payment_flistp, TAB_FLD_GL_GRP_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR,payment_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_CORP_PYMT_KEY,payment_flistp, TAB_FLD_CORP_PYMT_KEY, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_WHT_CERT,payment_flistp, TAB_FLD_WHT_CERT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_WHT_AMOUNT,payment_flistp, TAB_FLD_WHT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_ERCPT_METHOD,payment_flistp, TAB_FLD_ERCPT_METHOD, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_event_payment: "
			"Input Flist", update_event_input_flistp);
	PCM_OP( ctxp,PCM_OP_WRITE_FLDS,32, update_event_input_flistp, &update_event_output_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_event_payment: "
			"output Flist", update_event_output_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_event_payment:"
				" in_flistp", update_event_input_flistp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&update_event_input_flistp, NULL);
	
	*out_flistpp=update_event_output_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_update_event_payment output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * We use this function to create payment input flist
 * account level, service level, bill level, item level
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param db_no Database number.
 * @return flistp.
 * @param ebufp The error buffer.
 *******************************************************************/

static void
fm_tab_ar_apply_payment(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	int64		db_no,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_apply_payment input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_apply_payment error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_apply_payment:"
				" in_flistp", in_flistp);
		return;
	}

	poid_t 		*account_pdp= NULL;
	
	pin_flist_t 	*item_out_flistpp=NULL;
	pin_flist_t 	*payment_input_flistp=NULL;
	pin_flist_t 	*charges_flistp=NULL;
	pin_flist_t 	*bills_flistp=NULL;
	pin_flist_t 	*bill_out_flistpp=NULL;
	pin_flist_t 	*bill_result_flistp=NULL;
	pin_flist_t 	*item_flistp=NULL;
	pin_flist_t 	*items_pay_flistp=NULL;
	pin_flist_t 	*reason_code_flistp=NULL;
	pin_flist_t	*read_object_flistp=NULL;
	
	int		currency=0;
	int 		zero=0;
	int 		payment_type=10011;
	int 		item_search_elemid=0;
	
	pin_cookie_t 	item_search_cookie=NULL;
	
	pin_decimal_t	*duep = NULL;
	pin_decimal_t	*paymtp = NULL;
	pin_decimal_t	*tempp = NULL;
	
	char 		*item_namep=NULL;	
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	fm_tab_utils_common_read_object(ctxp,account_pdp,&read_object_flistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_read_object:",account_pdp);
		goto cleanup;
	}

	currency=*(int*)PIN_FLIST_FLD_GET(read_object_flistp, PIN_FLD_CURRENCY,0,ebufp);

	/*******************************************************************
	 *payment input flist prepration.
	 *******************************************************************/
	payment_input_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(payment_input_flistp, PIN_FLD_POID,account_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,payment_input_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR,payment_input_flistp, PIN_FLD_DESCR, ebufp);

	charges_flistp=PIN_FLIST_ELEM_ADD(payment_input_flistp,PIN_FLD_CHARGES,0,ebufp);
	PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_ACCOUNT_OBJ,account_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT,charges_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_COMMAND,(void*)&zero,ebufp);
	PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_CURRENCY,(void*)&currency,ebufp);	
	PIN_FLIST_FLD_SET(charges_flistp, PIN_FLD_PAY_TYPE,(void*)&payment_type,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID,charges_flistp, PIN_FLD_TRANS_ID, ebufp);

	/*******************************************************************
	 *reason id and reason code
	 *******************************************************************/
	if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_STRING_ID,1,ebufp)!=NULL &&
			PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VERSION_ID,1,ebufp)!=NULL)
	{
		reason_code_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_PAYMENT_REASONS,0,ebufp);

		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VERSION_ID,reason_code_flistp, PIN_FLD_REASON_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STRING_ID,reason_code_flistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);
	}

	/*******************************************************************
	 *Bill level and item level payment validation
	 *******************************************************************/
	if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO,1,ebufp)!=NULL)
	{
		/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
		0 PIN_FLD_FLAGS           INT [0] 0
		0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 = V2 "
		0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
		1     PIN_FLD_BILL_NO         STR [0] "B1-23"
		0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
		1     PIN_FLD_PARENT         POID [0] 0.0.0.0  0 0
		0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 0*/
		
		fm_tab_utils_common_search_bill_no(ctxp,in_flistp,&bill_out_flistpp,db_no,ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_bill_no:"
					" in_flistp", in_flistp);
			goto cleanup;
		}

		if (!PIN_FLIST_ELEM_COUNT(bill_out_flistpp,PIN_FLD_RESULTS,ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_apply_payment :"
					"failed", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_apply_payment input flist", in_flistp);
			goto cleanup;
		}		
		
		bill_result_flistp=PIN_FLIST_ELEM_GET(bill_out_flistpp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
			
		bills_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_BILLS,0,ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO,bills_flistp, PIN_FLD_BILL_NO, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT,bills_flistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(bill_result_flistp, PIN_FLD_POID,bills_flistp, PIN_FLD_POID, ebufp);		
		PIN_FLIST_FLD_COPY(bill_result_flistp,PIN_FLD_ACCOUNT_OBJ,payment_input_flistp,PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(bill_result_flistp,PIN_FLD_ACCOUNT_OBJ,charges_flistp,PIN_FLD_ACCOUNT_OBJ, ebufp);			

		if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME,1,ebufp)!=NULL )
		{
			PIN_FLIST_ELEM_DROP(charges_flistp,PIN_FLD_BILLS,PIN_ELEMID_ANY,ebufp);

			/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
			0 PIN_FLD_FLAGS           INT [0] 0
			0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 = V1 and F2 = V2 and F3 > V3 "
			0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
			1     PIN_FLD_AR_BILL_OBJ    POID [0] 0.0.0.1 /bill 2199796 17
			0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
			1     PIN_FLD_STATUS         ENUM [0] 2
			0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
			1     PIN_FLD_DUE          DECIMAL [0] 0
			0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 0*/
			fm_tab_utils_common_search_item_bill_pdp(ctxp,bill_result_flistp,&item_out_flistpp,db_no,ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_bill_pdp error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_search_item_bill_pdp:"
						" in_flistp", bill_result_flistp);
				goto cleanup;
			}

			paymtp = (pin_decimal_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 0, ebufp);
			tempp=pbo_decimal_copy(paymtp,ebufp);

			item_namep = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_NAME,0, ebufp);

			if (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN,1,ebufp)==NULL)
			{
				if (!PIN_FLIST_ELEM_COUNT(item_out_flistpp,PIN_FLD_RESULTS,ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ITEM_NOT_FOUND, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_apply_payment :"
					"item not found", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_apply_payment input flist", in_flistp);
					goto cleanup;
				}	
				
				while ((item_flistp = PIN_FLIST_ELEM_GET_NEXT(item_out_flistpp, PIN_FLD_RESULTS,
								&item_search_elemid, 1, &item_search_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					char *item_search_namep = PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_NAME,0, ebufp);
					poid_t *ar_billinfo_pdp = PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_AR_BILLINFO_OBJ,0, ebufp);
					poid_t *billinfo_pdp = PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_BILLINFO_OBJ,0, ebufp);

					duep = (pin_decimal_t *)PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_DUE,0, ebufp);

					if(strcmp(item_namep,item_search_namep)==0 &&
							PIN_POID_COMPARE(ar_billinfo_pdp,billinfo_pdp,0,ebufp)==0)
					{
						if (pbo_decimal_compare(tempp,duep, ebufp) > 0)
						{
							tempp=pbo_decimal_subtract(tempp,duep,ebufp);
							items_pay_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_ITEMS,item_search_elemid,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_POID,items_pay_flistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_DUE,items_pay_flistp, PIN_FLD_DUE, ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_BILL_OBJ,items_pay_flistp, PIN_FLD_BILL_OBJ, ebufp);
						}
						else
						{
							items_pay_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_ITEMS,item_search_elemid,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_POID,items_pay_flistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_SET(items_pay_flistp, PIN_FLD_DUE,(void *)tempp,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_BILL_OBJ,items_pay_flistp, PIN_FLD_BILL_OBJ, ebufp);
							break;
						}
					}
				}
			}			
			else
			{
				item_search_elemid=0;
				item_search_cookie=NULL;
				
				while ((item_flistp = PIN_FLIST_ELEM_GET_NEXT(item_out_flistpp, PIN_FLD_RESULTS,
								&item_search_elemid, 1, &item_search_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					char *item_search_namep = PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_NAME,0, ebufp);
					poid_t *item_account_pdp = PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);					
					duep = (pin_decimal_t*)PIN_FLIST_FLD_GET(item_flistp,PIN_FLD_DUE,0, ebufp);

					if(strcmp(item_namep,item_search_namep)==0 &&
							PIN_POID_COMPARE(account_pdp,item_account_pdp,0,ebufp)==0)
					{
						if (pbo_decimal_compare(tempp,duep, ebufp) > 0)
						{
							tempp=pbo_decimal_subtract(tempp,duep,ebufp);
							items_pay_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_ITEMS,item_search_elemid,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_POID,items_pay_flistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_DUE,items_pay_flistp, PIN_FLD_DUE, ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_BILL_OBJ,items_pay_flistp, PIN_FLD_BILL_OBJ, ebufp);
						}
						else
						{
							items_pay_flistp=PIN_FLIST_ELEM_ADD(charges_flistp,PIN_FLD_ITEMS,item_search_elemid,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_POID,items_pay_flistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_SET(items_pay_flistp, PIN_FLD_DUE,(void *)tempp,ebufp);
							PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_BILL_OBJ,items_pay_flistp, PIN_FLD_BILL_OBJ, ebufp);
							break;
						}
					}
				}
			}

		}
	}


	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCOUNT_VALIDATE_PAYMENT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_apply_payment :"
				"failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_apply_payment input flist", in_flistp);		
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
 
	 	 
	*out_flistpp=PIN_FLIST_COPY(payment_input_flistp,ebufp);
	 PIN_FLIST_DESTROY_EX(&bill_out_flistpp, NULL);
	 PIN_FLIST_DESTROY_EX(&item_out_flistpp, NULL);
	 PIN_FLIST_DESTROY_EX(&read_object_flistp, NULL);
	 PIN_FLIST_DESTROY_EX(&payment_input_flistp, NULL);
	 if(tempp){
		pbo_decimal_destroy(&tempp);
	 }
	 PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_apply_payment output flist", *out_flistpp);
	return;
}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the payload structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION for
 *  enrichment and return notification flist
 *************************************************************/

static void
fm_tab_ar_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_enrich_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_enrich_notification: "
			"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_RENAME(o_flistp, PIN_FLD_RESULTS, PIN_FLD_RESULTS_DATA, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	
	PIN_FLIST_FLD_DROP(o_flistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_CONCAT(o_flistp,*r_flistpp,ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, o_flistp, PIN_FLD_OUT_FLIST, ebufp);

	// Create Notification Flist
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_PAYMENT_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PAY_T_STR,notify_flistp, TAB_FLD_PAY_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT,notify_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID,notify_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CHANNEL_ID,notify_flistp, PIN_FLD_CHANNEL_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_BANK_BRNCH_CODE,notify_flistp, TAB_FLD_BANK_BRNCH_CODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DEALER_CODE,notify_flistp, PIN_FLD_DEALER_CODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DEALER_NAME,notify_flistp, PIN_FLD_DEALER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PAY_MODE,notify_flistp, TAB_FLD_PAY_MODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BANK_CODE,notify_flistp, PIN_FLD_BANK_CODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BANK_ACCOUNT,notify_flistp, PIN_FLD_BANK_ACCOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CARD_NUM,notify_flistp, TAB_FLD_CARD_NUM, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CARD_TYPE,notify_flistp, TAB_FLD_CARD_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CHECK_NO,notify_flistp, PIN_FLD_CHECK_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CHECK_ISSUE_T_STR,notify_flistp, TAB_FLD_CHECK_ISSUE_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_DESCR,notify_flistp, PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BILL_NO,notify_flistp, PIN_FLD_BILL_NO, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_enrich_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION, 0,
			notify_iflistp, &enrich_notify_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PAYMENT_NOTFIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_enrich_notification:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_enrich_notification:"
				" Error in Notification", ebufp);
		*r_flistpp=enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_enrich_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_PAYMENT_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
					*r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_enrich_notification output flist", *r_flistpp);
	return;
}
