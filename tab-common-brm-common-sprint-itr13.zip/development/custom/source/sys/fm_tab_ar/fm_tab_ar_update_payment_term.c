/*******************************************************************************
*
*		This material is the confidential property of Telenor/Oracle Corporation or its
*		licensors and may be used, reproduced, stored or transmitted only in
*		accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *					
 *	Delivery Code	| No	| Date		| Programmer		| Req/bug/Gap		| Change details 
 *					
 *			| 1	| 07-DEC-2021	| Shubham		|			| New file.
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_UPDATE_PAYMENT_TERM operation. 
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "tab_utils_common.h"

EXPORT_OP void 
op_tab_ar_update_payment_term(
		cm_nap_connection_t	*connp,
		int32			opcode,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		pin_errbuf_t		*ebufp);
		
static void 
fm_tab_ar_update_payment_term(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp);
	
/**
 *
 * New opcode TAB_OP_AR_UPDATE_PAYMENT_TERM is implemented to 
 * update payment term of a account.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_PAY_TYPE, PIN_FLD_PAYMENT_TERM 
 *					and PIN_FLD_ACCOUNT_NO .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID             POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO       STR [0] “ACCOUNT_NO_234"
 * 0 PIN_FLD_MSISDN           STR [0] "2345600"
 * 0 PIN_FLD_PAY_TYPE         ENUM [0] 10003
 * 0 PIN_FLD_PAYMENT_TERM     ENUM [0] 2
 * 0 PIN_FLD_CORRELATION_ID   STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"
 */

void
op_tab_ar_update_payment_term(
		cm_nap_connection_t	*connp,
		int32			opcode,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		pin_errbuf_t		*ebufp)
{
		pcm_context_t			*ctxp = connp->dm_ctx;
		pin_flist_t			*r_flistp = NULL;
		poid_t				*account_pdp = NULL;
		int32				status = PIN_BOOLEAN_TRUE;
		int32				tab_order_flag = 0;
		pin_flist_t			*enrich_iflistp = NULL;
		int32				error_clear_flag = 1;
		int32				cerror_code = 0;
		int64				db_no = 0;
		char				log_msg[512]= "";

		if(PIN_ERR_IS_ERR(ebufp))
		{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"op_tab_ar_update_payment_term function entry error", ebufp);
				return;
		}
		
		*ret_flistpp = NULL;
		/*******************************************************************
		 * Insanity check.
		 *******************************************************************/
		if(opcode != TAB_OP_AR_UPDATE_PAYMENT_TERM) {

				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						PIN_ERR_BAD_OPCODE, 0, 0, opcode);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_update_payment_term bad opcode error",
						ebufp);
				return;
		}

		/*******************************************************************
		 * Check for the input flist details
		 *******************************************************************/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_update_payment_term input flist", in_flistp);
		
		//To do get db no
		db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
					"Error getting database number");
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
					" input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
					&r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);
			fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
			*ret_flistpp = r_flistp;
			return;
		}
		/*Search for /tab_order object*/
		tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
					" input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
					" Error while searching /tab_order object", ebufp);
			cerror_code = ebufp->pin_err;
			if(cerror_code < 1000 )
			{
				cerror_code = TAB_ERR_CODE_API_UPDATE_PAYMENT_TERM;
				sprintf(log_msg,"%d",cerror_code);
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			}
			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
					cerror_code, &r_flistp,db_no, ebufp);

			PIN_ERR_CLEAR_ERR(ebufp);

			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			if(cerror_code == TAB_ERR_CODE_API_UPDATE_PAYMENT_TERM )
			{
				PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
				PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_PAYMENT_TERM, ebufp);
			}
			fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
			*ret_flistpp = r_flistp;
			return;
		}

		PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
		if(PIN_POID_IS_NULL(account_pdp))
		{
			account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
		}
		
		/* open transaction */
		if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
		{
				/* Validate the input arguments */
				fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term: "
								"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
						" input flist", in_flistp);
						status = TAB_FAIL;
						goto cleanup;
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_payment_term:"
						" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);
				
				/* call main function */
				fm_tab_ar_update_payment_term(ctxp,flags,enrich_iflistp,&r_flistp,db_no,ebufp);
				if(PIN_ERR_IS_ERR(ebufp))
				{
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_payment_term error", ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
						" input flist", enrich_iflistp);
						status = TAB_FAIL;
						goto cleanup;
				}
		}
		else
		{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_update_payment_term:"
						"Error Opening transaction");
				pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"op_tab_ar_update_payment_term: Error while Opening transaction",ebufp);
				fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp,db_no, ebufp);
				PIN_ERR_CLEAR_ERR(ebufp);
				fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
				*ret_flistpp = r_flistp;
				return;
		}

		cleanup:
		/* To commit or abort the transaction and to update the order */
		fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
				"TAB_OP_AR_UPDATE_PAYMENT_TERM", &r_flistp,db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
					" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_update_payment_term:"
					" Error while creating /tab_order object", ebufp);
			cerror_code = ebufp->pin_err;
			if(cerror_code < 1000 )
			{
				cerror_code = TAB_ERR_CODE_API_UPDATE_PAYMENT_TERM;
				sprintf(log_msg,"%d",cerror_code);
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			}
			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
					cerror_code, &r_flistp,db_no, ebufp);

			PIN_ERR_CLEAR_ERR(ebufp);

			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

			if(cerror_code == TAB_ERR_CODE_API_UPDATE_PAYMENT_TERM )
			{
				PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
				PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_UPDATE_PAYMENT_TERM , ebufp);
			}
		}
		else
		{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_payment_term:"
                                                " output flist", r_flistp);
				status = TAB_SUCCESS;
			 /*Prepare Return Flist*/
				PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_update_payment_term output flist", *ret_flistpp);
		return;
}

/**
 * We use this function to update address for a account.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param flags The opcode flags. 
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

static void
fm_tab_ar_update_payment_term(
		pcm_context_t		*ctxp,
		int32			flags,
		pin_flist_t		*in_flistp,
		pin_flist_t		**ret_flistpp,
		int64			db_no,
		pin_errbuf_t		*ebufp)
{
		int32			*payment_term = NULL;
		int32			*pay_type = NULL;
		char 			*msisdn = NULL;
		char			*accountno = NULL;
		poid_t                  *srchp  = NULL;
		poid_t			*paymentterm_poid = NULL;
		poid_t			*account_obj = NULL;
		int32                   s_flags = 256;
		void			*vp = NULL;
		pin_flist_t             *args_flistp = NULL;
        	pin_flist_t             *res_flistp = NULL;
		pin_flist_t		*contextinfo_flistp = NULL;
		pin_flist_t		*get_payinfo_iflistp = NULL;
		pin_flist_t		*get_payinfo_oflistp = NULL;
		pin_flist_t		*update_inflistp = NULL;
		pin_flist_t		*payment_term_flistp = NULL;
		int32			paymentterm_elemid = 0;
		pin_cookie_t		paymentterm_cookie = NULL;
		int32			payment_term_found = 0;
 		pin_flist_t		*inheritedinfo_flistp = NULL;
		pin_flist_t		*r_flistp = NULL;

		if (PIN_ERR_IS_ERR(ebufp)) 
		{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_ar_update_payment_term function entry error", ebufp);
				return;
		}

		get_payinfo_iflistp = PIN_FLIST_CREATE(ebufp);
		update_inflistp = PIN_FLIST_CREATE(ebufp);
	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_payment_term input flist", in_flistp);
		pay_type = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if (pay_type == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_PAYTYPE_MISSING, 0, 0, 0); 
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_update_payment_term: Error PIN_FLD_PAY_TYPE - Input is missing", ebufp);
			goto cleanup;
		}		
		payment_term = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAYMENT_TERM, 1, ebufp);
                if (payment_term == NULL)
                {
                        pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_PAYTERM_MISSING, 0, 0, 0); 
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                        "fm_tab_ar_update_payment_term: Error PIN_FLD_PAYMENT_TERM - Input is missing", ebufp);
                        goto cleanup;
                }
		accountno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);	
		msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
		if((msisdn == NULL || strlen(msisdn) == 0) && (accountno == NULL || strlen(accountno) == 0))
        	{
                pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
                                " Account_no/MSISDN missing in the request ", ebufp);
                goto cleanup;

        	}	
		else if(msisdn == NULL || strlen(msisdn) == 0)
		{
			account_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
		}	
		else
		{
			account_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
		}
		r_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
		//Validate payment_term if valid or not
		srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
		paymentterm_poid = PIN_POID_CREATE(db_no, "/config/payment_term", 1, ebufp);

                PIN_FLIST_FLD_PUT(get_payinfo_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
                PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

                vp =(void *)"select X from /config where  F1.type like V1";
                PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

                args_flistp = PIN_FLIST_ELEM_ADD(get_payinfo_iflistp, PIN_FLD_ARGS, 1, ebufp);
                PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, paymentterm_poid, ebufp);

		PIN_FLIST_ELEM_SET(get_payinfo_iflistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to validate payment_term from input flist", get_payinfo_iflistp);

                PCM_OP(ctxp, PCM_OP_SEARCH, 0,get_payinfo_iflistp, &get_payinfo_oflistp, ebufp);
                if (PIN_ERR_IS_ERR(ebufp))
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                                        "fm_tab_ar_update_payment_term: Base opcode error", get_payinfo_iflistp);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                        "fm_tab_ar_update_payment_term: Base opcode error", ebufp);
                        goto cleanup;
                }
		res_flistp = PIN_FLIST_ELEM_GET(get_payinfo_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		
		while((payment_term_flistp = PIN_FLIST_ELEM_GET_NEXT(res_flistp, PIN_FLD_PAYMENT_TERMS, &paymentterm_elemid, 1, &paymentterm_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			if(*payment_term == paymentterm_elemid)
			{
				payment_term_found = 1;
				break;
			}
		}
		
		if(payment_term_found == 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                        TAB_ERR_CODE_INVALID_PAYTERM, 0, 0, 0);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
                                        " input flist ", get_payinfo_iflistp);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
                                        "Invalid payment_term passed", ebufp);
                        goto cleanup;	
		}
				
		PIN_FLIST_DESTROY_EX(&get_payinfo_iflistp, NULL);
		
		get_payinfo_iflistp = PIN_FLIST_CREATE(ebufp);
		
		get_payinfo_oflistp = NULL;	
		//Search for payinfo object	
		srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

		PIN_FLIST_FLD_PUT(get_payinfo_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
		PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);
		
		vp =(void *)"select X from /payinfo 1, /billinfo 2 where  2.F1 = V1 and 1.F2 = 2.F3";
                PIN_FLIST_FLD_SET(get_payinfo_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

                args_flistp = PIN_FLIST_ELEM_ADD(get_payinfo_iflistp, PIN_FLD_ARGS, 1, ebufp);
                PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_obj, ebufp);
                args_flistp = PIN_FLIST_ELEM_ADD(get_payinfo_iflistp, PIN_FLD_ARGS, 2, ebufp);
                PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);
                args_flistp = PIN_FLIST_ELEM_ADD(get_payinfo_iflistp, PIN_FLD_ARGS, 3, ebufp);
                PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_PAYINFO_OBJ, NULL, ebufp);

		PIN_FLIST_ELEM_SET(get_payinfo_iflistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_SEARCH to get PAYINFO obj input flist", get_payinfo_iflistp);

		PCM_OP(ctxp, PCM_OP_SEARCH, 0,get_payinfo_iflistp, &get_payinfo_oflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_update_payment_term: Base opcode error", get_payinfo_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_update_payment_term: Base opcode error", ebufp);
			goto cleanup;
		}	
	
		if (get_payinfo_oflistp && (res_flistp = PIN_FLIST_ELEM_GET(get_payinfo_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID, update_inflistp, PIN_FLD_POID, ebufp);
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ACCT_NOT_PR, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
					" input flist ", get_payinfo_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_payment_term:"
					"Payinfo obj not found for input account : Seems its a non paying responsible ", ebufp);
			goto cleanup;
		}
			
                PIN_FLIST_FLD_SET(update_inflistp, PIN_FLD_ACCOUNT_OBJ, account_obj, ebufp);
                PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, update_inflistp, PIN_FLD_PROGRAM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYMENT_TERM, update_inflistp, PIN_FLD_PAYMENT_TERM, ebufp);

                contextinfo_flistp = PIN_FLIST_SUBSTR_ADD(update_inflistp, PIN_FLD_CONTEXT_INFO, ebufp);
                PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, contextinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
                PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, contextinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

		inheritedinfo_flistp = PIN_FLIST_SUBSTR_ADD(update_inflistp, PIN_FLD_INHERITED_INFO, ebufp);
		PIN_FLIST_ELEM_SET(inheritedinfo_flistp, NULL, PIN_FLD_INV_INFO, 0, ebufp);	
		
		PCM_OP(ctxp, PCM_OP_CUST_MODIFY_PAYINFO, 0, update_inflistp, ret_flistpp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_update_payment_term: Base opcode error", update_inflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_update_payment_term: Base opcode error", ebufp);
			goto cleanup;
		}
		*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	
cleanup:
	PIN_FLIST_DESTROY_EX(&get_payinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_inflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;

}
