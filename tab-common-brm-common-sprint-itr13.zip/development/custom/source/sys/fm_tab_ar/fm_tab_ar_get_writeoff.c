/*************************************************************************************************
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
**************************************************************************************************/
/*************************************************************************************************
 *  Change History
 *         
 * No | Date        | Programmer                | Req/bug/Gap          | Change details
 *
 * 1  | 18/Jan/2022 | Madhavi Dandi            |                       | New opcode implementation to
 *                                                                     |get Writeoff Transactions
 
*************************************************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "ops/ar.h"
#include "pin_ar.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_ar_get_writeoff(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_writeoff(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_writeoff_acct_obj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_ar_get_writeoff_transid_acctobj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/****************************************************************
 *  *  *  *  *External Routines Refered.
 ******************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 * 
 * New opcode TAB_OP_AR_GET_WRITEOFF is implemented to
 * get Writeoff flds
 *    *
 *  @param connp The connection pointer.
 *  @param opcode This opcode.
 *  @param flags The opcode flags.
 *  @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 *  @param ret_flistpp The output flist with account poid information.
 *  @param ebufp The error buffer.
 *  @return nothing.
 *  
 *  * Sample Input Flist
 *  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 *  0 PIN_FLD_ACCOUNT_NO      STR [0] "CN-0999009"
 *  0 PIN_FLD_TRANS_ID        STR [0] “9011”
 *  0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 *  0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 *
* */

void
op_tab_ar_get_writeoff (
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t			*r_flistp = NULL;
	int32				status = PIN_BOOLEAN_TRUE;
	pin_flist_t			*enrich_iflistp = NULL;
	int32				error_clear_flag = 1;
	int32				cerror_code = 0;
	char				log_msg[512]= "";
	int64				db_no= 0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_writeoff input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_writeoff error",ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *  *  *         * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_AR_GET_WRITEOFF) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_writeoff input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_writeoff BAD opcode error",ebufp);
		return;
	}
	/*******************************************************************
 	       * Check for the input flist details
	*******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_ar_get_writeoff input flist", in_flistp);
	 
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_writeoff input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* Common_input_validation */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_writeoff input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_ar_get_writeoff(ctxp, flags, enrich_iflistp, &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_writeoff input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_writeoff error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff:"
			" Error while getting WriteOff Flds", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_WRITEOFF;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_WRITEOFF, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_WRITEOFF )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_WRITEOFF, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_writeoff output flist", *ret_flistpp);
	return;
}


/**
 *  We use this function to get writeoff information.
 *  @param ctxp The context pointer.
 *  @param in_flistp in the input flist.
 *  @param ebufp The error buffer.
 *  @return flistp. 
 *    
 *  */

void
fm_tab_ar_get_writeoff (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*custom_result_flistp =NULL;
	pin_flist_t		*writeoff_srch_rflistp=NULL;
	pin_flist_t		*writeoff_res_flistp=NULL;
	int32			elem_id = 0;
	pin_cookie_t		cookie = NULL;
	poid_t			*event_pdp=NULL;
	pin_flist_t		*readobj_iflistp = NULL;
	pin_flist_t		*readobj_rflistp =NULL;
	char			*trans_id = NULL;
	poid_t			*acct_obj = NULL;
	pin_flist_t		*writeoff_info_flistp = NULL;
	pin_flist_t		*bal_impacts_flistp = NULL;
	pin_flist_t		*writeoff_flistp = NULL;
	time_t			*created_t = NULL;
	char			*created_strp = NULL;
	pin_flist_t		*allocation_flistp = NULL;
	pin_flist_t		*bill_details_flistp = NULL;
	pin_flist_t		*item_flistp = NULL;
	poid_t			*item_pdp = NULL;
	time_t			*bill_end_t = NULL;
	char			*bill_end_strp = NULL;
	pin_flist_t		*get_item_rflistp = NULL;
	pin_flist_t		*ar_item_flistp = NULL;
	int32			item_elem_id = 0;
	pin_cookie_t	item_cookie = NULL;
	int32			*impact_type=NULL;
	int32			bal_elem_id = 0;
	pin_cookie_t		bal_cookie = NULL;
	pin_flist_t		*read_fld_iflistp = NULL;
	pin_flist_t		*read_fld_rflistp = NULL;
	char			*account_no = NULL;
	pin_flist_t		*get_item_iflistp = NULL;
	pin_flist_t		*item_result_flistp = NULL;
	pin_flist_t		*transfer_out_flistp = NULL;
	pin_flist_t		*bill_read_fld_iflistp = NULL;
	pin_flist_t		*bill_read_fld_rflistp = NULL;
	time_t			*writeoff_t = NULL;
	char			*writeoff_t_strp = NULL;
	poid_t			*bill_obj = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_writeoff: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff: input flist", in_flistp);

	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	/*Validate arguments*/
	if(account_no == NULL || strlen(account_no) == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_writeoff input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_writeoff: Error PIN_FLD_ACCOUNT_NO is missing", ebufp);
		goto cleanup;
	}

	/*With Account_Obj only*/
	if ((!PIN_POID_IS_NULL(acct_obj)) && (trans_id == NULL || strlen(trans_id) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_writeoff_acct_obj:input flist",in_flistp);
		fm_tab_ar_get_writeoff_acct_obj(ctxp, flags, in_flistp, &writeoff_srch_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff:"
				"Error while doing search with Account Obj", ebufp);
			goto cleanup;
		}
	}
	else if ((trans_id != NULL) && (!PIN_POID_IS_NULL(acct_obj)))
	{
		/*With Trans_Id and Account_obj*/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_writeoff_transid_acctobj:"
			"input flist", in_flistp);
		fm_tab_ar_get_writeoff_transid_acctobj(ctxp, flags,in_flistp,&writeoff_srch_rflistp,db_no,ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_transid_acctobj:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff:"
				" Error while doing search with TransId and Account_obj", ebufp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_writeoff:input flist", in_flistp);
	}


	res_flistp = PIN_FLIST_ELEM_GET(writeoff_srch_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if (res_flistp != NULL)
	{
		custom_result_flistp = PIN_FLIST_CREATE(ebufp);
		elem_id = 0;
		cookie = NULL;
		while(writeoff_srch_rflistp && (writeoff_res_flistp = PIN_FLIST_ELEM_GET_NEXT(writeoff_srch_rflistp,
			PIN_FLD_RESULTS,&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			event_pdp = PIN_FLIST_FLD_GET(writeoff_res_flistp,PIN_FLD_POID, 0, ebufp);
			/*Read_Obj of Event_poid*/
			readobj_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(readobj_iflistp,PIN_FLD_POID,event_pdp,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Event Read_Obj input flist",readobj_iflistp);
			PCM_OP(ctxp,PCM_OP_READ_OBJ,0,readobj_iflistp,&readobj_rflistp,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Read_obj:"
						"input flist", readobj_iflistp);
				pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_WRITEOFF, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Read_obj:"
						"Error while doing event read_obj", ebufp);
				goto cleanup;
			}
			PIN_FLIST_DESTROY_EX (&readobj_iflistp, NULL);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Event Read_Obj return flist",readobj_rflistp);
			if(readobj_rflistp != NULL)
			{
				bal_elem_id =0;
				bal_cookie = NULL;
				while(readobj_rflistp && (bal_impacts_flistp = PIN_FLIST_ELEM_GET_NEXT(readobj_rflistp,
					PIN_FLD_BAL_IMPACTS,&bal_elem_id,1,&bal_cookie,ebufp)) != (pin_flist_t *)NULL)
				{
					writeoff_flistp = PIN_FLIST_ELEM_ADD(custom_result_flistp,TAB_FLD_WRITEOFF_INFO,
							elem_id,ebufp);

					read_fld_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(bal_impacts_flistp,PIN_FLD_ITEM_OBJ,read_fld_iflistp, 
						PIN_FLD_POID,ebufp);
					PIN_FLIST_FLD_SET(read_fld_iflistp, PIN_FLD_ITEM_TOTAL, NULL, ebufp);
					PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_fld_iflistp, &read_fld_rflistp, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Read_Flds:input flist", read_fld_iflistp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Read_Flds:"
								"input flist", read_fld_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Read_Flds:"
								"Error while doing READ_FLDS of Item_obj", ebufp);
						goto cleanup;
					}
					PIN_FLIST_DESTROY_EX (&read_fld_iflistp, NULL);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Read_Flds:return flist", read_fld_rflistp);

					PIN_FLIST_FLD_COPY(read_fld_rflistp,PIN_FLD_ITEM_TOTAL,writeoff_flistp,
							PIN_FLD_AMOUNT,ebufp);
					PIN_FLIST_FLD_COPY(bal_impacts_flistp, PIN_FLD_GL_ID ,writeoff_flistp,
							PIN_FLD_GL_ID,ebufp); 
					impact_type =  PIN_FLIST_FLD_GET(bal_impacts_flistp,PIN_FLD_IMPACT_TYPE, 1, ebufp);
					/*Tax*/
					if(*impact_type == 4)
					{
						PIN_FLIST_FLD_COPY(bal_impacts_flistp, PIN_FLD_AMOUNT,writeoff_flistp,
								PIN_FLD_AMOUNT_TAXED,ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(writeoff_flistp, PIN_FLD_AMOUNT_TAXED, NULL, ebufp);
					}
					created_t = PIN_FLIST_FLD_GET(readobj_rflistp,PIN_FLD_CREATED_T, 1, ebufp);
					if(created_t != NULL && *created_t != 0)
					{
						created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp,
								created_t, ebufp);
						PIN_FLIST_FLD_PUT(writeoff_flistp, TAB_FLD_CREATED_T_STR,
								created_strp, ebufp);
					}
					else
					{
						PIN_FLIST_FLD_SET(writeoff_flistp, TAB_FLD_CREATED_T_STR, "", ebufp);
					}
					writeoff_info_flistp = PIN_FLIST_ELEM_GET(readobj_rflistp, TAB_FLD_WRITEOFF_INFO,
							elem_id, 1, ebufp);
					if (writeoff_info_flistp != NULL)
					{
						PIN_FLIST_FLD_COPY(writeoff_info_flistp, PIN_FLD_TRANS_ID,writeoff_flistp,
								PIN_FLD_TRANS_ID ,ebufp);
						PIN_FLIST_FLD_COPY(writeoff_info_flistp, PIN_FLD_USER_NAME,writeoff_flistp,
								PIN_FLD_USER_NAME ,ebufp);
					}
					PIN_FLIST_FLD_COPY(readobj_rflistp, PIN_FLD_DESCR,writeoff_flistp,
							PIN_FLD_DESCR,ebufp);

					get_item_iflistp = PIN_FLIST_CREATE(ebufp);
					item_pdp = PIN_FLIST_FLD_GET(writeoff_res_flistp, PIN_FLD_ITEM_OBJ, 1, ebufp);
					PIN_FLIST_FLD_SET(get_item_iflistp, PIN_FLD_POID, item_pdp, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"AR Get ItemDetail:input flist",
							get_item_iflistp);
					PCM_OP(ctxp,PCM_OP_AR_GET_ITEM_DETAIL,0,get_item_iflistp,&get_item_rflistp,ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"AR Get ItemDetail:return flist",
							get_item_rflistp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"AR Get ItemDetail:input flist"
								"input flist", get_item_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Error while doing" 
								"PCM_OP_AR_GET_ITEM_DETAIL of Item_obj", ebufp);
							goto cleanup;
					}
					PIN_FLIST_DESTROY_EX (&get_item_iflistp, NULL);
					if((item_result_flistp = PIN_FLIST_ELEM_GET(get_item_rflistp,PIN_FLD_RESULTS,
									PIN_ELEMID_ANY,1,ebufp)) != NULL)
					{
						transfer_out_flistp = PIN_FLIST_ELEM_GET(item_result_flistp,
						PIN_FLD_TRANSFERS_OUT, PIN_ELEMID_ANY, 1, ebufp);
						if (transfer_out_flistp !=  NULL)
						{
							allocation_flistp = PIN_FLIST_ELEM_ADD(writeoff_flistp,
								TAB_FLD_ALLOCATION_DETAILS,elem_id,ebufp);
							bill_details_flistp = PIN_FLIST_ELEM_ADD(allocation_flistp,
								TAB_FLD_BILL_DETAILS,elem_id,ebufp);
							/*Read_flds to get bill_end_t*/
							bill_read_fld_iflistp = PIN_FLIST_CREATE(ebufp);
							bill_obj = PIN_FLIST_FLD_GET(transfer_out_flistp,
									PIN_FLD_AR_BILL_OBJ, 1, ebufp);
							if(!PIN_POID_IS_NULL(bill_obj))
							{
								PIN_FLIST_FLD_SET(bill_read_fld_iflistp, PIN_FLD_POID, bill_obj, ebufp);
								PIN_FLIST_FLD_SET(bill_read_fld_iflistp, PIN_FLD_END_T, NULL, ebufp);
								PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, bill_read_fld_iflistp, &bill_read_fld_rflistp, ebufp);
								if (PIN_ERR_IS_ERR(ebufp))
								{
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Read_Flds:"
										"input flist", bill_read_fld_iflistp);
									PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Read_Flds:"
										"Error while doing READ_FLDS of BillPoid to get BillDate", ebufp);
									goto cleanup;
								}
								PIN_FLIST_DESTROY_EX (&bill_read_fld_iflistp, NULL);
							}
							else
							{
								PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"Setting END_T as NULL");

								PIN_FLIST_FLD_SET(bill_read_fld_rflistp,
										PIN_FLD_END_T, NULL, ebufp);
							}
							bill_end_t = PIN_FLIST_FLD_GET(bill_read_fld_rflistp,
									PIN_FLD_END_T, 1, ebufp);
							if(bill_end_t != NULL && *bill_end_t != 0)
							{
								bill_end_strp=fm_tab_utils_common_convert_timestamp_to_date
									(ctxp,bill_end_t, ebufp);
								PIN_FLIST_FLD_PUT(bill_details_flistp,
									TAB_FLD_BILL_END_T_STR,bill_end_strp, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(bill_details_flistp,
										TAB_FLD_BILL_END_T_STR, "", ebufp);
							}
							PIN_FLIST_FLD_COPY(transfer_out_flistp,PIN_FLD_BILL_NO,
								bill_details_flistp,PIN_FLD_BILL_NO,ebufp);
							PIN_FLIST_FLD_COPY(transfer_out_flistp,PIN_FLD_AMOUNT,
								bill_details_flistp,PIN_FLD_WRITEOFF,ebufp);
							writeoff_t = PIN_FLIST_FLD_GET(item_result_flistp,
									PIN_FLD_CREATED_T, 1, ebufp);	
							if(writeoff_t != NULL && *writeoff_t != 0)
							{
								writeoff_t_strp=fm_tab_utils_common_convert_timestamp_to_date
									(ctxp,writeoff_t, ebufp);
								PIN_FLIST_FLD_PUT(bill_details_flistp,
									TAB_FLD_WRITEOFF_T_STR,writeoff_t_strp, ebufp);
							}
							else
							{
								PIN_FLIST_FLD_SET(bill_details_flistp,
									TAB_FLD_WRITEOFF_T_STR, "", ebufp);
							}
							get_item_rflistp = PIN_FLIST_ELEM_GET(transfer_out_flistp,
								PIN_FLD_ITEMS,PIN_ELEMID_ANY, 1, ebufp);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"ITEM_DETAILS Check",
								get_item_rflistp);
							if (get_item_rflistp != NULL)
							{	
								item_elem_id = 0;
								item_cookie = NULL;
								while(get_item_rflistp && (ar_item_flistp = 
									PIN_FLIST_ELEM_GET_NEXT(transfer_out_flistp,
										PIN_FLD_ITEMS,&item_elem_id, 1, 
											&item_cookie, ebufp)) != 
												(pin_flist_t *)NULL)
								{
									item_flistp = PIN_FLIST_ELEM_ADD(
										bill_details_flistp,PIN_FLD_ITEMS,
											item_elem_id,ebufp);
									PIN_FLIST_FLD_COPY(ar_item_flistp,
										PIN_FLD_NAME,item_flistp,
											PIN_FLD_POID_TYPE,ebufp);
									PIN_FLIST_FLD_COPY(ar_item_flistp, 
										PIN_FLD_AMOUNT,item_flistp,
											PIN_FLD_AMOUNT ,ebufp);
									PIN_FLIST_FLD_COPY(ar_item_flistp,
										PIN_FLD_ACCOUNT_NO ,item_flistp,
											PIN_FLD_ACCOUNT_NO,ebufp);
								}
							}
						}
					}
					PIN_FLIST_DESTROY_EX (&get_item_rflistp, NULL);
				}
				PIN_FLIST_DESTROY_EX (&read_fld_rflistp, NULL);
			}
			PIN_FLIST_DESTROY_EX (&readobj_rflistp, NULL);
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_writeoff input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_WRITEOFF_TRANSACTION_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff:"
			"Error No writeoff transactions found for the given Account", ebufp);
		goto cleanup;
	}

	PIN_FLIST_CONCAT(*ret_flistpp, custom_result_flistp, ebufp);


cleanup:
/******************************************************************
*          * Clean up.
******************************************************************/
	PIN_FLIST_DESTROY_EX (&custom_result_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&bill_read_fld_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&writeoff_srch_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_writeoff return flist", *ret_flistpp);
	return;

}

void
fm_tab_ar_get_writeoff_acct_obj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*acct_obj_srch_iflistp = NULL;
	pin_flist_t		*acct_obj_srch_rflistp = NULL;
	char			*acct_obj =NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	poid_t			*writeoff_poid = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_acct_obj:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_writeoff_transid function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_writeoff_acct_obj:input flist",in_flistp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);

	
	/*Sample Search Input Flist
	* 0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	 * 0 PIN_FLD_FLAGS           INT [0] 256
	 * 0 PIN_FLD_TEMPLATE        STR [0] " select X from /event where F1 = V1 and F2.type like V2"
	 * 0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	 * 1 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2065283 0
	 * 0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	 * 1 PIN_FLD_POID    POID [0] 0.0.0.1 /event/billing/writeoff% -1 0
	 * 0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	 * 1       PIN_FLD_POID           POID [0] NULL poid pointer
	 * 1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/
 

	writeoff_poid = PIN_POID_CREATE(db_no, "/event/billing/writeoff%", 1, ebufp);
	acct_obj_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(acct_obj_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(acct_obj_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event where F1 = V1 and F2.type like V2";
	PIN_FLIST_FLD_SET(acct_obj_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(acct_obj_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_obj, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(acct_obj_srch_iflistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, writeoff_poid, ebufp);

	srch_res_flistp = PIN_FLIST_ELEM_ADD(acct_obj_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff_acct_obj Search:"
		"input flist", acct_obj_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, acct_obj_srch_iflistp, &acct_obj_srch_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_acct_obj:"
			" input flist ", acct_obj_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_WRITEOFF, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_acct_obj:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff_acct_obj Search:"
		"return flist", acct_obj_srch_rflistp);
	

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&acct_obj_srch_iflistp, NULL);
	*ret_flistpp = acct_obj_srch_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_writeoff_acct_obj final flist", *ret_flistpp);
	return;
}


void
fm_tab_ar_get_writeoff_transid_acctobj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*transid_acctobj_srch_iflistp = NULL;
	pin_flist_t		*transid_acctobj_srch_rflistp = NULL;
	char			*acct_obj =NULL;
	poid_t			*srchp  = NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*writeoff_flistp=NULL;
	char			*trans_id = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_transid_acctobj:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_writeoff_transid_acctobj function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_writeoff_transid_acctobj:input flist",in_flistp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	trans_id=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	
	/*Sample Search Input Flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] " select X from /event/billing/writeoff where F1 = V1 and F2 = V2 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2065283 0
	0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	1 	  TAB_FLD_WRITEOFF_INFO  ARRAY [0] allocated 20, used 2
	2     	  PIN_FLD_TRANS_ID        STR [0] "E-12AL"
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1     PIN_FLD_POID           POID [0] NULL poid pointer
	1     PIN_FLD_ACCOUNT_OBJ POID [0] NULL poid pointer*/

	transid_acctobj_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(transid_acctobj_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(transid_acctobj_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event/billing/writeoff where F1 = V1 and F2 = V2";
	PIN_FLIST_FLD_SET(transid_acctobj_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	
	args_flistp = PIN_FLIST_ELEM_ADD(transid_acctobj_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_obj, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(transid_acctobj_srch_iflistp, PIN_FLD_ARGS, 2, ebufp);
	writeoff_flistp = PIN_FLIST_ELEM_ADD(args_flistp, TAB_FLD_WRITEOFF_INFO, 0, ebufp);
	PIN_FLIST_FLD_SET(writeoff_flistp, PIN_FLD_TRANS_ID, trans_id, ebufp);

	srch_res_flistp = PIN_FLIST_ELEM_ADD(transid_acctobj_srch_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ITEM_OBJ, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff_transid_acctobj Search:"
		"input flist", transid_acctobj_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, transid_acctobj_srch_iflistp, &transid_acctobj_srch_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_transid_acctobj:"
			" input flist ", transid_acctobj_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_WRITEOFF, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_writeoff_transid_acctobj:"
			" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_writeoff_transid_acctobj Search:"
		"return flist", transid_acctobj_srch_rflistp);

cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&transid_acctobj_srch_iflistp, NULL);
	*ret_flistpp = transid_acctobj_srch_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_get_writeoff_transid final flist", *ret_flistpp);
	return;
}

