/*******************************************************************************
* This material is the confidential property of Telenor/Oracle Corporation or its
* licensors and may be used, reproduced, stored or transmitted only in
* accordance with a valid agreement.
********************************************************************************/

/*************************************************************************************************
 *Change History	 
 * |No	| Date		| Programmer		| Req/bug/Gap		| Change details 
 *					
 * | 1	| 17-Feb-2022	| Madhavi Dandi 	|			| New file.
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_UPDATE_PAYTYPE operation. 
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "fm_bal.h"
#include "pin_pymt.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "tab_utils_common.h"

EXPORT_OP void 
op_tab_ar_update_paytype(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
		
void 
fm_tab_ar_update_paytype(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_update_paytype_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*create_paytype_oflistp,
	pin_flist_t		*set_billinfo_oflistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_create_external_paytype(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
		
static void
fm_tab_ar_create_paytype_invoice(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void		
fm_tab_ar_create_paytype_subords(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_update_paytype_set_billinfo(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

 /**
 *
 * New opcode TAB_OP_AR_UPDATE_PAYTYPE is implemented to 
 * update pay_type of a account.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_PAY_TYPE,
 * PIN_FLD_PAYINFO ,PIN_FLD_MSISDN and PIN_FLD_ACCOUNT_NO .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_ACCOUNT_NO           STR [0] "OGC_12345"
 * 0 PIN_FLD_MSISDN           STR [0] "987778900"
 * 0 PIN_FLD_PAY_TYPE   ENUM [0] 10003
 * 0 PIN_FLD_PAYINFO       ARRAY [0] allocated 20, used 4
 * 1	PIN_FLD_CC_INFO       ARRAY [0] allocated 20, used 9
 * 2		TAB_OP_CUST_OPERATION_TYPE	STR [0] "1"
 * 2		PIN_FLD_BANK_CODE	STR [0] "1"
 * 2		PIN_FLD_BANK_NO	STR [0] "1"
 * 2		PIN_FLD_NAME	STR [0] "Johny Boy"
 * 2		PIN_FLD_DEBIT_EXP       STR [0] "XXXX"
 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
 * 2		PIN_FLD_CHANNEL         STR [0] "Bangkok, Thailand"
 * 1	PIN_FLD_DD_INFO       ARRAY [0] allocated 20, used 9
 * 2		TAB_OP_CUST_OPERATION_TYPE	STR [0] "1"
 * 2		PIN_FLD_BANK_CODE	STR [0] "1"
 * 2		PIN_FLD_BANK_NO	STR [0] "1"
 * 2		PIN_FLD_NAME	STR [0] "Johny Boy"
 * 2		PIN_FLD_BRANCH_NO       STR [0] "SYP Road"
 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
 * 2		PIN_FLD_CHANNEL         STR [0] "Bangkok, Thailand"
 * 1	PIN_FLD_PAYMENT       SUBSTRUCT [0] allocated 20, used 9
 * 2		TAB_OP_CUST_CARD_TYPE	STR [0] "1"
 * 2		PIN_FLD_BANK_NAME	STR [0] "1"
 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
 * 2		PIN_FLD_DEBIT_EXP       STR [0] "XXXX"
 * 2		TAB_OP_CUST_DIGITAL_ID	STR [0] "1"
 * 2		PIN_FLD_DEALER_NAME	STR [0] "Johny Boy"
 * 2		PIN_FLD_DEALER_CODE       STR [0] "SYP code"
 * 2		TAB_OP_CUST_TOKEN_ID         STR [0] "23e5ty"
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "12012022611"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 */

void
op_tab_ar_update_paytype(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_update_paytype:"
				"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_update_paytype function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_UPDATE_PAYTYPE) {

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_update_paytype:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_update_paytype bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_update_paytype input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_PAY_TYPE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_PAY_TYPE)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_UPDATE_PAY_TYPE, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
					" input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_paytype:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_update_paytype(ctxp,flags,enrich_iflistp,&r_flistp,db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_paytype error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
					" input flist", enrich_iflistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_update_paytype:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_update_paytype: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
				&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_UPDATE_PAYTYPE", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_update_paytype:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_UPDATE_PAY_TYPE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_UPDATE_PAY_TYPE)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_UPDATE_PAY_TYPE , ebufp);
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_paytype:"
				" output flist", r_flistp);
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
                        PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
        }
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_update_paytype output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to update pay_type for a account.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param flags The opcode flags. 
 * @param db_no Database number.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void
fm_tab_ar_update_paytype(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	int32			*pay_type = NULL;
	pin_flist_t		*create_paytype_rflistp = NULL;
	pin_flist_t		*billinfo_details_rflistp = NULL;
	int32			*existing_paytype = NULL;
	poid_t			*billinfo_pdp = NULL;
	pin_flist_t		*billinfo_readobj_iflistp = NULL;
	pin_flist_t		*billinfo_readobj_rflistp = NULL;
	poid_t			*payinfo_pdp = NULL;
	pin_flist_t		*payinfo_readobj_iflistp = NULL;
	pin_flist_t		*payinfo_readobj_rflistp = NULL;
	pin_flist_t		*set_billinfo_return_flistp = NULL;	
	pin_flist_t		*paytype_res_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	char			*acct_no = NULL;
	char			*msisdn = NULL;
	poid_t			*acct_pdp = NULL;
	pin_flist_t		*payinfo_result = NULL;
	pin_flist_t		*payinfo_resflistp = NULL;
	pin_flist_t     	*find_payinfo_iflistp = NULL;
	pin_flist_t     	*find_payinfo_rflistp = NULL;
	poid_t			*find_payinfo_pdp = NULL;
	pin_flist_t		*r_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_paytype:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_update_paytype function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_paytype input flist", in_flistp);
	pay_type = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);

	/*validating Mandatory fields*/
	if((acct_no == NULL || strlen(acct_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_paytype:"
				"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	if (pay_type == NULL || *pay_type <= 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_update_paytype:"
			"input flist", in_flistp);	
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PAYTYPE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
			"Error PIN_FLD_PAY_TYPE - Input is missing", ebufp);
		goto cleanup;
	}

	if(*pay_type == PIN_PAY_TYPE_PREPAID)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_PAYMENT_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
			"Error PIN_FLD_PAY_TYPE is Prepaid", ebufp);
		goto cleanup;

	}

	acct_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	/*Check existing pay_type for the account*/
	fm_tab_utils_common_get_billinfo(ctxp, acct_pdp,0,&billinfo_details_rflistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo:"
			" Error while getting billinfo object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Existing Paytype for the account:"
			"return flist", billinfo_details_rflistp);
	PIN_FLIST_FLD_COPY(billinfo_details_rflistp, PIN_FLD_PAY_TYPE,in_flistp, TAB_FLD_OLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,billinfo_details_rflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	if(billinfo_details_rflistp != NULL)
	{
		existing_paytype = PIN_FLIST_FLD_GET(billinfo_details_rflistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if(*existing_paytype == PIN_PAY_TYPE_PREPAID)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_PAYMENT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Existing Paytype for the account:"
				"Error PIN_FLD_PAY_TYPE is Prepaid", ebufp);
			goto cleanup;
		}
	}
	billinfo_pdp = PIN_FLIST_FLD_GET(billinfo_details_rflistp, PIN_FLD_POID, 1, ebufp);

	billinfo_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET (billinfo_readobj_iflistp, PIN_FLD_POID, billinfo_pdp, ebufp);
	/*READ_OBJ of BILLINFO poid*/
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0,billinfo_readobj_iflistp, &billinfo_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
			"input flist ",billinfo_readobj_iflistp );
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:Error "
			"while doing READ_OBJ of billinfo_pdp and get PIN_FLD_PAYINFO_OBJ:",ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_READ_OBJ of Billinfo_pdp:"
		"return flist", billinfo_readobj_rflistp);
	payinfo_pdp = PIN_FLIST_FLD_GET(billinfo_readobj_rflistp, PIN_FLD_PAYINFO_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(payinfo_pdp))
	{
		/*To get Payinfo Details using PCM_OP_CUST_FIND_PAYINFO*/
		find_payinfo_iflistp = PIN_FLIST_CREATE(ebufp);
		find_payinfo_pdp = PIN_POID_CREATE(db_no, "/payinfo", -1, ebufp);
		PIN_FLIST_FLD_PUT(find_payinfo_iflistp, PIN_FLD_POID,find_payinfo_pdp ,ebufp);
		PIN_FLIST_FLD_SET (find_payinfo_iflistp, PIN_FLD_ACCOUNT_OBJ, acct_pdp, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_FIND_PAYINFO:input flist", find_payinfo_iflistp);
		PCM_OP(ctxp, PCM_OP_CUST_FIND_PAYINFO, 0,find_payinfo_iflistp, &find_payinfo_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"input flist ",find_payinfo_iflistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:Error"
				"while finding payinfo",ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_FIND_PAYINFO:return flist", find_payinfo_rflistp);
		payinfo_resflistp= PIN_FLIST_ELEM_GET(find_payinfo_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 0,ebufp);
		if(payinfo_resflistp != NULL)
		{
			payinfo_pdp = PIN_FLIST_FLD_GET(payinfo_resflistp, PIN_FLD_POID, 1, ebufp);
		}
 	}
	/*ReadObj of payinfo*/
	fm_tab_utils_common_read_object(ctxp,payinfo_pdp,&payinfo_result,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
    	{
        	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
            		"input flist ",payinfo_readobj_iflistp );
        	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:Error"
            		"while doing READ_OBJ of payinfo_pdp",ebufp);
        	goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"payinfo PCM_OP_READ_OBJ:return flist", payinfo_result);
	PIN_FLIST_FLD_COPY(payinfo_result,PIN_FLD_PAYMENT_OFFSET,in_flistp,PIN_FLD_PAYMENT_OFFSET,ebufp);
	PIN_FLIST_FLD_COPY(payinfo_result,PIN_FLD_PAYMENT_TERM, in_flistp,PIN_FLD_PAYMENT_TERM, ebufp);
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
    PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	/*Update_Paytype*/
	if(*pay_type == PIN_PAY_TYPE_CC || *pay_type == PIN_PAY_TYPE_DD || *pay_type == TAB_PAY_TYPE_AUTOPAY)
	{
		fm_tab_ar_create_external_paytype(ctxp, flags, in_flistp, &create_paytype_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype:"
				"Error while updating Paytype", ebufp);
			*ret_flistpp = create_paytype_rflistp;
			goto cleanup;
		}
	}
	else if(*pay_type == PIN_PAY_TYPE_INVOICE)
	{
		fm_tab_ar_create_paytype_invoice(ctxp, flags, in_flistp, &create_paytype_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"Error while updating Paytype", ebufp);
			*ret_flistpp = create_paytype_rflistp;
			goto cleanup;
		}	
	}
	else if(*pay_type == PIN_PAY_TYPE_SUBORD)
	{
		fm_tab_ar_create_paytype_subords(ctxp, flags, in_flistp, &create_paytype_rflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
				"Error while updating Paytype", ebufp);
			*ret_flistpp = create_paytype_rflistp;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_PAYMENT_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
			"Error Invalid Paytype is provided in Request", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_create_paytype: return flist",create_paytype_rflistp);	

	/* Calling SET_BILLINFO*/
	if(*pay_type == PIN_PAY_TYPE_CC || *pay_type == PIN_PAY_TYPE_DD || 
			*pay_type == TAB_PAY_TYPE_AUTOPAY || *pay_type == PIN_PAY_TYPE_INVOICE)
	{
		paytype_res_flistp = PIN_FLIST_ELEM_GET(create_paytype_rflistp,PIN_FLD_RESULTS,
				PIN_ELEMID_ANY,1,ebufp);
		if(paytype_res_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(paytype_res_flistp,PIN_FLD_POID, billinfo_details_rflistp,
					PIN_FLD_PAYINFO_OBJ,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PAY_TYPE, billinfo_details_rflistp,
                                        TAB_FLD_NEW_PAY_TYPE,ebufp);
			fm_tab_ar_update_paytype_set_billinfo(ctxp, flags,billinfo_details_rflistp, 
					&set_billinfo_return_flistp, db_no, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype_set_billinfo:"
					"input flist ",billinfo_details_rflistp );
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype_set_billinfo:"
					"Error while Setting Billinfo", ebufp);
				*ret_flistpp = set_billinfo_return_flistp;
				goto cleanup;
			}
		}
	}
	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	/*Call function to enrich notification details*/
	fm_tab_ar_update_paytype_notification(ctxp, in_flistp,create_paytype_rflistp,set_billinfo_return_flistp,
		db_no,&notify_oflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype:"
			" fm_tab_ar_update_paytype_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype: "
			" fm_tab_ar_update_paytype_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *ret_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*ret_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}


cleanup:
	/******************************************************************
	 *          * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&payinfo_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&payinfo_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&find_payinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&find_payinfo_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_details_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;

}

static void
fm_tab_ar_create_external_paytype(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*payinfo_flistp = NULL;
	pin_flist_t		*hook_paytype_iflistp = NULL;
	pin_flist_t		*hook_paytype_rflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype"
			"function entry error", ebufp);
		return;
	}
	/* Sample Input Flist
	 * 0 PIN_FLD_ACCOUNT_NO           STR [0] "OGC_12345"
	 * 0 PIN_FLD_MSISDN           STR [0] "987778900"
	 * 0 PIN_FLD_PAY_TYPE   ENUM [0] 10003
	 * 0 PIN_FLD_PAYINFO       ARRAY [0] allocated 20, used 4
	 * 1	PIN_FLD_CC_INFO       ARRAY [0] allocated 20, used 9
	 * 2		TAB_OP_CUST_OPERATION_TYPE	STR [0] "1"
	 * 2		PIN_FLD_BANK_CODE	STR [0] "1"
	 * 2		PIN_FLD_BANK_NO	STR [0] "1"
	 * 2		PIN_FLD_NAME	STR [0] "Johny Boy"
	 * 2		PIN_FLD_DEBIT_EXP       STR [0] "XXXX"
	 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
	 * 2		PIN_FLD_CHANNEL         STR [0] "Bangkok, Thailand"
	 * 1	PIN_FLD_DD_INFO       ARRAY [0] allocated 20, used 9
	 * 2		TAB_OP_CUST_OPERATION_TYPE	STR [0] "1"
	 * 2		PIN_FLD_BANK_CODE	STR [0] "1"
	 * 2		PIN_FLD_BANK_NO	STR [0] "1"
	 * 2		PIN_FLD_NAME	STR [0] "Johny Boy"
	 * 2		PIN_FLD_BRANCH_NO       STR [0] "SYP Road"
	 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
	 * 2		PIN_FLD_CHANNEL         STR [0] "Bangkok, Thailand"
	 * 1	PIN_FLD_PAYMENT       SUBSTRUCT [0] allocated 20, used 9
	 * 2		TAB_OP_CUST_CARD_TYPE	STR [0] "1"
	 * 2		PIN_FLD_BANK_NAME	STR [0] "1"
	 * 2		PIN_FLD_DEBIT_NUM       STR [0] "XXXX"
	 * 2			PIN_FLD_DEBIT_EXP       STR [0] "XXXX"
	 * 2		TAB_OP_CUST_DIGITAL_ID	STR [0] "1"
	 * 2		PIN_FLD_DEALER_NAME	STR [0] "Johny Boy"
	 * 2		PIN_FLD_DEALER_CODE       STR [0] "SYP code"
	 * 2		TAB_OP_CUST_TOKEN_ID         STR [0] "23e5ty"
	 * 0 PIN_FLD_CORRELATION_ID      STR [0] "12012022611"
	 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"*/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_create_external_paytype:input flist",in_flistp);
	payinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_PAYINFO, PIN_ELEMID_ANY, 1, ebufp);	
	hook_paytype_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

	if(payinfo_flistp != NULL)
	{
		/*Calling Hook Opcode*/
		PCM_OP(ctxp, TAB_OP_AR_POL_CREATE_PAYTYPE, 0, hook_paytype_iflistp, &hook_paytype_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_create_paytype:"
				"TAB_OP_AR_POL_CREATE_PAYTYPE Hook opcode prepare Input flist",hook_paytype_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_create_paytype:"
				"TAB_OP_AR_POL_CREATE_PAYTYPE Hook opcode prepare input flist error", ebufp);
			*ret_flistpp = hook_paytype_rflistp;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_PAYINFO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_external_paytype:"
			"Error Payinfo Array is missing", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_create_external_paytype:"
		"return flist", hook_paytype_rflistp);

cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&hook_paytype_iflistp, NULL);

	*ret_flistpp = hook_paytype_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_create_external_paytype:"
		"output flist", *ret_flistpp);
	return;

}


static void
fm_tab_ar_create_paytype_invoice (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*paytype_inv_iflistp = NULL;
	pin_flist_t		*paytype_inv_rflistp = NULL;
	pin_flist_t		*payinfo_flistp = NULL;
	pin_flist_t		*inherited_flistp = NULL;
	poid_t			*payinfo_pdp = NULL;
	pin_flist_t		*inv_info_flistp = NULL;
	int32			inv_paytype = PIN_PAY_TYPE_INVOICE;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_paytype_invoice:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_create_paytype_invoice function entry error", ebufp);
		return;
	}
	/*Sample Input Flist
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 72376 12
	  0 PIN_FLD_PROGRAM_NAME    STR [0] "<< correlationID|SystemIdentifer >>"
	  0 PIN_FLD_PAYMENT_OFFSET    INT [0] -1
	  0 PIN_FLD_PAYINFO       ARRAY [1] allocated 20, used 5
	  1     PIN_FLD_POID           POID [0] 0.0.0.1 /payinfo/invoice -1 0
	  1	  PIN_FLD_PAYMENT_TERM   ENUM [0] 0
	  1     PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 1
	  2         PIN_FLD_INV_INFO      ARRAY [0] allocated 20, used 3
	  3             PIN_FLD_DELIVERY_PREFER   ENUM [0] 0
	  1     PIN_FLD_PAY_TYPE       ENUM [0] 10001*/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_create_paytype_invoice:input flist",in_flistp);

	paytype_inv_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, paytype_inv_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, paytype_inv_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYMENT_OFFSET, paytype_inv_iflistp, PIN_FLD_PAYMENT_OFFSET, ebufp);

	payinfo_flistp = PIN_FLIST_ELEM_ADD(paytype_inv_iflistp, PIN_FLD_PAYINFO, 1, ebufp);
	payinfo_pdp = PIN_POID_CREATE(db_no, "/payinfo/invoice", -1, ebufp);
	PIN_FLIST_FLD_PUT(payinfo_flistp, PIN_FLD_POID,payinfo_pdp ,ebufp);

	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PAYMENT_TERM , paytype_inv_iflistp, PIN_FLD_PAYMENT_TERM, ebufp);

	inherited_flistp = PIN_FLIST_SUBSTR_ADD(payinfo_flistp, PIN_FLD_INHERITED_INFO, ebufp);
	inv_info_flistp = PIN_FLIST_ELEM_ADD(inherited_flistp, PIN_FLD_INV_INFO, 0, ebufp);
	PIN_FLIST_FLD_SET(inv_info_flistp,PIN_FLD_DELIVERY_PREFER ,0 , ebufp);

	PIN_FLIST_FLD_SET(payinfo_flistp, PIN_FLD_PAY_TYPE, (void *)&inv_paytype ,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_PAYINFO: input flist",paytype_inv_iflistp);
	/*Calling PCM_OP_CUST_SET_PAYINFO*/
	PCM_OP (ctxp, PCM_OP_CUST_SET_PAYINFO, 0, paytype_inv_iflistp, &paytype_inv_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_paytype_invoice:"
			" input flist ", paytype_inv_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_UPDATE_PAY_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_paytype_invoice:"
			"Error while Updating to Invoice Paytype", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_PAYINFO: return flist",paytype_inv_rflistp);


cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&paytype_inv_iflistp, NULL);

	*ret_flistpp = paytype_inv_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_create_paytype_invoice final flist", *ret_flistpp);
	return;
}



static void
fm_tab_ar_create_paytype_subords(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*prnt_iflistp = NULL;
	pin_flist_t		*prnt_rflistp = NULL;
	pin_flist_t		*context_flistp = NULL;
	poid_t			*parent_acct_no = NULL;
	pin_flist_t		*prnt_billinfo_rflistp = NULL;
	pin_flist_t		*set_billinfo_iflistp = NULL;
	pin_flist_t		*set_billinfo_rflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	int32			active_flag = 1;
	int32			subord_paytype = PIN_PAY_TYPE_SUBORD;
	poid_t			*acct_obj = NULL;
	pin_flist_t		*child_billinfo_rflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_paytype_subords:input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_create_paytype_subords function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_create_paytype_subords:input flist",in_flistp);
	/*Sample flist for PCM_OP_BILL_GROUP_GET_PARENT
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 8242387 0
	  0 PIN_FLD_CONTEXT_INFO      SUBSTRUCT [0]
	  1 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
	  1 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"*/

	prnt_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,prnt_iflistp , PIN_FLD_POID, ebufp);

	context_flistp = PIN_FLIST_SUBSTR_ADD(prnt_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_BILL_GROUP_GET_PARENT: input flist",prnt_iflistp );
	/*Calling PCM_OP_BILL_GROUP_GET_PARENT*/
	PCM_OP (ctxp, PCM_OP_BILL_GROUP_GET_PARENT, 0, prnt_iflistp, &prnt_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Get Parent:"
			" input flist ", prnt_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_UPDATE_PAY_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Get Parent:"
			"Error while getting Parent Information", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_BILL_GROUP_GET_PARENT: return flist",prnt_rflistp );
	acct_obj = PIN_FLIST_FLD_GET(prnt_rflistp, PIN_FLD_POID, 1, ebufp);
	parent_acct_no = PIN_FLIST_FLD_GET(prnt_rflistp, PIN_FLD_PARENT, 1, ebufp);
	if(parent_acct_no == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_create_paytype_subords:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_PARENT_DATA_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_create_paytype_subords: Error Parent NOT found", ebufp);
		goto cleanup;
	}
	/*Getting child Account Billinfo details*/
	fm_tab_utils_common_get_billinfo(ctxp, acct_obj, active_flag, &child_billinfo_rflistp,db_no, ebufp);
        if(PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo input flist",in_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Child Billinfo details Error: "
                        "fm_tab_utils_common_get_billinfo error", ebufp);
                goto cleanup;
        }
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Child Acct Billinfo details output flist",child_billinfo_rflistp);
	/* Getting parent Account Billinfo details*/
	fm_tab_utils_common_get_billinfo(ctxp, parent_acct_no, active_flag, &prnt_billinfo_rflistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Parent Billinfo details Error: "
			"fm_tab_utils_common_get_billinfo error", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parent Acct Billinfo details output flist",prnt_billinfo_rflistp);
	if((prnt_billinfo_rflistp == NULL) || (child_billinfo_rflistp == NULL))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_create_paytype_subords input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_create_paytype_subords:"
			"Error in getting billinfo details", ebufp);
		goto cleanup;
	}
	/*Calling PCM_OP_CUST_SET_BILLINFO 
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 8242387 14
	  0 PIN_FLD_PROGRAM_NAME    STR [0] "<< correlationID|SystemIdentifer >>"
	  0 PIN_FLD_BILLINFO      ARRAY [0] allocated 20, used 5
	  1     PIN_FLD_POID           POID [0] 0.0.0.1 /billinfo 8243923 18
	  1     PIN_FLD_PARENT_BILLINFO_OBJ   POID [0] 0.0.0.1 /billinfo 8245411 22
	  1     PIN_FLD_PAY_TYPE       ENUM [0] 10007
	  1     PIN_FLD_AR_BILLINFO_OBJ   POID [0] 0.0.0.1 /billinfo 8245411 2
	  1     PIN_FLD_PAYINFO_OBJ    POID [0] 0.0.0.0 / 0 0*/



	set_billinfo_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, set_billinfo_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME , set_billinfo_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	billinfo_flistp = PIN_FLIST_ELEM_ADD( set_billinfo_iflistp, PIN_FLD_BILLINFO, 0, ebufp);
	PIN_FLIST_FLD_COPY(child_billinfo_rflistp, PIN_FLD_POID, billinfo_flistp ,PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(prnt_billinfo_rflistp, PIN_FLD_POID, billinfo_flistp ,PIN_FLD_PARENT_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(prnt_billinfo_rflistp, PIN_FLD_POID, billinfo_flistp ,PIN_FLD_AR_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_SET(billinfo_flistp, PIN_FLD_PAY_TYPE, (void *)&subord_paytype ,ebufp);
	PIN_FLIST_FLD_COPY(prnt_billinfo_rflistp, PIN_FLD_PAYINFO_OBJ, billinfo_flistp ,PIN_FLD_PAYINFO_OBJ,ebufp);


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_BILLINFO: input flist",set_billinfo_iflistp );
	/*Calling PCM_OP_CUST_SET_BILLINFO*/
	PCM_OP (ctxp, PCM_OP_CUST_SET_BILLINFO, 0, set_billinfo_iflistp, &set_billinfo_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Set Billinfo :"
			"input flist ", set_billinfo_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_UPDATE_PAY_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Set Billinfo:"
			"Error while setting billinfo Information", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_BILLINFO: return flist",set_billinfo_rflistp );


cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&set_billinfo_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&prnt_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&prnt_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&child_billinfo_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&prnt_billinfo_rflistp, NULL);
	*ret_flistpp = set_billinfo_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_create_paytype_subords final flist", *ret_flistpp);
	return;
}



static void
fm_tab_ar_update_paytype_set_billinfo (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*setbillinfo_iflistp = NULL;
	pin_flist_t		*setbillinfo_rflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype_set_billinfo:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_update_paytype_set_billinfo function entry error", ebufp);
		return;
	}
	/*Sample Input Flist
	  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 4159801 12
	  0 PIN_FLD_PROGRAM_NAME    STR [0] "<< correlationID|SystemIdentifer >>"
	  0 PIN_FLD_BILLINFO      ARRAY [0] allocated 20, used 5
	  1     PIN_FLD_POID           POID [0] 0.0.0.1 /billinfo 4158265 21
	  1     PIN_FLD_PARENT_BILLINFO_OBJ   POID [0] 0.0.0.0 / 0 0
	  1     PIN_FLD_PAY_TYPE       ENUM [0] 10003
	  1     PIN_FLD_AR_BILLINFO_OBJ   POID [0] 0.0.0.1 /billinfo 4158265 21
	  1     PIN_FLD_PAYINFO_OBJ    POID [0] 0.0.0.1 /payinfo/cc 32777409 0*/

	setbillinfo_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_paytype_set_billinfo:input flist",in_flistp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, setbillinfo_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_PROGRAM_NAME,setbillinfo_iflistp,PIN_FLD_PROGRAM_NAME,ebufp);

	billinfo_flistp = PIN_FLIST_ELEM_ADD(setbillinfo_iflistp, PIN_FLD_BILLINFO, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, billinfo_flistp ,PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,billinfo_flistp ,
			PIN_FLD_PARENT_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_NEW_PAY_TYPE, billinfo_flistp ,PIN_FLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, billinfo_flistp ,
			PIN_FLD_AR_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PAYINFO_OBJ, billinfo_flistp ,PIN_FLD_PAYINFO_OBJ, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_BILLINFO: input flist",setbillinfo_iflistp);
	/*Calling PCM_OP_CUST_SET_BILLINFO*/
	PCM_OP (ctxp, PCM_OP_CUST_SET_BILLINFO, 0, setbillinfo_iflistp, &setbillinfo_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype_set_billinfo:"
				"input flist ", setbillinfo_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_UPDATE_PAY_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_update_paytype_set_billinfo:"
				"Error while setting BILLINFO", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_CUST_SET_BILLINFO: return flist",setbillinfo_rflistp);


cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&setbillinfo_iflistp, NULL);

	*ret_flistpp = setbillinfo_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_set_billinfo:"
		"output flist", *ret_flistpp);
	return;

}


/*************************************************************
 *  This function will prepare the notification flist
 *  based on the  structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_UPDATE_PAYTYPE for
 *  enrichment and return notification flist
 *************************************************************/
static void
fm_tab_ar_update_paytype_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*create_paytype_oflistp,
	pin_flist_t		*set_billinfo_oflistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*res_data_flistp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_notify_update_paytype"
			"prepare_notification:input flist", i_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_notify_update_paytype"
			"prepare_notification function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_paytype_notification: "
			"input flist", i_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_paytype_notification: "
			"output flist", create_paytype_oflistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_update_paytype_notification: "
			"output flist",set_billinfo_oflistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	temp_flistp = PIN_FLIST_COPY(create_paytype_oflistp, ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	if(set_billinfo_oflistp != NULL)
	{
		res_data_flistp = PIN_FLIST_COPY(set_billinfo_oflistp, ebufp);
		PIN_FLIST_ELEM_PUT(notify_out_flistp, res_data_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	else
	{
		PIN_FLIST_ELEM_SET(notify_out_flistp, NULL, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_UPDATE_PAYTYPE, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_OLD_PAY_TYPE, notify_flistp, TAB_FLD_OLD_PAY_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PAY_TYPE, notify_flistp, TAB_FLD_NEW_PAY_TYPE, ebufp);


	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_paytype_notification:"
		"TAB_OP_NOTIFY_POL_ENRICH_UPDATE_PAYTYPE input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_UPDATE_PAYTYPE, 0,
			notify_iflistp, &enrich_notify_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_update_paytype_notification:"
			"input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_update_paytype_notification:"
			"Error in Notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_update_paytype_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_UPDATE_PAYTYPE output flist ", enrich_notify_flistp);


cleanup:
	/******************************************************************
	Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_update_paytype_notification output flist", *r_flistpp);

	return;
}

