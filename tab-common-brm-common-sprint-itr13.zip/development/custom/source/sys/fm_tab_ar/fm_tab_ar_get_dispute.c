/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer    | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 16-Mar-2022   | Rajashekar    |               | New opcode TAB_OP_AR_GET_DISPUTE 
 *				                                            | to to enable raising disputes.
 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_GET_DISPUTE operation. 
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/ar.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_flds.h"
#include "pin_pymt.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP
void
op_tab_ar_get_dispute(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_dispute(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_dispute_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/*** Extern Function ***/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_get_billinfo (
        pcm_context_t           *ctxp,
        poid_t                  *acc_pdp,
        int32                   active_flag,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
        pcm_context_t           *ctxp,
        char                    *str_timestamp,
        pin_errbuf_t            *ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
        pcm_context_t           *ctxp,
        time_t                  *input_time_t,
        pin_errbuf_t            *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_AR_GET_DISPUTE operation.
 *************************************************************************/
/**
 * *
 * New opcode TAB_OP_AR_GET_DISPUTE is implemented to
 * enable raising disputes 
 * 
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains 
 * PIN_FLD_ACCOUNT_NO, PIN_FLD_MSISDN,PIN_FLD_BILL_NO,PIN_FLD_AMOUNT ,
 * PIN_FLD_REASON_DOMAIN_ID,PIN_FLD_REASON_ID,PIN_FLD_USER_NAME,PIN_FLD_TRANS_ID,
 * PIN_FLD_FLAGS,PIN_FLD_LOCATION ,PIN_FLD_CODE,PIN_FLD_DESCR 
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 * 
 * Sample Input Flist
 * 0 PIN_FLD_POID                POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "0.0.0.1-2616577"
 * 0 PIN_FLD_BILL_NO                STR [0] "B1-77"
 * 0 TAB_FLD_START_T_STR	STR [0] "03-FEB-2022 00:01:08"
 * 0 TAB_FLD_END_T_STR		STR [0] "03-MAR-2022 00:01:08"
 * 0 PIN_FLD_TRANS_ID     STR [0] “NEW-12AL”
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 **/

void 
op_tab_ar_get_dispute(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*trans_order_oflistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_ar_get_dispute"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_dispute function entry error",ebufp);
		return;
	}

	*out_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_GET_DISPUTE) 
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_dispute"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_dispute bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_dispute input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp,PIN_ERRLOC_CM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL,0,0,0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"input flist",in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,cerror_code, 
			&r_flistp, db_no,ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*out_flistpp = r_flistp;
		return;
	}

		/*Common_validate*/
		fm_tab_utils_common_validate_and_normalize_input(ctxp,in_flistp,
			&enrich_iflistp,db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_get_dispute input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute:"
			"fm_tab_utils_common_validate_and_normalize_input output flist",enrich_iflistp);
		/*Calling main function*/
		fm_tab_ar_get_dispute(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_dispute error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
				"in_flistp",in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	
cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
			"Error while getting dispute",ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_DISPUTE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_DISPUTE )
		{
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_CODE,log_msg,ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_GET_DISPUTE,ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*out_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_ar_get_dispute output flist",*out_flistpp);
	PIN_FLIST_DESTROY_EX(&trans_order_oflistp, NULL);
	return;
}

/********************************************
 * We use this function
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void 
fm_tab_ar_get_dispute(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*bill_no = NULL;
	char			*inp_start_date_str=NULL;
	char			*inp_end_date_str=NULL;
	time_t			start_t=0;
	time_t			end_t=0;
	time_t			current_time = pin_virtual_time((time_t *)NULL);
	pin_flist_t		*dispute_srch_rflistp = NULL;
	pin_flist_t		*acct_obj = NULL;
	int32           active_flag = 0;
    int32           paytype_i = 0;
    pin_flist_t     *billinfo_flistp = NULL;
    char            *account_no = NULL;

	bill_no = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILL_NO,1,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute" 
			"function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute"
			"in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute in_flistp", in_flistp);
	
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
    if((account_no && strlen(account_no) == 0) ||
                (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
    {
        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
            TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
            "Account Number is not passed in request", ebufp);
        goto cleanup;
    }
	if((inp_start_date_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_START_T_STR, 1, ebufp))!=NULL)
	{
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_start_date_str, ebufp);
	}

	if((inp_end_date_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_END_T_STR, 1, ebufp))!=NULL)
	{
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_end_date_str, ebufp);
	}

	if(start_t == 0 && end_t == 0)
    {
        end_t = current_time;
        start_t = end_t-ONEDAY*30;
    }
    else if(end_t == 0 && start_t != 0)
    {
        end_t = start_t+ONEDAY*30;
    }
    else if(start_t == 0 && end_t != 0)
    {
        start_t = end_t-ONEDAY*30;
    }

	if(!((end_t - start_t) <= ONEDAY * 30))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_dispute:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INPUT_BEYOND_MAXIMUM_RANGE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
			"Input Dates Beyond Maximum Allowed Range", ebufp);
		goto cleanup;
	}
	PIN_FLIST_FLD_SET(in_flistp,PIN_FLD_START_T,&start_t,ebufp);
	PIN_FLIST_FLD_SET(in_flistp,PIN_FLD_END_T,&end_t,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute input flist", in_flistp);

	acct_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);
	 /*SUBORD paytype checking*/
    fm_tab_utils_common_get_billinfo(ctxp, acct_obj, active_flag, &billinfo_flistp, db_no, ebufp);
    if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                "fm_tab_ar_get_dispute: Error in getting billinfo details", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                "fm_tab_ar_get_dispute input flist", in_flistp);
        goto cleanup;
    }
    paytype_i = *(int *)PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
    if (paytype_i == PIN_PAY_TYPE_SUBORD)
    {
        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                TAB_ERR_CODE_ACCT_NOT_PR , 0, 0, 0);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
                "Error Subord Paytype found for the given account", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute:"
                "Error SubordPaytype  input flist", billinfo_flistp);
        goto cleanup;
    }
	if((bill_no != NULL && strlen(bill_no) != 0) || (acct_obj != NULL))
	{
		dispute_srch_rflistp = PIN_FLIST_CREATE(ebufp);
		fm_tab_ar_get_dispute_search(ctxp,in_flistp,&dispute_srch_rflistp,db_no,ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"final return flist",dispute_srch_rflistp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist ",in_flistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search: "
				"Error while doing bill search/acct poid search", ebufp);
			goto cleanup;
		}
	}
	
	*out_flistpp=PIN_FLIST_COPY(dispute_srch_rflistp,ebufp);

	/******************************************************************
	 * Clean up.
	 ******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX (&dispute_srch_rflistp,NULL);
	return;
}

void 
fm_tab_ar_get_dispute_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*srchp = NULL;
	poid_t			*acct_srchp = NULL;
	poid_t			*res_acct_obj = NULL;
	poid_t			*evnt_billng_disp_p = NULL;
	poid_t			*event_pd = NULL;
	poid_t			*trnfr_pd = NULL;
	poid_t			*account_obj = NULL;
	poid_t			*bill_obj_pd = NULL;
	poid_t			*account_obj_pd = NULL;
	int32			s_flags = 256;
	int32			elem_id = 0;
	void			*vp = NULL;
	void			*descr = NULL;
	void			*temp = NULL;
	void			*item_temp = NULL;
	char			*trans_id = NULL;
	char			*transid = NULL;
	char			*bill_no = NULL;
	char			*bill_number = NULL;
	char			*inp_start_date_str=NULL;
	char			*inp_end_date_str=NULL;
	char			*created_t_str = NULL;
	char			*account_num = NULL;
	char			*poid_typep = NULL;
	time_t			start_t=0;
	time_t			end_t=0;
	time_t			time = 0;
	time_t			created_t = 0;
	pin_flist_t		*dispt_flistp = NULL;
	pin_flist_t		*billno_iflistp = NULL;
	pin_flist_t		*billno_rflistp = NULL;
	pin_flist_t		*transid_iflistp = NULL;
	pin_flist_t		*transid_rflistp = NULL;
	pin_flist_t		*transid_res_flistp = NULL;
	pin_flist_t		*acct_obj = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*srch_iflistp = NULL;
	pin_flist_t		*srch_rflistp = NULL;
	pin_flist_t		*sub_srch_iflistp = NULL;
	pin_flist_t		*disp_flistp = NULL;
	pin_flist_t		*sub_srch_rflistp = NULL;
	pin_flist_t		*results_acctobj_flistp = NULL;
	pin_flist_t		*search_result_flistp = NULL;
	pin_flist_t		*event_bllng_disp_iflistp = NULL;
	pin_flist_t		*event_bllng_disp_rflistp = NULL;
	pin_flist_t		*search_res_flistp = NULL;
	pin_flist_t		*trnsfr_iflistp = NULL;
	pin_flist_t		*trnsfr_rflistp = NULL;
	pin_flist_t		*read_flds_iflistp = NULL;
	pin_flist_t		*read_flds_rflistp = NULL;
	pin_flist_t		*disputes_flistp = NULL;
	pin_flist_t		*action_info_flistp = NULL;
	pin_flist_t		*item_iflistp = NULL;
	pin_flist_t		*item_rflistp = NULL;
	pin_flist_t		*item_result_flistp = NULL;
	pin_flist_t		*read_fields_iflistp = NULL;
	pin_flist_t		*read_fields_rflistp = NULL;
	pin_flist_t		*event_read_obj_iflistp = NULL;
	pin_flist_t		*event_read_obj_rflistp = NULL;
	pin_flist_t		*event_reason_flistp = NULL;
	pin_cookie_t		cookie = NULL;
	pin_decimal_t		*amount = NULL;
	poid_t 			*parent_pdp=NULL;
	poid_t 			*item_pdp=NULL;
	poid_t          *event_srchp  = NULL;
	pin_flist_t		*disp_res_flistp=NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_get_dispute_search function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_bill_acct_search:input flist",in_flistp);

	srch_iflistp = PIN_FLIST_CREATE(ebufp);
	srchp = PIN_POID_CREATE(db_no,"/search",-1,ebufp);
	PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_POID,(void *)srchp,ebufp);
	PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);

	sub_srch_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_POID,(void *)srchp,ebufp);
	PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);

	acct_obj = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);
	trans_id = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_TRANS_ID,1,ebufp);
	bill_no = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILL_NO,1,ebufp);

	inp_start_date_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_START_T_STR,1,ebufp);
	inp_end_date_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_END_T_STR,1,ebufp);
	start_t = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1,ebufp);
	end_t = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1,ebufp);

	if(acct_obj != NULL && bill_no == NULL && trans_id == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"1)With PIN_FLD_ACCOUNT_NO only");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);
		
		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp, PIN_FLD_ARGS,2, ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,zero,ebufp);
		
		parent_pdp =  PIN_POID_FROM_STR("0.0.0.0  0 0", NULL, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,3,ebufp);
		PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, (void *)parent_pdp, ebufp);
	
		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);
	
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);

		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"1)With PIN_FLD_ACCOUNT_NO only subcase");
		vp = (void *)"select X from /event where F1.type = V1 AND F2 = V2";
		PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		evnt_billng_disp_p = PIN_POID_CREATE(db_no,"/event/billing/dispute/bill",-1,ebufp);
		PIN_FLIST_FLD_PUT(args_flistp,PIN_FLD_POID,(void *)evnt_billng_disp_p,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,(void *)&time,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,(void *)&descr,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
	}

	else if(bill_no != NULL && strlen(bill_no) != 0 && acct_obj == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"2)With bill_no only");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_NO,bill_no,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp, PIN_FLD_ARGS,2, ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,zero,ebufp);

		parent_pdp =  PIN_POID_FROM_STR("0.0.0.0  0 0", NULL, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,3,ebufp);
		PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, (void *)parent_pdp, ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;	
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);

		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		if(results_acctobj_flistp == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST,PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_ar_get_dispute: Error Bill number not found in BRM DB",ebufp);
			return;
		}
		else
		{
			res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"2)With bill_no only subcase");
			vp =  (void *)"select X from /event where F1.type = V1 AND F2 = V2";
			PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
			evnt_billng_disp_p = PIN_POID_CREATE(db_no,"/event/billing/dispute/bill",-1,ebufp);
			PIN_FLIST_FLD_PUT(args_flistp,PIN_FLD_POID,(void *)evnt_billng_disp_p,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

			srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,(void *)&time,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,(void *)&descr,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
		}
	}

	else if(acct_obj != NULL && (bill_no != NULL && strlen(bill_no) != 0) && trans_id == NULL 
		&& inp_start_date_str == NULL && inp_end_date_str == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"3)With ACCOUNT_OBJ,BILL_NO only");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3 ";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_NO,bill_no,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,zero,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,3,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);

		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		if (results_acctobj_flistp != NULL)
		{
			res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"3)With ACCOUNT_OBJ, BILL_NO only subcase");
			vp =  (void *)"select X from /event where F1.type = V1 AND F2 = V2";
			PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
			evnt_billng_disp_p = PIN_POID_CREATE(db_no,"/event/billing/dispute/bill",-1,ebufp);
			PIN_FLIST_FLD_PUT(args_flistp,PIN_FLD_POID,(void *)evnt_billng_disp_p,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

			srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute: Error Bill number not found in BRM DB",ebufp);
			return;
		}
	}

	else if(acct_obj != NULL && (bill_no != NULL && strlen(bill_no) != 0) && trans_id == NULL 
		&& (inp_start_date_str != NULL && start_t != 0) || (inp_end_date_str != NULL && end_t != 0))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"4)With ACCOUNT_OBJ, BILL_NO and start_t or end_t only");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0 and F3 = V3 ";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_NO,bill_no,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,zero,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,3,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);
	
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);
		
		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		if (results_acctobj_flistp != NULL)
		{
			res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"4)With ACCOUNT_OBJ,BILL_NO,start_t or"
				"end_t only subcase");
			vp = (void *)"select X from /event where F1 >= V1 AND F2 <= V2 and F3.type = V3 AND F4 = V4";
			PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,&start_t,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,&end_t,ebufp);

			evnt_billng_disp_p = PIN_POID_CREATE(db_no,"/event/billing/dispute/bill",-1,ebufp);
			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,3,ebufp);
			PIN_FLIST_FLD_PUT(args_flistp,PIN_FLD_POID,(void *)evnt_billng_disp_p,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,4,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

			srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute: Error Bill number not found in BRM DB",ebufp);
			return;
		}
	}

	else if(acct_obj != NULL && (bill_no != NULL && strlen(bill_no) != 0) && (trans_id != NULL &&
		 strlen(trans_id) != 0) && inp_start_date_str == NULL && inp_end_date_str == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"5)With ACCOUNT_OBJ,BILL_NO and TRANS_ID");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_NO,bill_no,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_DISPUTED,zero,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);	
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);
	
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);
		
		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		if (results_acctobj_flistp != NULL)
		{
			res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"5)With ACCOUNT_OBJ,BILL_NO and TRANS_ID subcase");
			vp = (void *)"select X from /event/billing/dispute/bill where F1 = V1 AND F2 = V2";
			PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
			disp_flistp = PIN_FLIST_ELEM_ADD(args_flistp,TAB_FLD_DISPUTES,PIN_ELEMID_ANY,ebufp);
			PIN_FLIST_FLD_SET(disp_flistp,PIN_FLD_TRANS_ID,trans_id,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

			srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute: Error Bill number not found in BRM DB",ebufp);
			return;
		}
	}

	else if(acct_obj != NULL && (bill_no != NULL && strlen(bill_no) != 0) && (trans_id != NULL && 
		strlen(trans_id) != 0) && ((inp_start_date_str != NULL && start_t != 0) || 
			(inp_end_date_str != NULL && end_t != 0)))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"6)With ACCOUNT_OBJ,BILL_NO,START_T,END_T and TRANS_ID");
		vp = (void *)"select X from /bill where F1 = V1 and F2 <> 0";
		PIN_FLIST_FLD_SET(srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_NO,bill_no,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_DISPUTED,zero,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"input flist",srch_iflistp);

		PCM_OP(ctxp,PCM_OP_SEARCH,0,srch_iflistp,&srch_rflistp,ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"input flist",srch_iflistp);
			pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
				"Error while doing search:",ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_dispute_search:"
			"return flist",srch_rflistp);
		
		results_acctobj_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS,
			PIN_ELEMID_ANY,1,ebufp);
		if(results_acctobj_flistp != NULL)
		{
			res_acct_obj = PIN_FLIST_FLD_GET(results_acctobj_flistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);

			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"6)With ACCT_OBJ,BILL_NO,STRT_T,END_T,TRANS_ID"
				"subcase");
			vp = (void *)"select X from /event/billing/dispute/bill where F1 = V1 AND F2 = V2 AND F3 >= V3 AND F4 <= V4";
			PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
			disp_flistp = PIN_FLIST_ELEM_ADD(args_flistp,TAB_FLD_DISPUTES,PIN_ELEMID_ANY,ebufp);
			PIN_FLIST_FLD_SET(disp_flistp,PIN_FLD_TRANS_ID,trans_id,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,res_acct_obj,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,3,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,&start_t,ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,4,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T,&end_t,ebufp);

			srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,NULL,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute input flist",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST,PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_get_dispute: Error Bill number not found in BRM DB",ebufp);
			return;
		}
	}

	else if(acct_obj != NULL && (trans_id != NULL && strlen(trans_id) != 0))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "7)With both ACCOUNT_OBJ and TRANS_ID");
		vp = (void *)"select X from /event/billing/dispute/bill where F1 = V1 AND F2 = V2";
		PIN_FLIST_FLD_SET(sub_srch_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,1,ebufp);
		disp_flistp = PIN_FLIST_ELEM_ADD(args_flistp,TAB_FLD_DISPUTES,PIN_ELEMID_ANY,ebufp);
		PIN_FLIST_FLD_SET(disp_flistp,PIN_FLD_TRANS_ID,trans_id,ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_ARGS,2,ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

		srch_res_flistp = PIN_FLIST_ELEM_ADD(sub_srch_iflistp,PIN_FLD_RESULTS,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_CREATED_T,0,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DESCR,NULL,ebufp);
		PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ITEM_OBJ,NULL,ebufp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"sub flist search:input flist",sub_srch_iflistp);
	PCM_OP(ctxp,PCM_OP_SEARCH,0,sub_srch_iflistp,&sub_srch_rflistp,ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"sub_srch_rflistp return flist",sub_srch_rflistp);
	disp_res_flistp = PIN_FLIST_ELEM_GET(sub_srch_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if(disp_res_flistp == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
			"input flist",sub_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_DISPUTE_FOUND,0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
			"No Dispute found for the given Input",ebufp);
		goto cleanup;
	}
	
	disputes_flistp = PIN_FLIST_CREATE(ebufp);
	acct_srchp = PIN_POID_CREATE(db_no,"/account",-1,ebufp);
	PIN_FLIST_FLD_PUT(disputes_flistp,PIN_FLD_POID,(void *)acct_srchp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_ACCOUNT_NO,disputes_flistp,PIN_FLD_ACCOUNT_NO,ebufp);
	
	elem_id = 0;
	cookie = NULL;
	while((search_result_flistp = PIN_FLIST_ELEM_GET_NEXT(sub_srch_rflistp,PIN_FLD_RESULTS,
		&elem_id,1,&cookie,ebufp)) != (pin_flist_t *)NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"inside while");
		dispt_flistp=PIN_FLIST_ELEM_ADD(disputes_flistp,PIN_FLD_DISPUTES,elem_id,ebufp);
		event_pd = PIN_FLIST_FLD_GET(search_result_flistp,PIN_FLD_POID,1,ebufp);
		item_pdp = PIN_FLIST_FLD_GET(search_result_flistp,PIN_FLD_ITEM_OBJ,1,ebufp);
		poid_typep = (char *)PIN_POID_GET_TYPE(event_pd);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, poid_typep);

		if(poid_typep && (strcmp(poid_typep,"/event/billing/dispute/bill") == 0))
		{
			event_bllng_disp_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(event_bllng_disp_iflistp,PIN_FLD_POID,(void *)srchp,ebufp);
			PIN_FLIST_FLD_SET(event_bllng_disp_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);
			temp =  (void *)"select X from /event where F1 = V1 and F2 = V2";
			PIN_FLIST_FLD_SET(event_bllng_disp_iflistp,PIN_FLD_TEMPLATE,temp,ebufp);
			args_flistp = PIN_FLIST_ELEM_ADD(event_bllng_disp_iflistp,PIN_FLD_ARGS,1,ebufp);
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ITEM_OBJ,item_pdp,ebufp);
			args_flistp = PIN_FLIST_ELEM_ADD(event_bllng_disp_iflistp,PIN_FLD_ARGS,2,ebufp);
			event_srchp = PIN_POID_CREATE(db_no, "/event/billing/item/transfer", -1, ebufp);
			PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)event_srchp, ebufp);
			srch_res_flistp = PIN_FLIST_ELEM_ADD(event_bllng_disp_iflistp,
				PIN_FLD_RESULTS,0,ebufp);
			PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);	

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"event_bllng_disp_iflistp input flist",
				event_bllng_disp_iflistp);
			PCM_OP(ctxp,PCM_OP_SEARCH,0,event_bllng_disp_iflistp,&event_bllng_disp_rflistp,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
					" input flist ", sub_srch_iflistp);
				pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
					"Error while doing search:",ebufp);
				goto cleanup;
			}

			PIN_FLIST_DESTROY_EX (&event_bllng_disp_iflistp,NULL);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"event_bllng_disp_rflistp return flist",
					event_bllng_disp_rflistp);

			search_res_flistp = PIN_FLIST_ELEM_GET(event_bllng_disp_rflistp,
				PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
			trnfr_pd = PIN_FLIST_FLD_GET(search_res_flistp,PIN_FLD_POID,1,ebufp);
			poid_typep = (char *)PIN_POID_GET_TYPE(trnfr_pd);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, poid_typep);	

			if(poid_typep && (strcmp(poid_typep,"/event/billing/item/transfer") == 0))
			{
				trnsfr_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(trnsfr_iflistp,PIN_FLD_POID,trnfr_pd,ebufp);
				PIN_FLIST_FLD_SET(trnsfr_iflistp,PIN_FLD_AMOUNT,0,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"trnsfr_iflistp input flist",
					trnsfr_iflistp);
				PCM_OP(ctxp,PCM_OP_READ_OBJ,0,trnsfr_iflistp,&trnsfr_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist", sub_srch_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"trnsfr_rflistp return flist",
					trnsfr_rflistp);			
				account_obj = PIN_FLIST_FLD_GET(trnsfr_rflistp,PIN_FLD_ACCOUNT_OBJ,1,ebufp);
				read_flds_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(read_flds_iflistp,PIN_FLD_POID,account_obj,ebufp);
				PIN_FLIST_FLD_SET(read_flds_iflistp,PIN_FLD_ACCOUNT_NO,NULL,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"read_flds_iflistp input flist",
					read_flds_iflistp);
				PCM_OP(ctxp,PCM_OP_READ_FLDS,0,read_flds_iflistp,&read_flds_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist ", sub_srch_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}

				PIN_FLIST_DESTROY_EX (&read_flds_iflistp,NULL);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"read_flds_rflistp return flist",
					read_flds_rflistp);
				action_info_flistp = PIN_FLIST_ELEM_GET(trnsfr_rflistp,PIN_FLD_ACTION_INFO,
					PIN_ELEMID_ANY,1,ebufp);
				bill_obj_pd = PIN_FLIST_FLD_GET(action_info_flistp,PIN_FLD_AR_BILL_OBJ,
					1,ebufp);
				billno_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(billno_iflistp,PIN_FLD_POID,bill_obj_pd,ebufp);
				PIN_FLIST_FLD_SET(billno_iflistp,PIN_FLD_BILL_NO,NULL,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"billno_iflistp input flist",
					billno_iflistp);
				PCM_OP(ctxp,PCM_OP_READ_OBJ,0,billno_iflistp,&billno_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist", billno_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}

				PIN_FLIST_DESTROY_EX (&billno_iflistp,NULL);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"billno_rflistp return flist",
					billno_rflistp);
				bill_number = PIN_FLIST_FLD_GET(billno_rflistp,PIN_FLD_BILL_NO,1,ebufp);

				transid_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(transid_iflistp,PIN_FLD_POID,event_pd,ebufp);
				PIN_FLIST_FLD_SET(transid_iflistp,PIN_FLD_TRANS_ID,NULL,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"transid_iflistp input flist",
					transid_iflistp);
				PCM_OP(ctxp,PCM_OP_READ_OBJ,0,transid_iflistp,&transid_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist",transid_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}
				PIN_FLIST_DESTROY_EX (&transid_iflistp,NULL);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"transid_rflistp return flist",
					transid_rflistp);
				transid_res_flistp = PIN_FLIST_ELEM_GET(transid_rflistp,TAB_FLD_DISPUTES,
					PIN_ELEMID_ANY,1,ebufp);
				transid = PIN_FLIST_FLD_GET(transid_res_flistp,PIN_FLD_TRANS_ID,1,ebufp);
				amount = PIN_FLIST_FLD_GET(action_info_flistp,PIN_FLD_AMOUNT,1,ebufp);
				PIN_FLIST_FLD_SET(dispt_flistp,PIN_FLD_BILL_NO,bill_number,ebufp);
				PIN_FLIST_FLD_SET(dispt_flistp,PIN_FLD_AMOUNT,amount,ebufp);
				PIN_FLIST_FLD_SET(dispt_flistp,PIN_FLD_TRANS_ID,transid,ebufp);

				created_t = (time_t)PIN_FLIST_FLD_GET(search_result_flistp,
					PIN_FLD_CREATED_T,1,ebufp);
				if( created_t != 0)
				{
					created_t_str = (char*)fm_tab_utils_common_convert_timestamp_to_date
						(ctxp,&created_t,ebufp);
					PIN_FLIST_FLD_PUT(dispt_flistp,TAB_FLD_CREATED_T_STR,
						created_t_str,ebufp);						
				}
				PIN_FLIST_FLD_COPY(search_result_flistp,PIN_FLD_DESCR,dispt_flistp,
					PIN_FLD_DESCR,ebufp);

				item_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(item_iflistp,PIN_FLD_POID,(void *)srchp,ebufp);
				PIN_FLIST_FLD_SET(item_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);
				item_temp = (void *)"select X from /item where F1 = V1 and F2 <> 0";
				PIN_FLIST_FLD_SET(item_iflistp,PIN_FLD_TEMPLATE,item_temp,ebufp);
				args_flistp = PIN_FLIST_ELEM_ADD(item_iflistp,PIN_FLD_ARGS,1,ebufp);
				PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_BILL_OBJ,bill_obj_pd,ebufp);
				args_flistp = PIN_FLIST_ELEM_ADD(item_iflistp,PIN_FLD_ARGS,2,ebufp);
				pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
				PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_DISPUTED,zero,ebufp);
				srch_res_flistp = PIN_FLIST_ELEM_ADD(item_iflistp,PIN_FLD_RESULTS,0,ebufp);
				PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL,ebufp);
				PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL,ebufp);
				PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DISPUTED,0,ebufp);	
				
				PCM_OP(ctxp,PCM_OP_SEARCH,0,item_iflistp,&item_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist ", sub_srch_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}

				PIN_FLIST_DESTROY_EX (&item_iflistp,NULL);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"read_flds_rflistp return flist",
					item_rflistp);
				PIN_FLIST_DESTROY_EX (&read_flds_rflistp,NULL);

				item_result_flistp = PIN_FLIST_ELEM_GET(item_rflistp,PIN_FLD_RESULTS,
					PIN_ELEMID_ANY,1,ebufp);
				account_obj_pd = PIN_FLIST_FLD_GET(item_result_flistp,PIN_FLD_ACCOUNT_OBJ,
					1,ebufp);
				read_fields_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(read_fields_iflistp,PIN_FLD_POID,account_obj_pd,ebufp);
				PIN_FLIST_FLD_SET(read_fields_iflistp,PIN_FLD_ACCOUNT_NO,NULL,ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"read_fields_iflistp input flist",
					read_fields_iflistp);
				PCM_OP(ctxp,PCM_OP_READ_FLDS,0,read_fields_iflistp,&read_fields_rflistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"input flist ",sub_srch_iflistp);
					pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_GET_DISPUTE,0,0,0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_dispute_search:"
						"Error while doing search:",ebufp);
					goto cleanup;
				}

				PIN_FLIST_DESTROY_EX (&read_fields_iflistp,NULL);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"read_fields_rflistp return flist",
					read_fields_rflistp);
				account_num = PIN_FLIST_FLD_GET(read_fields_rflistp,PIN_FLD_ACCOUNT_NO,
					1,ebufp);

				args_flistp = PIN_FLIST_ELEM_ADD(dispt_flistp,TAB_FLD_ALLOCATION_DETAILS,
					1,ebufp);
				PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_POID_TYPE,"cycle_forward",ebufp);
				PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_AMOUNT,amount,ebufp);
				PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ACCOUNT_NO,account_num,ebufp);			
			}
			event_read_obj_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(event_read_obj_iflistp,PIN_FLD_POID,event_pd,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"event_read_obj_iflistp input flist",
					event_read_obj_iflistp);
			PCM_OP(ctxp,PCM_OP_READ_OBJ,0,event_read_obj_iflistp,&event_read_obj_rflistp,ebufp);
			PIN_FLIST_DESTROY_EX(&event_read_obj_iflistp, NULL);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"event_read_obj_rflistp return flist",
					event_read_obj_rflistp);
			event_reason_flistp = PIN_FLIST_ELEM_GET(event_read_obj_rflistp,PIN_FLD_EVENT_MISC_DETAILS,
					PIN_ELEMID_ANY,1,ebufp);
			if(event_reason_flistp != NULL)
			{	
				PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_ID, dispt_flistp, PIN_FLD_REASON_ID, ebufp);
				PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_DOMAIN_ID, dispt_flistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);	
			}
		}
	}
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,disputes_flistp,PIN_FLD_CORRELATION_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,disputes_flistp,PIN_FLD_EXTERNAL_USER,ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"dispute array to be returned",disputes_flistp);
	PIN_FLIST_CONCAT(*out_flistpp,disputes_flistp,ebufp);	

cleanup:
	PIN_FLIST_DESTROY_EX (&srch_iflistp,NULL);
	PIN_FLIST_DESTROY_EX (&srch_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&sub_srch_iflistp,NULL);
	PIN_FLIST_DESTROY_EX (&sub_srch_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&disputes_flistp,NULL);
	PIN_FLIST_DESTROY_EX (&event_bllng_disp_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&trnsfr_iflistp,NULL);
	PIN_FLIST_DESTROY_EX (&trnsfr_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&billno_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&transid_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&item_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&read_fields_rflistp,NULL);
	PIN_FLIST_DESTROY_EX (&event_read_obj_rflistp, NULL);
	PIN_POID_DESTROY(srchp,ebufp);
	return;
}
