/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 14/Apr/2022 | Piyush Suryavanshi	| 			| Wrapper for payment
 *
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_RELEASE_DEPOSIT operation.
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "ops/deposit.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include <stdlib.h>

EXPORT_OP void
op_tab_ar_release_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_release_deposit(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_release_deposit_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);
		
void
fm_tab_release_deposit_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_ar_release_deposit_specification(
	pcm_context_t 		*ctxp,
	pin_flist_t     	*in_flistp,
	int64			db_no,
	pin_flist_t     	**out_flistpp,
	pin_errbuf_t    	*ebufp);	

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);
	
extern void fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			error_clear_flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
extern pin_flist_t* fm_tab_utils_common_prep_simple_search_flist(
	char                   *template,
	field_t                 args_struct[],
	int                 	n_args,
	field_t                 result_struct[],
	int                 	n_results,
	int64			db_no,
	int			flags,
	pin_errbuf_t            *ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int fm_tab_utils_common_call_opcode(
	pcm_context_t     	*ctxp,
	u_int               	opcode,
	u_int               	flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**ret_flistpp,
	char			*log_info,
	int			set_error,
	pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_AR_RELEASE_DEPOSIT is implemented apply
 * release deposit on account
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains release deposit info
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 */

void
op_tab_ar_release_deposit(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*trans_order_oflistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_release_deposit:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_ar_release_deposit function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_RELEASE_DEPOSIT) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_release_deposit bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_release_deposit input flist", in_flistp);
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp);	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_RELEASE_DEPOSIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RELEASE_DEPOSIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RELEASE_DEPOSIT, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{

		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_utils_common_validate_and_normalize_input:"
					"flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_release_deposit:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_ar_release_deposit(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit:"
					"flist", enrich_iflistp);						
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_release_deposit: Error while Opening transaction",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_release_deposit:"
				"flist", in_flistp);		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_AR_RELEASE_DEPOSIT", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_RELEASE_DEPOSIT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RELEASE_DEPOSIT)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RELEASE_DEPOSIT, ebufp);
		}

	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if(PIN_FLIST_ELEM_COUNT(r_flistp,TAB_FLD_NOTIFICATION,ebufp))
		{
			PIN_FLIST_ELEM_DROP(r_flistp,TAB_FLD_NOTIFICATION,PIN_ELEMID_ANY,ebufp);
		}
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_release_deposit output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&trans_order_oflistp, NULL);
	return;
}

/*******************************************************
 * We use this function to release deposit on given 
 * account based on deposit specification and release 
 * type 
 * @param ctxp The context pointer.
 * @param flags opcode flag.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param db_no Database number.
 * @return flistp.
 *******************************************************/

static void
fm_tab_ar_release_deposit(
	pcm_context_t 		*ctxp,
	int32			flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t     	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_release_deposit input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t *deposit_spec_out_flistp=NULL;
	pin_flist_t 	*enrich_resp_flistp=NULL;

	/*******************************************************************
	 * Call validation
	 *******************************************************************/

	fm_tab_release_deposit_validate_input(ctxp, in_flistp, ebufp);

	/*******************************************************************
	 * Call release deposit
	 *******************************************************************/

	fm_tab_ar_release_deposit_specification(ctxp,in_flistp,db_no, &deposit_spec_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification :"
				" release deposit failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit_specification:"
				" input flist ", in_flistp);
		goto cleanup;
	}


	/*******************************************************************
	 * Call output enrichment
	 *******************************************************************/
	PCM_OP( ctxp, TAB_OP_AR_POL_ENRICH_RESP_RELEASE_DEPOSIT,0, in_flistp, &enrich_resp_flistp, ebufp );	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit : "
				" TAB_OP_AR_POL_ENRICH_RESP_RELEASE_DEPOSIT error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit : "
				" ENRICH_RESP_RELEASE_DEPOSIT input", in_flistp);
		goto cleanup;
	}			
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_release_deposit:return flist from enrich opcode", enrich_resp_flistp);
	/*******************************************************************
	 * Call notification
	 *******************************************************************/

	fm_tab_ar_release_deposit_notification(ctxp, in_flistp,db_no,deposit_spec_out_flistp,&enrich_resp_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit : "
				" fm_tab_ar_release_deposit_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit : "
				" fm_tab_ar_release_deposit_notification:"
				" in_flistp", in_flistp);
		goto cleanup;
	}
	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_ACCOUNT_OBJ,ebufp);
	
	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_GROUP_OBJ, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_GROUP_OBJ,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_BAL_GRP_OBJ, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_BAL_GRP_OBJ,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_SERVICE_OBJ,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_PROGRAM_NAME, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_PROGRAM_NAME,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, TAB_FLD_EXCEPTION_FLAG, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,TAB_FLD_EXCEPTION_FLAG,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_RELEASE_TYPE, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_RELEASE_TYPE,ebufp);

	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_NAME, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_NAME,ebufp);
	
	if (PIN_FLIST_FLD_GET(enrich_resp_flistp, PIN_FLD_AMOUNT, 1, ebufp) != NULL)
		PIN_FLIST_FLD_DROP(enrich_resp_flistp,PIN_FLD_AMOUNT,ebufp);
	
	*out_flistpp = enrich_resp_flistp;
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, *out_flistpp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, *out_flistpp, PIN_FLD_MSISDN, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, *out_flistpp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, *out_flistpp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, *out_flistpp,PIN_FLD_TRANS_ID,ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/	
	PIN_FLIST_DESTROY_EX(&deposit_spec_out_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_release_deposit output flist", *out_flistpp);
	return;
}

static void
fm_tab_ar_release_deposit_specification(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	int64		db_no,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_release_deposit_specification frame input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit_specification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_release_deposit_specification:"
				" in_flistp", in_flistp);
		return;
	}

	poid_t 		*account_pdp= NULL;
	poid_t 		*specification_pdp=NULL;
	char		*deposit_specp=NULL;
	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*specification_result_flistp=NULL;
	pin_flist_t 	*purchased_deposit_flistp=NULL;
	pin_flist_t 	*release_deposit_input_flistp=NULL;
	pin_flist_t 	*release_deposit_out_flistp=NULL;
	
	field_t		args_struct[1];
	field_t		result_struct[1];
	int		n_args =1;
	int		n_results =1;
	char		*template= "select X from /deposit_specification where F1 = V1 ";
	int 		flags=0;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,	
				"fm_tab_ar_release_deposit_specification input flist", in_flistp);		

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID,0,ebufp);

	deposit_specp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME,0,ebufp);

		//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_NAME;
	args_struct[0].fld_value = deposit_specp;

	//Setting the results
	result_struct[0].fld_name = PIN_FLD_POID;
	result_struct[0].fld_value = NULL;
	
	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	int	opcode_result= 0 ;

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_ar_release_deposit_specification search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DEPOSIT_SEPECIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification"
				"error search sepecification failed", ebufp);
		goto cleanup;
	}


	if (!PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp)) 
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DEPOSIT_SEPECIFICATION_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification"
				"error search sepecification failed", ebufp);
		goto cleanup;
	}

	specification_result_flistp=PIN_FLIST_ELEM_GET(search_out_flistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	
	specification_pdp = PIN_FLIST_FLD_GET(specification_result_flistp, PIN_FLD_POID,1,ebufp);
	

	template= "select X from /purchased_deposit where F1 = V1 and F2 = V2 ";

	field_t		args_struct1[2];
	n_args =2;
	//Setting the arguments
	args_struct1[0].fld_name = PIN_FLD_DEPOSIT_SPEC_OBJ;
	args_struct1[0].fld_value = specification_pdp;

	//Setting the results
	args_struct1[1].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct1[1].fld_value = account_pdp;
	
	search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct1, n_args,result_struct, n_results,db_no,flags, ebufp);

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_ar_release_deposit_specification purchased deposit search", 1, ebufp);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DEPOSIT_SEPECIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification"
				"error purchased deposit search sepecification failed", ebufp);
		goto cleanup;
	}


	if (!PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PURCHASED_DEPOSIT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification"
				"error purchased deposit search sepecification failed", ebufp);
		goto cleanup;
	}

	purchased_deposit_flistp=PIN_FLIST_ELEM_GET(search_out_flistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	
	/*******************************************************************
	 *release deposit input flist prepration.
	 *******************************************************************/
	release_deposit_input_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(purchased_deposit_flistp, PIN_FLD_POID,release_deposit_input_flistp, PIN_FLD_POID, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,release_deposit_input_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT,release_deposit_input_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RELEASE_TYPE,release_deposit_input_flistp, PIN_FLD_RELEASE_TYPE, ebufp);
	PIN_FLIST_FLD_SET(release_deposit_input_flistp, PIN_FLD_NOTE_STR, "Default Notes", ebufp);

	/*******************************************************************
	 * Release deposit opcode call
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_release_deposit : PCM_OP_DEPOSIT_RELEASE_DEPOSIT: "
			"input Flist", release_deposit_input_flistp);
	PCM_OP( ctxp, PCM_OP_DEPOSIT_RELEASE_DEPOSIT , 0, release_deposit_input_flistp, &release_deposit_out_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_release_deposit : PCM_OP_DEPOSIT_RELEASE_DEPOSIT: "
			"output Flist", release_deposit_out_flistp);

	PIN_FLIST_DESTROY_EX(&release_deposit_input_flistp, NULL);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_RELEASE_DEPOSIT_FAILED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_release_deposit_specification :"
				"failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_release_deposit_specification input flist", in_flistp);		
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&release_deposit_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	
	*out_flistpp=release_deposit_out_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_release_deposit_specification frame flist output flist", *out_flistpp);
	return;
}

/*************************************************************
 *  This function will prepare the notification flist
 *  based on the payload structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_RELEASE_DEPOSIT_NOTIFICATION for
 *  enrichment and return notification flist
 *************************************************************/

static void
fm_tab_ar_release_deposit_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*o_flistp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t	*enrich_notify_flistp = NULL;
	pin_flist_t	*notify_tflistp = NULL;
	pin_flist_t	*notify_flistp = NULL;
	pin_flist_t *notify_out_flistp=NULL;
	poid_t		*notify_pdp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_release_deposit_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_release_deposit_notification: "
			"input flist", i_flistp);

	notify_flistp =PIN_FLIST_CREATE(ebufp);
	notify_out_flistp =PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_POID, ebufp); 
	PIN_FLIST_ELEM_SET(notify_out_flistp, o_flistp, PIN_FLD_RESULTS_DATA,0, ebufp);
	notify_tflistp = PIN_FLIST_CREATE(ebufp);

	// Create Notification Flist
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_RELEASE_DEPOSIT_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_tflistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_tflistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_tflistp, TAB_FLD_NOTIFICATION, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_release_deposit_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_RELEASE_DEPOSIT_NOTIFICATION input flist ", notify_flistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_RELEASE_DEPOSIT_NOTIFICATION, 0,
			notify_flistp, &enrich_notify_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_RELEASE_DEPOSIT_NOTIFICATION_FAILED, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_release_deposit_notification:"
				" input flist ", notify_tflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_release_deposit_notification:"
				" Error in Notification", ebufp);
		*r_flistpp=enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_release_deposit_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_RELEASE_DEPOSIT_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		if (( PIN_FLIST_ELEM_GET(enrich_notify_flistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(enrich_notify_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*r_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*r_flistpp, enrich_notify_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
*r_flistpp=enrich_notify_flistp;

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_ar_release_deposit_notification output flist", *r_flistpp);
	return;
}


/*************************************************************
 *  This function will validate the input fields in the flist
 *   and return error if any mandatory fields are missing 
 *************************************************************/

void
fm_tab_release_deposit_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp)
{
	char			*acct_nop = NULL;
	char			*msisdnp = NULL;
	char			*deposit_specp = NULL;
	int			     release_type = 0;
	pin_decimal_t 	*amountp=NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_release_deposit_validate_input function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_release_deposit_validate_input: "
		" input flist", i_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_ACCOUNT_NO,1,ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_MSISDN,1, ebufp);
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_release deposit:"
			"account number/msisdn is not passed", ebufp);
		return;
	}
	
	deposit_specp =  PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_NAME,1, ebufp);

	if((deposit_specp == NULL) || (deposit_specp && strlen(deposit_specp) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DEPOSIT_SPECIFICATION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_release_deposit_validate_input:"
			"Deposit specification is not passed/empty", ebufp);
		return;
	}


	if(PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_RELEASE_TYPE,1, ebufp)==NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_RELEASE_TYPE_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_release_deposit_validate_input:"
			" Release type is not passed/empty", ebufp);
		return;
	}
	
	release_type = *(int*) PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_RELEASE_TYPE,1, ebufp);
	
	if(release_type!=1 && release_type!=2)
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_RELEASE_DEPOSIT_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_release_deposit_validate_input:"
			" Wrong release type flag", ebufp);
		return;
	}	

	amountp =  PIN_FLIST_FLD_GET(i_flistp,PIN_FLD_AMOUNT,1, ebufp);

	if(amountp == NULL) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_release_deposit_validate_input:"
			" Amount is not passed", ebufp);
		return;
	}

	return;
}
