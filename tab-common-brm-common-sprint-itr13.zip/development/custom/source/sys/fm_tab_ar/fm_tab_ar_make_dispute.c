/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer    | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 01-Mar-2022   | Rajashekar    |               | New opcode TAB_OP_AR_MAKE_DISPUTE 
 *				                                            | to to enable raising disputes.
 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_MAKE_DISPUTE operation. 
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/ar.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_bill.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP
void
op_tab_ar_make_dispute(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_make_dispute(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_bill_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_bill_acct_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_pol_make_dispute_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*results_flistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_ar_dispute_event_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_ar_get_bill_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *in_flistp,
        pin_flist_t             **out_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);


/*** Extern Function ***/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
        pcm_context_t           *ctxp,
        poid_t                  *pdp,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   status,
        poid_t                  *account_pdp,
        char                    *opcode_name,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_get_billinfo (
        pcm_context_t           *ctxp,
        poid_t                  *acc_pdp,
        int32                   active_flag,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
    pcm_context_t        *ctxp,
    pin_flist_t        *i_flistp,
    pin_errbuf_t        *ebufp);

/**************************************************************************
 * Main routine for the TAB_OP_AR_MAKE_DISPUTE operation.
 *************************************************************************/
/**
 * *
 * New opcode TAB_OP_AR_MAKE_DISPUTE is implemented to
 * enable raising disputes 
 * 
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains 
 * PIN_FLD_ACCOUNT_NO, PIN_FLD_MSISDN,PIN_FLD_BILL_NO,PIN_FLD_AMOUNT ,
 * PIN_FLD_REASON_DOMAIN_ID,PIN_FLD_REASON_ID,PIN_FLD_USER_NAME,PIN_FLD_TRANS_ID,
 * PIN_FLD_FLAGS,PIN_FLD_LOCATION ,PIN_FLD_CODE,PIN_FLD_DESCR 
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 * 
 * Sample Input Flist
 * 0 PIN_FLD_POID                POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO          STR [0] "OGC_12345"
 * 0 PIN_FLD_MSISDN              STR [0] "987778900"
 * 0 PIN_FLD_BILL_NO             STR [0] "B1-2273"
 * 0 PIN_FLD_AMOUNT              DECIMAL [0] 400
 * 0 PIN_FLD_REASON_DOMAIN_ID    INT [0] 100
 * 0 PIN_FLD_REASON_ID           INT [0] 0
 * 0 PIN_FLD_USER_NAME           STR [0] "AL-1234"
 * 0 PIN_FLD_TRANS_ID            STR [0] "T-1234"
 * 0 PIN_FLD_FLAGS               INT [0] 2
 * 0 PIN_FLD_LOCATION            STR [0] "NY"
 * 0 PIN_FLD_CODE                STR [0] ".12345"
 * 0 PIN_FLD_DESCR               STR [0] "cust-dispute"
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "12012022611"
 * 0 PIN_FLD_EXTERNAL_USER       STR [0] "CRM"
 *
 **/

void 
op_tab_ar_make_dispute(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	pin_flist_t		*enrich_iflistp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_dispute" 
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_dispute function entry error", ebufp);
		return;
	}

	*out_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_AR_MAKE_DISPUTE) 
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_dispute"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_dispute bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_dispute input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE, 
			TAB_ERR_CODE_GET_DB_NO_FAIL,0,0,0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error while getting database no",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,cerror_code, 
			&r_flistp, db_no,ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
 		* in the response with the errorCode coming from the return flist*/
 		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*out_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
			"Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_DISPUTE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_DISPUTE)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_MAKE_DISPUTE, ebufp);
		}
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*out_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
			/* Common_input_validation */
			fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, 
				&enrich_iflistp,db_no, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"op_tab_ar_make_dispute input flist", in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
				status = TAB_FAIL;
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_dispute:"
				"fm_tab_utils_common_validate_and_normalize_input output flist",enrich_iflistp);	
			/* call main function */
			fm_tab_ar_make_dispute(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_make_dispute error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
					" in_flistp", in_flistp);
				status = TAB_FAIL;
				goto cleanup;
			}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_dispute:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_make_dispute: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*out_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_AR_MAKE_DISPUTE", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			"input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_ar_make_dispute:"
			"Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_MAKE_DISPUTE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_MAKE_DISPUTE )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_MAKE_DISPUTE, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	
	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*out_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_make_dispute output flist", *out_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/********************************************
 * We use this function
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void 
fm_tab_ar_make_dispute(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*wflds_iflistp = NULL;
	pin_flist_t		*wflds_rflistp = NULL;
	pin_flist_t		*winfo_flistp = NULL;
	pin_flist_t		*acct_billinfo_rflistp = NULL;
	pin_flist_t		*bill_search_rflistp = NULL;
	pin_flist_t		*bill_result_flistp = NULL;
	pin_flist_t		*bill_dispute_iflistp = NULL;
	pin_flist_t		*post_bill_dispute_iflistp = NULL;
    pin_flist_t		*post_bill_dispute_rflistp = NULL;
	pin_flist_t 	*event_return_flistp=NULL;
	poid_t			*payinfo_obj = NULL;
	poid_t			*eventobj_pdp = NULL;
	char			*poid_typep     = NULL;
	pin_decimal_t		*amount = NULL;
	char			*bill_no = NULL;
	char			*tran_id =  NULL;
	poid_t			*acct_obj = NULL;
	int32			active_flag = 1;
	char			*corr_id = NULL;
	char			*extern_user = NULL;
	char			prog_name[255];
	pin_flist_t		*bill_dispute_rflistp = NULL;
	int			*resultp= NULL; 
	pin_decimal_t		*dispute_amount = NULL;
	pin_decimal_t		*due_amount = NULL;
	int32			*dispute_flag = NULL;
	pin_flist_t		*hook_iflistp = NULL;
	char			db_no_str[10];
	pin_flist_t		*hook_oflistp = NULL;
	int32			disp_flag=0;
	pin_flist_t		*notify_oflistp=NULL;
	char			*account_no = NULL;
	char			*msisdn = NULL;
	int32            error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute" 
			"function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute"
			"in_flistp", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_dispute in_flistp", in_flistp);

	/* Validate the input arguments */
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if((account_no == NULL || strlen(account_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
				"account number/msisdn is not passed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute: input flist", in_flistp);
		goto cleanup;
	}
	
	amount = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1,ebufp);
	if(amount == NULL || strlen(amount) == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_dispute: Error PIN_FLD_AMOUNT is missing", ebufp);
		return;
	}

	bill_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1,ebufp);
	if(bill_no == NULL || strlen(bill_no) == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILL_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_dispute: Error PIN_FLD_BILL_NO is missing", ebufp);
		return;
	}

	tran_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	if(tran_id == NULL || strlen(tran_id) == 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_dispute: Error PIN_FLD_TRANS_ID is missing", ebufp);
		return;
	}
	/********************************************************************************
	* Call VALIDATE HOOK opcode to validate input flist specific to BU's
	********************************************************************************/
	hook_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);

	/*Add source database*/
	memset(db_no_str, '\0', sizeof(db_no_str));
	snprintf(db_no_str, sizeof(db_no_str), "%d", db_no);

	if(db_no_str != NULL)
	{
		PIN_FLIST_FLD_SET(hook_iflistp, PIN_FLD_SRC_DATABASE, db_no_str, ebufp);
	}

	PCM_OP(ctxp, TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE, 0, hook_iflistp, &hook_oflistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute: "
			"TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE input flist", hook_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute: "
			"TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute: "
			"TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE output flist", hook_oflistp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp = PIN_FLIST_COPY(hook_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_make_dispute: "
		"TAB_OP_AR_POL_VALIDATE_MAKE_DISPUTE output flist", hook_oflistp);

	/******************************************************************************/

	/*checking Account number / MSISDN should be a paying account number*/
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(acct_obj != NULL )
	{
		fm_tab_utils_common_get_billinfo(ctxp, acct_obj, active_flag, 
			&acct_billinfo_rflistp,db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_utils_common_get_billinfo:"
				"input flist ",in_flistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Get Billinfo details: "
				"fm_tab_utils_common_get_billinfo error", ebufp);
			goto cleanup;
		}
		if (acct_billinfo_rflistp!= NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_dispute:"
				"fm_tab_utils_common_get_billinfo output flist is ",acct_billinfo_rflistp);
			payinfo_obj = PIN_FLIST_FLD_GET(acct_billinfo_rflistp,PIN_FLD_PAYINFO_OBJ,1,ebufp);
			poid_typep = (char *)PIN_POID_GET_TYPE(payinfo_obj);
			if ( poid_typep && ((strcmp(poid_typep,TAB_OBJ_TYPE_PAYINFO_PREPAID) == 0 )
					|| (strcmp(poid_typep,PIN_OBJ_TYPE_PAYINFO_SUBORD) == 0 ) ) )
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute" 
					"input flist", in_flistp);
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_PAYTYPE, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:" 
					"Error PIN_FLD_PAYINFO_OBJ is incorrect", ebufp);
				goto cleanup;
			}
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_ar_make_dispute input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
				"Error in getting billinfo details", ebufp);
			goto cleanup;
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_dispute input flist", in_flistp);

	if ((bill_no != NULL && strlen(bill_no) != 0) && (acct_obj != NULL))
	{
		/* With Bill_no and account_poid*/
		fm_tab_ar_bill_acct_search(ctxp,in_flistp,&bill_search_rflistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_bill_acct_search:"
				"input flist ",in_flistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_bill_acct_search: "
				"Error while doing bill search", ebufp);
			goto cleanup;
		}
	}

	/* With Bill_no only */
	if ((bill_no != NULL && strlen(bill_no) != 0) && (acct_obj == NULL))
	{
		fm_tab_ar_get_bill_details(ctxp,in_flistp,&bill_search_rflistp, db_no, ebufp);
                 if(PIN_ERR_IS_ERR(ebufp))
                {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_get_bill_details:"
                                "input flist ",in_flistp );
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_bill_details: "
                                "Error while doing bill search", ebufp);
                        goto cleanup;
                }
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"bill_search_rflistp return flist",bill_search_rflistp);
	bill_result_flistp = PIN_FLIST_ELEM_GET(bill_search_rflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	PIN_FLIST_FLD_COPY(bill_result_flistp,PIN_FLD_POID,in_flistp,PIN_FLD_BILL_OBJ,ebufp);

	if (bill_search_rflistp != NULL && bill_result_flistp != NULL)
	{
		dispute_amount = (pin_decimal_t *)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_AMOUNT,1,ebufp);
		due_amount = (pin_decimal_t *)PIN_FLIST_FLD_GET(bill_result_flistp,PIN_FLD_DUE,1,ebufp);
				

		fm_tab_ar_dispute_event_search(ctxp,in_flistp,&event_return_flistp,db_no,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_dispute_event_search:"
				"input flist ",in_flistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_dispute_event_search: "
				"Error while doing bill search", ebufp);
			goto cleanup;
		}

		if(PIN_FLIST_ELEM_COUNT(event_return_flistp,PIN_FLD_RESULTS,ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ALREADY_DISPUTED, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute: input flist ", 
				in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute"
				"Bill is already disputed, more than one dispute not allowed", ebufp);
			goto cleanup;
		}
				
		if(pbo_decimal_compare(dispute_amount,due_amount,ebufp)>0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_AMOUNT, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute: input flist ", 
				in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute"
				"Dispute Amount provided in request is greater than bill amount", ebufp);
			goto cleanup;
		}      
	}	
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_make_dispute input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_make_dispute: Error Invoice number not found in BRM DB ", ebufp);
		goto cleanup;
	}

	bill_dispute_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(bill_result_flistp,PIN_FLD_POID,bill_dispute_iflistp,PIN_FLD_POID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AMOUNT,bill_dispute_iflistp,PIN_FLD_AMOUNT,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DESCR,bill_dispute_iflistp,PIN_FLD_DESCR,ebufp);

	corr_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CORRELATION_ID, 1, ebufp);
	extern_user = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_EXTERNAL_USER, 1, ebufp);
	dispute_flag = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_FLAGS,1,ebufp);

	if( dispute_flag && *dispute_flag == 1 )
	{
		disp_flag = PIN_AR_WITH_TAX;
		PIN_FLIST_FLD_SET(bill_dispute_iflistp, PIN_FLD_FLAGS, &disp_flag,ebufp);
	}
	else 
	{
		disp_flag = PIN_AR_WITHOUT_TAX;
		PIN_FLIST_FLD_SET(bill_dispute_iflistp, PIN_FLD_FLAGS, &disp_flag,ebufp);
	}

	if(corr_id != NULL && extern_user != NULL)
	{
		memset(prog_name, '\0', sizeof(prog_name));
		strcpy(prog_name, corr_id);
		strcat(prog_name, "|");
		strcat(prog_name, extern_user);

		PIN_FLIST_FLD_SET(bill_dispute_iflistp, PIN_FLD_PROGRAM_NAME, prog_name, ebufp);
	}
	
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_REASON_DOMAIN_ID,bill_dispute_iflistp,
		PIN_FLD_REASON_DOMAIN_ID,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_REASON_ID,bill_dispute_iflistp,PIN_FLD_REASON_ID,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_AR_BILL_DISPUTE: i/p flist",bill_dispute_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_BILL_DISPUTE, 0, bill_dispute_iflistp, &bill_dispute_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_BILL_DISPUTE:"
			"input flist",bill_dispute_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_BILL_DISPUTE:"
			"Error while executing PCM_OP_AR_BILL_DISPUTE ", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_AR_BILL_DISPUTE: o/p flist",bill_dispute_rflistp);

        post_bill_dispute_iflistp = PIN_FLIST_COPY(bill_dispute_rflistp, ebufp);

        PCM_OP(ctxp, TAB_OP_AR_POL_POST_MAKE_DISPUTE , 0, post_bill_dispute_iflistp, &post_bill_dispute_rflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:TAB_OP_AR_POL_POST_MAKE_DISPUTE"
				"input flist",post_bill_dispute_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
				"Error in TAB_OP_AR_POL_POST_MAKE_DISPUTE ", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		PIN_FLIST_DESTROY_EX(out_flistpp, NULL);
		*out_flistpp = PIN_FLIST_COPY(post_bill_dispute_rflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);

		goto cleanup;
	}

	if(bill_dispute_rflistp != NULL)
	{
		resultp = PIN_FLIST_FLD_GET(bill_dispute_rflistp, PIN_FLD_RESULT, 1, ebufp);
		if(resultp && *resultp == 0 )
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_AMOUNT, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_AR_BILL_DISPUTE:"
				"input flist ", bill_dispute_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"This AR action is not allowed"
				"as the existing positive bill due is becoming negative", ebufp);
			goto cleanup;
		}
	}
	/*Commented as part of Enginnering bug 34532590*/
	//results_billinfo_flistp = PIN_FLIST_ELEM_GET(bill_dispute_rflistp,
	//	PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
	eventobj_pdp = PIN_FLIST_FLD_GET(bill_dispute_rflistp, PIN_FLD_EVENT_OBJ, 1, ebufp); 
	poid_typep = (char *)PIN_POID_GET_TYPE(eventobj_pdp);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, poid_typep);

	if(poid_typep && (strcmp(poid_typep, PIN_OBJ_TYPE_EVENT_BILL_DISPUTE) == 0))
	{
		wflds_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET(wflds_iflistp, PIN_FLD_POID, eventobj_pdp, ebufp);
		winfo_flistp = PIN_FLIST_ELEM_ADD(wflds_iflistp, TAB_FLD_DISPUTES,PIN_ELEMID_ANY,ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME,winfo_flistp, PIN_FLD_USER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID,winfo_flistp, PIN_FLD_TRANS_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION,winfo_flistp, PIN_FLD_LOCATION, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CODE,winfo_flistp, PIN_FLD_CODE, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_WRITE_FLDS input flist", wflds_iflistp);
		PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 32, wflds_iflistp, &wflds_rflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS"
				" input flist", wflds_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_WRITE_FLDS:"
				"Error while writing poid", ebufp);
			goto cleanup;
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_WRITE_FLDS output flist",wflds_rflistp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, *out_flistpp, PIN_FLD_BILL_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, *out_flistpp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, *out_flistpp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, *out_flistpp, PIN_FLD_DESCR, ebufp);	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_dispute:"
		" fm_tab_ar_pol_make_dispute_notify input flist ", in_flistp);

	// Call function to enrich notification details
	fm_tab_ar_pol_make_dispute_notify(ctxp, in_flistp, db_no,bill_dispute_rflistp,*out_flistpp, 
		&notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute:"
			" fm_tab_ar_pol_make_dispute_notify input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_make_dispute: "
			" fm_tab_ar_pol_make_dispute_notify error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_make_dispute:"
		" fm_tab_ar_pol_make_dispute_notify output flist ", notify_oflistp);

	if (notify_oflistp)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	/******************************************************************
	 * Clean up.
	 ******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX(&bill_dispute_iflistp,NULL);	
	PIN_FLIST_DESTROY_EX(&post_bill_dispute_iflistp,NULL);	
	PIN_FLIST_DESTROY_EX(&post_bill_dispute_rflistp,NULL);
	PIN_FLIST_DESTROY_EX(&bill_dispute_rflistp,NULL);	
	PIN_FLIST_DESTROY_EX(&wflds_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&hook_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&event_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_search_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&acct_billinfo_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&wflds_rflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_make_dispute output flist", *out_flistpp);
	return;
}

void
fm_tab_ar_bill_acct_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*bill_no = NULL;
	poid_t		*acct_obj = NULL;
	pin_flist_t		*bill_acct_search_iflistp = NULL;
	void			*vp = NULL;
	pin_flist_t		*search_flist_arg = NULL;
	pin_flist_t		*result_flist_arg = NULL;
	pin_flist_t		*bill_acct_search_rflistp = NULL;
	poid_t			*srch_bill_pdp = NULL;
	int32			s_flags = 256;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_bill_acct_search:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_bill_acct_search function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_bill_acct_search:input flist",in_flistp);
	bill_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);

	/*Sample _input flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] " select X from /bill where F1 = V1 and F2 = V2 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_BILL_NO           STR [0] "B1-2273"
	0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	1 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 32779650 0
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 1
	1 PIN_FLD_POID           POID [0] NULL poid pointer*/

	bill_acct_search_iflistp = PIN_FLIST_CREATE(ebufp);
	srch_bill_pdp = PIN_POID_CREATE(db_no, "/search", -1,ebufp);
	PIN_FLIST_FLD_PUT(bill_acct_search_iflistp,PIN_FLD_POID,(void *)srch_bill_pdp,ebufp);
	PIN_FLIST_FLD_SET(bill_acct_search_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);

	vp = (void *)"select X from /bill where F1 = V1 and F2 = V2 ";
	PIN_FLIST_FLD_SET(bill_acct_search_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

	search_flist_arg = PIN_FLIST_ELEM_ADD(bill_acct_search_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(search_flist_arg,PIN_FLD_BILL_NO,bill_no,ebufp);

	search_flist_arg = PIN_FLIST_ELEM_ADD(bill_acct_search_iflistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(search_flist_arg,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

	result_flist_arg = PIN_FLIST_ELEM_ADD(bill_acct_search_iflistp,PIN_FLD_RESULTS,0, ebufp);
	PIN_FLIST_FLD_SET(result_flist_arg,PIN_FLD_POID,NULL,ebufp);
	PIN_FLIST_FLD_SET(result_flist_arg, PIN_FLD_DUE, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_bill_acct_search:"
		"input flist", bill_acct_search_iflistp);
        
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0,bill_acct_search_iflistp, &bill_acct_search_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_bill_acct_search:"
			"input flist ",bill_acct_search_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_bill_acct_search:"
			"Error while doing search:", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_bill_acct_search:"
		"return flist", bill_acct_search_rflistp);
cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&bill_acct_search_iflistp, NULL);
	*out_flistpp = bill_acct_search_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_bill_acct_search output flist", *out_flistpp);
	return;
}

/********************************************
 * We use this function to call notification opcode
 * It will create notification entry in Kafka queue.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 *******************************************/

void
fm_tab_ar_pol_make_dispute_notify(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		*make_dispute_oflistp,
	pin_flist_t		*opresp_flistpp,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*res_data_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_dispute_notify error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_pol_make_dispute_notify:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_pol_make_dispute_notify: "
		"input flist", i_flistp);

	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	/*OUT_FLIST*/
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	temp_flistp = PIN_FLIST_COPY(make_dispute_oflistp, ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	if(opresp_flistpp != NULL)
	{
		res_data_flistp = PIN_FLIST_COPY(opresp_flistpp, ebufp);
		PIN_FLIST_ELEM_PUT(notify_out_flistp, res_data_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	else
	{
		PIN_FLIST_ELEM_SET(notify_out_flistp, NULL, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);

	/*TAB_FLD_NOTIFICATION*/
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_MAKE_DISPUTE, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_dispute_notify:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_DISPUTE input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_MAKE_DISPUTE, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_dispute_notify:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_ar_pol_make_dispute_notify:"
			" Error in update invoice notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_pol_make_dispute_notify:"
		" TAB_OP_NOTIFY_POL_ENRICH_MAKE_DISPUTE output flist ", enrich_notify_flistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 *******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_pol_make_dispute_notify output flist", *r_flistpp);
	return;
}


void
fm_tab_ar_dispute_event_search(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	poid_t			*acct_obj = NULL;
	poid_t			*bill_obj = NULL;
	pin_flist_t		*event_search_iflistp = NULL;
	pin_flist_t		*event_search_rflistp = NULL;
	void			*vp = NULL;
	pin_flist_t		*search_flist_arg = NULL;
	pin_flist_t		*account_info_arg = NULL;
	pin_flist_t		*result_flist_arg = NULL;
	poid_t			*srch_bill_pdp = NULL;
	poid_t 			*srch_item_pdp=NULL;
	int32			s_flags = 256;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_dispute_event_search:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_ar_dispute_event_search function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_dispute_event_search:input flist",in_flistp);
	
	acct_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	bill_obj = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_OBJ, 1, ebufp);

	/*Sample _input flist
	0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 0
	0 PIN_FLD_TEMPLATE        STR [0] "select X from /event/billing/item/transfer where  F1 = V1 and F2 = V2 and F3.type = V3 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2167035 9
	0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	1 PIN_FLD_ACTION_INFO   ARRAY [0] allocated 20, used 3
	2     PIN_FLD_AR_BILL_OBJ    POID [0] 0.0.0.1 /bill 2167547 0
	0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	1 PIN_FLD_ITEM_OBJ    POID [0] 0.0.0.1 /item/dispute -1 9
	0 PIN_FLD_RESULTS       ARRAY [0] allocated 20, used 3*/

	event_search_iflistp = PIN_FLIST_CREATE(ebufp);
	srch_bill_pdp = PIN_POID_CREATE(db_no, "/search", -1,ebufp);
	srch_item_pdp = PIN_POID_CREATE(db_no, "/item/dispute", -1,ebufp);
	PIN_FLIST_FLD_PUT(event_search_iflistp,PIN_FLD_POID,(void *)srch_bill_pdp,ebufp);
	PIN_FLIST_FLD_SET(event_search_iflistp,PIN_FLD_FLAGS,&s_flags,ebufp);

	vp = (void *)"select X from /event/billing/item/transfer where  F1 = V1 and F2 = V2 and F3.type = V3 ";
	PIN_FLIST_FLD_SET(event_search_iflistp,PIN_FLD_TEMPLATE,vp,ebufp);

	search_flist_arg = PIN_FLIST_ELEM_ADD(event_search_iflistp, PIN_FLD_ARGS,1,ebufp);
	PIN_FLIST_FLD_SET(search_flist_arg,PIN_FLD_ACCOUNT_OBJ,acct_obj,ebufp);

	search_flist_arg = PIN_FLIST_ELEM_ADD(event_search_iflistp, PIN_FLD_ARGS,2,ebufp);
	account_info_arg = PIN_FLIST_ELEM_ADD(search_flist_arg, PIN_FLD_ACTION_INFO,0,ebufp);
	PIN_FLIST_FLD_SET(account_info_arg,PIN_FLD_AR_BILL_OBJ,bill_obj,ebufp);

	search_flist_arg = PIN_FLIST_ELEM_ADD(event_search_iflistp, PIN_FLD_ARGS,3,ebufp);
	PIN_FLIST_FLD_PUT(search_flist_arg,PIN_FLD_ITEM_OBJ,srch_item_pdp,ebufp);

	result_flist_arg = PIN_FLIST_ELEM_ADD(event_search_iflistp,PIN_FLD_RESULTS,0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_dispute_event_search:"
		"input flist", event_search_iflistp);
        
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0,event_search_iflistp, &event_search_rflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_dispute_event_search:"
			"input flist ",event_search_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_dispute_event_search:"
			"Error while doing search:", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_dispute_event_search:"
		"return flist", event_search_rflistp);
cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&event_search_iflistp, NULL);
	*out_flistpp = event_search_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_ar_dispute_event_search output flist", *out_flistpp);
	return;
}

void
fm_tab_ar_get_bill_details(
        pcm_context_t           *ctxp,
        pin_flist_t             *in_flistp,
        pin_flist_t             **out_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *args_flistp=NULL;
        pin_flist_t             *search_iflistp=NULL;
        pin_flist_t             *search_rflistp=NULL;
        poid_t                  *srchp=NULL;
        poid_t                  *parent_pdp = NULL;
        pin_flist_t             *srch_res_flistp=NULL;
        void                    *vp=NULL;
        int32                   s_flags=256;



        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_bill_details:"
                        "input flist",in_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_ar_get_bill_details function entry error", ebufp);
                return;
        }

        /* Create search template to get bill poid */
        search_iflistp = PIN_FLIST_CREATE(ebufp);
        srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
        PIN_FLIST_FLD_PUT(search_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
        PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

        vp =  (void *)"select X from /bill where F1 = V1 and F2 = V2 ";
        PIN_FLIST_FLD_SET(search_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

        args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 1, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILL_NO,args_flistp,PIN_FLD_BILL_NO,ebufp);

        parent_pdp =  PIN_POID_FROM_STR("0.0.0.0  0 0", NULL, ebufp);
        args_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_ARGS, 2, ebufp);
        PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, (void *)parent_pdp, ebufp);

        srch_res_flistp = PIN_FLIST_ELEM_ADD(search_iflistp, PIN_FLD_RESULTS, 0, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_POID,NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_ACCOUNT_OBJ,NULL, ebufp);
        PIN_FLIST_FLD_SET(srch_res_flistp,PIN_FLD_DUE,NULL, ebufp);

        /***************Perform the search*************************/
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_bill_details:"
                        "Search input flist ", search_iflistp);

        PCM_OP (ctxp, PCM_OP_SEARCH, 0, search_iflistp, &search_rflistp, ebufp);
        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_bill_details:"
                                " input flist ", search_iflistp);
                pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_API_MAKE_DISPUTE, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_bill_details:"
                                "No bill information is available for given input", ebufp);
                goto cleanup;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_bill_details:"
                        "return flist", search_rflistp);
        *out_flistpp = search_rflistp;
        PIN_FLIST_DESTROY_EX (&search_iflistp, NULL);
        return;

cleanup:
        /******************************************************************
        *            * Clean up.
        ******************************************************************/
        PIN_FLIST_DESTROY_EX (&search_iflistp, NULL);
        PIN_FLIST_DESTROY_EX (&search_rflistp, NULL);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_ar_get_bill_details final flist", *out_flistpp);
        return;
}

