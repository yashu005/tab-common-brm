/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer                 | Req/bug/Gap           | Change details
 *
 * 1  | 04/May/2022 | Rahul Honnaiah            |                       | New opcode implementation to
 *                                                                      | get refund.
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_AR_GET_REFUND operation.
 *******************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "ops/ar.h"
#include "pin_ar.h"
#include "pin_bill.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "pin_rate.h"

EXPORT_OP void
op_tab_ar_get_refund(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_ar_get_refund(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);


extern void
fm_tab_utils_common_get_refund_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 * 
 * New opcode TAB_OP_AR_GET_REFUND is implemented to
 * get refund information
 *  @param connp The connection pointer.
 *  @param opcode This opcode.
 *  @param flags The opcode flags.
 *  @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_TRANS_ID
 *  @param ret_flistpp The output flist with account poid information.
 *  @param ebufp The error buffer.
 *  @return nothing.
 *  
 *
 * */
void
op_tab_ar_get_refund (
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp=connp->dm_ctx;
	pin_flist_t		*r_flistp=NULL;
	int32			status=PIN_BOOLEAN_TRUE;
	int32			error_clear_flag=1;
	int32			cerror_code=0;
	char			log_msg[512]="";
	int64			db_no=0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund error",ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *  Insanity check.
	 ***********************************************************/
	if(opcode != TAB_OP_AR_GET_REFUND) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund BAD opcode error",ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	*******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_ar_get_refund input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no: "
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/* call main function */
	fm_tab_ar_get_refund(ctxp, flags, in_flistp, &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_ar_get_refund error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
			" Error while getting Payment", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_REFUND;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_REFUND, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_REFUND)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_REFUND, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_ar_get_refund output flist", *ret_flistpp);
	return;
}


/**
 * We use this function to get refund information
 * on basis transaction id or MSISDN or ACCOUNT_NO.
 *     *
 *  @param ctxp The context pointer.
 *  @param in_flistp in the input flist.
 *  @param ebufp The error buffer.
 *  @return flistp. 
 *    
 *  */

void
fm_tab_ar_get_refund (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	pin_flist_t		*search_inp_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	pin_flist_t		*search_rflistp = NULL;
	pin_flist_t		*refund_flistp = NULL;
	pin_flist_t		*bal_impacts_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*refund_res_flistp = NULL;
	pin_flist_t		*return_flistp = NULL;
	pin_flist_t		*hook_return_flistp = NULL;
	pin_flist_t             *event_read_obj_iflistp = NULL;
	pin_flist_t             *event_read_obj_rflistp = NULL;
	pin_flist_t             *event_reason_flistp = NULL;
	char			*trans_id = NULL;
	char			*account_no = NULL;
	char			*msisdn = NULL;
	char			log_msg[512] = "";
	char			log_msg1[512] = "";
	char			*inp_start_date_str = NULL;
	char			*inp_end_date_str = NULL;
	time_t			current_time = pin_virtual_time((time_t *)NULL);
	time_t			start_t = 0;
	time_t			end_t = 0;
	pin_cookie_t		refund_cookie = NULL;
	int32			refund_elemid = 0;
	pin_cookie_t		bal_cookie = NULL;
	int32			bal_elemid = 0;
	int32			*impact_type = NULL;
	pin_flist_t		*res_data_return_flistp = NULL;
	pin_cookie_t            res_cookie = NULL;
	int32                   res_elemid = 0;
	int32                   error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_refund: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund function entry error",ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_refund: input flist", in_flistp);

	/*Check for account number or MSISDN*/
	account_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if((account_no == NULL || strlen(account_no ) == 0)
		&& (msisdn == NULL || strlen(msisdn) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_refund:input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	trans_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	search_inp_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, search_inp_flistp, PIN_FLD_POID, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, search_inp_flistp, PIN_FLD_TRANS_ID, ebufp);

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_ar_get_refund input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_refund:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	PIN_FLIST_FLD_COPY(enrich_iflistp, PIN_FLD_ACCOUNT_OBJ, search_inp_flistp, PIN_FLD_POID, ebufp);

	/* Check for dates ranges from input */
	inp_start_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_START, 1, ebufp);
	if(inp_start_date_str != NULL && strlen(inp_start_date_str) != 0)	
	{
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_start_date_str, ebufp);
	}

	inp_end_date_str = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_END, 1, ebufp);
	if(inp_end_date_str != NULL && strlen(inp_end_date_str) != 0)
	{
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, inp_end_date_str, ebufp);
	}

	if(start_t == 0 && end_t == 0)
	{
		end_t = current_time;
		start_t = end_t- ONEDAY * 30;
	}
	else if(end_t == 0 && start_t != 0)
	{
		end_t = start_t + ONEDAY * 30;
	}
	else if(start_t == 0 && end_t != 0)
	{
		start_t = end_t - ONEDAY * 30;
	}
	if(!((end_t - start_t) <= ONEDAY * 30))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_ar_get_refund:"
			" input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INCORRECT_DATE_RANGE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
			"Start and End Date Range is greater than 30 days", ebufp);
		goto cleanup;
	}

	sprintf(log_msg,"start_t %ld",start_t);
	sprintf(log_msg1,"current_time %ld",current_time);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg1);

	PIN_FLIST_FLD_SET(search_inp_flistp, PIN_FLD_START_T, &start_t, ebufp);
	PIN_FLIST_FLD_SET(search_inp_flistp, PIN_FLD_END_T, &end_t, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_refund_details"
		" input flist:", search_inp_flistp);

	fm_tab_utils_common_get_refund_details(ctxp, flags, search_inp_flistp, &search_rflistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_ar_get_refund input flist", search_inp_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund: "
                        "fm_tab_utils_common_get_refund_details error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_REFUND, 0, 0, 0);
                goto cleanup;
        }

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_refund: fm_tab_utils_common_get_refund_details"
		" output flist:", search_rflistp);

	if((res_flistp = PIN_FLIST_ELEM_GET_NEXT(search_rflistp, PIN_FLD_RESULTS,
		&refund_elemid, 1, &refund_cookie, ebufp)) == (pin_flist_t *)NULL)
	{
		if(trans_id != NULL && strlen(trans_id) != 0)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
				"Error,  No events associated with TransID", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_REFUND_DATA_FOUND, 0, 0, 0);
			goto cleanup;
		}
		else if(((msisdn != NULL && strlen(msisdn)) != 0) ||(account_no != NULL && strlen(account_no) != 0))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
				"input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
				"Error, No events associated with given MSISDN and date range", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NO_REFUND_DATA_FOUND, 0, 0, 0);
			goto cleanup;
		}

	}
	return_flistp = PIN_FLIST_CREATE(ebufp);

	refund_elemid = 0;
	refund_cookie = NULL;
	while((res_flistp= PIN_FLIST_ELEM_GET_NEXT(search_rflistp, PIN_FLD_RESULTS,
		&refund_elemid, 1, &refund_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                        "fm_tab_ar_get_refund result flist", res_flistp);
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_ACCOUNT_OBJ,return_flistp, PIN_FLD_POID, ebufp);
		refund_res_flistp = PIN_FLIST_ELEM_GET(res_flistp, TAB_FLD_REFUND_INFO,
				PIN_ELEMID_ANY, 1, ebufp);

		refund_flistp = PIN_FLIST_ELEM_ADD(return_flistp, TAB_FLD_REFUND_INFO, 
				refund_elemid, ebufp);

		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_CHANNEL_ID_STR, refund_flistp, TAB_FLD_CHANNEL_ID_STR, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_BRANCH_NO, refund_flistp, PIN_FLD_BRANCH_NO, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_DEALER_CODE, refund_flistp, PIN_FLD_DEALER_CODE, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_DEALER_NAME, refund_flistp, PIN_FLD_DEALER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_TRANS_ID, refund_flistp, PIN_FLD_TRANS_ID, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_PAYMENT_TRANS_ID , refund_flistp, PIN_FLD_PAYMENT_TRANS_ID , ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_BANK_CODE, refund_flistp, PIN_FLD_BANK_CODE, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_DESCR, refund_flistp, PIN_FLD_DESCR, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_LOCATION, refund_flistp, PIN_FLD_LOCATION, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_USER_NAME, refund_flistp, PIN_FLD_USER_NAME, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_BANK_ACCOUNT, refund_flistp, PIN_FLD_BANK_ACCOUNT, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, PIN_FLD_CHECK_NO, refund_flistp, PIN_FLD_CHECK_NO, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_CHECK_AMOUNT, refund_flistp, TAB_FLD_CHECK_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_CHECK_NAME, refund_flistp, TAB_FLD_CHECK_NAME, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_BANK_BRNCH_CODE, refund_flistp, TAB_FLD_BANK_BRNCH_CODE, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_CHECK_ISSUE_T_STR, refund_flistp, TAB_FLD_CHECK_ISSUE_T_STR, ebufp);
		PIN_FLIST_FLD_COPY(refund_res_flistp, TAB_FLD_GL_GRP_CODE, refund_flistp, TAB_FLD_GL_GRP_CODE, ebufp);

		bal_elemid = 0;
		bal_cookie = NULL;
		while((bal_impacts_flistp = PIN_FLIST_ELEM_GET_NEXT(res_flistp, PIN_FLD_BAL_IMPACTS,
			&bal_elemid, 1, &bal_cookie, ebufp)) != (pin_flist_t *)NULL)
		{

			impact_type = (int32 *)PIN_FLIST_FLD_GET(bal_impacts_flistp, PIN_FLD_IMPACT_TYPE, 1, ebufp);
			if ( impact_type && *impact_type == PIN_IMPACT_TYPE_PRERATED )
			{
				PIN_FLIST_FLD_COPY(bal_impacts_flistp, PIN_FLD_AMOUNT, 
					refund_flistp, PIN_FLD_AMOUNT, ebufp);
			}
			if ( impact_type && *impact_type == PIN_IMPACT_TYPE_TAX)
			{
				/*
				PIN_FLIST_FLD_COPY(bal_impacts_flistp, PIN_FLD_AMOUNT,
					refund_flistp, PIN_FLD_TAX_RECVD, ebufp);
				*/
			}
		}
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID,refund_flistp, PIN_FLD_EVENT_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_ITEM_OBJ,refund_flistp,PIN_FLD_ITEM_OBJ,ebufp);
		event_read_obj_iflistp = PIN_FLIST_CREATE(ebufp);	
		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_POID,event_read_obj_iflistp, PIN_FLD_POID, ebufp);	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_refund:"
				" READ_OBJ input flist:", event_read_obj_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, event_read_obj_iflistp, &event_read_obj_rflistp,ebufp);
		PIN_FLIST_DESTROY_EX(&event_read_obj_iflistp, NULL);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_refund:"
				"READ_OBJ output flist", event_read_obj_rflistp);
		event_reason_flistp = PIN_FLIST_ELEM_GET(event_read_obj_rflistp,PIN_FLD_EVENT_MISC_DETAILS,
				PIN_ELEMID_ANY,1,ebufp);
		if(event_reason_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_ID, refund_flistp, PIN_FLD_REASON_ID, ebufp);
			PIN_FLIST_FLD_COPY(event_reason_flistp, PIN_FLD_REASON_DOMAIN_ID, refund_flistp, PIN_FLD_REASON_DOMAIN_ID, ebufp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_ar_get_refund:"
			" POL_POST_GET_REFUND hook input flist:", return_flistp);

	/*Calling TAB_OP_AR_POL_POST_GET_REFUND Policy opcode*/
	PCM_OP(ctxp, TAB_OP_AR_POL_POST_GET_REFUND, 0, return_flistp, &hook_return_flistp,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
			"Hook opcode  flist", return_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_ar_get_refund:"
			"Hook opcode  flist error", ebufp);

		error_code = (ebufp)->pin_err;
                PIN_ERRBUF_CLEAR(ebufp);
                *ret_flistpp = PIN_FLIST_COPY(hook_return_flistp, ebufp);
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                error_code, 0, 0, 0);

		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_refund:"
		"POL_POST_GET_REFUND hook return flist", hook_return_flistp);
	
	PIN_FLIST_FLD_DROP(hook_return_flistp,PIN_FLD_POID,ebufp);
	res_elemid = 0;
	res_cookie = NULL;
	while((res_data_return_flistp = PIN_FLIST_ELEM_GET_NEXT(hook_return_flistp, TAB_FLD_REFUND_INFO,
					&res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		PIN_FLIST_FLD_DROP(res_data_return_flistp,PIN_FLD_EVENT_OBJ,ebufp);
		PIN_FLIST_FLD_DROP(res_data_return_flistp,PIN_FLD_ITEM_OBJ,ebufp);
	}

	PIN_FLIST_CONCAT(*ret_flistpp, hook_return_flistp, ebufp);

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&hook_return_flistp,NULL);
	PIN_FLIST_DESTROY_EX (&return_flistp,NULL);
	PIN_FLIST_DESTROY_EX (&res_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_rflistp,NULL);
	PIN_FLIST_DESTROY_EX(&search_inp_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp,NULL);
	PIN_FLIST_DESTROY_EX(&event_read_obj_rflistp, NULL);	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_ar_get_refund output flist ",*ret_flistpp);
	return;
}
