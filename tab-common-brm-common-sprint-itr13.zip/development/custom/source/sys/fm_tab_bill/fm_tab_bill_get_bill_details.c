/*******************************************************************************
 *
 *	 This material is the confidential property	of Telenor/Oracle Corporation or its
 *	 licensors and may be used,	reproduced,	stored or transmitted only in
 *	 accordance	with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details
 *
 *					| 1		| 11-Mar-2022	| Piyush		   |			   | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains	the	TAB_OP_BILL_GET_BILL_DETAILS operation.
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "ops/ar.h"
#include "cm_fm.h"
#include "tab_common.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines	contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_bill_get_bill_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_bill_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_bills_without_date(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp);

static void
fm_tab_bill_get_bills_with_bill_no(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp);

static void
fm_tab_bill_get_bills_with_date(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp);

static void
fm_tab_bill_get_bills_prepare_outpt(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	*return_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern pin_flist_t*
fm_tab_utils_common_prep_simple_search_flist(
    char                    *template,
    field_t                 args_struct[],
    int                     n_args,
    field_t                 result_struct[],
    int                     n_results,
    int64                   db_no,
    int                     flags,
    pin_errbuf_t            *ebufp);
	
/**************************************************************************
 *
 * New opcode TAB_OP_BILL_GET_BILL_DETAILS	is implemented to
 * get the bill details for the account object.
 * @param connp	The	connection pointer.
 * @param opcode This opcode.
 * @param flags	The	opcode flags.
 * @param in_flistp	The	input flist	contains PIN_FLD_MSISDN	& PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with	account	poid information.
 * @param ebufp	The	error buffer.
 * @return nothing.
 *
 * Sample Input	Flist
 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_ACCOUNT_NO      STR [0] "CINT_ACC003"
 0 PIN_FLD_MSISDN            STR [0] "0902022002"
 0 PIN_FLD_BILL_NO            STR [0] "B1-24"
 0 TAB_FLD_ITEM_DET_FLAG INT [0] 1
 0 TAB_FLD_BILL_START_T_STR STR [0] "01-NOV-202100:00:00"
 0 TAB_FLD_BILL_END_T_STR STR [0] "01-DEC-202100:00:00"
 0 PIN_FLD_CORRELATION_ID    STR [0] "02122021_60005"
 0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM3"
 *
 **************************************************************************/
/**************************************************************************
 * Main	routine	for	the	TAB_OP_BILL_GET_BILL_DETAILS operation.
 *************************************************************************/
void
op_tab_bill_get_bill_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp =	connp->dm_ctx;
	pin_flist_t		*r_flistp =	NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp	= NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code	= 0;
	char			log_msg[512]= "";
	int64			db_no =	0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details:"
				"flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_bill_get_bill_details function	entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity	check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_GET_BILL_DETAILS)	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,	0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details bad opcode	error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_bill_details input	flist",	in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no =	fm_tab_utils_common_get_db_no(ctxp,	in_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details:"
				"fm_tab_utils_common_get_db_no flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_bill_details: "
				"fm_tab_utils_common_get_db_no error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}	

	/******************************************************************************
	 * Validate	and	normalize the input.
	 ******************************************************************************/

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details:"
				" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_bill_details: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_bill_details:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/******************************************************************************
	 * Call	main routine
	 ******************************************************************************/

	fm_tab_bill_get_bill_details(ctxp,enrich_iflistp,&r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details:"
				"flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_bill_details error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_bill_details:"
				"input flist ",	in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_bill_details:"
				" Error	while  fetching	the	events", ebufp);

		cerror_code	= ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code	= TAB_ERR_CODE_API_GET_BILL_DETAILS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp,	in_flistp, error_clear_flag,
				cerror_code, &r_flistp,	db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_BILL_DETAILS )
		{
			PIN_FLIST_FLD_SET(r_flistp,	PIN_FLD_ERROR_CODE,	log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,	PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_BILL_DETAILS, ebufp);
		}
		PIN_FLIST_FLD_SET(r_flistp,	TAB_FLD_REQUEST_STATUS,	&status, ebufp)
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp,	TAB_FLD_REQUEST_STATUS,	&status, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_bill_details output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/***********************************************************
 * This	is the core	function which searches	bills, items 
 * prepares	the	output flist as	per	the	spec.
 * logs	the	input and output flist.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param db_no	Database number
 * @param ebufp	The	error buffer.
 ***********************************************************/

/***********************************************************
  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
  0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
  0 PIN_FLD_MSISDN            STR [0] "68748927495"
  0 PIN_FLD_BILL_NO            STR [0] "bill-1234"
  0 TAB_FLD_ITEM_DET_FLAG INT [0] 0
  0 TAB_FLD_BILL_START_T_STRSTR [0] “01-NOV-202100:00:00”
  0 TAB_FLD_BILL_END_T_STRSTR [0] “01-DEC-202100:00:00”
  0 PIN_FLD_CORRELATION_ID    STR [0] "02122021_60005"
  0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM3"
 ***********************************************************/
static void
fm_tab_bill_get_bill_details(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	pin_flist_t	*return_flistp=NULL;
	pin_flist_t	*rbillinfo_flistp=NULL;
	pin_flist_t 	*get_unbilled_items_iflistp=NULL;
	pin_flist_t 	*get_unbilled_items_outflistp=NULL;
	pin_flist_t 	*get_details_policy_flistp=NULL;
	pin_flist_t 	*get_details_policy_outflistp=NULL;
	poid_t 		*account_pdp=NULL;
	int 		pay_type=0;
	int 		status=0;
	int 		include_child=1;
	int32           error_code = 0;
	pin_flist_t 	*result_billinfo_flistp=NULL;
	pin_flist_t 	*output_flistp=NULL;

	char		*acct_nop = NULL;
	char		*msisdnp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	

	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bill_details:"
				"account number/msisdn is not passed", ebufp);
		return;
	}	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bill_details input flist", in_flistp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);	

	/*******************************************************************
	 * get the pay type details
	 *******************************************************************/
	fm_tab_utils_common_get_owner_billinfo_details(ctxp,in_flistp,&rbillinfo_flistp,db_no,ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_BILL_DETAILS, 0, 0, 0);
		goto cleanup;
	}

	if((result_billinfo_flistp=PIN_FLIST_ELEM_GET(rbillinfo_flistp,PIN_FLD_RESULTS,0,1,ebufp))!=NULL)
	{
		pay_type = *(int *)PIN_FLIST_FLD_GET(result_billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		PIN_FLIST_FLD_SET(in_flistp,PIN_FLD_PAY_TYPE,&pay_type,ebufp);	

		PIN_FLIST_FLD_COPY(result_billinfo_flistp,PIN_FLD_AR_BILLINFO_OBJ,in_flistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
		PIN_FLIST_FLD_COPY(result_billinfo_flistp,PIN_FLD_POID,in_flistp,PIN_FLD_BILLINFO_OBJ,ebufp);
		PIN_FLIST_FLD_COPY(result_billinfo_flistp,PIN_FLD_ACTG_CYCLE_DOM,in_flistp,PIN_FLD_ACTG_CYCLE_DOM,ebufp);
		PIN_FLIST_FLD_COPY(result_billinfo_flistp,PIN_FLD_BILL_WHEN,in_flistp,PIN_FLD_BILL_WHEN,ebufp);	
	}

	if(pay_type==10000) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bill_details:"
				"Prepaid account not supported", ebufp);
		return;
	}		

	/******************************************************************************
	 * Prepare bill	search for API.
	 ******************************************************************************/

	if (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp)!=NULL)
	{
		fm_tab_bill_get_bills_with_bill_no(ctxp,in_flistp,&return_flistp,db_no,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_bills_with_bill_no: "
				"return:", return_flistp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_bill_no: "
					"Input:", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_bill_no: "
					"error", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GET_BILL_DETAILS, 0, 0, 0);
			goto cleanup;
		}
	} else if (pay_type!=10007 && (PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_BILL_START_T_STR,1, ebufp)==NULL && 
				PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_BILL_END_T_STR,1, ebufp)==NULL	))
	{
		fm_tab_bill_get_bills_without_date(ctxp,in_flistp,&return_flistp,db_no,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date: "
					"Input:", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date: "
					"error", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GET_BILL_DETAILS, 0, 0, 0);
			goto cleanup;
		}
	}
	else if (pay_type == 10007)
	{
		status=1;
		get_unbilled_items_iflistp=PIN_FLIST_CREATE(ebufp);	
		PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_POID,account_pdp,ebufp);
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,get_unbilled_items_iflistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILLINFO_OBJ,get_unbilled_items_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
		PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_INCLUDE_CHILDREN,&include_child,ebufp);
		PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_STATUS,&status,ebufp);

		/*******************************************************************
		 * Call PCM_OP_AR_GET_BILL_ITEMS
		 *******************************************************************/		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS input flist", get_unbilled_items_iflistp);
		PCM_OP(ctxp, PCM_OP_AR_GET_BILL_ITEMS, 0, get_unbilled_items_iflistp, &get_unbilled_items_outflistp, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS output flist", get_unbilled_items_outflistp);
		PIN_FLIST_DESTROY_EX(&get_unbilled_items_iflistp, NULL);

		PIN_FLIST_FLD_RENAME(get_unbilled_items_outflistp,PIN_FLD_RESULTS,PIN_FLD_ITEMS,ebufp);
		PIN_FLIST_FLD_DROP(get_unbilled_items_outflistp,PIN_FLD_POID,ebufp);

		//unbilled_item_flistp=PIN_FLIST_ELEM_ADD(return_flistp,TAB_FLD_UNBILLED_DETAILS,0,ebufp);		
		return_flistp=PIN_FLIST_CREATE(ebufp);	
		PIN_FLIST_ELEM_SET(return_flistp,get_unbilled_items_outflistp,TAB_FLD_UNBILLED_DETAILS,0,ebufp);

	}
	else if (pay_type!=10007 && (PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_BILL_START_T_STR,1, ebufp)!=NULL || 
				PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_BILL_END_T_STR,1, ebufp)!=NULL ))
	{
		fm_tab_bill_get_bills_with_date(ctxp,in_flistp,&return_flistp,db_no,ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date: "
					"Input:", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date: "
					"error", ebufp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills: "
			"Input:", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills: No Bills found with search criteria "
			"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_BILL_DETAILS, 0, 0, 0);
		goto cleanup;
	}

	if (return_flistp!=NULL)
	{
		fm_tab_bill_get_bills_prepare_outpt(ctxp,in_flistp,return_flistp,&output_flistp,db_no,ebufp);		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt: "
				"return:", output_flistp);		

	}

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt: "
				"error", ebufp);
		goto cleanup;
	}

	get_details_policy_flistp = PIN_FLIST_COPY(output_flistp, ebufp);

	/*******************************************************************
	 * Call TAB_OP_BILL_POL_GET_BILL_DETAILS
	 *******************************************************************/	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "TAB_OP_BILL_POL_GET_BILL_DETAILS input flist", get_details_policy_flistp);
	PCM_OP(ctxp, TAB_OP_BILL_POL_GET_BILL_DETAILS, 0, get_details_policy_flistp, &get_details_policy_outflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "TAB_OP_BILL_POL_GET_BILL_DETAILS output flist", get_details_policy_outflistp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_BILL_POL_GET_BILL_DETAILS input flist: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt: "
				"error", ebufp);
		error_code = (ebufp)->pin_err;
	        PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp=PIN_FLIST_COPY(get_details_policy_outflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            error_code, 0, 0, 0);
		goto cleanup;
	}	

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
    *out_flistpp=PIN_FLIST_COPY(get_details_policy_outflistp, ebufp);

	PIN_FLIST_DESTROY_EX(&get_details_policy_outflistp, NULL);
	PIN_FLIST_DESTROY_EX(&output_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_unbilled_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_details_policy_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rbillinfo_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_flistp, NULL);	 

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bill_details output flist", *out_flistpp);

	return;
}

/*******************************************************************
 * This	function is	to search the bills without dates based on 
 * account , msisdn and paytype details details
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param out_flistpp return flist.
 * @param db_no for the DB search.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_bills_without_date(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp)
{

	poid_t	*account_pdp=NULL;
	field_t	args_struct[1];
	field_t	result_struct[0];

	int	n_args = 2;
	int	n_results = 0;

	char 	*template= "select X from /bill where  F1 = V1 and F2 != V2";

	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*get_ar_action_items_outflistp=NULL;
	pin_flist_t 	*get_ar_action_items_iflistp=NULL;
	pin_flist_t 	*get_unbilled_items_outflistp=NULL;
	pin_flist_t 	*get_unbilled_items_iflistp=NULL;


	int 		flags=0;
	int 		include_child=0;
	int 		status=2;	
	int		opcode_result= 0 ;

	pin_decimal_t *zerop = pbo_decimal_from_str("0",ebufp);		

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_without_date input flistp", in_flistp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date:"
				" in_flistp", in_flistp);
		return;
	}

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[0].fld_value = account_pdp;

	args_struct[1].fld_name = PIN_FLD_DUE ;
	args_struct[1].fld_value = zerop;

	search_input_flistp = (pin_flist_t *)fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_bill_get_bill_details bill search", 1, ebufp);

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_without_date"
				"error search bill failed", ebufp);
		goto cleanup;
	}

	if (search_out_flistp!=NULL && PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{

		PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);	
		PIN_FLIST_FLD_RENAME(search_out_flistp,	PIN_FLD_RESULTS,PIN_FLD_BILLS,	ebufp);
		PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
	}

	get_ar_action_items_iflistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_POID,account_pdp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,get_ar_action_items_iflistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILLINFO_OBJ,get_ar_action_items_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_INCLUDE_CHILDREN,&include_child,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_STATUS,&status,ebufp);

	/*******************************************************************
	 * Call PCM_OP_AR_GET_ACTION_ITEMS
	 *******************************************************************/	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ACTION_ITEMS input flist", get_ar_action_items_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_GET_ACTION_ITEMS, 0, get_ar_action_items_iflistp, &get_ar_action_items_outflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ACTION_ITEMS output flist", get_ar_action_items_outflistp);

	PIN_FLIST_DESTROY_EX(&get_ar_action_items_iflistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date:"
				" in_flistp", get_ar_action_items_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_without_date"
				"error event not present", ebufp);
		goto cleanup;
	}

	if (PIN_FLIST_ELEM_COUNT(get_ar_action_items_outflistp,PIN_FLD_RESULTS,ebufp))
	{			
		PIN_FLIST_FLD_DROP(get_ar_action_items_outflistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_RENAME(get_ar_action_items_outflistp,	PIN_FLD_RESULTS,PIN_FLD_ITEMS,ebufp);		
		PIN_FLIST_ELEM_SET(search_out_flistp,get_ar_action_items_outflistp,TAB_FLD_UNALLOCATED_AR,0,ebufp);
	}	

	status=1;
	get_unbilled_items_iflistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_POID,account_pdp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,get_unbilled_items_iflistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILLINFO_OBJ,get_unbilled_items_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_INCLUDE_CHILDREN,&include_child,ebufp);
	PIN_FLIST_FLD_SET(get_unbilled_items_iflistp, PIN_FLD_STATUS,&status,ebufp);


	/*******************************************************************
	 * Call PCM_OP_AR_GET_BILL_ITEMS
	 *******************************************************************/	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS input flist", get_unbilled_items_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_GET_BILL_ITEMS, 0, get_unbilled_items_iflistp, &get_unbilled_items_outflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS out flist", get_unbilled_items_outflistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_without_date:"
				" in_flistp", get_ar_action_items_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_without_date"
				"error event not present", ebufp);
		goto cleanup;
	}

	if (PIN_FLIST_ELEM_COUNT(get_unbilled_items_outflistp,PIN_FLD_RESULTS,ebufp))
	{			
		PIN_FLIST_FLD_DROP(get_unbilled_items_outflistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_RENAME(get_unbilled_items_outflistp,	PIN_FLD_RESULTS,PIN_FLD_ITEMS,ebufp);
		PIN_FLIST_ELEM_SET(search_out_flistp,get_unbilled_items_outflistp,TAB_FLD_UNBILLED_DETAILS,0,ebufp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_unbilled_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_ar_action_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_unbilled_items_outflistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_ar_action_items_outflistp, NULL);	
    if (zerop)
    {
		pbo_decimal_destroy(&zerop);
    }

	*out_flistpp=search_out_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_without_date output flist", *out_flistpp);

	return;
}


/*******************************************************************
 * This	function is	to search the bills by bill no and get bills 
 * Items.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param out_flistpp return flist.
 * @param db_no for the DB search.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_bills_with_bill_no(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp)
{

	poid_t	*account_pdp=NULL;
	poid_t	*billinfo_pdp=NULL;
	poid_t	*ar_billlinfo_pdp=NULL;

	field_t	args_struct[3];
	field_t	result_struct[0];

	int	n_args = 3;
	int	n_results = 0;

	char 	*template= "select X from /bill 1 where  F1 = V1 and F2 = V2 and F3 = V3 ";

	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*get_billed_items_outflistp=NULL;
	pin_flist_t 	*get_billed_items_iflistp=NULL;

	int 		flags=0;
	int 		include_child=1;
	int		opcode_result= 0 ;

	char 	*bill_nop=NULL;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_with_bill_no input flistp", in_flistp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_bill_no	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_bill_no:"
				" in_flistp", in_flistp);
		return;
	}

	bill_nop=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILL_NO,1, ebufp);
	billinfo_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILLINFO_OBJ,1, ebufp);
	ar_billlinfo_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,1, ebufp);

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_BILL_NO;
	args_struct[0].fld_value = bill_nop;

	args_struct[1].fld_name = PIN_FLD_BILLINFO_OBJ;
	args_struct[1].fld_value = billinfo_pdp;

	args_struct[2].fld_name = PIN_FLD_AR_BILLINFO_OBJ;
	args_struct[2].fld_value = ar_billlinfo_pdp;

	search_input_flistp = (pin_flist_t*)fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_bill_get_bills_with_bill_no bill search", 1, ebufp);

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_bill_no"
				"error search bill failed", ebufp);
		goto cleanup;
	}

	if (search_out_flistp!=NULL && PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		PIN_FLIST_FLD_RENAME(search_out_flistp,PIN_FLD_RESULTS,PIN_FLD_BILLS,ebufp);
		PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);	
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_bill_no"
				"error bill not found", ebufp);
		goto cleanup;
	}

	get_billed_items_iflistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_SET(get_billed_items_iflistp, PIN_FLD_POID,account_pdp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,get_billed_items_iflistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILL_NO,get_billed_items_iflistp,PIN_FLD_BILL_NO,ebufp);	
	PIN_FLIST_FLD_SET(get_billed_items_iflistp, PIN_FLD_INCLUDE_CHILDREN,&include_child,ebufp);

	/*******************************************************************
	 * Call PCM_OP_AR_GET_BILL_ITEMS
	 *******************************************************************/

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1, ebufp)!=NULL && 
			PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_ITEM_DET_FLAG,1, ebufp)!=NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS input flist", get_billed_items_iflistp);
		PCM_OP(ctxp, PCM_OP_AR_GET_BILL_ITEMS, 0, get_billed_items_iflistp, &get_billed_items_outflistp, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_BILL_ITEMS out flist", get_billed_items_outflistp);

		PIN_FLIST_FLD_RENAME(get_billed_items_outflistp,PIN_FLD_RESULTS,PIN_FLD_ITEMS,ebufp);
		PIN_FLIST_FLD_DROP(get_billed_items_outflistp,PIN_FLD_POID,ebufp);	
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_bill_no:"
					" in_flistp", get_billed_items_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_bill_no"
					"error event not present", ebufp);
			goto cleanup;
		}

		PIN_FLIST_DESTROY_EX(&get_billed_items_iflistp, NULL);
		PIN_FLIST_CONCAT(search_out_flistp,get_billed_items_outflistp,ebufp);
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_billed_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_billed_items_outflistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);


	*out_flistpp=search_out_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_with_bill_no output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * This	function is	to search the bills by given dates
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param out_flistpp return flist.
 * @param db_no for the DB search.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_bills_with_date(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64 		db_no,
	pin_errbuf_t	*ebufp)
{

	poid_t	*account_pdp=NULL;
	field_t	args_struct[4];
	field_t	result_struct[0];

	int	n_args = 4;
	int	n_results = 0;

	char 	*template= "select X from /bill 1 where  F1 = V1 and F2 >= V2 and F3 <= V3 and F4 != V4 ";

	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*get_ar_action_items_iflistp=NULL;
	pin_flist_t 	*get_ar_action_items_outflistp=NULL;

	int 		flags=0;
	int		opcode_result= 0 ;
	int 	include_child=0;
	int 	status=2;

	char 	*input_start_date=NULL;
	char 	*input_end_date=NULL;
	time_t 	start_date=0;
	time_t 	end_date=0;
	time_t 	now_t=pin_virtual_time(NULL);

	pin_decimal_t *zerop = pbo_decimal_from_str("0",ebufp);	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_with_date input flistp", in_flistp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_date	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_date:"
				" in_flistp", in_flistp);
		return;
	}

	if((input_start_date = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_BILL_START_T_STR, 1, ebufp))!=NULL)
	{
		start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_start_date,ebufp);
	}

	if((input_end_date=PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_BILL_END_T_STR, 1, ebufp))!=NULL)
	{
		end_date= fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_end_date,ebufp);
	}

	if(!start_date)
	{
		if(!end_date)
			end_date=now_t;

		start_date=end_date-ONEDAY*90;
	}

	if(!end_date)
	{
		if(!start_date)
			start_date=now_t-ONEDAY*90;

		end_date=start_date+ONEDAY*90;
	}

	//Setting the arguments
	args_struct[0].fld_name = PIN_FLD_ACCOUNT_OBJ;
	args_struct[0].fld_value = account_pdp;

	args_struct[1].fld_name = PIN_FLD_START_T;
	args_struct[1].fld_value = &start_date;

	args_struct[2].fld_name = PIN_FLD_END_T;
	args_struct[2].fld_value = &end_date;

	args_struct[3].fld_name = PIN_FLD_DUE;
	args_struct[3].fld_value = zerop;

	search_input_flistp = (pin_flist_t *)fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

	opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
			&search_out_flistp, "fm_tab_bill_get_bills_with_date bill search", 1, ebufp);

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (opcode_result != 0) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_date"
				"error search bill failed", ebufp);
		goto cleanup;
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_date:"
				" in_flistp", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_date:"
				"error", ebufp);
		goto cleanup;
	}

	if (search_out_flistp!=NULL && PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{

		PIN_FLIST_FLD_RENAME(search_out_flistp,PIN_FLD_RESULTS,PIN_FLD_BILLS,ebufp);
		PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);	
	}


	get_ar_action_items_iflistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_POID,account_pdp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_AR_BILLINFO_OBJ,get_ar_action_items_iflistp,PIN_FLD_AR_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BILLINFO_OBJ,get_ar_action_items_iflistp,PIN_FLD_BILLINFO_OBJ,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_INCLUDE_CHILDREN,&include_child,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_STATUS,&status,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_START_T,&start_date,ebufp);
	PIN_FLIST_FLD_SET(get_ar_action_items_iflistp, PIN_FLD_END_T,&end_date,ebufp);

	/*******************************************************************
	 * Call PCM_OP_AR_GET_ACTION_ITEMS
	 *******************************************************************/	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ACTION_ITEMS input flist", get_ar_action_items_iflistp);
	PCM_OP(ctxp, PCM_OP_AR_GET_ACTION_ITEMS, 0, get_ar_action_items_iflistp, &get_ar_action_items_outflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ACTION_ITEMS output flist", get_ar_action_items_outflistp);

	PIN_FLIST_DESTROY_EX(&get_ar_action_items_iflistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_with_date:"
				" in_flistp", get_ar_action_items_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_date:"
				"error ar item search failed", ebufp);
		goto cleanup;
	}

	if (PIN_FLIST_ELEM_COUNT(get_ar_action_items_outflistp,PIN_FLD_RESULTS,ebufp))
	{			
		PIN_FLIST_FLD_DROP(get_ar_action_items_outflistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_RENAME(get_ar_action_items_outflistp,	PIN_FLD_RESULTS,PIN_FLD_ITEMS,ebufp);		
		PIN_FLIST_ELEM_SET(search_out_flistp,get_ar_action_items_outflistp,TAB_FLD_UNALLOCATED_AR,0,ebufp);
	}		

	if(!PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_BILLS,ebufp) && 
			!PIN_FLIST_ELEM_COUNT(get_ar_action_items_outflistp,PIN_FLD_ITEMS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_bills_with_date"
				"error bill not found", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
    if (zerop)
    {
    	pbo_decimal_destroy(&zerop);
    }

	*out_flistpp=search_out_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_with_date output flist", *out_flistpp);

	return;
}

/*******************************************************************
 * This	function is	to create the output response of get bill detail
 * search opcode.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param function_flistp as input for function for output alignment.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/
static void
fm_tab_bill_get_bills_prepare_outpt(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	*function_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_bills_prepare_outpt input", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_bills_prepare_outpt:"
				" input	flist",	in_flistp);
		return;
	}

	pin_flist_t	*items_flistp=NULL;
	pin_flist_t *bills_flistp=NULL;
	pin_flist_t *return_bill_flistp=NULL;
	pin_flist_t *return_item_flistp=NULL;
	pin_flist_t *return_unbilled_item_flistp=NULL;
	pin_flist_t *return_ar_item_flistp=NULL;
	pin_flist_t *ar_item_flistp=NULL;
	pin_flist_t *unbilled_item_flistp=NULL;
	pin_flist_t *unbilled_flistp=NULL;
	pin_flist_t *ar_flistp=NULL;
	pin_flist_t *read_bill_flistp=NULL;

	int		elem_bill = 0 ;
	int		elem_item=0;
	int 	item_flag=0;
	int 	status =2;

	pin_cookie_t	cookie_bill = NULL;
	pin_cookie_t	cookie_item= NULL;

	time_t 		start_t=0;
	time_t 		end_t=0;
	time_t 		due_t=0;
	time_t		closed_t=0;
	time_t 		effective_t=0;

	poid_t 		*bill_pdp=NULL;
	poid_t 		*ar_bill_pdp=NULL;

	char 		*start_datep=NULL;
	char 		*end_datep=NULL;
	char 		*due_datep=NULL;
	char 		*closed_datep=NULL;
	char 		*effective_datep=NULL;
       
    int32           error_code = 0;

	pin_decimal_t *duep=pbo_decimal_from_str("0",ebufp);
	pin_decimal_t *zerop=pbo_decimal_from_str("0",ebufp);

	/******************************************************************
	 * Global Flist	return_flistp
	 ******************************************************************/
	pin_flist_t	*return_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,	return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACTG_CYCLE_DOM,	return_flistp, PIN_FLD_ACTG_CYCLE_DOM, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_WHEN,	return_flistp, PIN_FLD_BILL_WHEN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp,	PIN_FLD_EXTERNAL_USER, ebufp);

	if (PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_ITEM_DET_FLAG,1,ebufp)!=NULL && 
			PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILL_NO,1,ebufp)!=NULL)
	{
		item_flag =*(int*)PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_ITEM_DET_FLAG,1,ebufp);
	}

	/******************************************************************
	 * Traverse	Item to	get	the	events and add it in return	Flist
	 ******************************************************************/

	while ((bills_flistp	= PIN_FLIST_ELEM_GET_NEXT(function_flistp, PIN_FLD_BILLS,
					&elem_bill,	1, &cookie_bill, ebufp)) !=	(pin_flist_t*)NULL)
	{						
		return_bill_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_BILLS,elem_bill,ebufp);

		start_t =*(time_t*)PIN_FLIST_FLD_GET(bills_flistp,PIN_FLD_START_T,0,	ebufp);
		end_t = *(time_t*)PIN_FLIST_FLD_GET(bills_flistp,PIN_FLD_END_T,0,	ebufp);
		due_t = *(time_t*)PIN_FLIST_FLD_GET(bills_flistp,PIN_FLD_DUE_T,0, ebufp);
		closed_t = *(time_t*)PIN_FLIST_FLD_GET(bills_flistp,PIN_FLD_CLOSED_T,0, ebufp);

		bill_pdp = PIN_FLIST_FLD_GET(bills_flistp,PIN_FLD_POID,0, ebufp);

		start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&start_t,ebufp);
		PIN_FLIST_FLD_SET(return_bill_flistp, TAB_FLD_BILL_START_T_STR, start_datep, ebufp);
		free(start_datep);

		end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&end_t,ebufp);
		PIN_FLIST_FLD_SET(return_bill_flistp, TAB_FLD_BILL_END_T_STR, end_datep, ebufp);
		free(end_datep);

		due_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&due_t,ebufp);
		PIN_FLIST_FLD_SET(return_bill_flistp, TAB_FLD_DUE_T_STR,	due_datep, ebufp);
		free(due_datep);
	
		closed_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&closed_t,ebufp);
		PIN_FLIST_FLD_SET(return_bill_flistp, TAB_FLD_CLOSED_T_STR,	closed_datep, ebufp);				
		free(closed_datep);

		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_BILL_NO,return_bill_flistp,PIN_FLD_BILL_NO, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_NAME,return_bill_flistp,PIN_FLD_NAME, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_TOTAL_DUE,return_bill_flistp,PIN_FLD_TOTAL_DUE, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_DUE,return_bill_flistp,PIN_FLD_DUE, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_PREVIOUS_TOTAL,return_bill_flistp,PIN_FLD_PREVIOUS_TOTAL, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_CURRENT_TOTAL,return_bill_flistp,PIN_FLD_CURRENT_TOTAL, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_SUBORDS_TOTAL,return_bill_flistp,PIN_FLD_SUBORDS_TOTAL, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_RECVD,return_bill_flistp,PIN_FLD_RECVD, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_ADJUSTED,return_bill_flistp,PIN_FLD_ADJUSTED, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_DISPUTED,return_bill_flistp,PIN_FLD_DISPUTED, ebufp);
		PIN_FLIST_FLD_COPY(bills_flistp, PIN_FLD_TAX,return_bill_flistp,PIN_FLD_TAX, ebufp);	

		/******************************************************************
		 * Traverse	item add it in return	Flist
		 ******************************************************************/
		elem_item=0;
		cookie_item=NULL;

		if(item_flag)
		{
			while ((items_flistp =	PIN_FLIST_ELEM_GET_NEXT(function_flistp,
							PIN_FLD_ITEMS,	&elem_item, 1,	&cookie_item, ebufp)) != (pin_flist_t*)NULL)
			{												
				effective_t =*(time_t*)PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_EFFECTIVE_T,0,ebufp);
				effective_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&effective_t,ebufp);

				ar_bill_pdp = PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_AR_BILL_OBJ,0, ebufp);

				duep = PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_DUE,0, ebufp);

				if (!pbo_decimal_compare(duep,zerop,ebufp))
					status =4;
				else 
					status =2;

				if (!PIN_POID_COMPARE(bill_pdp,ar_bill_pdp,0,ebufp))
				{	
					return_item_flistp=PIN_FLIST_ELEM_ADD(return_bill_flistp,PIN_FLD_ITEMS,elem_item,ebufp);

					PIN_FLIST_FLD_SET(return_item_flistp, TAB_FLD_EFFECTIVE_T_STR, effective_datep, ebufp);
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_DUE, return_item_flistp,PIN_FLD_DUE, ebufp);
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_ADJUSTED, return_item_flistp,PIN_FLD_ADJUSTED, ebufp);
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_DISPUTED, return_item_flistp,PIN_FLD_DISPUTED, ebufp);
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_TAX, return_item_flistp,PIN_FLD_TAX, ebufp);			
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_NAME, return_item_flistp,PIN_FLD_NAME, ebufp);			
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_ITEM_TOTAL, return_item_flistp,PIN_FLD_ITEM_TOTAL, ebufp);					
					PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_STATUS, return_item_flistp,PIN_FLD_STATUS, ebufp);			
					PIN_FLIST_FLD_SET(return_item_flistp, PIN_FLD_STATUS,&status, ebufp);

				}			
			}
		}		
	}

	elem_item=0;
	cookie_item=NULL;	
	bill_pdp=NULL;

	if(PIN_FLIST_ELEM_GET(function_flistp,TAB_FLD_UNBILLED_DETAILS,0,1,ebufp)!=NULL)
	{		
		unbilled_flistp=PIN_FLIST_ELEM_GET(function_flistp,TAB_FLD_UNBILLED_DETAILS,0,1,ebufp);		
		unbilled_item_flistp=PIN_FLIST_ELEM_ADD(return_flistp,TAB_FLD_UNBILLED_DETAILS,0,ebufp);
		status=1;
		while ((items_flistp =	PIN_FLIST_ELEM_GET_NEXT(unbilled_flistp,
						PIN_FLD_ITEMS,	&elem_item, 1,	&cookie_item, ebufp)) != (pin_flist_t*)NULL)
		{			
			return_unbilled_item_flistp=PIN_FLIST_ELEM_ADD(unbilled_item_flistp,PIN_FLD_ITEMS,elem_item,ebufp);
			effective_t =*(time_t*)PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_EFFECTIVE_T,0,ebufp);						
			effective_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&effective_t,ebufp);

			bill_pdp = PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_BILL_OBJ,0, ebufp);

			PIN_FLIST_FLD_SET(return_unbilled_item_flistp, TAB_FLD_EFFECTIVE_T_STR, effective_datep, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_DUE, return_unbilled_item_flistp,PIN_FLD_DUE, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_NAME, return_unbilled_item_flistp,PIN_FLD_NAME, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_ITEM_TOTAL, return_unbilled_item_flistp,PIN_FLD_ITEM_TOTAL, ebufp);			
			PIN_FLIST_FLD_SET(return_unbilled_item_flistp, TAB_FLD_EFFECTIVE_T_STR, effective_datep, ebufp);
			PIN_FLIST_FLD_SET(return_unbilled_item_flistp, PIN_FLD_STATUS,&status, ebufp);
		}

		if (bill_pdp!=NULL && !PIN_POID_IS_NULL(bill_pdp))
		{
			fm_tab_utils_common_read_object(ctxp,bill_pdp,&read_bill_flistp,ebufp);

			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,
						"fm_tab_bill_get_bills_prepare_outpt bill poid flist",	bill_pdp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_bill_get_bills_prepare_outpt: ", ebufp);
				goto cleanup;
			}

			start_t =*(time_t*)PIN_FLIST_FLD_GET(read_bill_flistp,PIN_FLD_START_T,0,ebufp);						
			start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&start_t,ebufp);
			PIN_FLIST_FLD_SET(unbilled_item_flistp, TAB_FLD_BILL_START_T_STR, start_datep, ebufp);
			free(start_datep);

			PIN_FLIST_DESTROY_EX(&read_bill_flistp, NULL);
		}
	}

	elem_item=0;
	cookie_item=NULL;

	if(PIN_FLIST_ELEM_GET(function_flistp,TAB_FLD_UNALLOCATED_AR,0,1,ebufp)!=NULL)
	{	
		status=2;
		ar_flistp=PIN_FLIST_ELEM_GET(function_flistp,TAB_FLD_UNALLOCATED_AR,0,1,ebufp);

		ar_item_flistp=PIN_FLIST_ELEM_ADD(return_flistp,TAB_FLD_UNALLOCATED_AR,0,ebufp);

		while ((items_flistp =	PIN_FLIST_ELEM_GET_NEXT(ar_flistp,
						PIN_FLD_ITEMS,	&elem_item, 1,	&cookie_item, ebufp)) != (pin_flist_t*)NULL)
		{
			return_ar_item_flistp=PIN_FLIST_ELEM_ADD(ar_item_flistp,PIN_FLD_ITEMS,elem_item,ebufp);						

			effective_t =*(time_t*)PIN_FLIST_FLD_GET(items_flistp,PIN_FLD_EFFECTIVE_T,0,ebufp);
			effective_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&effective_t,ebufp);

			PIN_FLIST_FLD_SET(return_ar_item_flistp, TAB_FLD_EFFECTIVE_T_STR, effective_datep, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_DUE, return_ar_item_flistp,PIN_FLD_DUE, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_NAME, return_ar_item_flistp,PIN_FLD_NAME, ebufp);
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_ITEM_TOTAL, return_ar_item_flistp,PIN_FLD_ITEM_TOTAL, ebufp);			
			PIN_FLIST_FLD_COPY(items_flistp, PIN_FLD_STATUS, return_ar_item_flistp,PIN_FLD_STATUS, ebufp);
			PIN_FLIST_FLD_SET(return_ar_item_flistp, PIN_FLD_STATUS,&status, ebufp);			
		}				
	}	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_bills_prepare_outpt input	flist",	in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_bills_prepare_outpt: ", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(return_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);

		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_bill_get_bills_prepare_outpt output flist", return_flistp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp = PIN_FLIST_COPY(return_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_bill_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
	if(effective_datep!=NULL);
	{
		free(effective_datep);
	}
	if (zerop)
	{
		pbo_decimal_destroy(&zerop);
	}

	return;
}
