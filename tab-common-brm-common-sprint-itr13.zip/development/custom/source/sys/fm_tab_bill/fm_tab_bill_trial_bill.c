/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *			| 1	| 16-NOV-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_BILL_TRIAL_BILL operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_pymt.h"
#include "fm_bill_utils.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_bill_trial_bill(
	cm_nap_connection_t 	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_bill_trial_bill(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_execute_trial_bill(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*billinfo_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


/**************************************************************************
 * Main routine for the TAB_OP_BILL_TRIAL_BILL operation.
 *************************************************************************/
void
op_tab_bill_trial_bill(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	poid_t			*account_pdp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_trial_bill function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_TRIAL_BILL) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_trial_bill bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_trial_bill input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_TRIAL_BILL;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_TRIAL_BILL )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_TRIAL_BILL, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_bill_trial_bill(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_trial_bill error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_bill_trial_bill:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_trial_bill: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_BILL_TRIAL_BILL", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_trial_bill:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_TRIAL_BILL;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_TRIAL_BILL )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_TRIAL_BILL, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_trial_bill output flist", *ret_flistpp);
	return;

}

/**
 * We use this function to perform
 * and execute operations related
 * to trial billing.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param db_no
 * @return out_flistpp.
 *
 */

void fm_tab_bill_trial_bill(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*billinfo_details_flistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*trial_bill_oflistp = NULL;
	pin_flist_t		*trial_invoice_read_iflistp = NULL;
	pin_flist_t		*trial_invoice_read_oflistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	int			bill_now_flag = 0;
	int			*resultp = NULL;
	int32			*bill_typep = NULL;
	int32			results_elemid = 0;
	char			*end_date_strp = NULL;
	char			*start_date_strp = NULL;
	char			*msisdnp = NULL;
	char			*account_nop = NULL;
	time_t			start_t = 0;
	time_t			end_t = 0;
	time_t			*next_bill_t =	NULL;
	pin_cookie_t		results_cookie = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_bill_trial_bill input flist", in_flistp);

	end_date_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_END, 1, ebufp);
	/*Check for mandatory end date field*/	
	if((end_date_strp == NULL || PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_END, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_END_T_NOT_PASSED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill:"
			"End Date is mandatory and field not passed", ebufp);
		return;
	}

	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	
	/*Check for account number or MSISDN*/
	if((account_nop == NULL || strlen(account_nop ) == 0) 
		&& (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	/*Get bill info details based on input*/
	if(msisdnp && strlen(msisdnp) != 0)
	{
		fm_tab_utils_common_get_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill: "
				"fm_tab_utils_common_get_billinfo_details output flist", billinfo_details_flistp);
			bill_now_flag = 1;
		}
	}
	else if(account_nop && strlen(account_nop) != 0 && bill_now_flag == 0)
	{
		fm_tab_utils_common_get_owner_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill: "
				"fm_tab_utils_common_get_owner_billinfo_details output flist", billinfo_details_flistp);
		}
	}
	
	if(end_date_strp != NULL)
	{
		/*Convert date in string format to unix timestamp*/
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_date_strp, ebufp);
		PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_END_T, 
				(void *)&end_t, ebufp);
	}

	start_date_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RANGE_START, 1, ebufp);
	if(start_date_strp != NULL)
	{
		/*Convert date in string format to unix timestamp*/
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, start_date_strp, ebufp);
		PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_START_T, 
				(void *)&start_t, ebufp);
	}

	if (billinfo_details_flistp && (billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_flistp, 
			PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		bill_typep = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE,1, ebufp);
		if(*bill_typep == PIN_PAY_TYPE_PREPAID)
		{
			PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_trial_bill input flist",
				billinfo_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill:"
				"Given Account/MSISDN paytype is Prepaid", ebufp);
			goto cleanup;
		}

		if(bill_typep && (*bill_typep != PIN_PAY_TYPE_INVOICE))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_PAY_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill:"
				"Trial Bill cannot be performed for the pay type", ebufp);
			goto cleanup;
		}

		next_bill_t = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_NEXT_BILL_T, 1, ebufp );
		/*Verify if the end date passed is less than that of next billing cycle date*/
		if((end_t != 0) && next_bill_t && (end_t <= *next_bill_t))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INCORRECT_END_T, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_trial_bill:"
				"End Date passed is less than that of next billing cycle date", ebufp);
			goto cleanup;
		}

		/*Execute Trail bill opcode by calling PCM_OP_BILL_MAKE_TRIAL_BILL*/
		fm_tab_execute_trial_bill(ctxp, in_flistp, billinfo_flistp, 
			&trial_bill_oflistp,db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_trial_bill:"
				" input flist ", billinfo_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_trial_bill:"
				" Error while calling PCM_OP_BILL_MAKE_TRIAL_BILL", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill: "
				"fm_tab_execute_trial_bill output flist", trial_bill_oflistp);

			resultp = PIN_FLIST_FLD_GET(trial_bill_oflistp, PIN_FLD_RESULT, 1, ebufp);

			/*Verify the result code*/
			if(resultp && (*resultp == PIN_RESULT_PASS))
			{
				if (trial_bill_oflistp && (PIN_FLIST_ELEM_GET(trial_bill_oflistp, 
					PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);
					PIN_FLIST_FLD_COPY(trial_bill_oflistp, PIN_FLD_POID, *out_flistpp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, *out_flistpp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, *out_flistpp, PIN_FLD_EXTERNAL_USER, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill: "
						"trail bill pass flist", *out_flistpp);

					while ((results_flistp = PIN_FLIST_ELEM_GET_NEXT(trial_bill_oflistp, PIN_FLD_RESULTS, 
						&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_trial_bill: "
							"trail invoice flist", results_flistp);

						/*Read trial invoice poid and get the bill number*/
						trial_invoice_read_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_POID, trial_invoice_read_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_SET(trial_invoice_read_iflistp, PIN_FLD_BILL_NO, NULL, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_execute_trial_bill: "
							"Read trial invoice object input flist", trial_invoice_read_iflistp);
						PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, trial_invoice_read_iflistp, &trial_invoice_read_oflistp, ebufp);
						PIN_FLIST_DESTROY_EX(&trial_invoice_read_iflistp, NULL);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Trial Invoice object PCM_OP_READ_FLDS:"
								" input flist ", trial_invoice_read_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
								" Error while reading trial invoice object", ebufp);
							goto cleanup;
						}
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_execute_trial_bill: "
								"Read trial invoice object output flist", trial_invoice_read_oflistp);

							if(trial_invoice_read_oflistp != NULL)
							{
								PIN_FLIST_FLD_COPY(trial_invoice_read_oflistp, PIN_FLD_BILL_NO, 
									*out_flistpp, TAB_FLD_BILL_INVOICE_NO, ebufp);
							}

							PIN_FLIST_DESTROY_EX(&trial_invoice_read_oflistp, NULL);
						}
					}
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
						" input flist ", billinfo_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
						" Trial Billing Operation Failed", ebufp);
					goto cleanup;
				}
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_CREATE_TRIAL_BILL, 0, 0, 0);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
					" input flist ", billinfo_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
					" Trial Billing Operation Failed", ebufp);
				goto cleanup;
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&billinfo_details_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&trial_bill_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_bill_trial_bill output flist", *out_flistpp);
	return;
}

/**
 * We use this function to call
 * PCM_OP_BILL_MAKE_TRIAL_BILL opcode.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void
fm_tab_execute_trial_bill(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*billinfo_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*trial_bill_iflistp = NULL;
	pin_flist_t		*trial_bill_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	char			*program_namep = TRIAL_BILLING_PROGRAM_NAME;
	pcm_context_t		*vctxp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_trial_bill error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_trial_bill:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_trial_bill input", i_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_trial_bill billinfo flist", billinfo_flistp);

	trial_bill_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_ACCOUNT_OBJ, trial_bill_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, trial_bill_iflistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_START_T, trial_bill_iflistp, PIN_FLD_START_T, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_END_T, trial_bill_iflistp, PIN_FLD_END_T, ebufp);
	PIN_FLIST_FLD_SET(trial_bill_iflistp, PIN_FLD_PROGRAM_NAME, program_namep, ebufp);
	context_info_flistp = PIN_FLIST_SUBSTR_ADD(trial_bill_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_execute_trial_bill: "
		"PCM_OP_BILL_MAKE_TRIAL_BILL input", trial_bill_iflistp);

	/* Open a new context */
	PCM_CONTEXT_OPEN(&vctxp, (pin_flist_t *)0, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_FLIST_LOG_ERR("fm_tab_execute_trial_bill"
			"pcm_context_open error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
			" input flist ", trial_bill_iflistp);
		PCM_CONTEXT_CLOSE(vctxp, 0, ebufp);
		goto cleanup;
	}


	PCM_OP(vctxp, PCM_OP_BILL_MAKE_TRIAL_BILL, 0, trial_bill_iflistp, &trial_bill_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_TRIAL_BILL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
			" input flist ", trial_bill_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_TRIAL_BILL:"
			" Error while creating trial bill object", ebufp);
		PCM_CONTEXT_CLOSE(vctxp, 0, ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_execute_trial_bill: "
		"PCM_OP_BILL_MAKE_TRIAL_BILL output", trial_bill_oflistp);

	*r_flistpp = trial_bill_oflistp;

	PCM_CONTEXT_CLOSE(vctxp, 0, ebufp);
	cleanup:
	PIN_FLIST_DESTROY_EX(&trial_bill_iflistp, NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_trial_bill output flist", *r_flistpp);

	return;
}
