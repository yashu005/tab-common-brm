/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code		| No		| Date			| Programmer	| Req/bug/Gap	| Change details 
 *			
 *				| 1		| 24-DEC-2021		| Shubham	|		| New file.
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_BILL_FETCH_INVOICE operation. 
 *******************************************************************/
#include "pcm.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/bal.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

EXPORT_OP void 
op_tab_bill_fetch_invoice(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
		
static void 
fm_tab_bill_fetch_invoice(
	pcm_context_t	*ctxp,
	int32		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);
	
/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	pin_errbuf_t	*ebufp);

extern int64 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	int32		flag,
	int32		cerror_code,
	pin_flist_t	**err_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern void
fm_tab_utils_common_get_billinfo (
	pcm_context_t	*ctxp,
	poid_t		*acc_pdp,
	int32		active_flag,
	pin_flist_t	**r_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern time_t
fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t	*ctxp,
	char	*str_timestamp,
	pin_errbuf_t	*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	pin_errbuf_t	*ebufp);

/**
 *
 * New opcode TAB_OP_BILL_FETCH_INVOICE is implemented to 
 * fetch invoice poid as per inputs passed.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO, PIN_FLD_MSISDN, 
 * PIN_FLD_BILL_NO, TAB_FLD_BILL_END_T_STR.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID			POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_ACCOUNT_NO		STR [0] "CH_112"
 0 PIN_FLD_MSISDN		STR [0] "68748927495"
 0 PIN_FLD_BILL_NO		STR [0] "bill-1234"
 0 TAB_FLD_BILL_END_T_STR		TSTAMP [0] “1638297000”
 0 PIN_FLD_CORRELATION_ID	STR [0] "02122021_60005"
 0 PIN_FLD_EXTERNAL_USER	STR [0] "CRM3"
 */

void
op_tab_bill_fetch_invoice(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";

	if(PIN_ERR_IS_ERR(ebufp))
	{
	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_fetch_invoice function entry error", ebufp);
	return;
	}
		
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_FETCH_INVOICE) {
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_fetch_invoice bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_fetch_invoice input flist", in_flistp);

	//To do get db no
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				" input flist", in_flistp); 
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
		
	/* Validate the input arguments */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_validate_and_normalize_input:"
					" input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice: "
		"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_fetch_invoice:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);
	
	/* call main function */
	fm_tab_bill_fetch_invoice(ctxp,flags,enrich_iflistp,&r_flistp,db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
					" input flist", enrich_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_fetch_invoice error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
	}
		
	cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_fetch_invoice:"
				" Error while getting invoice details", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_FETCH_INVOICE_PDF;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_FETCH_INVOICE_PDF)
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_FETCH_INVOICE_PDF , ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_fetch_invoice output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to fetch invoice obj and invoice template details as per input.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param flags The opcode flags.
 * @param db_no Database number.
 * @return flistp.
 *
 */

static void
fm_tab_bill_fetch_invoice(
	pcm_context_t	*ctxp,
	int32		flags,
	pin_flist_t	*in_flistp,
	pin_flist_t	**ret_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t		*get_invoice_iflistp = NULL;
	pin_flist_t		*get_invoice_rflistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	poid_t			*acct_pdp =NULL;
	poid_t			*srchp	= NULL;
	int32			s_flags = 256;
	void			*vp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*srch_res_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	char			*bill_no = NULL;
	char			*end_t_str = NULL;
	time_t			end_t = 0;
	char			*msisdn = NULL;
	char			*accountno = NULL;
	int32			*paytype = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_fetch_invoice function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_fetch_invoice input flist", in_flistp);
	
	accountno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
		
	if((msisdn == NULL || strlen(msisdn) == 0) && (accountno == NULL || strlen(accountno) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
			" Account_no/MSISDN missing in the request ", ebufp);
		goto cleanup;		
	}
	else if(msisdn == NULL || strlen(msisdn) == 0)
	{
		acct_pdp = (poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}	
	else
	{	
		acct_pdp=(poid_t *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	}
	fm_tab_utils_common_get_billinfo(ctxp, acct_pdp, 0, &billinfo_flistp, db_no, ebufp);

	if (billinfo_flistp)
	{
		paytype = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
		if(*paytype == PIN_PAY_TYPE_SUBORD)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ACCT_NOT_PR, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
					" Error while doing search: Account no entered is not paying responsible", ebufp);
			goto cleanup;
		}			 
	} 
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
				" Error while doing search: Inputs seems wrong", ebufp);
		goto cleanup;
	} 

	/*******Sample Search Input flist*****
	 * 0 PIN_FLD_POID		POID [0] 0.0.0.1 /search -1 0
	 * 0 PIN_FLD_FLAGS		 INT [0] 256
	 * 0 PIN_FLD_TEMPLATE		 STR [0] "select X from /invoice 1 where F1=V1 and F2=V2"
	 * 0 PIN_FLD_ARGS		ARRAY [1]
	 * 1 PIN_FLD_ACCOUNT_OBJ	POID [0] 0.0.0.1 /account 14425245 0
	 * 0 PIN_FLD_ARGS		ARRAY [2]
	 * 1 PIN_FLD_BILL_NO		STR [0] "TRIAL-14425245-1634886001"
	 * 0 PIN_FLD_RESULTS		ARRAY [0]
	 * 1 PIN_FLD_POID		POID [0] NULL
	 * 1 PIN_FLD_ACCOUNT_OBJ	POID [0] NULL
	 * 1 PIN_FLD_TEMPLATE_NAME	 STR [0] NULL
	 */

	get_invoice_iflistp = PIN_FLIST_CREATE(ebufp);

	bill_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);
	end_t_str = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_BILL_END_T_STR, 1, ebufp);
	end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_t_str, ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	PIN_FLIST_FLD_PUT(get_invoice_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(get_invoice_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	if((bill_no == NULL || (strlen(bill_no) == 0)) && (end_t == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_ARG, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
			" Mandatory inputs missing: ", ebufp);
		goto cleanup;
	}
	else if(bill_no == NULL || (strlen(bill_no) == 0))
	{
		vp =(void *)"select X from /invoice 1,/bill 2 where 2.F1=V1 and 2.F2=2.F3 and 2.F4=V4 and 2.F5=1.F6";
		PIN_FLIST_FLD_SET(get_invoice_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, &end_t, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILLINFO_OBJ, NULL, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_AR_BILLINFO_OBJ, NULL, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_pdp, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_INVOICE_OBJ, NULL, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 6, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);

	}
	else
	{
		vp =(void *)"select X from /invoice 1 where F1=V1 and F2=V2";
		PIN_FLIST_FLD_SET(get_invoice_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, acct_pdp, ebufp);
		args_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_ARGS, 2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_NO, bill_no, ebufp); 
	}

	srch_res_flistp = PIN_FLIST_ELEM_ADD(get_invoice_iflistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(srch_res_flistp, PIN_FLD_TEMPLATE_NAME, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_fetch_invoice Search input flist", get_invoice_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, get_invoice_iflistp, &get_invoice_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
				" input flist ", get_invoice_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
				" Error while doing search: ", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_fetch_invoice Search return flist", get_invoice_rflistp);
	if (get_invoice_rflistp && (res_flistp = PIN_FLIST_ELEM_GET(get_invoice_rflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		*ret_flistpp = res_flistp;
		PIN_FLIST_DESTROY_EX(&get_invoice_iflistp, NULL);
		return;
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVOICE_NUM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
				" input flist ", get_invoice_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_fetch_invoice:"
				"Requested invoice not found : Check inputs ", ebufp);
		goto cleanup;
	} 

cleanup:
	/******************************************************************
	 *				* Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&get_invoice_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&get_invoice_iflistp, NULL);
	return;

}
