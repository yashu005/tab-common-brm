/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 16-NOV-2021   | Darshan ,Shubha   |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_BILL_GET_OUTSTANDING operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "ops/ar.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "pin_pymt.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_bill_get_outstanding(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_bill_get_outstanding(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_execute_get_outstanding(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void 
fm_tab_get_outstanding_prepare_output(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_object(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_trans_abort(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern char *fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_BILL_GET_OUTSTANDING is implemented to 
 * produce Bill Now for the specified billinfo object.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN & PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
 * 0 PIN_FLD_MSISDN          STR [0] "0049100502"
 * 0 PIN_FLD_CORRELATION_ID    STR [0] "erID3"
 * 0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM3"
 *
 */ 
/**************************************************************************
 * Main routine for the TAB_OP_BILL_GET_OUTSTANDING operation.
 *************************************************************************/
void
op_tab_bill_get_outstanding(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_get_outstanding function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_GET_OUTSTANDING) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_outstanding bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_outstanding input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_outstanding:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_OUTSTANDING_AMOUNT, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_outstanding: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_get_outstanding:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */

	fm_tab_bill_get_outstanding(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_outstanding error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_outstanding:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_OUTSTANDING_AMOUNT, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "output flist", *ret_flistpp);
	return;
}

void fm_tab_bill_get_outstanding(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*msisdnp = NULL;
	char			*account_nop = NULL;
	poid_t			*account_pdp = NULL;
	pin_flist_t		*billinfo_details_flistp = NULL;
	pin_flist_t		*bill_now_result_flistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*bill_read_iflistp = NULL;
	pin_flist_t		*bill_read_oflistp = NULL;
	pin_flist_t		*bill_now_iflistp = NULL;
	pin_flist_t		*bill_now_oflistp = NULL;
	poid_t			*bill_poidp = NULL;
	int			bill_now_flag = 0;
	int32			results_elemid = 0;
	pin_cookie_t		results_cookie = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	pin_flist_t		*r_flistp = NULL;
	int32			status = 2;
	int			*paytypep=0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_bill_get_outstanding input flist", in_flistp);

	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);

	if(msisdnp && strlen(msisdnp) != 0)
	{
		fm_tab_utils_common_get_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_get_outstanding:"
				"fm_tab_utils_common_get_billinfo_details output flist", billinfo_details_flistp);
			bill_now_flag = 1;
		}
	}
	else if(account_nop && strlen(account_nop) != 0 && bill_now_flag == 0)
	{
		fm_tab_utils_common_get_owner_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_get_outstanding:"
				"fm_tab_utils_common_get_owner_billinfo_details output flist", billinfo_details_flistp);
		}
	}
	else if(msisdnp && account_nop && strlen(msisdnp) == 0 && strlen(account_nop) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_outstanding:"
			"Both MSISDN & Account Number not passed in input", ebufp);
		return;
	}
	else if(msisdnp && strlen(msisdnp) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding:"
			"account number/msisdn is not passed", ebufp);
		return;
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding:"
			"Account No is not passed in input", ebufp);
		return;
	}
	billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	paytypep = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);
	if(*paytypep == PIN_PAY_TYPE_PREPAID)
	{
		PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_outstanding input flist",
				billinfo_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_outstanding:"
				"Given Account/MSISDN paytype is Prepaid", ebufp);
		return;
	}
	pin_flist_t 	*ret_out_flistpp=NULL;
	
	if(!fm_tab_utils_common_trans_open(ctxp,account_pdp,ebufp))
	{
		if (billinfo_details_flistp && (billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_flistp, 
			PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			bill_now_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, bill_now_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, bill_now_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, bill_now_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);
			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_get_outstanding:"
				      "fm_tab_execute_get_outstanding input flist", bill_now_iflistp);
					
			fm_tab_execute_get_outstanding(ctxp, bill_now_iflistp, 
				&bill_now_oflistp,db_no, ebufp);
			PIN_FLIST_DESTROY_EX(&bill_now_iflistp, NULL);
			
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_get_outstanding:"
				" input flist ", bill_now_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_get_outstanding:"
					" Error while calling PCM_OP_BILL_MAKE_BILL_NOW", ebufp);
				goto cleanup;
			}
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_get_outstanding:"
					"fm_tab_execute_get_outstanding output flist", bill_now_oflistp);
				
				if(bill_now_oflistp != NULL && PIN_FLIST_ELEM_COUNT(bill_now_oflistp, PIN_FLD_RESULTS, ebufp) > 0 )
				{                
					while ((bill_now_result_flistp = PIN_FLIST_ELEM_GET_NEXT(bill_now_oflistp, PIN_FLD_RESULTS, 
						&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						/*Read Bill object to get bill number*/
						
						bill_poidp = PIN_FLIST_FLD_GET(bill_now_result_flistp,PIN_FLD_LAST_BILL_OBJ,1,ebufp);
						
						fm_tab_utils_common_read_object(ctxp,bill_poidp,&ret_out_flistpp,ebufp);
																			
						if(PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Bill object PCM_OP_READ_FLDS: input flist ", bill_read_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: Error while reading last bill object", ebufp);
							goto cleanup;
						}
					}
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"PCM_OP_READ_FLDS:  output flist", ret_out_flistpp);
				}
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding:"
				"Billinfo is not associated with input account", ebufp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_tab_bill_get_outstanding: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*out_flistpp = r_flistp;
		return;
	}

	/* Abort Transaction to prevent commiting Bill Now */ 
	fm_tab_utils_common_trans_abort(ctxp,account_pdp,ebufp)	;
	
	PIN_FLIST_CONCAT(ret_out_flistpp,in_flistp,ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_tab_bill_get_outstanding:"
		      "Concatinated with Input Output Flist", ret_out_flistpp);
	
	pin_flist_t		*ar_get_action_items_iflistp=NULL;
	pin_flist_t		*ar_get_action_items_oflistp = NULL;
	ar_get_action_items_iflistp = PIN_FLIST_CREATE(ebufp);
		
	PIN_FLIST_FLD_COPY(ret_out_flistpp, PIN_FLD_POID, ar_get_action_items_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(ret_out_flistpp, PIN_FLD_AR_BILLINFO_OBJ, ar_get_action_items_iflistp, 
			PIN_FLD_AR_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(ret_out_flistpp, PIN_FLD_BILLINFO_OBJ, ar_get_action_items_iflistp, 
			PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_SET(ar_get_action_items_iflistp,PIN_FLD_INCLUDE_CHILDREN,0,ebufp);
	PIN_FLIST_FLD_SET(ar_get_action_items_iflistp,PIN_FLD_STATUS,&status,ebufp);
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_AR_GET_ACTION_ITEMS input flist", ar_get_action_items_iflistp);
		
		
	/*******************************************************************
	* Call PCM_OP_AR_GET_ACTION_ITEMS
	*******************************************************************/ 	
		
	PCM_OP(ctxp, PCM_OP_AR_GET_ACTION_ITEMS, 0, ar_get_action_items_iflistp, &ar_get_action_items_oflistp, ebufp);
		
	if(ar_get_action_items_oflistp==NULL || PIN_ERR_IS_ERR(ebufp))
	{						
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding: "
			"PCM_OP_AR_GET_ACTION_ITEMS Input Flist", ar_get_action_items_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_get_outstanding: "
			"PCM_OP_AR_GET_ACTION_ITEMS error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT, 0, 0, 0);	
		goto cleanup;
	}
	PIN_FLIST_CONCAT(ret_out_flistpp,ar_get_action_items_oflistp,ebufp);
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_tab_bill_get_outstanding:"
		      "PCM_OP_AR_GET_ACTION_ITEMS Output Flist", ar_get_action_items_oflistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_tab_bill_get_outstanding:"
		      	"Concatinated Output Flist", ret_out_flistpp);
		
		
	/*******************************************************************
	* Set output as per Specs
	*******************************************************************/ 	
	pin_flist_t *formated_out_flistp= NULL;	
	fm_tab_get_outstanding_prepare_output(ctxp,ret_out_flistpp,&formated_out_flistp,db_no,ebufp);
	
	if(formated_out_flistp == NULL || PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_outstanding_prepare_output: "
			"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_outstanding_prepare_output: "
			"error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT, 0, 0, 0);	
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_tab_bill_get_outstanding: "
		"fm_tab_get_outstanding_prepare_output Output Flist", formated_out_flistp);
		
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&billinfo_details_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_now_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ar_get_action_items_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ar_get_action_items_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_out_flistpp, NULL);

	*out_flistpp = formated_out_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_bill_get_outstanding output flist", *out_flistpp);
	return;
}

/**
 * We use this function to call 
 * PCM_OP_BILL_MAKE_BILL_NOW opcode.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_execute_get_outstanding(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*bill_now_iflistp = NULL;
	pin_flist_t		*bill_now_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
    
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_get_outstanding error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_get_outstanding:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_get_outstanding input", i_flistp);

	bill_now_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, bill_now_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, bill_now_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(bill_now_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_get_outstanding: PCM_OP_BILL_MAKE_BILL_NOW input", bill_now_iflistp);

	PCM_OP(ctxp, PCM_OP_BILL_MAKE_BILL_NOW, 0, bill_now_iflistp, &bill_now_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&bill_now_iflistp, NULL);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_OUTSTANDING_AMOUNT, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_BILL_NOW:"
			" input flist ", bill_now_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_BILL_NOW:"
			" Error while creating bill object", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_get_outstanding: PCM_OP_BILL_MAKE_BILL_NOW output", bill_now_oflistp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*r_flistpp = bill_now_oflistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_get_outstanding output flist", *r_flistpp);

	return;
	}
void 
fm_tab_get_outstanding_prepare_output(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{	
	
	int			elem_unallocated_ar=0;
	pin_cookie_t		cookie_unallocated_ar = NULL;
	int32			status = 2;
	pin_flist_t		*return_items_flistp= NULL;
	pin_flist_t		*unallocated_ar_flistp=NULL;
	pin_flist_t		*return_unallocated_ar_flistp = NULL;
	


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_get_outstanding_prepare_output input", in_flistp);	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_outstanding_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_outstanding_prepare_output:"
			" input flist", in_flistp);
		return;
	}

	
	/*******************************************************************
	* Prepare return flist
	*******************************************************************/ 	
	pin_flist_t		*return_flistp=PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);	
	

	
	/*******************************************************************
	* Verify and set Output
	*******************************************************************/ 	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1, ebufp)!=NULL)
	{
		time_t start_Date = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,0, ebufp);
		char *output_start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&start_Date,ebufp);
		PIN_FLIST_FLD_SET(return_flistp, TAB_FLD_BILL_START_T_STR, output_start_datep, ebufp);
		free(output_start_datep);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1, ebufp)!=NULL)
	{
		time_t end_Date = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,0, ebufp);
		char *output_end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&end_Date,ebufp);				
		PIN_FLIST_FLD_SET(return_flistp, TAB_FLD_BILL_END_T_STR, output_end_datep, ebufp);
		free(output_end_datep);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_TOTAL_DUE,0, ebufp)!=NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TOTAL_DUE,return_flistp, PIN_FLD_TOTAL_DUE, ebufp);
	}
	else 
	{
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(return_flistp, PIN_FLD_TOTAL_DUE, zero, ebufp);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_DUE,0, ebufp)!=NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DUE, return_flistp, PIN_FLD_DUE, ebufp);
	}
	else 
	{
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(return_flistp, PIN_FLD_DUE, zero, ebufp);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_PREVIOUS_TOTAL,1, ebufp)!=NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PREVIOUS_TOTAL, return_flistp, PIN_FLD_PREVIOUS_TOTAL, ebufp);
	}
	else 
	{
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(return_flistp, PIN_FLD_PREVIOUS_TOTAL, zero, ebufp);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_CURRENT_TOTAL,1, ebufp)!=NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CURRENT_TOTAL, return_flistp, PIN_FLD_CURRENT_TOTAL, ebufp);
	}
	else 
	{
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(return_flistp, PIN_FLD_CURRENT_TOTAL, zero, ebufp);
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SUBORDS_TOTAL,1, ebufp)!=NULL)
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SUBORDS_TOTAL, return_flistp, PIN_FLD_SUBORDS_TOTAL, ebufp);
	}
	else 
	{
		pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
		PIN_FLIST_FLD_SET(return_flistp, PIN_FLD_SUBORDS_TOTAL, zero, ebufp);
	}
	/*******************************************************************
	* Unallocated AR traverse
	*******************************************************************/ 
		/*******************************************************************
		* Add items inside unalloacted AR
		*******************************************************************/ 
	while ((unallocated_ar_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_RESULTS,
		&elem_unallocated_ar, 1, &cookie_unallocated_ar, ebufp)) != (pin_flist_t*)NULL)
	{
		return_unallocated_ar_flistp=PIN_FLIST_ELEM_ADD(return_flistp,TAB_FLD_UNALLOCATED_AR,elem_unallocated_ar,ebufp);
		return_items_flistp=PIN_FLIST_ELEM_ADD(return_unallocated_ar_flistp,PIN_FLD_ITEMS,elem_unallocated_ar,ebufp);
		
		if ((PIN_FLIST_FLD_GET(unallocated_ar_flistp,PIN_FLD_NAME,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_COPY(unallocated_ar_flistp, PIN_FLD_NAME, return_items_flistp, PIN_FLD_NAME, ebufp);
		}
		
		PIN_FLIST_FLD_SET(return_items_flistp,PIN_FLD_STATUS,&status,ebufp);
		
		if ((PIN_FLIST_FLD_GET(unallocated_ar_flistp,PIN_FLD_ITEM_TOTAL,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_COPY(unallocated_ar_flistp, PIN_FLD_ITEM_TOTAL, return_items_flistp, PIN_FLD_ITEM_TOTAL, ebufp);
		}
		else 
		{
			pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
			PIN_FLIST_FLD_SET(return_items_flistp, PIN_FLD_ITEM_TOTAL, zero, ebufp);
		}
		
		if ((PIN_FLIST_FLD_GET(unallocated_ar_flistp,PIN_FLD_DUE,1,ebufp))!=NULL)
		{
			PIN_FLIST_FLD_COPY(unallocated_ar_flistp, PIN_FLD_DUE, return_items_flistp, PIN_FLD_DUE, ebufp);
		}
		else 
		{
			pin_decimal_t *zero = pbo_decimal_from_str("0",ebufp);
			PIN_FLIST_FLD_SET(return_items_flistp, PIN_FLD_DUE, zero, ebufp);
		}
		
		if(PIN_FLIST_FLD_GET(unallocated_ar_flistp,PIN_FLD_EFFECTIVE_T,1, ebufp)!=NULL)
		{
			time_t effective_time = *(time_t*)PIN_FLIST_FLD_GET(unallocated_ar_flistp,PIN_FLD_EFFECTIVE_T,0, ebufp);
			char *output_effective_timep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&effective_time,ebufp);				
			PIN_FLIST_FLD_SET(return_items_flistp, TAB_FLD_EFFECTIVE_T_STR, output_effective_timep, ebufp);
			free(output_effective_timep);
		}
		
	}
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_balances_prepare_output input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_balances_prepare_output: Error in date range selection", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_prepare_output output flist", return_flistp);			
	}

cleanup:
	/******************************************************************
	* Clean up.
	******************************************************************/
	
	*out_flistpp= return_flistp;	
	
	return;	
}
