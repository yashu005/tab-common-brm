/*******************************************************************************
 *
 *	 This material is the confidential property	of Telenor/Oracle Corporation or its
 *	 licensors and may be used,	reproduced,	stored or transmitted only in
 *	 accordance	with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details
 *
 *					| 1		| 04-Jan-2021	| Piyush		   |			   | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains	the	TAB_OP_BILL_GET_EVENT_DETAILS operation.
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "ops/ece.h"
#include "fm_bill_utils.h"

/*******************************************************************
 * Routines	contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_bill_get_event_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_event_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


static void
fm_tab_bill_get_event_prepare_output(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


static void
fm_tab_bill_get_event_search_bill(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_event_search_item(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_event_search_event(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_get_event_enrich_offering(
	pcm_context_t		*ctxp,
	pin_flist_t		*event_bal_flistp,
	pin_flist_t		*return_offering_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_read_object(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_service_from_account(
	pcm_context_t		*ctxp,
	poid_t			*poid_pdp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

extern char
*fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern time_t fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

/* Extern functions	*/

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_offering_details(
	pcm_context_t		*ctxp,
	poid_t			*account_pdp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern pin_flist_t *config_beid_out_flistp;

extern pin_flist_t *cfg_tab_system_prod_flistp;

/**
 *
 * New opcode TAB_OP_BILL_GET_EVENT_DETAILS	is implemented to
 * get the balance details for the account object.
 * @param connp	The	connection pointer.
 * @param opcode This opcode.
 * @param flags	The	opcode flags.
 * @param in_flistp	The	input flist	contains PIN_FLD_MSISDN	& PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with	account	poid information.
 * @param ebufp	The	error buffer.
 * @return nothing.
 *
 * Sample Input	Flist
 0 PIN_FLD_POID					 POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_MSISDN		 STR [0] "1633330150"
 0 PIN_FLD_ACCOUNT_NO	   STR [0] "C2_remove"
 0 TAB_FLD_BILL_START_T_STR	STR	[0]	"01-DEC-21 00:00:00"
 0 TAB_FLD_BILL_END_T_STR STR [0] "01-JAN-21 00:00:00"
 0 PIN_FLD_BILL_NO STR [0] "B1-137"
 0 PIN_FLD_ITEMS ARRAY [0]
 1 PIN_FLD_NAME	STR	[0]	"Cycle forward arrear"
 0 PIN_FLD_CORRELATION_ID	   STR [0] "er2345"
 0 PIN_FLD_EXTERNAL_USER	  STR [0] "CRM"
 *
 */
/**************************************************************************
 * Main	routine	for	the	TAB_OP_BILL_GET_EVENT_DETAILS operation.
 *************************************************************************/
void
op_tab_bill_get_event_details(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp =	connp->dm_ctx;
	pin_flist_t		*r_flistp =	NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp	= NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code	= 0;
	char			log_msg[512]= "";
	int64			db_no =	0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_details:"
				"flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_bill_get_event_details function	entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity	check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_GET_EVENT_DETAILS)	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE,	0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_details bad opcode	error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_event_details input	flist",	in_flistp);

	db_no =	fm_tab_utils_common_get_db_no(ctxp,	in_flistp, ebufp);

	/******************************************************************************
	 * Validate	and	normalize the input.
	 ******************************************************************************/

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bal_bill_get_event_details:"
				" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bal_bill_get_event_details: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bal_bill_get_event_details:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/******************************************************************************
	 * Call	main routine
	 ******************************************************************************/

	fm_tab_bill_get_event_details(ctxp,	enrich_iflistp,	&r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_details:"
				"flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_details error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_event_details:"
				"input flist ",	in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_event_details:"
				" Error	while  fetching	the	events", ebufp);

		cerror_code	= ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code	= TAB_ERR_CODE_API_GET_EVENT_DETAILS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp,	in_flistp, error_clear_flag,
				cerror_code, &r_flistp,	db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_EVENT_DETAILS )
		{
			PIN_FLIST_FLD_SET(r_flistp,	PIN_FLD_ERROR_CODE,	log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,	PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_EVENT_DETAILS, ebufp);
		}
		PIN_FLIST_FLD_SET(r_flistp,	TAB_FLD_REQUEST_STATUS,	&status, ebufp)
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp,	TAB_FLD_REQUEST_STATUS,	&status, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_event_details output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}


/***********************************************************
 * This	is the core	function which searches	bills, items and events
 * prepares	the	output flist as	per	the	spec.
 * logs	the	input and output flist.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param db_no	Database number
 * @param ebufp	The	error buffer.
 ***********************************************************/

static void
fm_tab_bill_get_event_details(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	pin_flist_t	*return_flistp=NULL;
	pin_flist_t *bill_return_flistp=NULL;
	pin_flist_t *item_return_flistp=NULL;
	pin_flist_t *event_return_flistp=NULL;
	pin_flist_t *event_return_oflistp = NULL;
	pin_flist_t *posthook_input_flistp = NULL;
	pin_errbuf_t local_ebuf = {0};
	pin_errbuf_t *local_ebufp = &local_ebuf;

	char		*acct_nop = NULL;
	char		*msisdnp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bal_bill_get_event_details input flist", in_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_details:"
			"account number/msisdn is not passed", ebufp);
		return;
	}


	/******************************************************************************
	 * Prepare bill	search for API.
	 ******************************************************************************/

	bill_return_flistp=PIN_FLIST_COPY(in_flistp,ebufp);

	fm_tab_bill_get_event_search_bill(ctxp,in_flistp,&bill_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill: "
				"error", ebufp);
		return_flistp=PIN_FLIST_COPY(event_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare item	search for API.
	 ******************************************************************************/
	item_return_flistp=PIN_FLIST_COPY(bill_return_flistp,ebufp);

	fm_tab_bill_get_event_search_item(ctxp,bill_return_flistp,&item_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_item: "
				"Input flist", bill_return_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_item: "
				"error", ebufp);
		return_flistp=PIN_FLIST_COPY(item_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare item	search for API.
	 ******************************************************************************/	
	event_return_flistp=PIN_FLIST_COPY(item_return_flistp,ebufp);

	fm_tab_bill_get_event_search_event(ctxp,item_return_flistp,&event_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_event: "
				"Input flist", item_return_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_event: "
				"error", ebufp);
		return_flistp=PIN_FLIST_COPY(event_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare output
	 ******************************************************************************/
	
	fm_tab_bill_get_event_prepare_output(ctxp,event_return_flistp,&event_return_oflistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_prepare_output: "
				"Input flist", event_return_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_prepare_output:	"
				"error", ebufp);
		goto cleanup;
	}

	posthook_input_flistp=PIN_FLIST_COPY(event_return_oflistp,ebufp);

	PCM_OP( ctxp, TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS,0,posthook_input_flistp, &return_flistp, ebufp );

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS:"
				"error", posthook_input_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_POST_GET_EVENT_DETAILS:"
				"error", ebufp);
		return_flistp=PIN_FLIST_COPY(posthook_input_flistp,local_ebufp);;
		goto cleanup;
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp=return_flistp;
	PIN_FLIST_DESTROY_EX(&bill_return_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&item_return_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&event_return_flistp,NULL);
	PIN_FLIST_DESTROY_EX(&posthook_input_flistp,NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bal_bill_get_event_details output flist", *out_flistpp);

	return;
}

/*******************************************************************
 * This	function is	to create the output response of get event
 * search opcode.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/
static void
fm_tab_bill_get_event_prepare_output(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_prepare_output input", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_prepare_output:"
				" input	flist",	in_flistp);
		return;
	}

	pin_flist_t	*item_flistp=NULL;
	pin_flist_t	*return_item_flistp	= NULL;
	pin_flist_t	*events_flistp = NULL;
	pin_flist_t	*event_bal_flistp =	NULL;
	pin_flist_t	*return_offering_flistp	= NULL;
	pin_flist_t 	*event_sub_bal_imp_flistp=NULL;
	pin_flist_t	*event_sub_bal_flistp=NULL;

	int		elem_event_balance = 0 ;
	int		event_count=0;	
	int		elem_event = 0 ;
	int		elem_item=0;
	int		elem_sub_bal_imp=0;
	int 		elem_sub_bal=0;

	pin_cookie_t	cookie_event_balance = NULL;
	pin_cookie_t	cookie_item= NULL;
	pin_cookie_t	cookie_event = NULL;
	pin_cookie_t 	cookie_sub_bal_imp=NULL;
	pin_cookie_t	cookie_sub_bal=NULL;
	
	time_t 		earned_start_t=0;
	time_t 		earned_end_t=0;
	time_t 		created_t=0;
	
	poid_t 		*event_poidp=NULL;
	poid_t		*account_pdp=NULL;
	
	char 		*poid_typep=NULL;
	char 		*output_earned_start_datep=NULL;
	char 		*output_earned_end_datep=NULL;
	char 		*created_datep=NULL;

	/******************************************************************
	 * Global Flist	config_beid_out_flistp
	 ******************************************************************/

	/******************************************************************
	 * Global Flist	return_flistp
	 ******************************************************************/
	pin_flist_t	*return_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,	return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_BILL_START_T_STR,	return_flistp, TAB_FLD_BILL_START_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, return_flistp, PIN_FLD_BILL_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_BILL_END_T_STR, return_flistp, TAB_FLD_BILL_END_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp,	PIN_FLD_EXTERNAL_USER, ebufp);

	/******************************************************************
	 * Condition to	handle the MSISDN account or root account
	 * for offering	fetch
	 ******************************************************************/

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);

	fm_tab_utils_common_get_offering_details(ctxp,account_pdp,&return_offering_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details:"
				" input	flist",	account_pdp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_OFFERING_DETAILS, 0, 0, 0);
		return;
	}

	/******************************************************************
	 * Traverse	Item to	get	the	events and add it in return	Flist
	 ******************************************************************/

	while ((item_flistp	= PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ITEMS,
					&elem_item,	1, &cookie_item, ebufp)) !=	(pin_flist_t*)NULL)
	{
		elem_event=0;
		cookie_event = NULL;

		if(PIN_FLIST_ELEM_COUNT(item_flistp,PIN_FLD_EVENTS,ebufp))
		{
			return_item_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_ITEMS,elem_item,ebufp);
			PIN_FLIST_FLD_COPY(item_flistp,	PIN_FLD_NAME, return_item_flistp, PIN_FLD_NAME,	ebufp);
		}

		/******************************************************************
		 * Traverse	Events add it in return	Flist
		 ******************************************************************/
		while ((events_flistp =	PIN_FLIST_ELEM_GET_NEXT(item_flistp,
						PIN_FLD_EVENTS,	&elem_event, 1,	&cookie_event, ebufp)) != (pin_flist_t*)NULL)
		{
			earned_start_t =*(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_EARNED_START_T,0,	ebufp);
			earned_end_t = *(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_EARNED_END_T,0,	ebufp);
			created_t = *(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_CREATED_T,0, ebufp);

			output_earned_start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&earned_start_t,ebufp);
			PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_EARN_START_T_STR, output_earned_start_datep, ebufp);
			free(output_earned_start_datep);

			output_earned_end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&earned_end_t,ebufp);
			PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_EARN_END_T_STR, output_earned_end_datep, ebufp);
			free(output_earned_end_datep);
			
			created_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&created_t,ebufp);
			PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_CREATED_T_STR,	created_datep, ebufp);
			free(created_datep);

			event_poidp	= PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_POID,0, ebufp);

			poid_typep = (char*)PIN_POID_GET_TYPE(event_poidp);

			PIN_FLIST_FLD_SET(events_flistp, PIN_FLD_EVENT_TYPE, poid_typep, ebufp);

			elem_sub_bal_imp=0;
			cookie_sub_bal_imp=NULL;
			/******************************************************************
			 * Traverse	Sub balance	impacts	add	it in return Flist
			 ******************************************************************/
			while ((event_sub_bal_imp_flistp = PIN_FLIST_ELEM_GET_NEXT(events_flistp,
				PIN_FLD_SUB_BAL_IMPACTS, &elem_sub_bal_imp, 1, &cookie_sub_bal_imp,	ebufp))	!= (pin_flist_t*)NULL)
			{
				if(PIN_FLIST_FLD_GET(event_sub_bal_imp_flistp,PIN_FLD_BAL_GRP_OBJ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_sub_bal_imp_flistp,PIN_FLD_BAL_GRP_OBJ,ebufp);

				elem_sub_bal=0;
				cookie_sub_bal=NULL;
				/******************************************************************
				 * Traverse	sub balances in return Flist
				 ******************************************************************/
				while ((event_sub_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(event_sub_bal_imp_flistp,
								PIN_FLD_SUB_BALANCES,&elem_sub_bal, 1,&cookie_sub_bal,ebufp))!= (pin_flist_t*)NULL)
				{
					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_FROM,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_FROM,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_FROM_DETAILS,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_FROM_DETAILS,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_TO_DETAILS,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_TO_DETAILS,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_CONTRIBUTOR_STR,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_CONTRIBUTOR_STR,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_ROLLOVER_DATA,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_ROLLOVER_DATA,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_GRANTOR_OBJ,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_GRANTOR_OBJ,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_TO ,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_TO,ebufp);
				}
			}

			elem_event_balance=0;
			cookie_event_balance = NULL;

			/******************************************************************
			 * Traverse	Balance	impacts	add	it in return Flist
			 ******************************************************************/
			while ((event_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(events_flistp,
							PIN_FLD_BAL_IMPACTS, &elem_event_balance, 1, &cookie_event_balance,	ebufp))	!= (pin_flist_t*)NULL)
			{

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ ,1,ebufp)!=NULL)
					fm_tab_bill_get_event_enrich_offering(ctxp,event_bal_flistp,return_offering_flistp,&event_bal_flistp,db_no,ebufp);

				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_event_enrich_offering input flist", event_bal_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_event_enrich_offering:	", ebufp);
					goto cleanup;
				}

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_OFFERING_OBJ,ebufp);

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_ACCOUNT_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_ACCOUNT_OBJ,ebufp);

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_PRODUCT_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_PRODUCT_OBJ,ebufp)	;

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_ITEM_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_ITEM_OBJ,ebufp);

				event_count++;
			}

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_POID	,1,ebufp)!=NULL)
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_POID,ebufp);

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_CREATED_T ,1,ebufp)!=NULL)
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_CREATED_T,ebufp);

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_EARNED_END_T	,1,ebufp)!=NULL)
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_EARNED_END_T,ebufp);

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_EARNED_START_T ,1,ebufp)!=NULL)
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_EARNED_START_T,ebufp);

			PIN_FLIST_ELEM_SET(return_item_flistp,events_flistp,PIN_FLD_EVENTS,elem_event,ebufp);
		}
	}

	if (!event_count)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0,	0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_prepare_output"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_event_prepare_output input	flist",	in_flistp);
		goto cleanup;
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_event_prepare_output input	flist",	in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_event_prepare_output: ", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_bill_get_event_prepare_output output flist", return_flistp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&event_bal_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_offering_flistp, NULL);
	*out_flistpp= return_flistp;

	return;
}

/*******************************************************************
 * This	function is	to search the bill no either based on bill number
 * or input	start and end date
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_event_search_bill(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_bill input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t	*search_out_flistp=NULL;
	pin_flist_t		*args_flistp=NULL;

	time_t		start_date=0;
	time_t		end_date=0;
	time_t		zero=0;	
	time_t  	now_t = pin_virtual_time((time_t *)NULL);
	
	int		flags=0;
	
	poid_t		*account_pdp=NULL;
	poid_t		*srch_poidp=NULL;

	char		*bill_nop=NULL;
	char		*input_start_date=NULL;
	char		*input_end_date=NULL;
	char		*template=NULL;
	
	if((input_start_date = PIN_FLIST_FLD_GET(in_flistp,	TAB_FLD_BILL_START_T_STR, 1, ebufp))!=NULL)
	{
		start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_start_date,ebufp);
	}

	if((input_end_date=PIN_FLIST_FLD_GET(in_flistp,	TAB_FLD_BILL_END_T_STR,	1, ebufp))!=NULL)
	{
		end_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_end_date,ebufp);
	}
		
	if (!start_date && !end_date)
	{
		end_date=now_t;
		start_date=end_date-ONEDAY*30;
	}
	
	if(!start_date)
	{
		start_date=end_date-ONEDAY*60;
	}

	if(!end_date)
	{
		end_date=start_date+ONEDAY*60;
	}	

	/*******************************************************************
	 * Error handling if the duration is more than the 60 days
	 *******************************************************************/
	if ((start_date	||end_date)	&& (end_date-start_date)/ONEDAY>60)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_details: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_details:	"
				"Date range	is more	than 60 days error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INPUT_BEYOND_MAXIMUM_RANGE, 0, 0, 0);
		goto cleanup;
	}

	search_input_flistp	= PIN_FLIST_CREATE(ebufp);

	srch_poidp = PIN_POID_CREATE(db_no,	"/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID,	srch_poidp,	ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	pin_flist_t		*result_flistp = NULL;
	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);

	if (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp)!=NULL)
		account_pdp	= PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ,	1, ebufp);
	else
		account_pdp	= PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1,	ebufp);

	if((bill_nop = PIN_FLIST_FLD_GET(in_flistp,	PIN_FLD_BILL_NO, 1,	ebufp))!=NULL)
	{
		template= "select X from /bill where F1 = V1 and F2 = V2 ";
		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_NO,	bill_nop, ebufp);

		if ((PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp))!=NULL)
		{
			args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,2, ebufp);
			PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ,	account_pdp, ebufp);
		}
		else
		{
			poid_t	*parent_pdp	= PIN_POID_CREATE(0, "", 0,	ebufp);
			args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
			PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_PARENT, parent_pdp, ebufp);
		}
		goto opcode;
	}

	if (start_date && end_date)
	{
		template= "select X from /bill where F1 = V1 and ((F2 <= V2 and F3 >= V3 and F4 <= V4 ) or (F5 >= V5 and F6 >= V6 and F7 <= V7) or ( (F8 >= V8 or F9 = V9) and F10 <= V10 ))  ";		

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ,	account_pdp, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T,	(void *)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void	*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void	*)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T,	(void *)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	6, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	7, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,8, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T,	(void*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,9, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void*)&zero, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,10, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&end_date, ebufp);

		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

		PIN_FLIST_FLD_SET(*out_flistpp,	PIN_FLD_START_T, (void*)&start_date, ebufp);
		PIN_FLIST_FLD_SET(*out_flistpp,	PIN_FLD_END_T, (void *)&end_date, ebufp);

		goto opcode;
	}

opcode:
	/*
	   0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	   0 PIN_FLD_FLAGS           INT [0] 0
	   0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 1
	   1     PIN_FLD_POID           POID [0] NULL poid pointer
	   0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 = V2 "
	   0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	   1     PIN_FLD_BILL_NO         STR [0] "B1-24"
	   0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	   1     PIN_FLD_PARENT         POID [0] 0.0.0.0  0 0*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 1
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2222704 0
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_START_T      TSTAMP [0] (1646899200) Thu Mar 10 00:00:00 2022
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_START_T      TSTAMP [0] (1647029076) Fri Mar 11 12:04:36 2022
	  0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	  1     PIN_FLD_END_T        TSTAMP [0] (0) <null>
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 >= V2 and ( F3 <= V3 or F4 = V4 ) "
	  */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_bill: "
			"Input Flist", search_input_flistp);
	PCM_OP(	ctxp, PCM_OP_SEARCH, 0,	search_input_flistp, &search_out_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_bill: "
			"Output Flist", search_out_flistp);

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (bill_nop && !PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0,	0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_search_bill"
				"error search bill failed",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill: "
				"Input Flist", in_flistp);
		goto cleanup;
	}


	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0,	0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_search_bill"
				"error search bill failed",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_bill: "
				"Input Flist", in_flistp);
		goto cleanup;
	}


	if(PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_RENAME(search_out_flistp,	PIN_FLD_RESULTS, PIN_FLD_BILLS,	ebufp);
		PIN_FLIST_CONCAT(*out_flistpp,search_out_flistp,ebufp);
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_bill output flist", *out_flistpp);
	return;
}


/*******************************************************************
 * This	function is	to search the item based on	bill number	search
 * function	output.	It searches	billable as	well as	non	billable items.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_event_search_item(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_item input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_item	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_item:"
				" in_flistp", in_flistp);
		return;
	}

	int		item_search_elemid =0;
	int		bill_input_elemid =0;
	int		item_input_elemid =0;	
	int		flags=0;
	int		item_elem=0;
	int		item_ar_search_elemid=0;
	
	pin_cookie_t	item_search_cookie = NULL;
	pin_cookie_t	bill_input_cookie =	NULL;
	pin_cookie_t	item_input_cookie =	NULL;
	pin_cookie_t	item_ar_search_cookie =	NULL;
	pin_flist_t	*item_search_flistp=NULL;
	pin_flist_t	*item_input_flistp =NULL;
	pin_flist_t	*search_out_flistp=NULL;

	pin_flist_t	*search_input_flistp = PIN_FLIST_CREATE(ebufp);
	pin_flist_t	*args_flistp=NULL;
	pin_flist_t	*search_ar_out_flistp=NULL;		
	poid_t		*srch_poidp=NULL;
	poid_t		*account_pdp=NULL;

	poid_t 		*bill_poidp=NULL;
	char		*template=NULL;
	char 		*item_input_namep =NULL;
	char 		*item_search_namep=NULL;
	
	time_t start_t=0;
	time_t end_t=0;

	srch_poidp = PIN_POID_CREATE(db_no,	"/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID,	srch_poidp,	ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	pin_flist_t	*result_flistp = NULL;
	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_NAME, NULL, ebufp);

	args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_NAME,(void*)	"%Usage%", ebufp);

	pin_flist_t	*bill_input_flistp=NULL;
	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 2
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_NAME            STR [0] NULL str ptr
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_NAME            STR [0] "%Usage%"
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_BILL_OBJ       POID [0] 0.0.0.1 /bill 2222448 0
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 not like V1 and F2 = V2 "
	  */

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 2
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_NAME            STR [0] NULL str ptr
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_NAME            STR [0] "%Usage%"
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_AR_BILL_OBJ    POID [0] 0.0.0.1 /bill 2213227 7
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_BILL_OBJ    POID [0] 0.0.0.1 /bill 2213227 7	  
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 not like V1 and ( F2 = V2 or F3 = V3 ) "*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 2
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_NAME            STR [0] NULL str ptr
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_NAME            STR [0] "%Usage%"
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2222704 0
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_EFFECTIVE_T  TSTAMP [0] (1647029076) Fri Mar 11 12:04:36 2022
	  0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	  1     PIN_FLD_EFFECTIVE_T  TSTAMP [0] (1646899200) Thu Mar 10 00:00:00 2022
	  0 PIN_FLD_ARGS          ARRAY [5] allocated 20, used 1
	  1     PIN_FLD_BILL_OBJ       POID [0] 0.0.0.0  0 0
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 not like V1 and F2 = V2 and F3 <= V3 and F4 >= V4 and F5 = V5 "*/

	/******************************************************************
	 * Billable	item search	flist
	 ******************************************************************/
	while ((bill_input_flistp =	PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_BILLS,
					&bill_input_elemid,	1, &bill_input_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		bill_poidp = PIN_FLIST_FLD_GET(bill_input_flistp, PIN_FLD_POID,	1, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_OBJ, bill_poidp, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_AR_BILL_OBJ,	bill_poidp,	ebufp);

		template= "select X from /item where F1 not like V1 and ( F2 = V2 or F3 = V3 ) ";
		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_item billable: "
				"Input Flist", search_input_flistp);
		PCM_OP(	ctxp, PCM_OP_SEARCH, 0,	search_input_flistp, &search_out_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_item billable: "
				"Output	Flist",	search_out_flistp);

		item_input_elemid=0;
		item_input_cookie=NULL;

		if(PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp))
		{
			while ((item_input_flistp =	PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ITEMS,
							&item_input_elemid,	1, &item_input_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				item_input_namep = PIN_FLIST_FLD_GET(item_input_flistp,PIN_FLD_NAME,0, ebufp);

				item_search_elemid = 0;
				item_search_cookie = NULL;

				while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp,	PIN_FLD_RESULTS,
								&item_search_elemid, 1,	&item_search_cookie, ebufp)) !=	(pin_flist_t *)NULL)
				{
					item_search_namep	= PIN_FLIST_FLD_GET(item_search_flistp,PIN_FLD_NAME,0, ebufp);

					if(strcmp(item_input_namep,item_search_namep)==0)
					{
						PIN_FLIST_ELEM_COPY(search_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp,	PIN_FLD_ITEMS,item_elem, ebufp);
						item_elem++;
					}
				}
			}


		}
		else
		{
			PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);

			item_search_elemid=0;
			item_search_cookie=NULL;
			while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp,	PIN_FLD_RESULTS,
							&item_search_elemid, 1,	&item_search_cookie, ebufp)) !=	(pin_flist_t *)NULL)
			{
				PIN_FLIST_ELEM_COPY(search_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp,	PIN_FLD_ITEMS,item_elem, ebufp);
				item_elem++;
			}
		}
		
		PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);	
	}

	/******************************************************************
	 * Non billable	item search	flist
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	search_input_flistp	= PIN_FLIST_CREATE(ebufp);

	srch_poidp = PIN_POID_CREATE(db_no,	"/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID,	srch_poidp,	ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_NAME, NULL, ebufp);

	args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_NAME,(void*)	"%Usage%", ebufp);

	if (PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BILL_NO,1, ebufp)==NULL	)
	{

		start_t = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,0, ebufp);
		end_t = *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,0, ebufp);
		template= "select X from /item where F1 not like V1 and F2 = V2 and F3 <= V3 and F4 >= V4 and F5 = V5 ";

		account_pdp	= PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1,	ebufp);
		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ,	account_pdp, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_EFFECTIVE_T,	(void *)&end_t, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_EFFECTIVE_T,	(void *)&start_t,	ebufp);

		bill_poidp =	PIN_POID_CREATE(0, "", 0, ebufp);
		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_OBJ,bill_poidp, ebufp);

		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_item AR: "
				"Input Flist", search_input_flistp);
		PCM_OP(	ctxp, PCM_OP_SEARCH, 0,	search_input_flistp, &search_ar_out_flistp,	ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_event_search_item AR: "
				"out Flist", search_ar_out_flistp);
				
		PIN_POID_DESTROY(bill_poidp,ebufp);

		item_input_elemid =	0;
		item_input_cookie =	NULL;
		if(PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp))
		{
			while ((item_input_flistp =	PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ITEMS,
							&item_input_elemid,	1, &item_input_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				item_input_namep = PIN_FLIST_FLD_GET(item_input_flistp,PIN_FLD_NAME,0, ebufp);

				item_ar_search_elemid =	0;
				item_ar_search_cookie =	NULL;

				while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_ar_out_flistp, PIN_FLD_RESULTS,
								&item_ar_search_elemid,	1, &item_ar_search_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					item_search_namep	= PIN_FLIST_FLD_GET(item_search_flistp,PIN_FLD_NAME,0, ebufp);

					if(strcmp(item_input_namep,item_search_namep)==0)
					{
						PIN_FLIST_ELEM_COPY(search_ar_out_flistp, PIN_FLD_RESULTS,item_ar_search_elemid,*out_flistpp, PIN_FLD_ITEMS,item_elem, ebufp);
						item_elem++;
					}				
				}			
			}
			
			PIN_FLIST_DESTROY_EX(&search_ar_out_flistp, NULL);
		}
		else
		{
			item_search_elemid=0;
			item_search_cookie=NULL;
			while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_ar_out_flistp, PIN_FLD_RESULTS,
							&item_search_elemid, 1,	&item_search_cookie, ebufp)) !=	(pin_flist_t *)NULL)
			{
				PIN_FLIST_ELEM_COPY(search_ar_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp, PIN_FLD_ITEMS,item_elem,	ebufp);
				item_elem++;
			}
			PIN_FLIST_FLD_DROP(search_ar_out_flistp,PIN_FLD_POID,ebufp);
			
			PIN_FLIST_DESTROY_EX(&search_ar_out_flistp, NULL);
		}
	}


	if (PIN_ERR_IS_ERR(ebufp) || (PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp) &&
										!item_elem))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ITEM_NOT_FOUND, 0,	0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_item:"
				"error item	not	found",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item:"
				" in_flistp", in_flistp);
		goto cleanup;
	}


	if ((!PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp) &&
				!PIN_FLIST_ELEM_COUNT(*out_flistpp,PIN_FLD_ITEMS,ebufp)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ITEM_NOT_FOUND, 0,	0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_item:"
				"error item	not	found",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item:"
				" in_flistp", in_flistp);
		goto cleanup;
	}


	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(*out_flistpp,PIN_FLD_ITEMS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0,	0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_search_item:"
				"error search item failed",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item:"
				" in_flistp", in_flistp);
		goto cleanup;
	}




cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_ar_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_item output flist", *out_flistpp);
	return;
}


/*******************************************************************
 * This	function is	to search the event	based on item poid and start
 * and end dates as	input parameter.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_event_search_event(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_event	input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_event error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_event:"
				" in_flistp", in_flistp);
		return;
	}

	char		*template= NULL;
	int		flags=768;
	int		event_search_elemid= 0;
	int 		found=0;
	poid_t		*item_poidp	=NULL;
	
	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t	*search_out_flistp=NULL;
	pin_flist_t	*bal_impacts_result_flistp = NULL;
	pin_flist_t	*args_flistp=NULL;	
	pin_flist_t	*result_flistp = NULL;

	time_t		start_t	=0;
	time_t		end_t =	0 ;	

	poid_t		*srch_poidp=NULL;
	pin_flist_t	*bal_impacts_flistp	= NULL;
	
	pin_flist_t	*event_search_flistp=NULL;

	pin_cookie_t	event_search_cookie	= NULL;
	
	/******************************************************************
	 * Prepration of event search flist
	 ******************************************************************/
	search_input_flistp	= PIN_FLIST_CREATE(ebufp);
	srch_poidp = PIN_POID_CREATE(db_no,	"/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID,	srch_poidp,	ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);
	
	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 768
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 1
	  2         PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/cycle_forward 2221296 6
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /event/billing where F1 = V1 and F2 = V2 order by event_t.created_t desc "
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/cycle_forward 2221296 6
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 5
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_CREATED_T    TSTAMP [0] (0) <null>
	  1     PIN_FLD_EARNED_START_T TSTAMP [0] (0) <null>
	  1     PIN_FLD_EARNED_END_T TSTAMP [0] (0) <null>
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 9
	  2         PIN_FLD_ACCOUNT_OBJ    POID [0] NULL poid pointer
	  2         PIN_FLD_AMOUNT       DECIMAL [0] NULL pin_decimal_t ptr
	  2         PIN_FLD_GL_ID           INT [0] 0
	  2         PIN_FLD_OFFERING_OBJ   POID [0] NULL poid pointer
	  2         PIN_FLD_PRODUCT_OBJ    POID [0] NULL poid pointer
	  2         PIN_FLD_RESOURCE_ID     INT [0] 0
	  2         PIN_FLD_ITEM_OBJ       POID [0] NULL poid pointer
	  2         PIN_FLD_IMPACT_TYPE    ENUM [0] 0*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 768
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 1
	  2         PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/cycle_forward 2221296 6
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_CREATED_T    TSTAMP [0] (1646899200) Thu Mar 10 00:00:00 2022
	  0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	  1     PIN_FLD_CREATED_T    TSTAMP [0] (1647029076) Fri Mar 11 12:04:36 2022
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /event/billing where F1 = V1 and F2 = V2 and F3 >= V3 and F4 <= V4 order by event_t.created_t desc "
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/cycle_forward 2221296 6
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 5
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_CREATED_T    TSTAMP [0] (0) <null>
	  1     PIN_FLD_EARNED_START_T TSTAMP [0] (0) <null>
	  1     PIN_FLD_EARNED_END_T TSTAMP [0] (0) <null>
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 9
	  2         PIN_FLD_ACCOUNT_OBJ    POID [0] NULL poid pointer
	  2         PIN_FLD_AMOUNT       DECIMAL [0] NULL pin_decimal_t ptr
	  2         PIN_FLD_GL_ID           INT [0] 0
	  2         PIN_FLD_OFFERING_OBJ   POID [0] NULL poid pointer
	  2         PIN_FLD_PRODUCT_OBJ    POID [0] NULL poid pointer
	  2         PIN_FLD_RESOURCE_ID     INT [0] 0
	  2         PIN_FLD_ITEM_OBJ       POID [0] NULL poid pointer
	  2         PIN_FLD_IMPACT_TYPE    ENUM [0] 0*/

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1, ebufp)!=NULL && PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1, ebufp)!=NULL	)
	{
		// Modified the template from /event/billing to /event to incorporate the /event/accumlator objects.
		template= "select X from /event where  F1 = V1 and F2 >= V2 and F3 <= V3 and F4 = V4 order by event_t.created_t desc ";
		start_t= *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1, ebufp);
		end_t= *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, (void*)&start_t, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, (void*)&end_t,	ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	4, ebufp);
		bal_impacts_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_BAL_IMPACTS, PIN_ELEMID_ANY, ebufp);

	}
	else
	{	// Modified the template from /event/billing to /event to incorporate the /event/accumlator objects.
		template= "select X from /event where F1 = V1 and F2 = V2 order by event_t.created_t desc ";

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		bal_impacts_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_BAL_IMPACTS, PIN_ELEMID_ANY, ebufp);
	}

	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

	args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	1, ebufp);
	
	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_POID, NULL,	ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_CREATED_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_EARNED_START_T,	NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_EARNED_END_T, NULL,	ebufp);
    PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_PROVIDER_DESCR, NULL,     ebufp);

	PIN_FLIST_ELEM_SET(result_flistp,NULL,PIN_FLD_SUB_BAL_IMPACTS,PIN_ELEMID_ANY,ebufp);

	bal_impacts_result_flistp= PIN_FLIST_ELEM_ADD(result_flistp,PIN_FLD_BAL_IMPACTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_AMOUNT,	NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_GL_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_OFFERING_OBJ, NULL,	ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_PRODUCT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_RESOURCE_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_ITEM_OBJ, NULL,	ebufp);
	PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_IMPACT_TYPE, NULL, ebufp);
	/*PIN_FLIST_FLD_SET(bal_impacts_result_flistp,PIN_FLD_RATE_TAG, NULL,	ebufp); //Commneted as part of fix API*/

	while ((event_search_flistp	= PIN_FLIST_ELEM_GET_NEXT(*out_flistpp, PIN_FLD_ITEMS,&event_search_elemid, 1,	&event_search_cookie, ebufp)) != (pin_flist_t *)NULL)
	{

		if((item_poidp = PIN_FLIST_FLD_GET(event_search_flistp,PIN_FLD_POID,1, ebufp))!=NULL)
		{
			PIN_FLIST_FLD_SET(bal_impacts_flistp,PIN_FLD_ITEM_OBJ,item_poidp,ebufp);

			//setting event	level item object
			PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_ITEM_OBJ,	item_poidp,	ebufp);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_bill_get_event_search_event search input flistp", search_input_flistp);

			PCM_OP(	ctxp, PCM_OP_SEARCH, 0,	search_input_flistp, &search_out_flistp, ebufp );

			if(PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
				found++;

			PIN_FLIST_FLD_RENAME(search_out_flistp,	PIN_FLD_RESULTS,PIN_FLD_EVENTS,	ebufp);
			PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
			PIN_FLIST_CONCAT(event_search_flistp,search_out_flistp,ebufp);
			PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
		}
	}

	if (PIN_ERR_IS_ERR(ebufp) || !found )
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0,	0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_search_event"
				"error search bill failed",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_search_event:"
				" in_flistp", search_input_flistp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_search_event	output flist", *out_flistpp);
	return;
}


/*******************************************************************
 * This	function is	to enrich the event	balance	flist with offering
 * product details
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param return_offering_flistp product details.
 * @param out_flistpp return flist.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_event_enrich_offering(
	pcm_context_t	*ctxp,
	pin_flist_t	*event_bal_flistp,
	pin_flist_t	*return_offering_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_enrich_offering input flistp", event_bal_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_enrich_offering cfg_tab_system_prod_flistp flistp", cfg_tab_system_prod_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_enrich_offering	error",	ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_enrich_offering:"
				" in_flistp", event_bal_flistp);
		return;
	}

	pin_flist_t	*product_flistp=NULL;
	pin_flist_t	*discount_flistp=NULL;
	pin_flist_t	*config_beid_bal_flistp=NULL;
	pin_flist_t	*sponsorship_flistp=NULL;
	
	int		elem_conf_bal=0;
	int		resource_id=0;
	int		elem_prod=0;
	int		elem_dis=0;
	
	pin_cookie_t	cookie_conf_bal=NULL;
	pin_cookie_t 	cookie_prod= NULL;
	pin_cookie_t 	cookie_dis=NULL;

	poid_t		*offering_event_objp=NULL;
	poid_t 		*offering_prod_objp=NULL;
	
	
	/******************************************************************
	 * Prepration of event search flist
	 ******************************************************************/
	 
	offering_event_objp = PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ,1, ebufp);
	offering_prod_objp = PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_PRODUCT_OBJ,1, ebufp);
	resource_id	= *(int*)PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_RESOURCE_ID,1, ebufp);

	/******************************************************************
	 * Traverse	Balance	impacts	resource id	and	resource name return
	 * Flist
	 ******************************************************************/
	while ((config_beid_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
					&elem_conf_bal,	1, &cookie_conf_bal, ebufp)) !=	(pin_flist_t*)NULL)
	{
		if(elem_conf_bal==resource_id)
		{
			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_NAME, *out_flistpp, PIN_FLD_RESOURCE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_SYMBOL, *out_flistpp, PIN_FLD_NAME, ebufp);

		}
	}

	while ((product_flistp = PIN_FLIST_ELEM_GET_NEXT(return_offering_flistp, PIN_FLD_PRODUCTS,
					&elem_prod,	1, &cookie_prod, ebufp)) !=	(pin_flist_t*)NULL)
	{
		poid_t *offering_acct_objp = PIN_FLIST_FLD_GET(product_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_event_objp,offering_acct_objp,0,ebufp))
		{
			PIN_FLIST_FLD_SET(event_bal_flistp,TAB_FLD_OFFER_TYPE,CHARGE,ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_PACKAGE_NAME, event_bal_flistp, TAB_FLD_PACKAGE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_OFFER_NAME, event_bal_flistp, TAB_FLD_OFFER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_BUNDLE_NAME,	event_bal_flistp, TAB_FLD_BUNDLE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_OFFER_ID, event_bal_flistp, TAB_FLD_OFFER_ID, ebufp);
		}
	}

	while ((discount_flistp	= PIN_FLIST_ELEM_GET_NEXT(return_offering_flistp, PIN_FLD_DISCOUNTS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *offering_acct_objp = PIN_FLIST_FLD_GET(discount_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_event_objp,offering_acct_objp,0,ebufp))
		{
			PIN_FLIST_FLD_SET(event_bal_flistp,TAB_FLD_OFFER_TYPE,DISCOUNT,ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp,TAB_FLD_PACKAGE_NAME,event_bal_flistp,TAB_FLD_PACKAGE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp,TAB_FLD_OFFER_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp,TAB_FLD_BUNDLE_NAME,event_bal_flistp,TAB_FLD_BUNDLE_NAME,	ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp,TAB_FLD_OFFER_ID,event_bal_flistp,TAB_FLD_OFFER_ID, ebufp);
		}
	}

	cookie_prod=NULL;
	elem_prod=0;

	while ((product_flistp	= PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp, PIN_FLD_PRODUCTS,
					&elem_prod, 1, &cookie_prod, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *product_pdp = PIN_FLIST_FLD_GET(product_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,product_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(product_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	cookie_dis=NULL;
	elem_dis=0;

	while ((discount_flistp	= PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp,PIN_FLD_DISCOUNTS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *dis_pdp = PIN_FLIST_FLD_GET(discount_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,dis_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(discount_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	cookie_dis=NULL;
	elem_dis=0;

	while ((sponsorship_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp, PIN_FLD_SPONSORS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *sponsorship_pdp = PIN_FLIST_FLD_GET(sponsorship_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,sponsorship_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(sponsorship_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_enrich_offering:"
				" in_flistp", event_bal_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_enrich_offering"
				"error event not present", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp=event_bal_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_event_enrich_offering output flist", *out_flistpp);

	return;
}
