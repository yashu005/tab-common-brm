/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/
/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 18/Nov/2021 | Madhavi Dandi		| 			| New opcode implementation to
 *                                             				| suppress the bill cycles manually
 *
 *********************************************************************************/
/*******************************************************************
 * Contains the TAB_OP_BILL_SUPPRESS operation.
 *******************************************************************/

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "pin_pymt.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_bill_suppress(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_bill_suppress(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/**
 *
 * New opcode TAB_OP_BILL_SUPPRESS is implemented to suppress the bill cycles
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN, PIN_FLD_ACCOUNT_NO,
 *        and PIN_FLD_SUPPRESSION_CYCLES_LEFT.
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "0.0.0.1-8244369"
 * 0 PIN_FLD_MSISDN            STR [0] "68748927495"
 * 0 SUPPRESSION_CYCLES_LEFT    INT [0] 5
 * 0 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 **/

void
op_tab_bill_suppress(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code=0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_suppress function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_SUPPRESS) {
	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_suppress input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
			" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_BILL_SUPPRESS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_BILL_SUPPRESS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_BILL_SUPPRESS, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_suppress:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_bill_suppress(ctxp, flags, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_suppress input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_bill_suppress: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_BILL_SUPPRESS", &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
			" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_BILL_SUPPRESS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_BILL_SUPPRESS, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_BILL_SUPPRESS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_BILL_SUPPRESS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp,r_flistp,ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX (&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_suppress output flist", *ret_flistpp);
	return;
}
/**
 * We use this function to update the billinfo information.
 * in /billinfo object 
 * 
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_bill_suppress(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*bill_suppress_iflistp = NULL;
	pin_flist_t		*bill_suppress_rflistp = NULL;
	poid_t			*acc_pdp=NULL;
	pin_flist_t		*balgrp_readobj_iflistp=NULL;
	pin_flist_t		*balgrp_readobj_rflistp=NULL;
	pin_flist_t		*billinfo_readobj_iflistp=NULL;
	pin_flist_t		*billinfo_readobj_rflistp=NULL;
	pin_flist_t		*arg_flistp=NULL;
	poid_t			*balgrp_obj= NULL;
	poid_t			*billinfo_obj= NULL;
	int32			*suppress_cycles = NULL;
	int			*paytypep=0;
	pin_flist_t		*paytype_readobj_rflistp=NULL;
	pin_flist_t		*paytype_readobj_iflistp=NULL;
	char			*acct_no = NULL;
	char			*msisdn = NULL;
	pin_flist_t		*r_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress: input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_suppress function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_suppress: input flist", in_flistp);

	/* Validate the input arguments */
	acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if((acct_no == NULL || strlen(acct_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
				"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	suppress_cycles = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SUPPRESSION_CYCLES_LEFT, 1, ebufp);
	if(suppress_cycles == NULL || *suppress_cycles < 0)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress: input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_SUPRESS_CYC_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
				"PIN_FLD_SUPPRESSION_CYCLES_LEFT is NULL", ebufp);
		goto cleanup;
	}

	acc_pdp=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 0, ebufp);
	if(!PIN_POID_IS_NULL(acc_pdp))
	{	
		/*********************************************************************
		 * PCM_OP_READ_OBJ of account poid and get PIN_FLD_BAL_GRP_OBJ    
		 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account 8244369 1
		 ********************************************************************/
		balgrp_readobj_iflistp = PIN_FLIST_CREATE(ebufp);	
		PIN_FLIST_FLD_SET (balgrp_readobj_iflistp, PIN_FLD_POID,acc_pdp, ebufp);	
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_READ_OBJ to get PIN_FLD_BAL_GRP_OBJ:"
			"input flist", balgrp_readobj_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0,balgrp_readobj_iflistp, &balgrp_readobj_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
				" input flist ",balgrp_readobj_iflistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
			"Error while doing PCM_OP_READ_OBJ of acct_poid and get PIN_FLD_BAL_GRP_OBJ",ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_READ_OBJ to get PIN_FLD_BAL_GRP_OBJ:"
			"return flist", balgrp_readobj_rflistp);

		balgrp_obj = PIN_FLIST_FLD_GET(balgrp_readobj_rflistp, PIN_FLD_BAL_GRP_OBJ, 0, ebufp);
		/*************************************************************************
		 * PCM_OP_READ_OBJ of PIN_FLD_BAL_GRP_OBJ poid and get PIN_FLD_BILLINFO_OBJ
		 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /balance_group 8242577  1
		 **************************************************************************/
		billinfo_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET (billinfo_readobj_iflistp, PIN_FLD_POID,balgrp_obj, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_READ_OBJ to get PIN_FLD_BILLINFO_OBJ:"
			"input flist", billinfo_readobj_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0,billinfo_readobj_iflistp, &billinfo_readobj_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
				"input flist ",billinfo_readobj_iflistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:Error"
				"while doing READ_OBJ of bal_grp poid and get PIN_FLD_BILLINFO_OBJ:",ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_READ_OBJ to get PIN_FLD_BILLINFO_OBJ:"
			"return flist", billinfo_readobj_rflistp);

		billinfo_obj = PIN_FLIST_FLD_GET(billinfo_readobj_rflistp, PIN_FLD_BILLINFO_OBJ, 0, ebufp);

		/*****************************************************************************************
		 * PCM_OP_READ_OBJ of PIN_FLD_BILLINFO_OBJ poid and Checking the account is Payingtype Only 
		 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /balance_group 8242577  1
		 ******************************************************************************************/
		paytype_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_SET (paytype_readobj_iflistp, PIN_FLD_POID,billinfo_obj, ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Call PCM_OP_READ_OBJ to get Paytype",
			paytype_readobj_iflistp);
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, paytype_readobj_iflistp, &paytype_readobj_rflistp, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					" input flist ",paytype_readobj_iflistp );
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					" Error while doing PCM_OP_RAED_OBJ to get Paytype: ", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Call PCM_OP_READ_OBJ to get Paytype return flist", 
			paytype_readobj_rflistp);
		paytypep = PIN_FLIST_FLD_GET(paytype_readobj_rflistp, PIN_FLD_PAY_TYPE, 0, ebufp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"checking Prepaid Paytype");	
		if(*paytypep == PIN_PAY_TYPE_PREPAID)
		{
			PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress input flist",
					paytype_readobj_rflistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					"Given Account/MSISDN paytype is Prepaid", ebufp);
			goto cleanup;

		}
		if(*paytypep != PIN_PAY_TYPE_SUBORD)
		{
			/**Sample Input flist for PCM_OP_BILL_SET_BILL_SUPPRESSION ***********
			 * 0 PIN_FLD_POID   				POID [0] 0.0.0.1 /billinfo 8242833 0
			 * 0 SUPPRESSION_CYCLES_LEFT    	 INT [0] 5
			 * 0 PIN_FLD_CONTEXT_INFO     SUBSTRUCT [0] 
			 * 1 	PIN_FLD_CORRELATION_ID       STR [0] "er2345"
			 * 1 	PIN_FLD_EXTERNAL_USER        STR [0] "CRM"
			 **********************************************************************/
			bill_suppress_iflistp = PIN_FLIST_CREATE(ebufp);

			PIN_FLIST_FLD_SET(bill_suppress_iflistp, PIN_FLD_POID, billinfo_obj, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_SUPPRESSION_CYCLES_LEFT,bill_suppress_iflistp, 
				PIN_FLD_SUPPRESSION_CYCLES_LEFT, ebufp);

			arg_flistp = PIN_FLIST_SUBSTR_ADD(bill_suppress_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
			PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_CORRELATION_ID,arg_flistp, 
				PIN_FLD_CORRELATION_ID, ebufp);
			PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, arg_flistp, 
				PIN_FLD_EXTERNAL_USER, ebufp);

			PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "Opcode PCM_OP_BILL_SET_BILL_SUPPRESSION:"
				"input flist", bill_suppress_iflistp);
			PCM_OP (ctxp, PCM_OP_BILL_SET_BILL_SUPPRESSION, 0, bill_suppress_iflistp, 
				&bill_suppress_rflistp, ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:input flist",
					bill_suppress_iflistp );
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                          	        TAB_ERR_CODE_API_BILL_SUPPRESS, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					"Error while doing BILL_SUPPRESSION: ", ebufp);
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "Opcode PCM_OP_BILL_SET_BILL_SUPPRESSION:"
				"return flist", bill_suppress_rflistp);
		}
		else
		{
			PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_suppress input flist",paytype_readobj_rflistp);
			if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 0, ebufp)!= NULL)
			{
				PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress input flist",
					paytype_readobj_rflistp);
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_MSISDN_NOT_PR, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					"Given MSISDN is a non-paying MSISDN", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress input flist",in_flistp);
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ACCT_NOT_PR, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
					"Given Account_no is a non-paying Account_no", ebufp);
				goto cleanup;
			}
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_suppress input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ACCT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_suppress:"
				"Account Not Found", ebufp);
		goto cleanup;
	}

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&bill_suppress_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&bill_suppress_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&balgrp_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&balgrp_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&billinfo_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&billinfo_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&paytype_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	return;
}
