/*******************************************************************************
*	Copyright (c) 2008, 2012, Oracle and/or its affiliates. All rights reserved.
*
*	This material is the confidential property of Oracle Corporation
*	or its licensors and may be used, reproduced, stored or transmitted
*	only in accordance with a valid Oracle license or sublicense agreement.
*********************************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "pinlog.h"
#include "cm_fm.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_bill_config_func();
#endif

/*******************************************************************
 *	NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 *	AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 *	OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 ********************************************************************/

struct cm_fm_config fm_tab_bill_config[] = {
        /* opcode as a int32, function name (as a string) */
	{ TAB_OP_BILL_MAKE_BILL_NOW,	"op_tab_bill_make_bill_now" },
	{ TAB_OP_BILL_GET_EVENT_DETAILS,	"op_tab_bill_get_event_details" },
	{ TAB_OP_BILL_GET_CALL_DETAILS,	"op_tab_bill_get_call_details" },
	{ TAB_OP_BILL_GET_OUTSTANDING, "op_tab_bill_get_outstanding" },
	{ TAB_OP_BILL_SUPPRESS, "op_tab_bill_suppress"},
	{ TAB_OP_BILL_CHANGE_BDOM,      "op_tab_bill_change_bdom", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_BILL_TRIAL_BILL,       "op_tab_bill_trial_bill" },
	{ TAB_OP_BILL_GET_BILL_DETAILS,      "op_tab_bill_get_bill_details" },
	{ TAB_OP_BILL_FETCH_INVOICE,      "op_tab_bill_fetch_invoice" },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tab_bill_config_func()
{
  return ((void *) (fm_tab_bill_config));
}
#endif
