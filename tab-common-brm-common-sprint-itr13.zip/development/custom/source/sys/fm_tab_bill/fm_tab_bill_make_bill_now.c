/*******************************************************************************
 *
 *	 This material is the confidential property of Telenor/Oracle Corporation or its
 *	 licensors and may be used, reproduced, stored or transmitted only in
 *	 accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *		
 *			| 1	| 16-NOV-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_BILL_MAKE_BILL_NOW operation. 
 *******************************************************************/

#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_pymt.h"
#include "pin_inv.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_bill_make_bill_now(
	cm_nap_connection_t 	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void fm_tab_bill_make_bill_now(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_execute_make_bill_now(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_get_owner_billinfo_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_BILL_MAKE_BILL_NOW is implemented to 
 * produce Bill Now for the specified billinfo object.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN & PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID			POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO		 STR [0] "CH_112"
 * 0 PIN_FLD_MSISDN			 STR [0] "0049100502"
 * 0 PIN_FLD_CORRELATION_ID	   STR [0] "erID3"
 * 0 PIN_FLD_EXTERNAL_USER	  STR [0] "CRM3"
 *
 */ 
/**************************************************************************
 * Main routine for the TAB_OP_BILL_MAKE_BILL_NOW operation.
 *************************************************************************/
void
op_tab_bill_make_bill_now(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*enrich_iflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;
	char			log_msg[512]= "";
	poid_t			*account_pdp = NULL;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_make_bill_now function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_MAKE_BILL_NOW) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_make_bill_now bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_make_bill_now input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_make_bill_now:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_BILL_NOW;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_BILL_NOW )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_BILL_NOW, ebufp);
		}

		*ret_flistpp = r_flistp;
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_make_bill_now: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_bill_make_bill_now(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_make_bill_now error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_bill_make_bill_now:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_bill_make_bill_now: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_BILL_MAKE_BILL_NOW", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_make_bill_now:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_BILL_NOW;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_BILL_NOW )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, 
				TAB_ERR_DESCR_API_CREATE_BILL_NOW, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_make_bill_now output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to perform
 * and execute operations related 
 * to bill now.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @param db_no
 * @return out_flistpp.
 *
 */

void fm_tab_bill_make_bill_now(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*msisdnp = NULL;
	char			*account_nop = NULL;
	pin_flist_t		*billinfo_details_flistp = NULL;
	pin_flist_t		*bill_now_result_flistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*bill_read_iflistp = NULL;
	pin_flist_t		*bill_read_oflistp = NULL;
	pin_flist_t		*bill_now_iflistp = NULL;
	pin_flist_t		*bill_now_oflistp = NULL;
	pin_flist_t		*make_invoice_iflistp = NULL;
	pin_flist_t		*make_invoice_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	poid_t			*last_bill_obj_pdp = NULL;
	int			bill_now_flag = 0;
	int32			results_elemid = 0;
	pin_cookie_t		results_cookie = NULL;
	int                     *paytypep=0;
	int32			inv_flags = PIN_INV_TYPE_DETAIL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_bill_make_bill_now input flist", in_flistp);

	msisdnp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	
	/*Check for account number or MSISDN*/
	if((account_nop == NULL || strlen(account_nop ) == 0) 
		&& (msisdnp == NULL || strlen(msisdnp) == 0)) 
    {
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_cust_get_account_info:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}

	/*Get billinfo details based on input*/
	if(msisdnp && strlen(msisdnp) != 0)
	{
		fm_tab_utils_common_get_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
				"fm_tab_utils_common_get_billinfo_details output flist", billinfo_details_flistp);
			bill_now_flag = 1;
		}
	}
	else if(account_nop && strlen(account_nop) != 0 && bill_now_flag == 0)
	{
		fm_tab_utils_common_get_owner_billinfo_details(ctxp, in_flistp, 
			&billinfo_details_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_owner_billinfo_details:"
				" Error while getting billinfo object", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
				"fm_tab_utils_common_get_owner_billinfo_details output flist", billinfo_details_flistp);
		}
	}
	billinfo_flistp = PIN_FLIST_ELEM_GET(billinfo_details_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	paytypep = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 0, ebufp);

	if(*paytypep == PIN_PAY_TYPE_PREPAID)
	{
		PIN_ERR_LOG_FLIST (PIN_ERR_LEVEL_ERROR, "fm_tab_bill_make_bill_now input flist",
				billinfo_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_PREPAID_ACCOUNT_NOT_SUPPORTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_make_bill_now:"
				"Given Account/MSISDN paytype is Prepaid", ebufp);
		goto cleanup;

	}
	if (billinfo_details_flistp && (billinfo_flistp != NULL))
	{
		/*Prepare input flist for PCM_OP_BILL_MAKE_BILL_NOW*/
		bill_now_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, bill_now_iflistp, PIN_FLD_BILLINFO_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, bill_now_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, bill_now_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, bill_now_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
			"fm_tab_execute_make_bill_now input flist", bill_now_iflistp);

		/*Execute PCM_OP_BILL_MAKE_BILL_NOW opcode*/
		fm_tab_execute_make_bill_now(ctxp, bill_now_iflistp, 
				&bill_now_oflistp,db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_make_bill_now:"
				" input flist ", bill_now_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_make_bill_now:"
				" Error while calling PCM_OP_BILL_MAKE_BILL_NOW", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
				"fm_tab_execute_make_bill_now output flist", bill_now_oflistp);

			if(bill_now_oflistp != NULL && PIN_FLIST_ELEM_COUNT(bill_now_oflistp, PIN_FLD_RESULTS, ebufp) > 0 )
			{
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);
				PIN_FLIST_FLD_COPY(bill_now_oflistp, PIN_FLD_POID, *out_flistpp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, *out_flistpp, PIN_FLD_ACCOUNT_NO, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, *out_flistpp, PIN_FLD_CORRELATION_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, *out_flistpp, PIN_FLD_EXTERNAL_USER, ebufp);

				while ((bill_now_result_flistp = PIN_FLIST_ELEM_GET_NEXT(bill_now_oflistp, PIN_FLD_RESULTS, 
					&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					/*Read Bill object to get bill number*/
					bill_read_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(bill_now_result_flistp, PIN_FLD_LAST_BILL_OBJ, 
						bill_read_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_SET(bill_read_iflistp, PIN_FLD_BILL_NO, NULL, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
						"Read bill object input flist", bill_read_iflistp);
					PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, bill_read_iflistp, &bill_read_oflistp, ebufp);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Bill object PCM_OP_READ_FLDS:"
							" input flist ", bill_read_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
							" Error while reading bill object", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
							"Read bill object output flist", bill_read_oflistp);

						if(bill_read_oflistp != NULL)
						{
							PIN_FLIST_FLD_COPY(bill_read_oflistp, PIN_FLD_BILL_NO, 
								*out_flistpp, PIN_FLD_BILL_NO, ebufp);
						}

						last_bill_obj_pdp = PIN_FLIST_FLD_GET(bill_now_result_flistp, 
							PIN_FLD_LAST_BILL_OBJ, 1, ebufp);

						if(!PIN_POID_IS_NULL(last_bill_obj_pdp))
						{
							/*Execute PCM_OP_INV_MAKE_INVOICE on the generated bill object*/
							make_invoice_iflistp = PIN_FLIST_CREATE(ebufp);
							PIN_FLIST_FLD_SET(make_invoice_iflistp, PIN_FLD_POID, 
								last_bill_obj_pdp, ebufp);
							PIN_FLIST_FLD_SET(make_invoice_iflistp, PIN_FLD_INV_FLAGS, 
								&inv_flags, ebufp);

							context_info_flistp = PIN_FLIST_SUBSTR_ADD(make_invoice_iflistp, 
								PIN_FLD_CONTEXT_INFO, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
								context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
								context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
								"PCM_OP_INV_MAKE_INVOICE input flist", make_invoice_iflistp);
							PCM_OP(ctxp, PCM_OP_INV_MAKE_INVOICE, 0, make_invoice_iflistp, &make_invoice_oflistp, ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									TAB_ERR_CODE_MAKE_INVOICE, 0, 0, 0);
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_INV_MAKE_INVOICE:"
									" input flist ", make_invoice_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_INV_MAKE_INVOICE:"
									" Error while creating invoice object", ebufp);
								goto cleanup;
							}
							else
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bill_make_bill_now: "
									"PCM_OP_INV_MAKE_INVOICE output flist", make_invoice_oflistp);
							}
						}
					}

					PIN_FLIST_DESTROY_EX(&bill_read_oflistp, NULL);
					PIN_FLIST_DESTROY_EX(&make_invoice_oflistp, NULL);
					PIN_FLIST_DESTROY_EX(&bill_read_iflistp, NULL);
					PIN_FLIST_DESTROY_EX(&make_invoice_iflistp, NULL);
				}
			}
		}
	}
	else
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_tab_bill_make_bill_now:"
			"Billinfo is not associated with input account", ebufp);
		goto cleanup;
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&billinfo_details_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_now_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_now_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&make_invoice_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&make_invoice_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_bill_make_bill_now output flist", *out_flistpp);
	return;
}

/**
 * We use this function to call 
 * PCM_OP_BILL_MAKE_BILL_NOW opcode.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void
fm_tab_execute_make_bill_now(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*bill_now_iflistp = NULL;
	pin_flist_t		*bill_now_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_execute_make_bill_now error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_execute_make_bill_now:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_make_bill_now input", i_flistp);

	bill_now_iflistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, bill_now_iflistp, 
		PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, bill_now_iflistp, 
		PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, bill_now_iflistp, 
		PIN_FLD_PROGRAM_NAME, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(bill_now_iflistp, 
		PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, 
		PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, 
		PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_execute_make_bill_now: "
		"PCM_OP_BILL_MAKE_BILL_NOW input", bill_now_iflistp);

	PCM_OP(ctxp, PCM_OP_BILL_MAKE_BILL_NOW, 0, bill_now_iflistp, &bill_now_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_BILL_NOW, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_BILL_NOW:"
			" input flist ", bill_now_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BILL_MAKE_BILL_NOW:"
			" Error while creating bill object", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,	"fm_tab_execute_make_bill_now: "
		"PCM_OP_BILL_MAKE_BILL_NOW output", bill_now_oflistp);

	cleanup:
	PIN_FLIST_DESTROY_EX(&bill_now_iflistp, NULL);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*r_flistpp = bill_now_oflistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_execute_make_bill_now output flist", *r_flistpp);

	return;
}
