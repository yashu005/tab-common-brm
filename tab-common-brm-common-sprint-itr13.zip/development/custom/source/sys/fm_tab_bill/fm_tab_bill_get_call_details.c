/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details
 *
 *                  | 1     | 17-Jan-2021   | Piyush           |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_BILL_GET_CALL_DETAILS operation.
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "ops/ece.h"
#include "fm_bill_utils.h"
#include <stdbool.h>
#include "tab_utils_common.h"


/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_bill_get_call_details(
	cm_nap_connection_t *connp,
	int       	 opcode,
	int              flags,
	pin_flist_t      *in_flistp,
	pin_flist_t      **out_flistpp,
	pin_errbuf_t     *ebufp);

static void
fm_tab_bill_get_call_details(
	pcm_context_t  	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);


static void
fm_tab_bill_get_prepare_output(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);


static void
fm_tab_bill_get_search_bill(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static void
fm_tab_bill_get_search_item(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static void
fm_tab_bill_get_search_event(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static void
fm_tab_bill_get_search_event_result(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	int64 		db_no,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp);

static void
fm_tab_bill_get_enrich_offering(
	pcm_context_t 	*ctxp,
	pin_flist_t     *event_bal_flistp,
	pin_flist_t	*return_offering_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static char
*fm_tab_bill_get_event_unit(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_errbuf_t    *ebufp);


extern pin_flist_t *config_beid_out_flistp;

extern pin_flist_t *cfg_tab_system_prod_flistp;

/**
 *
 * New opcode TAB_OP_BILL_GET_CALL_DETAILS is implemented to
 * get event call details for the account object.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN & PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID                  POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_MSISDN        STR [0] "1633330150"
 0 PIN_FLD_ACCOUNT_NO      STR [0] "C2_remove"
 0 TAB_FLD_BILL_START_T_STR STR [0] "01-DEC-21 00:00:00"
 0 TAB_FLD_BILL_END_T_STR STR [0] "01-JAN-21 00:00:00"
 0 PIN_FLD_BILL_NO STR [0] "B1-137"
 0 PIN_FLD_ITEMS ARRAY [0]
 1 PIN_FLD_NAME STR [0] "Cycle forward arrear"
 0 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
 0 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"
 *
 */
/**************************************************************************
 * Main routine for the TAB_OP_BILL_GET_CALL_DETAILS operation.
 *************************************************************************/
void
op_tab_bill_get_call_details(
	cm_nap_connection_t     *connp,
	int                     opcode,
	int                     flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **ret_flistpp,
	pin_errbuf_t            *ebufp)
{
	pcm_context_t           *ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	int32                   status = PIN_BOOLEAN_TRUE;
	pin_flist_t             *enrich_iflistp = NULL;
	int32                   error_clear_flag = 1;
	int32                   cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_call_details input flist :",
				in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_bill_get_event_call_details function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_BILL_GET_CALL_DETAILS) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_call_details bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_event_call_details input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/******************************************************************************
	 * Validate and normalize the input.
	 ******************************************************************************/

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_call_details:"
			" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_call_details: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_call_details:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/******************************************************************************
	 * Call main routine
	 ******************************************************************************/

	fm_tab_bill_get_call_details(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_call_details input flist :",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_bill_get_event_call_details error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_call_details:"
			"input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_bill_get_call_details:"
			" Error while  fetching the events", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_CALL_DETAILS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_CALL_DETAILS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_CALL_DETAILS, ebufp);
		}
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp)
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_bill_get_call_details output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}


/***********************************************************
 * fm_tab_bill_get_call_details()
 * This is the core function which searches bill,items, events
 * and based on on the given input finally prepares the desired ouptut.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param db_no,Database number
 * @param ebufp The error buffer.
 * @returns a void.
 ***********************************************************/

static void
fm_tab_bill_get_call_details(
	pcm_context_t  	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	pin_flist_t	*bill_return_flistp=NULL;
	pin_flist_t 	*post_return_flistp=NULL;
	pin_flist_t 	*item_return_flistp=NULL;
	pin_flist_t 	*event_return_flistp=NULL;
	char		*acct_nop = NULL;
	char		*msisdnp = NULL;
	pin_flist_t	*input_post_get_call_flistp=NULL;
	pin_flist_t	*return_flistp=NULL;
	pin_errbuf_t    local_ebuf = {0};
	pin_errbuf_t    *local_ebufp = &local_ebuf;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_call_details input flist", in_flistp);

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_call_details:"
			"account number/msisdn is not passed", ebufp);
		return;
	}

	bill_return_flistp=PIN_FLIST_COPY(in_flistp,ebufp);

	/******************************************************************************
	 * Prepare bill search for API.
	 ******************************************************************************/

	fm_tab_bill_get_search_bill(ctxp,in_flistp,&bill_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"error", ebufp);
		post_return_flistp=PIN_FLIST_COPY(bill_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare item search for API.
	 ******************************************************************************/

	item_return_flistp=PIN_FLIST_COPY(bill_return_flistp,ebufp);

	fm_tab_bill_get_search_item(ctxp,bill_return_flistp,&item_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item: "
				"error", ebufp);
		post_return_flistp=PIN_FLIST_COPY(item_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare item search for API.
	 ******************************************************************************/

	event_return_flistp=PIN_FLIST_COPY(item_return_flistp,ebufp);

	fm_tab_bill_get_search_event(ctxp,item_return_flistp,&event_return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event: "
				"error", ebufp);
		post_return_flistp=PIN_FLIST_COPY(event_return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	/******************************************************************************
	 * Prepare output
	 ******************************************************************************/
	
	fm_tab_bill_get_prepare_output(ctxp,event_return_flistp,&return_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_prepare_output: "
				"Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_prepare_output: "
				"error", ebufp);
		post_return_flistp=PIN_FLIST_COPY(return_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}
	
	input_post_get_call_flistp=PIN_FLIST_CREATE(ebufp);
	
	PIN_FLIST_SUBSTR_SET(input_post_get_call_flistp,in_flistp,PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(input_post_get_call_flistp,return_flistp,PIN_FLD_OUT_FLIST, ebufp);
		
	PCM_OP( ctxp, TAB_OP_BILL_POL_POST_GET_CALL_DETAILS,0,input_post_get_call_flistp, &post_return_flistp, ebufp );

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_POST_GET_CALL_DETAILS:"
				"error", input_post_get_call_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_POST_GET_CALL_DETAILS:"
				"error", ebufp);
		*out_flistpp=input_post_get_call_flistp;
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&input_post_get_call_flistp, NULL);	 
	PIN_FLIST_DESTROY_EX(&item_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&event_return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&bill_return_flistp, NULL);
	
	*out_flistpp=post_return_flistp;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bal_bill_get_event_call_details output flist", *out_flistpp);

	return;
}


/*******************************************************************
 * This	function is	to create the output response of get event
 * search opcode.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_prepare_output(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_prepare_output input", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_prepare_output:"
				" input flist", in_flistp);
		return;
	}

	int		elem_item=0;
	int 		elem_event = 0 ;	
	int 		elem_event_balance = 0;
	int 		elem_imp=0;
	int 		elem_sub_bal=0;
	int 		elem_sub_bal_imp=0;

	pin_cookie_t 	cookie_sub_bal_imp=NULL;
	pin_cookie_t 	cookie_sub_bal=NULL;
	pin_cookie_t 	cookie_item= NULL;	
	pin_cookie_t 	cookie_event = NULL;
	pin_cookie_t 	cookie_event_balance = NULL;	
	pin_cookie_t 	cookie_imp = NULL;
	
	pin_flist_t	*item_flistp=NULL;
	pin_flist_t	*return_flistp=PIN_FLIST_CREATE(ebufp);
	pin_flist_t	*return_item_flistp = NULL;
	pin_flist_t 	*events_flistp = NULL;
	pin_flist_t 	*event_bal_flistp = NULL;
	pin_flist_t 	*return_offering_flistp = NULL;
	pin_flist_t	*latest_event_flistp=NULL;
	pin_flist_t 	*event_sub_bal_imp_flistp=NULL;
	pin_flist_t 	*event_sub_bal_flistp=NULL;

	poid_t 		*account_pdp=NULL;
	poid_t 		*event_poidp=NULL;
	int 		event_count=0;	
	int 		latest_call_flag =0;
	int 		max_event_rec_id=0;
	int 		max_item_rec_id=0;
	time_t 		max_created_t=0;

	time_t 		start_t=0;
	time_t 		end_t=0;
	time_t 		created_t=0;
	
	char 		*event_imp_category = NULL;
	char 		*output_start_datep=NULL;
	char 		*output_end_datep=NULL;
	char 		*created_datep=NULL;
	char 		*unit_str=NULL;
	char 		*impact_category=NULL;
	char 		*poid_typep=NULL;
	

	pin_flist_t 	*impact_flistp=NULL;
	pin_flist_t	*return_elem_flistp=PIN_FLIST_CREATE(ebufp);

	/******************************************************************
	 * Global Flist return_flistp
	 ******************************************************************/
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_BILL_START_T_STR, return_flistp, TAB_FLD_BILL_START_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_BILL_END_T_STR, return_flistp, TAB_FLD_BILL_END_T_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILL_NO, return_flistp, PIN_FLD_BILL_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/******************************************************************
	 * Condition to handle the MSISDN account or root account
	 * for offering fetch
	 ******************************************************************/

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0, ebufp);

	fm_tab_utils_common_get_offering_details(ctxp,account_pdp,&return_offering_flistp,db_no,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details error", ebufp);
		PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_offering_details:"
				" input flist", account_pdp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_OFFERING_DETAILS, 0, 0, 0);
		return;
	}

	/******************************************************************
	 * Flag to get the latest event
	 ******************************************************************/

	if (PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_LAST_CALL_DETAIL ,1,ebufp)!=NULL)
	{
		latest_call_flag = *(int*)PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_LAST_CALL_DETAIL ,1,ebufp)	;
	}

	/******************************************************************
	 * Traverse Item to get the events and add it in return Flist
	 ******************************************************************/

	while ((item_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ITEMS,
					&elem_item, 1, &cookie_item, ebufp)) != (pin_flist_t*)NULL)
	{			
		if(PIN_FLIST_ELEM_COUNT(item_flistp,PIN_FLD_EVENTS,ebufp))
		{
			return_item_flistp=PIN_FLIST_ELEM_ADD(return_elem_flistp,PIN_FLD_ITEMS,elem_item,ebufp);
			PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_NAME, return_item_flistp, PIN_FLD_NAME, ebufp);
		}

		/******************************************************************
		 * Traverse Events add it in return Flist
		 ******************************************************************/
		elem_event=0;
		cookie_event=NULL;
		while ((events_flistp = PIN_FLIST_ELEM_GET_NEXT(item_flistp,
						PIN_FLD_EVENTS, &elem_event, 1, &cookie_event, ebufp)) != (pin_flist_t*)NULL)
		{		
			elem_sub_bal_imp=0;
			cookie_sub_bal_imp=NULL;

			/******************************************************************
			 * Traverse	Sub balance	impacts	add	it in return Flist
			 ******************************************************************/
			while ((event_sub_bal_imp_flistp = PIN_FLIST_ELEM_GET_NEXT(events_flistp,
				PIN_FLD_SUB_BAL_IMPACTS,&elem_sub_bal_imp,1,&cookie_sub_bal_imp,ebufp))!=(pin_flist_t*)NULL)
			{
				if(PIN_FLIST_FLD_GET(event_sub_bal_imp_flistp,PIN_FLD_BAL_GRP_OBJ	,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_sub_bal_imp_flistp,PIN_FLD_BAL_GRP_OBJ,ebufp);

				elem_sub_bal=0;
				cookie_sub_bal=NULL;
				/******************************************************************
				 * Traverse	sub balances in return Flist
				 ******************************************************************/
				while ((event_sub_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(event_sub_bal_imp_flistp,
					PIN_FLD_SUB_BALANCES,&elem_sub_bal, 1,&cookie_sub_bal,ebufp))!= (pin_flist_t*)NULL)
				{
					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_FROM,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_FROM,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_FROM_DETAILS,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_FROM_DETAILS,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_TO_DETAILS,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_TO_DETAILS,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_CONTRIBUTOR_STR,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_CONTRIBUTOR_STR,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_ROLLOVER_DATA,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_ROLLOVER_DATA,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_GRANTOR_OBJ,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_GRANTOR_OBJ,ebufp);

					if(PIN_FLIST_FLD_GET(event_sub_bal_flistp,PIN_FLD_VALID_TO ,1,ebufp)!=NULL)
						PIN_FLIST_FLD_DROP(event_sub_bal_flistp,PIN_FLD_VALID_TO,ebufp);
				}
			}

			unit_str=NULL;
			bool	impt_flag=true;

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_UNIT ,1,ebufp)!=NULL)
			{
				unit_str = fm_tab_bill_get_event_unit(ctxp,events_flistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_event_unit input flist", events_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_event_unit: ", ebufp);
					goto cleanup;
				}
				//PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_UNIT,ebufp);
				PIN_FLIST_FLD_SET(events_flistp, PIN_FLD_UNIT_STR, unit_str, ebufp);
			}

			/******************************************************************
			 * Traverse Balance impacts add it in return Flist
			 ******************************************************************/
			elem_event_balance=0;
			cookie_event_balance = NULL;

			while ((event_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(events_flistp,
							PIN_FLD_BAL_IMPACTS, &elem_event_balance, 1, &cookie_event_balance, ebufp)) != (pin_flist_t*)NULL)
			{
				event_imp_category=NULL;
				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_IMPACT_CATEGORY,1, ebufp)!=NULL)
					event_imp_category=PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_IMPACT_CATEGORY,1, ebufp);							

				if (PIN_FLIST_ELEM_COUNT(item_flistp,PIN_FLD_IMPACT_CATEGORIES,ebufp))
				{
					impt_flag=false;
					elem_imp=0;
					cookie_imp = NULL;

					while ((impact_flistp = PIN_FLIST_ELEM_GET_NEXT(item_flistp,
									PIN_FLD_IMPACT_CATEGORIES, &elem_imp, 1, &cookie_imp, ebufp)) != (pin_flist_t*)NULL)
					{										
						impact_category = PIN_FLIST_FLD_GET(impact_flistp,PIN_FLD_IMPACT_CATEGORY,0, ebufp);

						if (strcmp(impact_category,event_imp_category)==0)
						{
							impt_flag=true;										
							break;
						}										
					}
				}

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ ,1,ebufp)!=NULL)
					fm_tab_bill_get_enrich_offering(ctxp,event_bal_flistp,return_offering_flistp,&event_bal_flistp,db_no,ebufp);

				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_enrich_offering input flist", event_bal_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_bill_get_enrich_offering: ", ebufp);
					goto cleanup;
				}

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_OFFERING_OBJ,ebufp);

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_PRODUCT_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_PRODUCT_OBJ,ebufp)	;

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_ITEM_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_ITEM_OBJ,ebufp);

				if(PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_ITEM_OBJ ,1,ebufp)!=NULL)
					PIN_FLIST_FLD_DROP(event_bal_flistp,PIN_FLD_ITEM_OBJ,ebufp);
			}

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_START_T ,1,ebufp)!=NULL)
			{
				start_t = *(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_START_T,0, ebufp);
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_START_T,ebufp);
				output_start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&start_t,ebufp);
				PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_START_T_STR, output_start_datep, ebufp);
				free(output_start_datep);
			}

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_END_T ,1,ebufp)!=NULL)
			{
				end_t = *(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_END_T,0, ebufp);
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_END_T,ebufp);
				output_end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&end_t,ebufp);
				PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_END_T_STR, output_end_datep, ebufp);
				free(output_end_datep);
			}

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_CREATED_T ,1,ebufp)!=NULL)
			{
				created_t = *(time_t*)PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_CREATED_T,0, ebufp);
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_CREATED_T,ebufp);
				created_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&created_t,ebufp);
				PIN_FLIST_FLD_SET(events_flistp, TAB_FLD_CREATED_T_STR, created_datep, ebufp);
				free(created_datep);
			}

			if(PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_POID ,1,ebufp)!=NULL)
			{
				event_poidp = PIN_FLIST_FLD_GET(events_flistp,PIN_FLD_POID,0, ebufp);
				poid_typep = (char*)PIN_POID_GET_TYPE(event_poidp);
				PIN_FLIST_FLD_SET(events_flistp, PIN_FLD_EVENT_TYPE, poid_typep, ebufp);
				PIN_FLIST_FLD_DROP(events_flistp,PIN_FLD_POID,ebufp);
			}

			if(latest_call_flag && created_t> max_created_t && strcmp(poid_typep,"/event/delayed/session/telco/gsm")==0)
			{
				max_created_t=created_t;
				max_event_rec_id=elem_event;
				max_item_rec_id = elem_item;
			}

			if(impt_flag)
			{
				PIN_FLIST_ELEM_SET(return_item_flistp,events_flistp,PIN_FLD_EVENTS,elem_event,ebufp);
				event_count++;
			}
		}
	}

	if (!event_count)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_prepare_output:"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_prepare_output input flist", in_flistp);
		goto cleanup;
	}

	//Handling latest event  case.
	if (latest_call_flag)
	{	
		item_flistp=PIN_FLIST_ELEM_GET(return_elem_flistp,PIN_FLD_ITEMS,max_item_rec_id,1,ebufp);
		latest_event_flistp= PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_ITEMS,max_item_rec_id,ebufp);
		PIN_FLIST_FLD_COPY(item_flistp, PIN_FLD_NAME, latest_event_flistp, PIN_FLD_NAME, ebufp);
		PIN_FLIST_ELEM_COPY(item_flistp,PIN_FLD_EVENTS,max_event_rec_id,latest_event_flistp,PIN_FLD_EVENTS,max_event_rec_id,ebufp);
	}
	else
		PIN_FLIST_CONCAT(return_flistp,return_elem_flistp,ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_prepare_output input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_bill_get_prepare_output: ", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_bill_get_prepare_output output flist", return_flistp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&return_offering_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&return_elem_flistp, NULL);
	*out_flistpp= return_flistp;

	return;
}

/*******************************************************************
 * This	function is	to search the bill no either based on bill number
 * or input	start and end date
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_search_bill(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_bill input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*search_service_flistp=NULL;
	pin_flist_t 	*result_service_flistp=NULL;
	pin_flist_t 	*service_alias_flistp=NULL;
	pin_flist_t 	*args_flistp=NULL;
	
	poid_t 		*account_pdp=NULL;
	poid_t 		*srch_poidp=NULL;	
	
	time_t 		zero=0;
	time_t 		start_date=0;
	time_t 		end_date=0;
	
	int		flags=0;
	char		*template = NULL;
	char		log_msg[512]= "";
	char		*bill_nop= NULL;
	char 		*input_start_date = NULL;
	char 		*input_end_date = NULL;
	
	double 		oneday=0;
	double 		diff=0;
	double 		days=31;

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0, ebufp);

	fm_tab_utils_common_get_service_from_account(ctxp,account_pdp,db_no,&search_service_flistp,ebufp);

	if((result_service_flistp = PIN_FLIST_ELEM_GET(search_service_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp ))!= NULL)
	{
		if ((service_alias_flistp = PIN_FLIST_ELEM_GET(result_service_flistp, PIN_FLD_ALIAS_LIST, PIN_ELEMID_ANY, 1, ebufp ))== NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_NOT_SUBSCRIBER_ACCOUNT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_bill"
					"error search bill failed", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill:"
					" in_flistp", in_flistp);
			goto cleanup;
		}
	}

	if((input_start_date = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_BILL_START_T_STR, 1, ebufp))!=NULL)
	{
		start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_start_date,ebufp);
	}

	if((input_end_date=PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_BILL_END_T_STR, 1, ebufp))!=NULL)
	{
		end_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_end_date,ebufp);
	}

	/*******************************************************************
	 * setting the end date to sysdate and start date to sysdate-1
	 *******************************************************************/
	if(!start_date && !end_date &&  (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp))==NULL)
	{
		end_date=pin_virtual_time(NULL);
		start_date=end_date-ONEDAY;
	}

	if(!start_date)
	{	
		start_date=end_date-ONEDAY*31;
	}

	if(!end_date)
	{	
		end_date=start_date+ONEDAY*31;
	}	
	
	oneday=ONEDAY;
	diff=(end_date-start_date)/oneday;

	sprintf(log_msg,"Difference value : %f",diff);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

	/*******************************************************************
	 * Error handling if the duration is more than the 31 days
	 *******************************************************************/
	if ((start_date ||end_date) && diff>days)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"Date range is more than a month error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INCORRECT_DATE_RANGE, 0, 0, 0);
		goto cleanup;
	}

	search_input_flistp = PIN_FLIST_CREATE(ebufp);

	srch_poidp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID, srch_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	pin_flist_t *result_flistp = NULL;
	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);

	if((bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp))!=NULL)
	{
		template= "select X from /bill where F1 = V1 and F2 = V2 ";
		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE, template, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_NO, bill_nop, ebufp);

		if ((PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp))!=NULL)
		{
			args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,2, ebufp);
			PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GET_MSISDN_NOT_PRESENT, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_bill"
					"error search bill failed", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
					"Input Flist", in_flistp);
			goto cleanup;
		}

		goto opcode;
	}

	if (start_date && end_date)
	{
		template= "select X from /bill where F1 = V1 and ((F2 <= V2 and F3 >= V3 and F4 <= V4 ) or (F5 >= V5 and F6 >= V6 and F7 <= V7) or ( (F8 >= V8 or F9 = V9) and F10 <= V10 ))  ";		

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ,	account_pdp, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T,	(void *)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void	*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void	*)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	5, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T,	(void *)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	6, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,	7, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&end_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,8, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T,	(void*)&start_date, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,9, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_END_T, (void*)&zero, ebufp);

		args_flistp	= PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS,10, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_START_T, (void*)&end_date, ebufp);

		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE,	template, ebufp);

		PIN_FLIST_FLD_SET(*out_flistpp,	PIN_FLD_START_T, (void*)&start_date, ebufp);
		PIN_FLIST_FLD_SET(*out_flistpp,	PIN_FLD_END_T, (void *)&end_date, ebufp);


		goto opcode;
	}

opcode:
	/*
	   0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	   0 PIN_FLD_FLAGS           INT [0] 0
	   0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 1
	   1     PIN_FLD_POID           POID [0] NULL poid pointer
	   0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 = V2 "
	   0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	   1     PIN_FLD_BILL_NO         STR [0] "B1-1366"
	   0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	   1     PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2067948 0*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 1
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2067948 0
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_START_T      TSTAMP [0] (1643119077) Tue Jan 25 05:57:57 2022
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_END_T        TSTAMP [0] (1643205477) Wed Jan 26 05:57:57 2022
	  0 PIN_FLD_ARGS          ARRAY [4] allocated 20, used 1
	  1     PIN_FLD_END_T        TSTAMP [0] (0) <null>
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /bill where F1 = V1 and F2 >= V2 and (F3 <= V3 or F4 = V4 )"
	  */

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_bill: "
			"Input Flist", search_input_flistp);
	PCM_OP( ctxp, PCM_OP_SEARCH, 0, search_input_flistp, &search_out_flistp, ebufp );
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_bill: "
			"Output Flist", search_out_flistp);

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (bill_nop && !PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_bill"
				"error search bill failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"Input Flist", in_flistp);
		goto cleanup;
	}

	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(search_out_flistp,PIN_FLD_RESULTS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_bill"
				"error search bill failed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_bill: "
				"Input Flist", in_flistp);
		goto cleanup;
	}

	if(!PIN_FLIST_ELEM_COUNT(*out_flistpp,PIN_FLD_RESULTS,ebufp))
	{
		PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);
		PIN_FLIST_FLD_RENAME(search_out_flistp, PIN_FLD_RESULTS, PIN_FLD_BILLS, ebufp);
		PIN_FLIST_CONCAT(*out_flistpp,search_out_flistp,ebufp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_service_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_bill output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * This	function is	to search the item based on	bill number	search
 * function	output.	It searches	billable as	well as	non	billable items.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_search_item(
	pcm_context_t 	*ctxp,
	pin_flist_t    	*in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_item input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item:"
				" in_flistp", in_flistp);
		return;
	}

	int 		item_search_elemid =0;
	int 		bill_input_elemid =0;
	int 		item_input_elemid =0;
	int 		flags=0;
	int 		item_elem=0;
	int 		latest_call_flag=0;
	
	pin_cookie_t 	item_search_cookie = NULL;
	pin_cookie_t 	bill_input_cookie = NULL;
	pin_cookie_t 	item_input_cookie = NULL;

	pin_flist_t	*item_search_flistp=NULL;
	pin_flist_t	*item_input_flistp =NULL;
	pin_flist_t	*search_out_flistp=NULL;
	pin_flist_t 	*search_last_out_flistp=NULL;
	pin_flist_t 	*bill_input_flistp=NULL;
	pin_flist_t 	*search_input_flistp = PIN_FLIST_CREATE(ebufp);
	pin_flist_t 	*args_flistp=NULL;
	
	poid_t 		*srch_poidp=NULL;
	poid_t 		*account_pdp=NULL;
	poid_t 		*bill_poidp=NULL;
	poid_t 		*item_poidp=PIN_POID_CREATE(db_no, "/item/misc", -1, ebufp);;
	
	char		*template=NULL;	
	time_t		zero=0;
	

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0, ebufp);

	srch_poidp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID, srch_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	pin_flist_t *result_flistp = NULL;
	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_NAME, NULL, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_NAME,(void*) "%Usage%", ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID,item_poidp, ebufp);


	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 2
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_NAME            STR [0] NULL str ptr
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_NAME            STR [0] "%Usage%"
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_BILL_OBJ       POID [0] 0.0.0.1 /bill 2068460 3
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 like V1 and F2 = V2 "*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 0
	  0 PIN_FLD_RESULTS       ARRAY [*] allocated 20, used 2
	  1     PIN_FLD_POID           POID [0] NULL poid pointer
	  1     PIN_FLD_NAME            STR [0] NULL str ptr
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_NAME            STR [0] "%Usage%"
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_EFFECTIVE_T  TSTAMP [0] (0) <null>
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /item where F1 like V1 and F2 = V2 and F3 = V3 "
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 2068460 */

	if (PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_LAST_CALL_DETAIL ,1,ebufp)!=NULL)
	{
		latest_call_flag = *(int*)PIN_FLIST_FLD_GET(in_flistp,TAB_FLD_LAST_CALL_DETAIL ,1,ebufp);

		if (latest_call_flag)
		{
			args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 3, ebufp);
			PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_EFFECTIVE_T, (void *	)&zero, ebufp);

			template= "select X from /item where F1 like V1 and (F2.type not like V2 and F1 like V1) and F3 = V3 and F4 = V4 ";
			PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE, template, ebufp);

			args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 4, ebufp);
			PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, account_pdp, ebufp);

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_item: "
					"Input Flist", search_input_flistp);
			PCM_OP( ctxp, PCM_OP_SEARCH, 0, search_input_flistp, &search_last_out_flistp, ebufp );
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_item: "
					"out Flist", search_last_out_flistp);

			item_search_elemid=0;
			item_search_cookie=NULL;
			while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_last_out_flistp, PIN_FLD_RESULTS,
							&item_search_elemid, 1, &item_search_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_FLIST_ELEM_COPY(search_last_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp, PIN_FLD_ITEMS,item_elem, ebufp);
				item_elem++;
			}
                        PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
			PIN_FLIST_DESTROY_EX(&search_last_out_flistp, NULL);
			goto cleanup;

		}
	}

	item_search_elemid=0;
	item_search_cookie=NULL;

	while ((bill_input_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_BILLS,
					&bill_input_elemid, 1, &bill_input_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		bill_poidp = PIN_FLIST_FLD_GET(bill_input_flistp, PIN_FLD_POID, 1, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_BILL_OBJ, bill_poidp, ebufp);

		template= "select X from /item where F1 like V1 and ( F2.type not like  V2 and F1 like V1 ) and F3 = V3 ";
		PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE, template, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_item billable: "
				"Input Flist", search_input_flistp);
		PCM_OP( ctxp, PCM_OP_SEARCH, 0, search_input_flistp, &search_out_flistp, ebufp );
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_bill_get_search_item billable: "
				"Output Flist", search_out_flistp);

		item_input_elemid=0;
		item_input_cookie=NULL;

		if(PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp))
		{
			while ((item_input_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ITEMS,
							&item_input_elemid, 1, &item_input_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				char *item_input_namep = PIN_FLIST_FLD_GET(item_input_flistp,PIN_FLD_NAME,0, ebufp);

				item_search_elemid = 0;
				item_search_cookie = NULL;

				while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp, PIN_FLD_RESULTS,
								&item_search_elemid, 1, &item_search_cookie, ebufp)) != (pin_flist_t *)NULL)
				{
					char *item_search_namep = PIN_FLIST_FLD_GET(item_search_flistp,PIN_FLD_NAME,0, ebufp);

					if(strcmp(item_input_namep,item_search_namep)==0)
					{
						PIN_FLIST_FLD_DROP(item_search_flistp,PIN_FLD_NAME,ebufp);
						PIN_FLIST_CONCAT(item_search_flistp,item_input_flistp,ebufp);
						PIN_FLIST_ELEM_COPY(search_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp, PIN_FLD_ITEMS,item_elem, ebufp);						
						item_elem++;
					}
				}
			}
		}
		else
		{
			PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);

			item_search_elemid=0;
			item_search_cookie=NULL;
			while ((item_search_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp, PIN_FLD_RESULTS,
							&item_search_elemid, 1, &item_search_cookie, ebufp)) != (pin_flist_t *)NULL)
			{
				PIN_FLIST_ELEM_COPY(search_out_flistp, PIN_FLD_RESULTS,item_search_elemid,*out_flistpp, PIN_FLD_ITEMS,item_elem, ebufp);
				item_elem++;
			}
		}
				
		PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	}

	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp) || (PIN_FLIST_ELEM_COUNT(in_flistp,PIN_FLD_ITEMS,ebufp) &&
                                                !item_elem))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_ITEM_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_item:"
				"error item not found", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item: "
				"Input Flist", in_flistp);
		goto cleanup;
	}

	if (PIN_ERR_IS_ERR(ebufp) || !PIN_FLIST_ELEM_COUNT(*out_flistpp,PIN_FLD_ITEMS,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_item:"
				"error item not found", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_item: "
				"Input Flist", in_flistp);
		goto cleanup;
	}
	
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_item output flist", *out_flistpp);
	return;
}

/*******************************************************************
 * This	function is	to enrich the event balance impact with offerings
 * @param ctxp The context pointer.
 * @param in_flistp	event balance impact as input flist.
 * @param return_offering_flistp	account's offering.
 * @return flistp.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_enrich_offering(
	pcm_context_t 	*ctxp,
	pin_flist_t     *event_bal_flistp,
	pin_flist_t	*return_offering_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_enrich_offering input flistp", event_bal_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_enrich_offering system product flistp", cfg_tab_system_prod_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_enrich_offering error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_enrich_offering:"
				" in_flistp", event_bal_flistp);
		return;
	}

	/******************************************************************
	 * Prepration of event search flist
	 ******************************************************************/
	int 		elem_prod=0;
	int 		resource_id=0;
	int 		elem_dis=0;
	int 		elem_conf_bal=0;


	pin_flist_t 	*product_flistp=NULL;
	pin_flist_t 	*discount_flistp=NULL;
	pin_flist_t 	*config_beid_bal_flistp=NULL;
	pin_flist_t		*sponsorship_flistp=NULL;
	
	pin_cookie_t	cookie_conf_bal=NULL;
	pin_cookie_t 	cookie_dis=NULL;	
	pin_cookie_t 	cookie_prod= NULL;
	poid_t 		*offering_event_objp = NULL;
	poid_t 		*offering_acct_objp=NULL;
	poid_t 			*offering_prod_objp=NULL;

	offering_event_objp=PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_OFFERING_OBJ,1, ebufp);
	resource_id = *(int*)PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_RESOURCE_ID,1, ebufp);
	offering_prod_objp = PIN_FLIST_FLD_GET(event_bal_flistp,PIN_FLD_PRODUCT_OBJ,1, ebufp);

	/******************************************************************
	 * Traverse Balance impacts resource id and resource name return
	 * Flist
	 ******************************************************************/
	while ((config_beid_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
					&elem_conf_bal, 1, &cookie_conf_bal, ebufp)) != (pin_flist_t*)NULL)
	{
		if(elem_conf_bal==resource_id)
		{
			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_NAME, *out_flistpp, PIN_FLD_RESOURCE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_SYMBOL, *out_flistpp, PIN_FLD_NAME, ebufp);

		}
	}

	while ((product_flistp = PIN_FLIST_ELEM_GET_NEXT(return_offering_flistp, PIN_FLD_PRODUCTS,
					&elem_prod, 1, &cookie_prod, ebufp)) != (pin_flist_t*)NULL)
	{
		offering_acct_objp = PIN_FLIST_FLD_GET(product_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_event_objp,offering_acct_objp,0,ebufp))
		{			
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_OFFER_NAME, event_bal_flistp, TAB_FLD_OFFER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_PACKAGE_NAME, event_bal_flistp, TAB_FLD_PACKAGE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(product_flistp, TAB_FLD_BUNDLE_NAME, event_bal_flistp, TAB_FLD_BUNDLE_NAME, ebufp);
			PIN_FLIST_FLD_SET(event_bal_flistp,TAB_FLD_OFFER_TYPE,CHARGE,ebufp);
		}
	}

	while ((discount_flistp = PIN_FLIST_ELEM_GET_NEXT(return_offering_flistp, PIN_FLD_DISCOUNTS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		offering_acct_objp = PIN_FLIST_FLD_GET(discount_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_event_objp,offering_acct_objp,0,ebufp))
		{		
			PIN_FLIST_FLD_COPY(discount_flistp, TAB_FLD_OFFER_NAME, event_bal_flistp, TAB_FLD_OFFER_NAME, ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp, TAB_FLD_PACKAGE_NAME, event_bal_flistp, TAB_FLD_PACKAGE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(discount_flistp, TAB_FLD_BUNDLE_NAME, event_bal_flistp, TAB_FLD_BUNDLE_NAME, ebufp);
			PIN_FLIST_FLD_SET(event_bal_flistp,TAB_FLD_OFFER_TYPE,DISCOUNT,ebufp);
		}
	}
	
	
	cookie_prod=NULL;
	elem_prod=0;

	while ((product_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp, PIN_FLD_PRODUCTS,
					&elem_prod, 1, &cookie_prod, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *product_pdp = PIN_FLIST_FLD_GET(product_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,product_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(product_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	cookie_dis=NULL;
	elem_dis=0;

	while ((discount_flistp	= PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp,PIN_FLD_DISCOUNTS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *dis_pdp = PIN_FLIST_FLD_GET(discount_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,dis_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(discount_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	cookie_dis=NULL;
	elem_dis=0;

	while ((sponsorship_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_system_prod_flistp, PIN_FLD_SPONSORS,
					&elem_dis, 1, &cookie_dis, ebufp)) != (pin_flist_t*)NULL)
	{
		poid_t *sponsorship_pdp = PIN_FLIST_FLD_GET(sponsorship_flistp,PIN_FLD_POID,1, ebufp);

		if(!PIN_POID_COMPARE(offering_prod_objp,sponsorship_pdp,0,ebufp))
		{
			PIN_FLIST_FLD_COPY(sponsorship_flistp,PIN_FLD_NAME,event_bal_flistp,TAB_FLD_OFFER_NAME, ebufp);
		}
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_enrich_offering"
				"error event not present", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp=event_bal_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_enrich_offering output flist", *out_flistpp);

	return;
}

/*******************************************************************
 * This	function is	to search the event	based on item poid and start
 * and end dates as	input parameter.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_search_event_result(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	int64 		db_no,
	pin_flist_t	**ret_flistpp,
	pin_errbuf_t	*ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_event_result input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event_result error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event_result:"
				" in_flistp", in_flistp);
		return;
	}

	char		*template= NULL;
	int 		flags=768;
	time_t 		start_t =0;
	time_t 		end_t = 0 ;
	pin_flist_t 	*result_flistp = NULL;
	pin_flist_t  	*result_telco_info_flistp= NULL;
	pin_flist_t 	*return_gprs_info_flistp=NULL;
	pin_flist_t 	*return_gsm_info_flistp=NULL;
	pin_flist_t	*return_bal_impacts_flistp=NULL;
	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	poid_t 		*srch_poidp=NULL;
	pin_flist_t 	*bal_impacts_flistp = NULL;
	pin_flist_t 	*args_flistp=NULL;
	pin_flist_t 	*search_out_hook_flistp=NULL;
	char 		*item_type=NULL;

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 768
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 1
	  2         PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/misc 2077140 1
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /event where F1 = V1 and F2 = V2 "
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/misc 2077140 1
	  0 PIN_FLD_RESULTS       ARRAY [*]     NULL array ptr*/

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	  0 PIN_FLD_FLAGS           INT [0] 768
	  0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 1
	  2         PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/misc 2067484 1
	  0 PIN_FLD_ARGS          ARRAY [3] allocated 20, used 1
	  1     PIN_FLD_BAL_IMPACTS   ARRAY [*] allocated 20, used 1
	  2         PIN_FLD_IMPACT_CATEGORY    STR [0] "Onnet"
	  0 PIN_FLD_TEMPLATE        STR [0] "select X from /event where F1 = V1 and F2 = V2 and F3 = V3 "
	  0 PIN_FLD_ARGS          ARRAY [2] allocated 20, used 1
	  1     PIN_FLD_ITEM_OBJ       POID [0] 0.0.0.1 /item/misc 2067484 1
	  0 PIN_FLD_RESULTS       ARRAY [*]     NULL array ptr*/


	/******************************************************************
	 * Prepration of event search flist
	 ******************************************************************/

	item_type= PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_NAME,1, ebufp);

	search_input_flistp = PIN_FLIST_CREATE(ebufp);
	srch_poidp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(search_input_flistp,PIN_FLD_POID, srch_poidp, ebufp);
	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_FLAGS, &flags, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 1, ebufp);
	bal_impacts_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_BAL_IMPACTS, PIN_ELEMID_ANY, ebufp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,bal_impacts_flistp, PIN_FLD_ITEM_OBJ, ebufp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1, ebufp)!=NULL && PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1, ebufp)!=NULL )
	{
		template= "select X from /event where F1 = V1 and F2 = V2 and F3 >= V3 and F4 <= V4 order by event_t.created_t desc ";
		start_t= *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_START_T,1, ebufp);
		end_t= *(time_t*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_END_T,1, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, (void*)&start_t, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 4, ebufp);
		PIN_FLIST_FLD_SET(args_flistp,PIN_FLD_CREATED_T, (void*)&end_t, ebufp);
	}
	else
	{
		template= "select X from /event where F1 = V1 and F2 = V2 order by event_t.created_t desc ";
	}

	PIN_FLIST_FLD_SET(search_input_flistp,PIN_FLD_TEMPLATE, template, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_input_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID,args_flistp, PIN_FLD_ITEM_OBJ, ebufp);

	result_flistp= PIN_FLIST_ELEM_ADD(search_input_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	PIN_FLIST_ELEM_SET(result_flistp,NULL,PIN_FLD_SUB_BAL_IMPACTS,PIN_ELEMID_ANY,ebufp);

	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_CREATED_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_START_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_END_T, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_QUANTITY, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_NET_QUANTITY, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_BATCH_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_UNIT, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_ORIGINAL_BATCH_ID, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_flistp,PIN_FLD_RATED_TIMEZONE_ID, NULL, ebufp);

	if(strcmp(item_type,ITEM_GPRS)==0 || strcmp(item_type,ITEM_ROAMING_DATA)==0 )
	{
		return_gprs_info_flistp=PIN_FLIST_SUBSTR_ADD(result_flistp,PIN_FLD_GPRS_INFO,ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_CELL_ID, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_SGSN_ADDRESS, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_GGSN_ADDRESS, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_APN, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_SESSION_ID, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_SGSN_PLMN_ID, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_SERVICE_AREA_CODE, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gprs_info_flistp,PIN_FLD_LOC_AREA_CODE, NULL, ebufp);
	}

	if(strcmp(item_type,ITEM_GSM)==0 || 
		strcmp(item_type,ITEM_ROAMING)==0 || 
		strcmp(item_type,ITEM_ROAMING_SMS)==0 || 
		strcmp(item_type,ITEM_CONTENT)==0 || 
		strcmp(item_type,ITEM_MMS)==0 ||
		strcmp(item_type,ITEM_SMS)==0
		)
	{
		return_gsm_info_flistp=PIN_FLIST_SUBSTR_ADD(result_flistp,PIN_FLD_GSM_INFO,ebufp);
		PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_ORIGIN_SID, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_DESTINATION_SID, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_DIRECTION, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_LOC_AREA_CODE, NULL, ebufp);
		PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_CELL_ID, NULL, ebufp);
		//PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_DIALED_NUMBER, NULL, ebufp);
		//PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_IMEI, NULL, ebufp);
		//PIN_FLIST_FLD_SET(return_gsm_info_flistp,PIN_FLD_NUMBER_OF_UNITS, NULL, ebufp);
	}

	result_telco_info_flistp=PIN_FLIST_SUBSTR_ADD(result_flistp,PIN_FLD_TELCO_INFO,ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_CALLED_TO, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_CALLING_FROM, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_ORIGIN_NETWORK, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_DESTINATION_NETWORK, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_PRIMARY_MSID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_SECONDARY_MSID, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_USAGE_CLASS, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_USAGE_TYPE, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_NETWORK_SESSION_ID, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_SVC_CODE, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_SVC_TYPE, NULL, ebufp);
	//PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_TERMINATE_CAUSE, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_BYTES_DOWNLINK, NULL, ebufp);
	PIN_FLIST_FLD_SET(result_telco_info_flistp,PIN_FLD_BYTES_UPLINK, NULL, ebufp);	

	return_bal_impacts_flistp= PIN_FLIST_ELEM_ADD(result_flistp,PIN_FLD_BAL_IMPACTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_AMOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_GL_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_OFFERING_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_PRODUCT_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_RESOURCE_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_ITEM_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_IMPACT_CATEGORY, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_IMPACT_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_TAX_CODE, NULL, ebufp);
	PIN_FLIST_FLD_SET(return_bal_impacts_flistp,PIN_FLD_QUANTITY, NULL, ebufp);
	

	PIN_FLIST_ELEM_SET(search_input_flistp,result_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_event_result TAB_OP_BILL_POL_GET_CALL_DETAILS flist",search_input_flistp);
	PCM_OP( ctxp, TAB_OP_BILL_POL_GET_CALL_DETAILS, 0, search_input_flistp, &search_out_hook_flistp, ebufp );
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_GET_CALL_DETAILS"
				"error event not present", search_input_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "TAB_OP_BILL_POL_GET_CALL_DETAILS"
				"error event not present", ebufp);
		goto cleanup;
	}

	//search_input_flistp = PIN_FLIST_COPY(search_out_hook_flistp, ebufp);
	//PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);

	PCM_OP( ctxp, PCM_OP_SEARCH, 0, search_out_hook_flistp, &search_out_flistp, ebufp );
	PIN_FLIST_DESTROY_EX(&search_out_hook_flistp, NULL);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event_result"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event_result:"
				" in_flistp", in_flistp)
			goto cleanup;
	}

	PIN_FLIST_FLD_RENAME(search_out_flistp,	PIN_FLD_RESULTS,PIN_FLD_EVENTS,	ebufp);
	PIN_FLIST_FLD_DROP(search_out_flistp,PIN_FLD_POID,ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event_result"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event_result"
				"error event not present", search_input_flistp);
		goto cleanup;
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*ret_flistpp=search_out_flistp;	
	PIN_FLIST_DESTROY_EX(&search_out_hook_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_event_result output flist", *ret_flistpp);
	return;
}


/*******************************************************************
 * This	function is	to loop through the items and call the event
 * search function and add it up in the output flist.
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @return flistp.
 * @param db_no	Database number.
 * @param ebufp	The	error buffer.
 *******************************************************************/

static void
fm_tab_bill_get_search_event(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_event input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event:"
				" in_flistp", in_flistp);
		return;
	}

	/******************************************************************
	 * Prepration of event search flist
	 ******************************************************************/

	pin_flist_t 	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	pin_flist_t 	*event_search_flistp=NULL;
	pin_flist_t 	*impact_category_flistp=NULL;

	int 		event_search_elemid=0;
	int 		elem_imp=0;
	
	pin_cookie_t 	event_search_cookie=NULL;
	pin_cookie_t 	cookie_imp=NULL;




	while ((event_search_flistp = PIN_FLIST_ELEM_GET_NEXT(*out_flistpp, PIN_FLD_ITEMS,&event_search_elemid, 1, &event_search_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		search_input_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(*out_flistpp, PIN_FLD_START_T,search_input_flistp, PIN_FLD_START_T, ebufp);
		PIN_FLIST_FLD_COPY(*out_flistpp, PIN_FLD_END_T,search_input_flistp, PIN_FLD_END_T, ebufp);		
		
		if (PIN_FLIST_FLD_GET(event_search_flistp,PIN_FLD_POID,1, ebufp)!=NULL)
		{
			PIN_FLIST_FLD_COPY(event_search_flistp, PIN_FLD_POID,search_input_flistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(event_search_flistp, PIN_FLD_NAME,search_input_flistp, PIN_FLD_NAME, ebufp);

			if(PIN_FLIST_ELEM_COUNT(*out_flistpp,PIN_FLD_IMPACT_CATEGORIES,ebufp))
			{
				elem_imp=0;
				cookie_imp=NULL;

				while ((impact_category_flistp = PIN_FLIST_ELEM_GET_NEXT(*out_flistpp, PIN_FLD_IMPACT_CATEGORIES,
								&elem_imp, 1, &cookie_imp, ebufp)) != (pin_flist_t*)NULL)
				{
					PIN_FLIST_FLD_COPY(impact_category_flistp, PIN_FLD_IMPACT_CATEGORY,search_input_flistp, PIN_FLD_IMPACT_CATEGORY, ebufp);
					fm_tab_bill_get_search_event_result(ctxp,search_input_flistp,db_no,&search_out_flistp,ebufp);

					if (PIN_ERR_IS_ERR(ebufp))
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event"
								"error search bill failed", ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event:"
								" in_flistp", search_input_flistp);
						goto cleanup;
					}
				}
			}
			else
			{
				fm_tab_bill_get_search_event_result(ctxp,search_input_flistp,db_no,&search_out_flistp,ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event"
							"error search bill failed", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event:"
							" in_flistp", search_input_flistp);
					goto cleanup;
				}
			}
		}
				
		PIN_FLIST_CONCAT(event_search_flistp,search_out_flistp,ebufp);
		PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
		PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);		
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_EVENT_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_search_event"
				"error event not present", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_search_event:"
				" in_flistp", in_flistp)
			goto cleanup;
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bill_get_search_event output flist", *out_flistpp);
	return;
}


/*******************************************************************
 * This	function is	to set the event unit in string format
 * @param ctxp The context pointer.
 * @param in_flistp	in the input flist.
 * @param ebufp	The	error buffer.
 * @return unit string
 *******************************************************************/

static char
*fm_tab_bill_get_event_unit(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_errbuf_t    *ebufp)
{

	char *unit_str = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_unit error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_unit:"
				"in_flistp", in_flistp);
		unit_str="None";
		return unit_str;
	}

	int unit = *(int *)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_UNIT,0, ebufp);

	switch(unit)
	{
		case -1:
			unit_str="FirstUsage";
			break;
		case 0:
			unit_str="None";
			break;
		case 1:
			unit_str="Second";
			break;
		case 2:
			unit_str="Minute";
			break;
		case 3:
			unit_str="Hour";
			break;
		case 4:
			unit_str="Day";
			break;
		case 5:
			unit_str="Month";
			break;
		case 6:
			unit_str="Year";
			break;
		case 7:
			unit_str="EventCyle";
			break;
		case 8:
			unit_str="ActCycle";
			break;
		case 9:
			unit_str="BillCycle";
			break;
		case 11:
			unit_str="Bytes";
			break;
		case 12:
			unit_str="KiloBytes";
			break;
		case 13:
			unit_str="MegaBytes";
			break;
		case 14:
			unit_str="GigaBytes";
			break;
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bill_get_event_unit:"
				"in_flistp", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_bill_get_event_unit"
				"error in event unit str", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	return unit_str;
}
