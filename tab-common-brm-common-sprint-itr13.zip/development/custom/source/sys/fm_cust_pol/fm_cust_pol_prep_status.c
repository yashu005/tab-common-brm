/*******************************************************************
 *
 *      Copyright (c) 1999-2006 Oracle. All rights reserved.
 *
 *      This material is the confidential property of Oracle Corporation
 *      or its licensors and may be used, reproduced, stored or transmitted
 *      only in accordance with a valid Oracle license or sublicense agreement.
 *
 *******************************************************************/

#ifndef lint
static  char Sccs_Id[] = "@(#)%Portal Version: fm_cust_pol_prep_status.c:BillingVelocityInt:2:2006-Sep-05 04:32:07 %";
#endif

#include <stdio.h>

#include "pcm.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained herein.
 *******************************************************************/
EXPORT_OP void
op_cust_pol_prep_status(
        cm_nap_connection_t	*connp,
	u_int			opcode,
        u_int			flags,
        pin_flist_t		*in_flistp,
        pin_flist_t		**ret_flistpp,
        pin_errbuf_t		*ebufp);

static void
fm_cust_pol_prep_status(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);
		
extern void
fm_tab_utils_common_get_service(
	pcm_context_t           *ctxp,
	poid_t                  *svc_pdp,
	int32                   active_flag,
	pin_flist_t             **r_flistpp,
	int64				db_no,
	pin_errbuf_t            *ebufp);
	
extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t			*i_flistp,
	int32				flag,
	int32				customErrorCode,
	pin_flist_t			**err_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);

 
/*******************************************************************
 * Main routine for the PCM_OP_CUST_POL_PREP_STATUS  command
 *******************************************************************/
void
op_cust_pol_prep_status(
        cm_nap_connection_t	*connp,
	u_int			opcode,
        u_int			flags,
        pin_flist_t		*in_flistp,
        pin_flist_t		**ret_flistpp,
        pin_errbuf_t		*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t				*r_flistp = NULL;
	int32					error_clear_flag = 1;
	int32					cerror_code = 0;
	int64					db_no = 0;

	/*
	 * Null out results until we have some.
	 */
	*ret_flistpp = NULL;
	PIN_ERR_CLEAR_ERR(ebufp);

	/*
	 * Insanity check.
	 */
	if (opcode != PCM_OP_CUST_POL_PREP_STATUS) {
		pin_set_err(ebufp, PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"bad opcode in op_cust_pol_prep_status", ebufp);
		return;
	}

	/*
	 * Debug: what did we get?
	 */
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_cust_pol_prep_status input flist", in_flistp);
	
	/*db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		*ret_flistpp = r_flistp;
		return;
	}*/
	
	db_no = cm_fm_get_current_db_no(ctxp);
	/*
	 * Call main function to do it
	 */
	fm_cust_pol_prep_status(ctxp, in_flistp, &r_flistp, db_no, ebufp);

	/*
	 * Results.
	 */
	if (PIN_ERR_IS_ERR(ebufp)) {
		*ret_flistpp = (pin_flist_t *)NULL;
		PIN_FLIST_DESTROY(r_flistp, NULL);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_cust_pol_prep_status error", ebufp);
	} else {
		*ret_flistpp = r_flistp;
		PIN_ERR_CLEAR_ERR(ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"op_cust_pol_prep_status return flist", r_flistp);
	}

	return;
}

/*******************************************************************
 * fm_cust_pol_prep_status()
 *
 *	Prep the status to be ready for on-line registration.
 *
 *	XXX NOOP - STUBBED ONLY XXX
 *
 *******************************************************************/
static void
fm_cust_pol_prep_status(
	pcm_context_t	*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t		*alias_flistp = NULL;
	pin_flist_t		*alias_list_flistp = NULL;
	pin_flist_t		*set_login_in_flistp = NULL;
	pin_flist_t		*set_login_out_flistp = NULL;
	pin_flist_t		*logins_flistp = NULL;
	pin_flist_t		*temp_flistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	poid_t			*in_poidp = NULL;
	int				*statusp = NULL;
	pin_cookie_t	alias_cookie = NULL;
	int32			alias_elemid = 0;
	pin_cookie_t	cookie = NULL;
	int32			elemid = 0;
	char			*in_poid_typep = NULL;
	char			*alias_namep = NULL;
	char			update_alias[256] = {""};
	time_t			current_time = 0;
	char			*loginp = NULL;
	char			update_login[256] = {""};	
	
	if (PIN_ERR_IS_ERR(ebufp))
		return;
	PIN_ERR_CLEAR_ERR(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_cust_pol_prep_status input flist", in_flistp);

	/*
	 * Create outgoing flist
	 */
	*out_flistpp = PIN_FLIST_COPY(in_flistp, ebufp);
	
	in_poidp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 0, ebufp);
	statusp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_STATUS, 0, ebufp);
	if(in_poidp && PIN_POID_GET_ID(in_poidp))
	{
		in_poid_typep = (char *)PIN_POID_GET_TYPE(in_poidp);
	}
	
	if(in_poid_typep && statusp && *statusp == PIN_STATUS_CLOSED && 
		strncmp(in_poid_typep, PIN_OBJ_TYPE_SERVICE, strlen(PIN_OBJ_TYPE_SERVICE)) == 0)
	{
		fm_tab_utils_common_get_service(ctxp, in_poidp, 0, &services_flistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp)) 
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
				"fm_cust_pol_prep_status: error while reading service", ebufp);
			goto Cleanup;
        }
		
		if(PIN_FLIST_ELEM_COUNT(services_flistp, PIN_FLD_RESULTS, ebufp) > 0)
		{
			cookie = NULL;
			elemid = 0;
			while ((temp_flistp = PIN_FLIST_ELEM_GET_NEXT(services_flistp, 
				PIN_FLD_RESULTS, &elemid, 1, &cookie, ebufp)) != NULL) 
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_cust_pol_prep_status: service output", temp_flistp);
				current_time = pin_virtual_time(NULL);
				set_login_in_flistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(temp_flistp, PIN_FLD_ACCOUNT_OBJ, set_login_in_flistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(temp_flistp, PIN_FLD_POID, set_login_in_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
				PIN_FLIST_FLD_SET(set_login_in_flistp, PIN_FLD_PROGRAM_NAME, TAB_TERMINATE_SERVICE, ebufp);

				logins_flistp = PIN_FLIST_ELEM_ADD(set_login_in_flistp, PIN_FLD_LOGINS, 0, ebufp);

				memset(update_login, 0, sizeof(update_login));
				loginp = PIN_FLIST_FLD_GET(temp_flistp, PIN_FLD_LOGIN, 0, ebufp);
				snprintf(update_login, sizeof(update_login), "%s_%ld", loginp, current_time);
				PIN_FLIST_FLD_SET(logins_flistp, PIN_FLD_LOGIN, update_login, ebufp);

				alias_cookie = NULL;
				alias_elemid = 0;
				while((alias_flistp = PIN_FLIST_ELEM_GET_NEXT(temp_flistp, PIN_FLD_ALIAS_LIST,
					&alias_elemid, 1, &alias_cookie, ebufp)) != NULL)
				{
					memset(update_alias, 0, sizeof(update_alias));
					alias_namep = PIN_FLIST_FLD_GET(alias_flistp, PIN_FLD_NAME, 0, ebufp);

					snprintf(update_alias, sizeof(update_alias), "%s_%ld", alias_namep, current_time);
					alias_list_flistp = PIN_FLIST_ELEM_ADD( logins_flistp, PIN_FLD_ALIAS_LIST, alias_elemid, ebufp);
					PIN_FLIST_FLD_SET(alias_list_flistp, PIN_FLD_NAME, update_alias, ebufp);
				}
				
				context_info_flistp = PIN_FLIST_SUBSTR_ADD(set_login_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
					context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
					context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_cust_pol_prep_status service set login input", set_login_in_flistp);

				PCM_OP(ctxp, PCM_OP_CUST_SET_LOGIN, 0, set_login_in_flistp, &set_login_out_flistp, ebufp);
	 
				PIN_FLIST_DESTROY_EX(&set_login_in_flistp, NULL);
				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_cust_pol_prep_status " "service set login error", ebufp);
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_cust_pol_prep_status " "service set login output",
					set_login_out_flistp);
				}
				PIN_FLIST_DESTROY_EX(&set_login_out_flistp, NULL);
			}
		}
	}
	
	Cleanup:
	 PIN_FLIST_DESTROY_EX(&services_flistp, NULL);
	/*
	 * Error?
	 */
	if (PIN_ERR_IS_ERR(ebufp)) {
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_cust_pol_prep_status error", ebufp);
	}
	return;
}
