/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 21-DEC-2021   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "pcm.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "fm_bill_utils.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#include "pin_currency.h"
#define FILE_SOURCE_ID "fm_tab_subscription_adjust_ncr_balance_validity.c"
#define DEFAULT_ACTION (int *)UPDATEENTRY_FLAG

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void fm_tab_subscription_adjust_ncr_balance_validity(
	pcm_context_t	       *ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

time_t 
fm_tab_subscription_get_effective_date(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_get_subbalancesinfo(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int32				resource_id,
	int32				debitelemid_ip,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_balance_group_info(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	

void 
fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_get_reason_code(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_notify_adjust_ncr_balance_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

int32
fm_tab_subscription_validate_resourceid_config(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
int32
fm_tab_subscription_adjncr_get_resourceid_by_name(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_adjust_ncr_create_event_bill_debit(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
int32
fm_tab_subscription_adjncr_transid_check(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
void
fm_tab_subscription_adjust_ncr_get_resourcename_by_id(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern pin_flist_t *config_beid_out_flistp;


 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY operation.
 *************************************************************************/
void
op_tab_subscription_adjust_ncr_balance_validity(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	int32                   tab_order_flag = 0;
	int32                   error_clear_flag = 1;
	int32                   cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	poid_t                  *account_pdp = NULL;
	int32                   status = PIN_BOOLEAN_TRUE;
	pin_flist_t             *enrich_iflistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_adjust_ncr_balance_validity error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_adjust_ncr_balance_validity opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_adjust_ncr_balance_validity input flist", in_flistp);
	
	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
				"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}
	
	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" Error while searching /tab_order object", ebufp);
        
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADJUST_NCR_BALANCE_VALIDITY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADJUST_NCR_BALANCE_VALIDITY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_ADJUST_NCR_BALANCE_VALIDITY, ebufp);
		}
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
        	return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
 		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
       
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_adjust_ncr_balance_validity: "
					"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_adjust_ncr_balance_validity:"
					" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_adjust_ncr_balance_validity:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_adjust_ncr_balance_validity(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
			
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_adjust_ncr_balance_validity error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_adjust_ncr_balance_validity:"
					" fm_tab_subscription_adjust_ncr_balance_validity input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_adjust_ncr_balance_validity:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_adjust_ncr_balance_validity: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	
	cleanup:
	
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY ", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_adjust_ncr_balance_validity:"
			
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_adjust_ncr_balance_validity:"
			
				" Error while creating /tab_order object", ebufp);
		
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADJUST_NCR_BALANCE_VALIDITY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADJUST_NCR_BALANCE_VALIDITY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_ADJUST_NCR_BALANCE_VALIDITY, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_adjust_ncr_balance_validity output flist", *ret_flistpp);
	return;
}

void fm_tab_subscription_adjust_ncr_balance_validity(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*adjustmentinfo_flistp = NULL;
	pin_flist_t			*enrich_out_flistp = NULL;
	pin_flist_t			*balgrp_out_flistp = NULL;
	pin_flist_t			*balgrps_flistp = NULL;
	pin_flist_t			*balgrpsubbalances_flistp = NULL;
	pin_flist_t			*billdebit_in_flistp = NULL;
	pin_flist_t			*billdebit_out_flistp = NULL;
	pin_flist_t			*billdebit_result_flistp = NULL;
	pin_flist_t			*billdebitenrich_out_flistp = NULL;
	pin_flist_t			*billdebit_info_flistp = NULL;
	pin_flist_t			*debitevent_flistp = NULL;
	pin_flist_t			*debit_flistp = NULL;
	pin_flist_t			*subbal_flistp = NULL;
	pin_flist_t			*nofification_out_flistp = NULL;
	pin_flist_t			*reason_out_flistp = NULL;
	pin_flist_t			*contextinfo_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*ret_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	pin_flist_t			*enrichresult_in_flistp = NULL;
	pin_flist_t			*enrichresult_out_flistp = NULL;
	pin_flist_t			*balances_flistp = NULL;
	pin_decimal_t			*zero_val = pbo_decimal_from_str("0.00", ebufp);
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	int32				newelem_id = 1;
	int32				*adjustmenttype_ip = NULL;
	int32				adjustment_cnt = 0;
	int32				*resource_idp = NULL;
	int32				*debitelemid_ip = NULL;
	int32				*mode_ip=NULL;
	time_t				effectivedate_tmst = 0;
	time_t				currenttime_tmst = 0;
	char				log_msg[256] = "";
	char				*reason_strp = NULL;
	int32				copyresult_i = -1;
	int32				*subalelemid_ip = NULL;
	int32				error_code = 0;
	pin_decimal_t		*newbalance_dcmlp = NULL;
	pin_flist_t         *billdebit_bal_impacts_flistp = NULL;
    int32               *bal_impact_res_idp = NULL;
	
	/**************************************************************************
	 * Insanity Check
	 **************************************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: error input flist", in_flistp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);
	
	/**************************************************************************
	 * Debug Input FLIST
	 **************************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_adjust_ncr_balance_validity input flist", in_flistp);
	/**************************************************************************
	 * Mandatory Fields Check
	 **************************************************************************/
	fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check (ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error found on Mandatory field check",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: Error found on Mandatory field check input flist", in_flistp);
		goto cleanup;
	}	

	/**************************************************************************
	 * Check if there is an PIN_FLD_ADJUSTMENT_INFO in the input flist
	 **************************************************************************/
	adjustment_cnt = PIN_FLIST_ELEM_COUNT(in_flistp, PIN_FLD_ADJUSTMENT_INFO, ebufp);
	
	sprintf(log_msg, "fm_tab_subscription_adjust_ncr_balance_validity - Adjustment Count - %d", adjustment_cnt);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	if ( adjustment_cnt <= 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_ADJUSTMENT_INFO, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity error",ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity input flist", in_flistp);
		goto cleanup;
	}
	
	/**************************************************************************
	 * Get the reason stringid and string version
	 **************************************************************************/
	reason_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_REASON_CODE, 1, ebufp);
	
	if((reason_strp && strlen(reason_strp) > 0))
	{
		fm_tab_subscription_get_reason_code( ctxp, in_flistp, &reason_out_flistp, db_no, ebufp);
	}
	
	if (PIN_ERR_IS_ERR(ebufp))
    {
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity Error Getting Searching for the Reason Code information input flist", in_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: Error Getting Searching for the Reason Code information", ebufp);
		goto cleanup;
    }
	
	if (reason_out_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(reason_out_flistp, PIN_FLD_STRING_ID, in_flistp, PIN_FLD_STRING_ID, ebufp);
		PIN_FLIST_FLD_COPY(reason_out_flistp, PIN_FLD_STR_VERSION, in_flistp, PIN_FLD_STR_VERSION, ebufp);
	}
	
	
	/**************************************************************************
	 * Get Balance Group Information
	 **************************************************************************/
	
	fm_tab_subscription_get_balance_group_info(ctxp, in_flistp, &balgrp_out_flistp, ebufp);	
	
	if (PIN_ERR_IS_ERR(ebufp))
    {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_balance_group_info:"
						"Error getting the service from MSISDN");
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_get_balance_group_info input flist", in_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_get_balance_group_info: Error in getting service from msisdn", ebufp);
		goto cleanup;
    }
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_get_balance_group_info output flist", balgrp_out_flistp);
	
	/**************************************************************************
	 * Creating the Balance Group Array in the input flist
	 **************************************************************************/	
	balgrps_flistp = PIN_FLIST_ELEM_ADD(in_flistp, PIN_FLD_BALANCE_GROUPS, 0, ebufp);
	
	/**************************************************************************
	 * Move all the PIN_FLD_BALANCES from the Balgroup Out Flist to Input FLIST
	 **************************************************************************/
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		/**************************************************************************
		 * Sanity Check
		 **************************************************************************/
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Element ID input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Element ID", ebufp);
			goto cleanup;
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Processing the adjustment info",adjustmentinfo_flistp);
		
		/**************************************************************************
		 * Setting the Default Value for PIN_FLD_ACTION_MODE if its not populated
		 **************************************************************************/
		if ((mode_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, 1, ebufp)) == NULL)
		{
			PIN_FLIST_FLD_SET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, DEFAULT_ACTION, ebufp);
			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Setting the default PIN_FLD_ACTION_MODE to 0",adjustmentinfo_flistp);
		}
		
		/**************************************************************************
		 * Getting the Adjustment type
		 **************************************************************************/
		adjustmenttype_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, 1, ebufp);
		
		/**************************************************************************
		 *Getting the Resource ID from the input AdjustmentInfo
		 **************************************************************************/
		resource_idp = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
		
		/**************************************************************************
		 *Getting the Resource Instance from the input AdjustmentInfo
		 **************************************************************************/
		debitelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ELEMENT_ID, 1, ebufp);
		
		/**************************************************************************
		 *Getting the addEntry Flag from the input AdjustmentInfo
		 **************************************************************************/
		mode_ip =  PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, 1, ebufp);
		
		/**************************************************************************
		 * Getting the PIN_FLD_BALANCES specific to the ResourceID
		 **************************************************************************/
		balances_flistp = PIN_FLIST_ELEM_GET(balgrp_out_flistp, PIN_FLD_BALANCES, *resource_idp, 1, ebufp);
		
		if (balances_flistp != NULL)
		{
			
			PIN_FLIST_ELEM_SET(balgrps_flistp,balances_flistp, PIN_FLD_BALANCES, *resource_idp, ebufp);
			
			/**************************************************************************
			 *Checking the PIN_FLD_SUB_BALANCES is they exist on the PIN_FLD_BALANCES of Balancegroup
			 **************************************************************************/
			if (PIN_FLIST_ELEM_COUNT(balances_flistp, PIN_FLD_SUB_BALANCES, ebufp) > 0)
			{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Subbalances has been found on the Balance of the resource");
				
				if (debitelemid_ip != NULL)
				{
					fm_tab_subscription_get_subbalancesinfo( ctxp, balgrp_out_flistp, &balgrpsubbalances_flistp,*resource_idp, *debitelemid_ip, ebufp);
				}
				else
				{
					fm_tab_subscription_get_subbalancesinfo( ctxp, balgrp_out_flistp, &balgrpsubbalances_flistp,*resource_idp, -1, ebufp);
				}
				
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balance_validity: Getting information fromt the subbalances has an error", balgrp_out_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balance_validity: Getting information fromt the subbalances has an error", ebufp);
					goto cleanup;
				}
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Sub Balance Function output flist",balgrpsubbalances_flistp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity : Before Updates Adjustmentinfo Flist",adjustmentinfo_flistp);
				
				PIN_FLIST_FLD_COPY(balgrpsubbalances_flistp, PIN_FLD_CURRENT_BAL, adjustmentinfo_flistp, PIN_FLD_CURRENT_BAL, ebufp);
				PIN_FLIST_FLD_COPY(balgrpsubbalances_flistp, PIN_FLD_VALID_FROM, adjustmentinfo_flistp, PIN_FLD_VALID_FROM, ebufp);	
				PIN_FLIST_FLD_COPY(balgrpsubbalances_flistp, PIN_FLD_VALID_TO, adjustmentinfo_flistp, PIN_FLD_VALID_TO, ebufp);
				
				if (debitelemid_ip == NULL)
				{
					PIN_FLIST_FLD_COPY(balgrpsubbalances_flistp, PIN_FLD_GROUP_ID, adjustmentinfo_flistp, PIN_FLD_GROUP_ID, ebufp);
				}
				else
				{
					PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_ELEMENT_ID, adjustmentinfo_flistp, PIN_FLD_GROUP_ID, ebufp);
				}
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity : After Updates Adjustmentinfo Flist",adjustmentinfo_flistp);
				
				continue;
			}
			else
			{
				if (*mode_ip != 1)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_RESOURCE_DOES_NOT_EXIST, 0, 0, 0);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balance_validity:"
						" ERROR invalid balance resource ID", in_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balance_validity:"
						" ERROR invalid Balance Resource ID", ebufp);
					goto cleanup;
				}
			}
		}
		else
		{
			if (*mode_ip != 1 || *adjustmenttype_ip == 2)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_DOES_NOT_EXIST, 0, 0, 0);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balance_validity:"
					" ERROR invalid balance resource ID", in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balance_validity:"
					" ERROR invalid Balance Resource ID", ebufp);
				goto cleanup;
			}
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_subscription_adjust_ncr_balance_validity :"
			"Before Updates Adjustmentinfo for a new resource balance Flist",adjustmentinfo_flistp);
			
			
		currenttime_tmst = pin_virtual_time(NULL);
		PIN_FLIST_FLD_SET(adjustmentinfo_flistp, PIN_FLD_CURRENT_BAL,pbo_decimal_from_str("0.00", ebufp),ebufp);
		PIN_FLIST_FLD_SET(adjustmentinfo_flistp, PIN_FLD_VALID_FROM,&currenttime_tmst,ebufp);
		PIN_FLIST_FLD_SET(adjustmentinfo_flistp, PIN_FLD_VALID_TO,&currenttime_tmst,ebufp);
		
		if (debitelemid_ip == NULL)
		{
			PIN_FLIST_FLD_SET(adjustmentinfo_flistp,PIN_FLD_GROUP_ID, &newelem_id, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_ELEMENT_ID, adjustmentinfo_flistp, PIN_FLD_GROUP_ID, ebufp);
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_subscription_adjust_ncr_balance_validity :"
			"AfterUpdates Adjustmentinfo for a new resource balance  Flist",adjustmentinfo_flistp);

	}


	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_adjust_ncr_balance_validity: enrichment input flist",in_flistp);
	
	/***************************************************
	 * Call for the Enrichment Opcode
	 ****************************************************/
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY, 0, in_flistp, &enrich_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
    {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_adjust_ncr_balance_validity:"
						"Error Enriching input flist");
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: Error Enriching input flist", in_flistp);
		 PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: Error Enriching output flist", enrich_out_flistp);
        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_adjust_ncr_balance_validity: Error Enrichment", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(enrich_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
    }
	
	 PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_adjust_ncr_balance_validity: Enrichment output flist", enrich_out_flistp);
	
	if ( enrich_out_flistp != NULL)
	{
		result_flistp = PIN_FLIST_ELEM_GET(enrich_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
	}
	/***************************************************
	 * Preparation of the Bill Debit_opcode
	 ****************************************************/
	billdebit_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, billdebit_in_flistp, PIN_FLD_POID, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, billdebit_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, billdebit_in_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, billdebit_in_flistp, PIN_FLD_DESCR, ebufp);
	if (result_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_STRING_ID, billdebit_in_flistp, PIN_FLD_STRING_ID, ebufp);
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_STR_VERSION, billdebit_in_flistp, PIN_FLD_STR_VERSION, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STRING_ID, billdebit_in_flistp, PIN_FLD_STRING_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_STR_VERSION, billdebit_in_flistp, PIN_FLD_STR_VERSION, ebufp);
	}
	contextinfo_flistp = PIN_FLIST_SUBSTR_ADD(billdebit_in_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, contextinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, contextinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Pregenerated bill debit flist", billdebit_in_flistp);
	
	/***************************************************
	 * Reset all the variables to be reused
	 ****************************************************/
	
	elem_id = 0;
	debitelemid_ip = NULL;
	cookie = 0;
	
	adjustment_cnt = PIN_FLIST_ELEM_COUNT(in_flistp, PIN_FLD_ADJUSTMENT_INFO, ebufp);
	sprintf(log_msg,"fm_tab_subscription_adjust_ncr_balance_validity: number of array for PIN_FLD_ADJUSTMENT_INFO -> %d",adjustment_cnt);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{		
		
		adjustmenttype_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, 0, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Adjustment Type input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Adjustment Type", ebufp);
			goto cleanup;
		}
		
		if (*adjustmenttype_ip < 1 || *adjustmenttype_ip > 3)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ADJUSTMENT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_balance_validity: Missing PIN_FLD_ADJUSTMENT_TYPE", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_balance_validity: Missing PIN_FLD_ADJUSTMENT_TYPE input flist", in_flistp);
			PIN_FLIST_DESTROY_EX(&billdebit_in_flistp, ebufp);
			return;
		}
				
		debitelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, 0, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Element ID input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balance_validity: Error in getting Element ID", ebufp);
			goto cleanup;
		}
		
		billdebit_info_flistp = PIN_FLIST_ELEM_ADD (billdebit_in_flistp, PIN_FLD_DEBIT_INFO, elem_id, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, billdebit_info_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
		debit_flistp = PIN_FLIST_ELEM_ADD (billdebit_info_flistp, PIN_FLD_DEBIT , *debitelemid_ip, ebufp);
		
		if (*adjustmenttype_ip == 1 || *adjustmenttype_ip == 3)
		{			
			PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, debit_flistp, PIN_FLD_BAL_OPERAND, ebufp);
		} 
		else if (*adjustmenttype_ip == 2)
		{
			PIN_FLIST_FLD_SET(debit_flistp, PIN_FLD_BAL_OPERAND, zero_val ,ebufp);
		}
		
		if (*adjustmenttype_ip == 1 || *adjustmenttype_ip == 2)
		{
			if ((mode_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, 1, ebufp)) != NULL)
			{
				
				if  (*mode_ip != UPDATEENTRY_FLAG)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_INVALID_ACTION_MODE, 0, 0, 0);
						
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_adjust_ncr_balance_validity:"
															"ERROR Action Mode 1 is not applicable for Adjustment type 2 input flist", in_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_adjust_ncr_balance_validity:"
															" ERROR Action Mode 1 is not applicable for Adjustment type 2", ebufp);
					goto cleanup;
				}
			}
		}
		
		if (*adjustmenttype_ip == 2 || *adjustmenttype_ip == 3)
		{
			subalelemid_ip = NULL;
			subalelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_GROUP_ID, 1, ebufp);
			
			mode_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, 1, ebufp);
			
			if ( *mode_ip == 1)
			{
				subbal_flistp = PIN_FLIST_ELEM_ADD (debit_flistp, PIN_FLD_SUB_BALANCES , PIN_ELEMID_ASSIGN , ebufp);
			}
			else
			{
				subbal_flistp = PIN_FLIST_ELEM_ADD (debit_flistp, PIN_FLD_SUB_BALANCES , *subalelemid_ip, ebufp);
			}
			
			PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_VALID_FROM, subbal_flistp, PIN_FLD_VALID_FROM, ebufp);
			
			effectivedate_tmst = fm_tab_subscription_get_effective_date(ctxp, adjustmentinfo_flistp, ebufp);
			
			PIN_FLIST_FLD_SET(subbal_flistp, PIN_FLD_VALID_TO,&effectivedate_tmst,ebufp);
			
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balance_validity: Bill Debit Info for this Adjustment info FLIST", subbal_flistp);
		}
	}
	
	/***************************************************
	 * Prepare the input flist for Enrichment of bill debit
	 ****************************************************/
	PIN_FLIST_ELEM_DROP(in_flistp, PIN_FLD_BALANCE_GROUPS, 0, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Generated Bill Debit FLIST", billdebit_in_flistp);
				
	PIN_FLIST_ELEM_SET(in_flistp, billdebit_in_flistp, PIN_FLD_DEBIT, 0 , ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Bill Debit FLIST Enrichment input", in_flistp);
				
	/***************************************************
	 * Execute the Bill Debit Enrichment opcode
	 ****************************************************/
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BILL_DEBIT , 0, in_flistp, &billdebitenrich_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing enrichment of Bill Debit FLIST input flist", in_flistp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing enrichment of Bill Debit FLIST output flist", billdebitenrich_out_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing enrichment of Bill Debit FLIST", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(billdebitenrich_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	/***************************************************
	 *Execution of Bill Debit opcode from the output of enrichment
	 ****************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Bill Debit FLIST Enrichment output flist", billdebitenrich_out_flistp);
				
	if (billdebitenrich_out_flistp != NULL)
	{
		PCM_OP(ctxp, PCM_OP_BILL_DEBIT , 0, billdebitenrich_out_flistp, &billdebit_out_flistp, ebufp);
	}
	else
	{
		PCM_OP(ctxp, PCM_OP_BILL_DEBIT , 0, billdebit_in_flistp, &billdebit_out_flistp, ebufp);
	}
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing bill debit", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: : Error processing bill debit", ebufp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Bill Debit output flist", billdebit_out_flistp);
	
	if ((billdebit_result_flistp = PIN_FLIST_ELEM_GET(billdebit_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp)) != NULL)
	{
		PIN_FLIST_FLD_COPY(billdebit_result_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	}
	
	/***************************************************
	 * Reset all the variables to be reused
	 ****************************************************/
	
	elem_id = 0;
	debitelemid_ip = NULL;
	cookie = 0;
	
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{	
	
		/********************************************************
		 * Get New Balance
		 ********************************************************/
		billdebit_bal_impacts_flistp = PIN_FLIST_ELEM_GET(billdebit_result_flistp, PIN_FLD_SUB_BAL_IMPACTS, 0, 1, ebufp);
		resource_idp = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
        if (billdebit_bal_impacts_flistp != NULL)
        {
            bal_impact_res_idp = PIN_FLIST_FLD_GET(billdebit_bal_impacts_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
            if (*bal_impact_res_idp ==  *resource_idp)
            {
               newbalance_dcmlp = PIN_FLIST_FLD_GET(billdebit_bal_impacts_flistp, PIN_FLD_CURRENT_BAL, 1, ebufp);
            }
        }
		
		if (pbo_decimal_is_null(newbalance_dcmlp, ebufp)) 
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_adjust_balance_validity: getting new balance from PIN_FLD_CURRENT_BAL error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_adjust_balance_validity:"
				" getting new balance from PIN_FLD_CURRENT_BAL error intput flist", billdebit_result_flistp);
			goto cleanup;
		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_subscr_get_current_main_balance: getting main balance output flist", billdebit_result_flistp);
		
		PIN_FLIST_FLD_DROP(adjustmentinfo_flistp, PIN_FLD_CURRENT_BAL, ebufp);
		PIN_FLIST_FLD_SET(adjustmentinfo_flistp,PIN_FLD_CURRENT_BAL, newbalance_dcmlp, ebufp);
	
	}
	
	/***************************************************
	 * Create Custom Event Function
	 ****************************************************/
	fm_tab_subscription_adjust_ncr_create_event_bill_debit(ctxp, in_flistp,  &debitevent_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error Processing Create Tab Bill Debit Event Input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: : Error Processing Create Tab Bill Debit Event", ebufp);
		goto cleanup;
	}
	
	/***************************************************
	 * Creation of Internal Return FLIST
	 ****************************************************/
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	/***************************************************
	 * Enrichment of Return/Result
	 ****************************************************/
	enrichresult_in_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichresult_in_flistp, r_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	/*	Below if else block added for CR_TP_2002 where TP wanted input flist being sent to 
		PCM_OP_BILL_DEBIT to be made available to flist enrichresult_in_flistp
	*/
	if (billdebitenrich_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(enrichresult_in_flistp, billdebitenrich_out_flistp, PIN_FLD_RESULTS, 0, ebufp);

	}
	else
	{
		PIN_FLIST_ELEM_SET(enrichresult_in_flistp, billdebit_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Enrich Results input flistp", enrichresult_in_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_RESULTS , 0, enrichresult_in_flistp, &enrichresult_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	/***************************************************
	 * Finalization of Return Flist
	 ****************************************************/
	if (enrichresult_out_flistp != NULL)
	{
		PIN_FLIST_DESTROY_EX(&r_flistp, ebufp);
		r_flistp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
	}
	
	ret_flistp = PIN_FLIST_COPY(r_flistp, ebufp);
	
	/***************************************************
	 * Preparation for notification
	 ****************************************************/
	 
	if (billdebit_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, billdebit_out_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	}
	
	PIN_FLIST_SUBSTR_SET(in_flistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balance_validity: Notification Preparation", in_flistp);
	
	/***************************************************
	 * Call to the notification function
	 ****************************************************/
	fm_tab_notify_adjust_ncr_balance_prepare_notification(ctxp, in_flistp, db_no, &nofification_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing notification  output flist", nofification_out_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity:  Error processing notification  input flist", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(nofification_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_adjust_ncr_balance_validity:"
			" output flist", nofification_out_flistp);
	
	if ( nofification_out_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(nofification_out_flistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(nofification_out_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						r_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(r_flistp, nofification_out_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	
	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&enrich_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&balgrp_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billdebit_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billdebit_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billdebitenrich_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&debitevent_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&nofification_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&reason_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&balgrpsubbalances_flistp, ebufp);
        pbo_decimal_destroy(&zero_val);	
	return;
}


time_t 
fm_tab_subscription_get_effective_date(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_errbuf_t		*ebufp)
{
	char				*effective_strp = NULL;
	time_t				effectivedate_tmst = 0;
	time_t				*validto_tmstp = NULL;
	int32				*validityindays_ip = NULL;
	char				log_msg[256] = "";
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_effective_date: input flist", in_flistp);
	

	if ((effective_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_EFFECTIVE_DATE, 1, ebufp))!=NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_effective_date: Using the TAB_FLD_EFFECTIVE_DATE");
		effectivedate_tmst = fm_tab_utils_common_convert_date_to_timestamp(ctxp,effective_strp,ebufp);
		
	} else {
		if ((validityindays_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALIDITY_IN_DAYS, 1, ebufp))!=NULL && (validto_tmstp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO, 1, ebufp)) != NULL)
		{
			sprintf(log_msg,"fm_tab_subscription_get_effective_date: Calculating PIN_FLD_VALID_TO = %d and PIN_FLD_VALIDITY_IN_DAYS = %d", *validto_tmstp, *validityindays_ip );
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			
			
			fm_utils_add_n_days(*validityindays_ip,validto_tmstp);
			
			
			
			sprintf(log_msg,"fm_tab_subscription_get_effective_date: Calculated Date is equal to %ld", *validto_tmstp);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			
			effectivedate_tmst = *validto_tmstp;
		}
		else
		{
			sprintf(log_msg,"fm_tab_subscription_get_effective_date: Misssing field has been detected", effectivedate_tmst);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		
		
	}
	
	return effectivedate_tmst;

}

void
fm_tab_subscription_get_balance_group_info(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*balinfo_in_flistp = NULL;
	pin_flist_t			*balinfo_out_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balance_group_info error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balance_group_info:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balance_group_info:"
			" input flist", in_flistp);
	
	balinfo_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, balinfo_in_flistp, PIN_FLD_POID, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balance_group_info:"
			" balance read object input flist", balinfo_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, balinfo_in_flistp, &balinfo_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balance_group_info error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balance_group_info:"
			" input flist", in_flistp);
		goto cleanup;
	} 
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balance_group_info:"
			" balance read object input flist", balinfo_out_flistp);
	
	r_flistp = PIN_FLIST_COPY(balinfo_out_flistp, ebufp);
	
	cleanup:
	
	*out_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&balinfo_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&balinfo_out_flistp, ebufp);
	
	return;
}

void
fm_tab_subscription_get_subbalancesinfo(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int32				resource_id,
	int32				debitelemid_ip,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*balances_flistp = NULL;
	pin_flist_t			*subbalances_flistp = NULL;
	pin_flist_t			*subbal_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	int32				status_i = 0;
	char				log_msg[256] = "";
	
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_subbalancesinfo error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_subbalancesinfo:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_subbalancesinfo:"
			" input flist", in_flistp);
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	
	balances_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_BALANCES, resource_id, 1, ebufp);
	
	if (balances_flistp == NULL)
	{
		goto cleanup;
	}
	
	sprintf(log_msg,"fm_tab_subscription_get_subbalancesinfo: Getting the subbalance for the element id : %d", debitelemid_ip);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	if (debitelemid_ip != -1)
	{
		subbal_flistp = PIN_FLIST_ELEM_GET(balances_flistp, PIN_FLD_SUB_BALANCES, debitelemid_ip, 1, ebufp);
	}
	status_i = 1;
	
	
	if (subbal_flistp != NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_subbalancesinfo:"
			" Found the Subbalance of the given Element ID");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_subbalancesinfo:"
			"Found the Subbalance of the given Element ID",subbal_flistp);
			
			
		PIN_FLIST_FLD_COPY(subbal_flistp, PIN_FLD_CURRENT_BAL, r_flistp, PIN_FLD_CURRENT_BAL, ebufp);
		PIN_FLIST_FLD_COPY(subbal_flistp, PIN_FLD_VALID_FROM, r_flistp, PIN_FLD_VALID_FROM, ebufp);
		PIN_FLIST_FLD_COPY(subbal_flistp, PIN_FLD_VALID_TO, r_flistp, PIN_FLD_VALID_TO, ebufp);
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_GROUP_ID, &elem_id, ebufp);
		
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_subbalancesinfo:"
			" Missing Subbalances FLIST of the given Element ID");
			
		while ((subbalances_flistp = PIN_FLIST_ELEM_GET_NEXT(balances_flistp, PIN_FLD_SUB_BALANCES,
				&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
		{
			PIN_FLIST_FLD_COPY(subbalances_flistp, PIN_FLD_CURRENT_BAL, r_flistp, PIN_FLD_CURRENT_BAL, ebufp);
			PIN_FLIST_FLD_COPY(subbalances_flistp, PIN_FLD_VALID_FROM, r_flistp, PIN_FLD_VALID_FROM, ebufp);
			PIN_FLIST_FLD_COPY(subbalances_flistp, PIN_FLD_VALID_TO, r_flistp, PIN_FLD_VALID_TO, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_GROUP_ID, &elem_id, ebufp);
		}	
	}
	
	
	
	cleanup:
	PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_FLAGS, &status_i, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_subbalancesinfo:"
			" output_flist flist", r_flistp);
	
	*out_flistpp = r_flistp;
	
	return;
}

void
fm_tab_subscription_get_reason_code(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*srch_pdp = NULL;
	int32				s_flags = 256;
	char				*template_str = NULL;
	int32				version_i = 1;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_reason_code: error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_reason_code: input flist error", in_flistp);
		return;
	} 
	
	/*******************************************
	 * Search FLIST Preparation
	 *******************************************/
	srch_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);

	search_in_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)srch_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /strings where  F1 = V1 and F2 = V2 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_REASON_CODE, args_flistp, PIN_FLD_STRING, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STR_VERSION, &version_i, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STRING_ID, NULL, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_STR_VERSION, NULL, ebufp);
	
	/*******************************************
	 * Debug Search Input FLIST
	 *******************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_get_bill_based_from_billno: Search Input Flist", search_in_flistp);
	
	/*******************************************
	 * Execution of PCM_OP_SEARCH
	 *******************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	
	/*******************************************
	 * Validation if there is an Error 
	 * on PCM_OP_SEARCH Execution
	 *******************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_get_billdetails_from_billno: Error in Searching Bill Details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_billdetails_from_billno:"
			" Error in Searching Bill Details input flist", search_in_flistp);
		goto cleanup;
	}
	
	result_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
	
	r_flistp = PIN_FLIST_COPY(result_flistp, ebufp);
	
	cleanup:
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return;
}


static void
fm_tab_notify_adjust_ncr_balance_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	int64				db_no,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*read_in_flistp = NULL;
	pin_flist_t		*read_out_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*notify_tflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*adjustmentinfo_flistp = NULL;
	pin_flist_t		*adjinfo_flistp = NULL;
	pin_flist_t		*subbal_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	time_t			currenttime_tmst = 0;
	time_t			*validdate_tmstp = NULL;
	int32			*subalelemid_ip = NULL;
	int32			error_code = 0;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	char			*effective_strp = NULL;
	char			*validdate_strp = NULL;
	
	/***************************************
	 * Insanity Check
	 ***************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_adjust_ncr_balance_prepare_notification function entry error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_adjust_ncr_balance_prepare_notification function entry error", in_flistp);
		goto cleanup;
	}
	
	read_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, read_in_flistp, PIN_FLD_POID, ebufp);
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_adjust_ncr_balance_prepare_notification: "
					"Read Account Object input flist", read_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, read_in_flistp, &read_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_notify_adjust_ncr_balance_prepare_notification: "
					"Error in Read Obj input flist", read_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_adjust_ncr_balance_prepare_notification: Error in Read Obj", ebufp);
		goto cleanup;
	}
	PIN_FLIST_DESTROY_EX(&read_in_flistp, NULL);	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_adjust_ncr_balance_prepare_notification: "
					"Read Account Object output flist", read_out_flistp);
	PIN_FLIST_DESTROY_EX(&read_out_flistp, NULL);
		
	/***************************************
	 * Debug Input
	 ***************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_adjust_ncr_balance_prepare_notification: "
					"input flist", in_flistp);
					
	currenttime_tmst = pin_virtual_time(NULL);
	effective_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, &currenttime_tmst,ebufp);
					
	/***************************************
	 * Prepare Read OBJ Input FLIST to get account no
	 ***************************************/
	read_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, read_in_flistp, PIN_FLD_POID, ebufp);
	
	/***************************************
	 * Execute Read Object Opcode
	 ***************************************/
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, read_in_flistp, &read_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_ncr_balance_prepare_notification:"
			" error read object input flist ", read_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_ncr_balance_prepare_notification:"
			" error read object input flist", ebufp);
		goto cleanup;
	}
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		 " Read Object Out Flist ", read_out_flistp);
	
	/***************************************
	 * Preparation Enrichment Input FLIST Preparation
	 ***************************************/
	notify_flistp =PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_POID, ebufp); 
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification prep flist ", notify_flistp);
	
	/***************************************
	 * PIN_FLD_OUT_FLIST Preparation
	 ***************************************/
	notify_oflistp =  PIN_FLIST_SUBSTR_GET(in_flistp,PIN_FLD_OUT_FLIST,1,ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification  in flist ", notify_oflistp);
	
	
	/***************************************
	 * PIN_FLD_IN_FLIST Preparation
	 ***************************************/
	notify_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_DROP (notify_iflistp, PIN_FLD_OUT_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification  in flist ", notify_iflistp);
	
	/***************************************
	 * TAB_FLD_NOTIFICATION Preparation
	 ***************************************/
	notify_tflistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, "/event/notification/custom/adjustncrbalancevalidity", -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_tflistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, notify_tflistp, PIN_FLD_MSISDN, ebufp); //MSISDN
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, notify_tflistp, PIN_FLD_TRANS_ID, ebufp); //TRANSACTION ID
	PIN_FLIST_FLD_COPY(read_out_flistp, PIN_FLD_ACCOUNT_NO, notify_tflistp, PIN_FLD_ACCOUNT_NO, ebufp); //Account NO
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_REASON_CODE, notify_tflistp, PIN_FLD_REASON_CODE, ebufp); //Reason
	PIN_FLIST_FLD_SET(notify_tflistp, TAB_FLD_EFFECTIVE_DATE, effective_strp, ebufp);
	
	free(effective_strp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification  body flist ", notify_tflistp);
	
	
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification  input Adjustment Info FLIST ", adjustmentinfo_flistp);
		
		adjinfo_flistp = PIN_FLIST_ELEM_ADD(notify_tflistp, PIN_FLD_ADJUSTMENT_INFO, elem_id, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, adjinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, ebufp); 
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, adjinfo_flistp, PIN_FLD_RESOURCE_ID, ebufp); 
		
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification  body adjustment flist ", adjinfo_flistp);
		
		subalelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_GROUP_ID, 1, ebufp);
		
		subbal_flistp = PIN_FLIST_ELEM_GET(adjustmentinfo_flistp, PIN_FLD_SUB_BALANCES, *subalelemid_ip, 1, ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification adjustment info subbalances flist ", subbal_flistp);
		
		if (subbal_flistp != NULL)
		{
			validdate_tmstp = PIN_FLIST_FLD_GET(subbal_flistp,PIN_FLD_VALID_FROM, 1, ebufp);
			if (validdate_tmstp != NULL)
			{
				validdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, validdate_tmstp, ebufp);
				PIN_FLIST_FLD_SET(adjinfo_flistp, PIN_FLD_VALID_FROM_STR, validdate_strp, ebufp);
			}
			
			validdate_tmstp = PIN_FLIST_FLD_GET(subbal_flistp,PIN_FLD_VALID_TO, 1, ebufp);
			if (validdate_tmstp != NULL)
			{
				validdate_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, validdate_tmstp, ebufp);
				PIN_FLIST_FLD_SET(adjinfo_flistp, PIN_FLD_VALID_TO_STR, validdate_strp, ebufp);
			}
			
			if(validdate_strp!=NULL)
                        {
                                free(validdate_strp);
                        }

		}
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" notification final body adjustment flist ", adjinfo_flistp);
	}
	
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_iflistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_oflistp, PIN_FLD_OUT_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_tflistp, TAB_FLD_NOTIFICATION, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_NOTIFICATION input flist ", notify_flistp);
		
	/***************************************
	 * Notification Enrichment Opcode Call
	 ***************************************/
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_NOTIFICATION, 0, notify_flistp, &enrich_notify_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_ncr_balance_prepare_notification:"
			" input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_ncr_balance_prepare_notification:"
			" Error in Notification", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_ncr_balance_prepare_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_ADJUST_NCR_BALANCE_VALIDITY_NOTIFICATION output flist ", enrich_notify_flistp);
	
	r_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
	
	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_notify_adjust_ncr_balance_prepare_notification output flist", *out_flistpp);
		
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_tflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);
	return;
}


int32
fm_tab_subscription_adjncr_get_resourceid_by_name(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			elem_out_id = 0;
	char			*resourcename_in_strp = NULL;
	char			*balresourcename_strp = NULL;
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_adjncr_get_resourceid_by_name:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_adjncr_get_resourceid_by_name:"
			" Error in Notification", ebufp);
		return 0;
	}
			
	resourcename_in_strp  = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_NAME, 1, ebufp);
	
	if (resourcename_in_strp == NULL)
	{
		return 0;
	}
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
			
	{
		balresourcename_strp  = PIN_FLIST_FLD_GET(balances_flistp, PIN_FLD_NAME, 1, ebufp);
		
		if (balresourcename_strp != NULL)
		{			
			if (strcmp(resourcename_in_strp,balresourcename_strp) == 0)
			{
				elem_out_id  = elem_id;
				break;
			}
		}
	
	}
	
	return elem_out_id;
}


int32
fm_tab_subscription_validate_resourceid_config(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			result_ip = 0;
	int32			*inresourceid_ip = NULL;
	char			log_msg[256] = "";
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_validate_resourceid_config:"
			" Error input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_validate_resourceid_config:"
			" Error input", ebufp); 
		return 0;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_validate_resourceid_config:"
			" input flist ", in_flistp);
	
	inresourceid_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
	
	sprintf(log_msg,"fm_tab_subscription_validate_resourceid_config: Resource ID to validate = %d", *inresourceid_ip);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);
	
	if (inresourceid_ip == NULL)
		return 0;
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		if (*inresourceid_ip == elem_id)
		{
			result_ip = 1;
		}
	}
	
	return result_ip;
}


void
fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	int64				db_no,		
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*adjustmentinfo_flistp = NULL;
	pin_flist_t			*resourceinfo_flistp = NULL;
	char				*msisdn_strp = NULL;
	char				*transid_strp = NULL;
	char				*effective_strp = NULL;
	char				*resourcename_strp = NULL;
	int32				*debitelemid_ip = NULL;
	int32				newdebitelemid_ip = 0;
	int32				*adjustmenttype_ip = NULL;
	int32				*validityindays_ip = NULL;
	int32				effectivedate_tmst = 0;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	int32				transidchk = 0;
	int32				*mode_ip = NULL;
	pin_decimal_t		*amtadj_dcmlp = NULL;
	char				log_msg[256] ="";
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in input - Input Flist", in_flistp);
		return;
	}
	
	/***********************************************************
	 *PIN_FLD_MSISDN
	 ***********************************************************/
	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	
	if((msisdn_strp == NULL) || (msisdn_strp && strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_MSISDN", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_MSISDN", in_flistp);
		return;
		
	}
	
	/***********************************************************
	 *PIN_FLD_TRANS_ID
	 ***********************************************************/
	transid_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	
	if((transid_strp == NULL) || (transid_strp && strlen(transid_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID input flist", in_flistp);
		return;
	}
	transidchk  = fm_tab_subscription_adjncr_transid_check(ctxp, in_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DUPLICATE_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID input flist", in_flistp);
		return;
	}
	
	if (transidchk == 1)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DUPLICATE_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_TRANS_ID input flist", in_flistp);
		return;
	}
		
	/**************************************************************************
	 * Check All the fields inside the Adjustment info
	 **************************************************************************/
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check:"
												" Adjustment Info Flist", adjustmentinfo_flistp);
		
		/***********************************************************
		 *PIN_FLD_RESOURCE_ID and PIN_FLD_RESOURCE_NAME
		 ***********************************************************/
		debitelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
		
		if (debitelemid_ip != NULL)
		{
			fm_tab_subscription_adjust_ncr_get_resourcename_by_id(ctxp, adjustmentinfo_flistp, &resourceinfo_flistp,db_no, ebufp);
			
			if (PIN_ERR_IS_ERR(ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
				PIN_FLIST_DESTROY_EX(&resourceinfo_flistp, NULL);
				return;
			}
			
			PIN_FLIST_FLD_COPY(resourceinfo_flistp, PIN_FLD_NAME, adjustmentinfo_flistp,PIN_FLD_RESOURCE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(resourceinfo_flistp, PIN_FLD_SYMBOL, adjustmentinfo_flistp,PIN_FLD_UNIT_STR, ebufp);
			PIN_FLIST_DESTROY_EX(&resourceinfo_flistp, NULL);
		}
		
		resourcename_strp = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_NAME, 1, ebufp);
		
		/***********************************************************
		 *PIN_FLD_RESOURCE_ID and PIN_FLD_RESOURCE_NAME is NULL
		 ***********************************************************/
		if (debitelemid_ip == NULL && resourcename_strp == NULL)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check:"
				" PIN_FLD_RESOURCE ID NULL and PIN_FLD_NAME NULL");
				
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_RESOURCE_ID_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
			return;
		}
		/***********************************************************
		 *PIN_FLD_RESOURCE_ID is NULL and PIN_FLD_NAME is not NULL
		 ***********************************************************/
		else if (debitelemid_ip == NULL && resourcename_strp != NULL)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check:"
				" PIN_FLD_RESOURCE ID NULL and PIN_FLD_NAME NOT NULL");
			
			newdebitelemid_ip = fm_tab_subscription_adjncr_get_resourceid_by_name(ctxp, adjustmentinfo_flistp, ebufp);
			
			if(newdebitelemid_ip == 0)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
				return;
			}
			else
			{
				PIN_FLIST_FLD_SET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, &newdebitelemid_ip, ebufp);
				fm_tab_subscription_adjust_ncr_get_resourcename_by_id(ctxp, adjustmentinfo_flistp, &resourceinfo_flistp,db_no, ebufp);
				
				if (PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
					PIN_FLIST_DESTROY_EX(&resourceinfo_flistp, NULL);
					return;
				}
				
				PIN_FLIST_FLD_COPY(resourceinfo_flistp, PIN_FLD_SYMBOL, adjustmentinfo_flistp,PIN_FLD_UNIT_STR, ebufp);
				PIN_FLIST_DESTROY_EX(&resourceinfo_flistp, NULL);
				
			}
		} 
		/***********************************************************
		 *PIN_FLD_RESOURCE_ID is NOT NULL and PIN_FLD_NAME is NULL
		 ***********************************************************/
		else if (debitelemid_ip != NULL && resourcename_strp == NULL)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check:"
				" PIN_FLD_RESOURCE ID NOT NULL and PIN_FLD_NAME NULL");
			
			if (fm_tab_subscription_validate_resourceid_config(ctxp, adjustmentinfo_flistp, ebufp) == 0)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
				return;
			}			
		}
		else
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, 
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check:"
				" PIN_FLD_RESOURCE ID NOT NULL and PIN_FLD_NAME NOT NULL");
				
			newdebitelemid_ip = fm_tab_subscription_adjncr_get_resourceid_by_name(ctxp, adjustmentinfo_flistp, ebufp);
			
			if (newdebitelemid_ip != *debitelemid_ip)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NAME_ID_NOT_MATCH, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_RESOURCE_ID input flist", in_flistp);
				return;
			}
		}
		
		/*******************************************************************************
		 * Full Re-evaluation if the inputted resource id or resourcename is non-currency
		 ********************************************************************************/
		debitelemid_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
		
		if (debitelemid_ip != NULL)
		{
			if (*debitelemid_ip <=	 PIN_CURRENCY_VAL_MAX)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_CURRENCY_RESOURCE_ID, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: ResourceID is Currency", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: ResourceID is Currency", in_flistp);
				return;
			}
		}
		
		/***********************************************************
		 *PIN_FLD_ADJUSTMENT_TYPE
		 ***********************************************************/
		adjustmenttype_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, 0, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_ADJUSTMENT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in getting Element ID input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in getting Element ID", ebufp);
			return;
		}
		
		if (adjustmenttype_ip == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_ADJUSTMENT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE input flist", in_flistp);
			return;
		}
		
		if (*adjustmenttype_ip < 1 && *adjustmenttype_ip > 3)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_ADJUSTMENT_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE input flist", in_flistp);
			return;
		}
		
		if (*adjustmenttype_ip == 1 || *adjustmenttype_ip == 3)
		{
			amtadj_dcmlp = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, 1, ebufp);
			
			if (pbo_decimal_is_null(amtadj_dcmlp, ebufp) == 1)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing PIN_FLD_ADJUSTMENT_TYPE input flist", in_flistp);
			return;
			}
		}
		if (*adjustmenttype_ip != 1)
		{
		
			if ((effective_strp = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, TAB_FLD_EFFECTIVE_DATE, 1, ebufp)) == NULL)
			{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: PIN_FLD_VALIDITY_IN_DAYS has been provided and for evaluation");
				validityindays_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, 0, ebufp);
				
				if (PIN_ERR_IS_ERR(ebufp))
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_MISSING_EFFECTIVE_VALIDITY_DAYS, 0, 0, 0);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in getting Element ID input flist", in_flistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in getting Element ID", ebufp);
					return;
				}
				
				if (validityindays_ip == NULL)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_MISSING_EFFECTIVE_DATE, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing TAB_FLD_EFFECTIVE_DATE", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Missing TAB_FLD_EFFECTIVE_DATE input flist", in_flistp);
					return;
				}			
			}
			else
			{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: TAB_FLD_EFFECTIVE_DATE has been provided and for evaluation");
				effectivedate_tmst = fm_tab_utils_common_convert_date_to_timestamp(ctxp,effective_strp,ebufp);
				
				if (effectivedate_tmst < 0)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_INVALID_EFFECTIVE_DATE, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
							"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in converting String Date to Timestamp", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
							"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in converting String Date to Timestamp input flist", in_flistp);
					return;
				}
			}
		}
		
		mode_ip = PIN_FLIST_FLD_GET(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, 1, ebufp);
		
		if (mode_ip != NULL)
		{
			sprintf(log_msg, "fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Action Mode Value is %d", *mode_ip);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);
			
			if (*mode_ip < UPDATEENTRY_FLAG || *mode_ip > ADDENTRY_FLAG)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_ACTION_MODE_INVALID, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in converting String Date to Timestamp", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_adjust_ncr_balval_mandatory_fields_check: Error in converting String Date to Timestamp input flist", in_flistp);
				return;
			}
		}
		
	}
	
	return;
}

void
fm_tab_subscription_adjust_ncr_create_event_bill_debit(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*create_in_flistp = NULL;
	pin_flist_t			*create_out_flistp = NULL;
	pin_flist_t			*debitinfo_flistp = NULL;
	pin_flist_t			*createobj_pdp = NULL;
	pin_flist_t			*adjustmentinfo_flistp = NULL;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	int32				opcode_idp = 3;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: Error in input - Input Flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: input flist", in_flistp);
	
	createobj_pdp = PIN_POID_CREATE(db_no, "/tab_event_bill_debit_info", -1, ebufp);
	
	create_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(create_in_flistp, PIN_FLD_POID, createobj_pdp, ebufp);
	PIN_FLIST_FLD_SET(create_in_flistp, PIN_FLD_PARAM_TYPE, &opcode_idp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, create_in_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, create_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXT_INFO_STR, create_in_flistp, PIN_FLD_EXT_INFO_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION, create_in_flistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, create_in_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_REASON_CODE, create_in_flistp, PIN_FLD_REASON_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, create_in_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, create_in_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_LOC_GROUP_CODE, create_in_flistp, TAB_FLD_LOC_GROUP_CODE, ebufp);
	while ((adjustmentinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_ADJUSTMENT_INFO,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		debitinfo_flistp = PIN_FLIST_ELEM_ADD(create_in_flistp, TAB_FLD_DEBIT_INFO,0, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_ACTION_MODE, debitinfo_flistp, PIN_FLD_ACTION_MODE, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, debitinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, debitinfo_flistp, PIN_FLD_AMOUNT, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_ELEMENT_ID, debitinfo_flistp, PIN_FLD_ELEMENT_ID, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_FLAGS, debitinfo_flistp, PIN_FLD_FLAGS, ebufp);	
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_NOTIFY_FLAG, debitinfo_flistp, PIN_FLD_NOTIFY_FLAG, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_RESOURCE_ID, debitinfo_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_RESOURCE_NAME, debitinfo_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_UNIT_STR, debitinfo_flistp, PIN_FLD_UNIT_STR, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_VALIDITY_FLAGS, debitinfo_flistp, PIN_FLD_VALIDITY_FLAGS, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, TAB_FLD_EFFECTIVE_DATE, debitinfo_flistp, TAB_FLD_EFFECTIVE_DATE, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, debitinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);
		PIN_FLIST_FLD_COPY(adjustmentinfo_flistp, PIN_FLD_CURRENT_BAL, debitinfo_flistp, PIN_FLD_CLOSE_BAL, ebufp);
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: create object input flist", create_in_flistp);

	PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, create_in_flistp, &create_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: Create Object Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: Create Object Error in input - Input Flist", create_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_adjust_ncr_create_event_bill_debit: create object input flist", create_out_flistp);
	
	cleanup:
	
	*out_flistpp = NULL;
	
	PIN_FLIST_DESTROY_EX(&create_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&create_out_flistp, ebufp);
	
	return;
}

int32
fm_tab_subscription_adjncr_transid_check(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t 		*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	poid_t				*search_pdp = NULL;
	char				*template_strp = NULL;
	int32				sflags_i = 0;
	int32				elemcnt_i = 0;
	int32				retval_i = 0;
	char				log_msg[256] = "";
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjbalval_transid_check: Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjbalval_transid_check: Error in input - Input Flist", in_flistp);
		retval_i = 0;
		goto cleanup;
	}
	
	search_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &sflags_i, ebufp);
	template_strp =  (void *)"select X from /tab_event_bill_debit_info where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_strp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, args_flistp, PIN_FLD_TRANS_ID, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjbalval_transid_check :"
			" Trans ID search input flist", search_in_flistp);
			
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjbalval_transid_check: Error in Search Trans ID ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjbalval_transid_check: Error in Search Trans ID Input Flist", search_in_flistp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjbalval_transid_check :"
			" Trans ID search output flist", search_out_flistp);
	
	elemcnt_i =  PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp);
	
	sprintf(log_msg, "fm_tab_subscription_adjbalval_transid_check: transid check element count %d", elemcnt_i);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	if (elemcnt_i == 0)
	{ 
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjbalval_transid_check: transid check return 0");
		retval_i = 0;
	} else {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_adjbalval_transid_check: transid check return 1");
		retval_i = 1;
	}
	
	
	cleanup:
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return retval_i;
}

void
fm_tab_subscription_adjust_ncr_get_resourcename_by_id(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			*resourceid_in_ip = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_adjbalval_get_resourcename_by_id:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_adjbalval_get_resourcename_by_id:"
			" Error in Notification", ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_adjbalval_get_resourcename_by_id:"
			" input flist ", in_flistp);
	
	resourceid_in_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
	
	if (resourceid_in_ip == NULL)
	{
		return;
	}
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
			
	{
		if (elem_id == *resourceid_in_ip)
		{
			r_flistp = PIN_FLIST_COPY(balances_flistp, ebufp);
		}
	
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_adjbalval_get_resourcename_by_id:"
			" output flist ", r_flistp);
	
	*out_flistpp = r_flistp;
	return;
}
