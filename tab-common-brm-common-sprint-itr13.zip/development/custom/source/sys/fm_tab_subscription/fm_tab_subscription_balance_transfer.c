
/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 7-MAR-2022   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER  operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "ops/bal.h"
#include "ops/loan.h"
#include "ops/bill.h"
#include "pin_rate.h"
#include "tab_common.h"
#include "tab_utils_common.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_balance_transfer(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
	
void 
fm_tab_subscription_balance_transfer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int64			tgt_db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_balance_transfer_mandatory_fields_check(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_balance_transfer_create_obj(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int64			tgt_db_no,
	pin_errbuf_t		*ebufp);
	
static void
fm_tab_notify_balance_transfer_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_balance_transfer_error_response(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		*tempresult_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);
	
int32
fm_tab_subscription_get_resourceid_by_name(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
int32
fm_tab_subscription_validate_baltransfer_transid(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
int32
fm_tab_subscription_validate_resourceid_check(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_get_bal_transfer_loan_info(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_get_target_loan_info(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_baltransfer_prepare_recover_loan(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_bal_transfer_recurring_renewal(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

extern int32    *cfg_tab_system_currency;
extern pin_flist_t *config_beid_out_flistp;
	
 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER  is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist for the opcode
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * 
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER operation.
 *************************************************************************/
void
op_tab_subscription_balance_transfer(
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t             	*r_flistp = NULL;
	int32                   	tab_order_flag = 0;
	int32                   	error_clear_flag = 1;
	int32                   	cerror_code = 0;
	char				log_msg[512]= "";
    char                            *sourcemsisdn_strp = NULL;
    char                            *targetmsisdn_strp = NULL;
	int64				db_no = 0;
	int64				tgt_db_no = 0;
	poid_t                  	*account_pdp = NULL;
	int32                   	status = PIN_BOOLEAN_TRUE;
	pin_flist_t             	*enrich_iflistp = NULL;
	pin_flist_t             	*servicetarget_out_flistp = NULL;
	pin_flist_t             	*copy_iflistp = NULL;
	pin_flist_t             	*svc_flistp = NULL;
	
	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
	PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
		"op_tab_subscription_balance_transfer error",ebufp);
	return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_balance_transfer opcode error",ebufp);
		return;
	}

	/***********************************************************
	 * Debug: Input Flist
	 ***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer input flist", in_flistp);

	/**********************************************************
	 * Check TAB_FLD_SOURCE_MSISDN
	 ***********************************************************/
	sourcemsisdn_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SOURCE_MSISDN, 0, ebufp);

	if((sourcemsisdn_strp == NULL) || (sourcemsisdn_strp && strlen(sourcemsisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_SOURCE_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer: Error TAB_FLD_SOURCE_MSISDN Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer:"
			"Error TAB_FLD_SOURCE_MSISDN Missing input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
        *ret_flistpp = r_flistp;
		return;
	}

	/**********************************************************
	 * Check TAB_FLD_TARGET_MSISDN
	 ***********************************************************/
	targetmsisdn_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_TARGET_MSISDN, 1, ebufp);
	if((targetmsisdn_strp == NULL) || (targetmsisdn_strp && strlen(targetmsisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_TARGET_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer: Error TAB_FLD_TARGET_MSISDN Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer:"
			"Error TAB_FLD_TARGET_MSISDN Missing input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
        *ret_flistpp = r_flistp;
		return;
	}
	/**********************************************************
	 * Target MSISDN and Source MSISDN is same
	 ***********************************************************/
	if (strcmp(targetmsisdn_strp, sourcemsisdn_strp) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERROR_CODE_INVALID_TRANSFER_TO_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer: Error TAB_FLD_TARGET_MSISDN and TAB_FLD_SOURCE_MSISDN is same", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer:"
			"Error TAB_FLD_TARGET_MSISDN and TAB_FLD_SOURCE_MSISDN is sam input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
        *ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, in_flistp, PIN_FLD_MSISDN, ebufp);

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	r_flistp = PIN_FLIST_CREATE(ebufp);
	
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
        	PIN_ERR_CLEAR_ERR(ebufp);
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
        	*ret_flistpp = r_flistp;
		return;
	}

	copy_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_FLD_COPY(copy_iflistp, TAB_FLD_TARGET_MSISDN, copy_iflistp, PIN_FLD_MSISDN, ebufp);
	tgt_db_no = fm_tab_utils_common_get_db_no(ctxp, copy_iflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting target database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting target database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		PIN_FLIST_DESTROY_EX(&copy_iflistp, NULL);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before:"
			" Error while searching /tab_order object", ebufp);
        
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_BALANCE_TRANSFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, 
			r_flistp, &r_flistp, ebufp);
		
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_BALANCE_TRANSFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_BALANCE_TRANSFER, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		PIN_FLIST_DESTROY_EX(&copy_iflistp, NULL);
        	return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);

	/*********************************************************
	 * Get the Balance Poid for the Target MSISDN
	 *********************************************************/
	svc_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_FLD_DROP(svc_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_MSISDN, svc_flistp, PIN_FLD_MSISDN, ebufp);
	fm_tab_utils_common_get_service_from_msisdn(ctxp, svc_flistp, &servicetarget_out_flistp, tgt_db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			" input flist", svc_flistp);
		goto cleanup;
	}

	if (servicetarget_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_TARGET_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Error Target MSISDN not on DB", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Error Target MSISDN not on DB input flist", in_flistp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		PIN_FLIST_DESTROY_EX(&copy_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&svc_flistp, NULL);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*********************************************************
	 * Debug the Service Information out flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer: "
		"fm_tab_utils_common_get_service_from_msisdn output flist for "
		"Target MSISDN", servicetarget_out_flistp);

	PIN_FLIST_ELEM_SET(in_flistp, servicetarget_out_flistp, PIN_FLD_SERVICES, 1, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		" input flist AFTER ", servicetarget_out_flistp);

	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, TAB_FLD_TARGET_ACCOUNT_OBJ, ebufp);

	/* open transaction */
	if (!fm_tab_utils_common_global_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer:"
				" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
           		status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer:"
				" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_balance_transfer(ctxp, enrich_iflistp, &r_flistp, db_no, tgt_db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_balance_transfer error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer:"
				" fm_tab_sub_extend_prepaid_validity input flist", in_flistp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer:"
				" fm_tab_sub_extend_prepaid_validity output flist", r_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer:"
				"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_balance_transfer: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, 
			r_flistp, &r_flistp, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		PIN_FLIST_DESTROY_EX(&copy_iflistp, NULL);
		PIN_FLIST_DESTROY_EX(&svc_flistp, ebufp);
		PIN_FLIST_DESTROY_EX(&servicetarget_out_flistp, ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	cleanup:

	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER", &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
				" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_balance_transfer:"
				" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_BALANCE_TRANSFER;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		fm_tab_subscription_balance_transfer_error_response(ctxp, in_flistp, 
			r_flistp, &r_flistp, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_BALANCE_TRANSFER )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_BALANCE_TRANSFER, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;

		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;

	PIN_FLIST_DESTROY_EX(&copy_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&svc_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&servicetarget_out_flistp, ebufp);
	//PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_balance_transfer output flist", *ret_flistpp);

	return;
	
}

void 
fm_tab_subscription_balance_transfer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int64			tgt_db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*servicesource_out_flistp = NULL;
	pin_flist_t		*servicetarget_out_flistp = NULL;
	pin_flist_t		*baltransfer_in_flistp = NULL;
	pin_flist_t		*baltansferenrich_out_flistp = NULL;
	pin_flist_t		*baltransfer_out_flistp = NULL;
	pin_flist_t		*serviceinfo_flistp = NULL;
	pin_flist_t		*createobj_out_flistp = NULL;
	pin_flist_t		*serviceenrichsvcval_out_flistp = NULL;
	pin_flist_t		*updateservice_in_flistp = NULL;
	pin_flist_t		*updateservice_out_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;
	pin_flist_t		*transferout_flistp = NULL;
	pin_flist_t		*transferoutresult_flistp = NULL;
	pin_flist_t		*transferoutbalimpacts_flistp = NULL;
	pin_flist_t		*transferinto_flistp = NULL;
	pin_flist_t		*transferintoresult_flistp = NULL;
	pin_flist_t		*transferintobalimpacts_flistp = NULL;
	pin_flist_t		*getnewbalancesrc_in_flistp = NULL;
	pin_flist_t		*getnewbalancesrc_out_flistp = NULL;
	pin_flist_t		*getnewbalancetrgt_in_flistp = NULL;
	pin_flist_t		*getnewbalancetrgt_out_flistp = NULL;
	pin_flist_t		*loaninfo_out_flistp = NULL;
	pin_flist_t		*bal_rec_rnwl_flistp = NULL;
	pin_flist_t		*enrichresult_in_flistp = NULL;
	pin_flist_t		*enrichresult_out_flistp = NULL;
	time_t			baleffective_tmst = 0;
	char			*baleffective_strp = NULL;
	time_t			*servicevalexp_tmstp = NULL;
	char			*servicevalexp_strp = NULL;
	int32			*transferflag_ip= NULL;
	int32			error_code = 0;
	
	/*********************************************************
	 * Insanity Check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_CLEAR_ERR(ebufp);
	
	/*********************************************************
	 * Debug Input Flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
			" input flist", in_flistp);
			
	/*********************************************************
	 * Mandatory Fields Check
	 *********************************************************/
	fm_tab_subscription_balance_transfer_mandatory_fields_check (ctxp, in_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Error found on Mandatory field check");
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_balance_transfer: Error found on Mandatory field check",ebufp);
        return;
	}
	
	/*********************************************************
	 * Validation of Transaction
	 *********************************************************/
	if (fm_tab_subscription_validate_baltransfer_transid(ctxp, in_flistp, db_no, ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_DUPLICATE_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Error Transaction ID is already used");
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_balance_transfer: Error Transaction ID is already used",ebufp);
        return;
	}
	
	/*********************************************************
	 * Get the Balance Poid for the Source MSISDN
	 *********************************************************/
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, in_flistp, PIN_FLD_MSISDN, ebufp);
	fm_tab_utils_common_get_service_from_msisdn(ctxp, in_flistp, &servicesource_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			" input flist", in_flistp);
		goto cleanup;
	} 
	
	/*********************************************************
	 * Debug the Service Information out flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		" fm_tab_utils_common_get_service_from_msisdn output flist for Source MSISDN", servicesource_out_flistp);
			
	serviceinfo_flistp = PIN_FLIST_ELEM_ADD(in_flistp, PIN_FLD_SERVICES, 0, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_ACCOUNT_OBJ, serviceinfo_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_ACCOUNT_OBJ, serviceinfo_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_POID, serviceinfo_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_BAL_GRP_OBJ, serviceinfo_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, serviceinfo_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_LIFECYCLE_STATE, serviceinfo_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 
			serviceinfo_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_STATUS, serviceinfo_flistp, PIN_FLD_STATUS, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_STATUS_FLAGS, serviceinfo_flistp, PIN_FLD_STATUS_FLAGS, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, serviceinfo_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, serviceinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, serviceinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, serviceinfo_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_EFFECTIVE_T, serviceinfo_flistp, PIN_FLD_EFFECTIVE_T, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_LAST_STATUS_T, serviceinfo_flistp, PIN_FLD_LAST_STATUS_T, ebufp);

	/*********************************************************
	 * Get the Balance Poid for the Target MSISDN
	 * Target MSISDN details are already stored in input flist
	 *********************************************************/

	servicetarget_out_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 1,1, ebufp);
	if (servicetarget_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_TARGET_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Error Target MSISDN not on DB", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Error Target MSISDN not on DB input flist", in_flistp);
		goto cleanup;
	}

	/*********************************************************
	 * Debug the Service Information out flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer: "
		"fm_tab_utils_common_get_service_from_msisdn output "
		"flist for Target MSISDN", servicetarget_out_flistp);

	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, servicetarget_out_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, servicetarget_out_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, servicetarget_out_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, servicetarget_out_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, servicetarget_out_flistp, PIN_FLD_PROGRAM_NAME, ebufp);	
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 
			in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);

	/*********************************************************
	 * Update Input Flist with balance group of source and target
	 *********************************************************/
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, PIN_FLD_FROM_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, PIN_FLD_TO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_FROM_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_TO_BAL_GRP_OBJ, ebufp);

        PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, in_flistp, PIN_FLD_MSISDN, ebufp);

	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		" fm_tab_utils_common_get_service_from_msisdn output flist for Target MSISDN", servicetarget_out_flistp);
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, serviceinfo_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, serviceinfo_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, serviceinfo_flistp, PIN_FLD_EXTERNAL_USER, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, serviceinfo_flistp, PIN_FLD_PROGRAM_NAME, ebufp);	
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 
			in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_EFFECTIVE_T, serviceinfo_flistp, PIN_FLD_EFFECTIVE_T, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_LAST_STATUS_T, serviceinfo_flistp, PIN_FLD_LAST_STATUS_T, ebufp);

	/*********************************************************
	 * Update Input Flist with balance group of source and target
	 *********************************************************/
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, PIN_FLD_FROM_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_ACCOUNT_OBJ, in_flistp, PIN_FLD_TO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicesource_out_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_FROM_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(servicetarget_out_flistp, PIN_FLD_BAL_GRP_OBJ, in_flistp, PIN_FLD_TO_BAL_GRP_OBJ, ebufp);
	
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, in_flistp, PIN_FLD_MSISDN, ebufp);	
	
	/*********************************************************
	 * Prepare Initial Balance Transfer FLIST
	 *********************************************************/
	baltransfer_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FROM_BAL_GRP_OBJ, baltransfer_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TO_BAL_GRP_OBJ, baltransfer_in_flistp, PIN_FLD_TRANSFER_TARGET, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, baltransfer_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, baltransfer_in_flistp, PIN_FLD_DESCR, ebufp); 
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, baltransfer_in_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, baltransfer_in_flistp, PIN_FLD_AMOUNT, ebufp);
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FEE_FLAG, baltransfer_in_flistp, PIN_FLD_FEE_FLAG, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PERCENT, baltransfer_in_flistp, PIN_FLD_PERCENT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TRANSFER_FEE, baltransfer_in_flistp, PIN_FLD_CHARGE_AMT, ebufp);
	PIN_FLIST_FLD_SET(baltransfer_in_flistp, PIN_FLD_CHARGE_RESOURCE_ID, cfg_tab_system_currency, ebufp);
	
	/*********************************************************
	 * Prepare Balance Transfer FLIST for Validation and Enrichment
	 *********************************************************/
	PIN_FLIST_SUBSTR_SET(in_flistp, baltransfer_in_flistp, PIN_FLD_IN_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
			"Balance Transfer Validation input flist", in_flistp);
			
	/*********************************************************
	 * Execution of the Validation opcode
	 *********************************************************/
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_VALIDATE_BALANCE_TRANSFER, 0, in_flistp, &baltansferenrich_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Balance Transfer Validation Error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Balance Transfer Validation Error input flist", in_flistp);
		
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(baltansferenrich_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	} 
	
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
			"Balance Transfer Enrichment input flist", in_flistp);
	
	/*********************************************************
	 * Execution of the Enrichment opcode
	 *********************************************************/
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER, 0, in_flistp, &baltansferenrich_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Balance Transfer Enrichment Error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Balance Transfer Enrichment Error input flist", in_flistp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Balance Transfer Enrichment Error output flist", baltansferenrich_out_flistp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(baltansferenrich_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	} 
	
	/*********************************************************
	 * Update the real information of 
	 * transfer from enrichment to input
	 *********************************************************/
	
	if (baltansferenrich_out_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
			"Get fee flag from input flist", baltansferenrich_out_flistp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
			"Set fee flag to input flist", in_flistp);
		
		PIN_FLIST_FLD_COPY(baltansferenrich_out_flistp, PIN_FLD_FEE_FLAG, in_flistp, PIN_FLD_FEE_FLAG, ebufp);
		PIN_FLIST_FLD_COPY(baltansferenrich_out_flistp, PIN_FLD_CHARGE_AMT, in_flistp, TAB_FLD_TRANSFER_FEE, ebufp);
		PIN_FLIST_FLD_COPY(baltansferenrich_out_flistp, PIN_FLD_PERCENT, in_flistp, PIN_FLD_PERCENT, ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
			"Enrichment update input flist", in_flistp);
	}
		
	if (baltansferenrich_out_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		"Balance Transfer Enrichment output flist", baltansferenrich_out_flistp);
		PCM_OP(ctxp, PCM_OP_BAL_TRANSFER_BALANCE, 0, baltansferenrich_out_flistp, &baltransfer_out_flistp, ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		"Balance Transfer Enrichment output flist", baltransfer_in_flistp);
		PCM_OP(ctxp, PCM_OP_BAL_TRANSFER_BALANCE, 0, baltransfer_in_flistp, &baltransfer_out_flistp, ebufp);
	}
	
	/*********************************************************
	 * Balance Transfer Execution Insanity check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Execution of Balance Transfer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Execution of Balance Transfer error input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
		"PCM_OP_BAL_TRANSFER_BALANCE output flist", baltransfer_out_flistp);

	/*********************************************************************
	 * Getting Balance transfer fee and loan information
	 *********************************************************************/
	if (baltransfer_out_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(baltransfer_out_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_EVENT_OBJ, ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer:"
			"get fee flag from input flist", in_flistp);
		transferflag_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_FEE_FLAG, 1, ebufp);
		
		/*********************************************************************
		 * Getting Balance transfer fee 
		 *********************************************************************/
	 
		if (transferflag_ip != NULL)
		{
			if (*transferflag_ip == 1 || *transferflag_ip == 3)
			{
				transferout_flistp = PIN_FLIST_ELEM_GET(baltransfer_out_flistp, PIN_FLD_TRANSFERS_OUT, 
						0, 1, ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer:"
					"Get fee Amount from the TRANSFERS OUT flist", transferout_flistp);
				
				if (transferout_flistp != NULL)
				{
					transferoutresult_flistp = PIN_FLIST_ELEM_GET(transferout_flistp, PIN_FLD_RESULTS, 
							0, 1, ebufp);
					
					if (transferoutresult_flistp != NULL)
					{
						transferoutbalimpacts_flistp  = PIN_FLIST_ELEM_GET(transferoutresult_flistp, 
								PIN_FLD_BAL_IMPACTS, 0, 1, ebufp);
						
						if (transferoutbalimpacts_flistp != NULL)
						{
							PIN_FLIST_FLD_COPY( transferoutbalimpacts_flistp, PIN_FLD_AMOUNT, 
								in_flistp, PIN_FLD_CHARGE_AMT, ebufp);
						}
					}
				}
			} 
			else if (*transferflag_ip == 2)
			{
				transferinto_flistp = PIN_FLIST_ELEM_GET(baltransfer_out_flistp, PIN_FLD_TRANSFERS_INTO, 
						0, 1, ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer:"
					"Get fee Amount from the TRANSFERS INTO flist", transferinto_flistp);
				if (transferinto_flistp != NULL)
				{
					transferintoresult_flistp = PIN_FLIST_ELEM_GET(transferinto_flistp, PIN_FLD_RESULTS, 
							0, 1, ebufp);
					
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer:"
							"Get fee Amount from the RESULTS flist", transferintoresult_flistp);
					
					if (transferintoresult_flistp != NULL)
					{
						transferintobalimpacts_flistp  = PIN_FLIST_ELEM_GET(transferintoresult_flistp, 
								PIN_FLD_BAL_IMPACTS, 0, 1, ebufp);
						
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer:"
							"Get fee Amount from the BALANCEIMPACT flist", transferintobalimpacts_flistp);
						
						if (transferintobalimpacts_flistp != NULL)
						{
							PIN_FLIST_FLD_COPY( transferintobalimpacts_flistp, PIN_FLD_AMOUNT, 
									in_flistp, PIN_FLD_CHARGE_AMT, ebufp);
						}
					}
				}
			}
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
				"input flist after getting transfer fee", in_flistp);
		
		/*********************************************************************
		 * Getting Loan Information
		 *********************************************************************/
		
		if (transferflag_ip != 0)
		{
			serviceinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 1, 1, ebufp);
			
			if (serviceinfo_flistp != NULL)
			{
				PIN_FLIST_FLD_COPY(baltransfer_out_flistp, PIN_FLD_POID, serviceinfo_flistp, 
						PIN_FLD_EVENT_OBJ, ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
					"get the loan information from input flist", serviceinfo_flistp);
				
				fm_tab_subscription_get_bal_transfer_loan_info(ctxp, serviceinfo_flistp, 
						&loaninfo_out_flistp, tgt_db_no, ebufp);
				
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
						"Execution of Balance Transfer error", ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
						"Execution of Balance Transfer error input flist", in_flistp);
					goto cleanup;
				}
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
					"Loan information output flist", loaninfo_out_flistp);
				
				if (loaninfo_out_flistp != NULL)
				{
					PIN_FLIST_FLD_COPY(loaninfo_out_flistp, PIN_FLD_OUTSTANDING_AMOUNT, 
							in_flistp, PIN_FLD_OUTSTANDING_AMOUNT, ebufp);
					PIN_FLIST_FLD_COPY(loaninfo_out_flistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, 
							in_flistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, ebufp);
					PIN_FLIST_FLD_COPY(loaninfo_out_flistp, PIN_FLD_OUTSTANDING_AMOUNT, 
							in_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, ebufp);
					PIN_FLIST_FLD_COPY(loaninfo_out_flistp, PIN_FLD_AMOUNT, 
							in_flistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, ebufp);
					
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
							"Afer Loan information input flist", in_flistp);
				}
			}
		}
	}
	
	/************************************************************
	 *Get required information of the execution of Balance Transfer
	 ************************************************************/
	baleffective_tmst = pin_virtual_time(NULL);
	baleffective_strp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, &baleffective_tmst,ebufp);
	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EFFECTIVE_DATE, baleffective_strp, ebufp);
	free(baleffective_strp);
	
	/*********************************************************
	 * Prepare input flist and call OOB opcode
	 * PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
	 *******************************************************/
	fm_tab_subscription_bal_transfer_recurring_renewal(ctxp, in_flistp, tgt_db_no, &bal_rec_rnwl_flistp, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_subscription_bal_transfer_recurring_renewal input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_subscription_bal_transfer_recurring_renewal error", ebufp);
	
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(bal_rec_rnwl_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	/*********************************************************
	 * Debug Updated Input flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		"Balance Transfer Enrichment output flist", in_flistp)
	
	/*********************************************************
	 * Execute Enrichment for Service Validity
	 *********************************************************/
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER_SVC_VALIDITY, 0, 
			in_flistp, &serviceenrichsvcval_out_flistp, ebufp);
	
	/*********************************************************
	 * Insanity Check after Enrich Balance Transfer Service Validity
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Enrichment for Service Validity error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Enrichment for Service Validity error input flist", in_flistp);
		
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(serviceenrichsvcval_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	/*********************************************************
	 * Debug Updated Input flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		"Enrichment for Service Validity output flist", serviceenrichsvcval_out_flistp);
	
	/*********************************************************
	 * Create Object /tab_event_balance_transfer Execution Insanity check
	 *********************************************************/
	if (serviceenrichsvcval_out_flistp != NULL)
	{
		serviceinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 1, 1, ebufp);
		
		updateservice_in_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(serviceenrichsvcval_out_flistp, PIN_FLD_POID, updateservice_in_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, updateservice_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(serviceinfo_flistp, PIN_FLD_ACCOUNT_OBJ, updateservice_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(serviceinfo_flistp, PIN_FLD_POID, updateservice_in_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(serviceenrichsvcval_out_flistp, PIN_FLD_LIFECYCLE_STATE, 
				updateservice_in_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
		PIN_FLIST_FLD_COPY(serviceenrichsvcval_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 
				updateservice_in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, updateservice_in_flistp, PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, updateservice_in_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
		
		
		/*********************************************************
		 * Update the inputflist with the enrich PIN_FLD_SERVICE_STATE_EXPIRATION_T
		 *********************************************************/
		PIN_FLIST_FLD_COPY(serviceenrichsvcval_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 
				in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
		
		/*********************************************************
		 * Debug Update Service Input Flist
		 *********************************************************/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
			"Update Service Function Input Flist", updateservice_in_flistp);
			
		/*********************************************************
		 * Execute Update Service Function
		 *********************************************************/
		fm_tab_utils_common_resume_service(ctxp, updateservice_in_flistp, &updateservice_out_flistp, tgt_db_no, ebufp);
		
		/*********************************************************
		 * Update Service Function Insanity Check
		 *********************************************************/
		if (PIN_ERR_IS_ERR(ebufp)) 
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
				"Update Service Function error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
				"Update Service Function error input flist", updateservice_in_flistp);
			goto cleanup;
		}
		
		/*********************************************************
		 *Debug the output of Update Service function
		 *********************************************************/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
			"Update Service Function output Flist", updateservice_out_flistp);
	}


	
	servicevalexp_tmstp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
	
	if (servicevalexp_tmstp != NULL)
	{
		servicevalexp_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp, servicevalexp_tmstp,ebufp);
		PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_SVC_VALIDITY_DATE, servicevalexp_strp, ebufp);
		free(servicevalexp_strp);
	}
	
	/*********************************************************
	 * Get the Service Information to start getting balances SOURCE
	 *********************************************************/
	serviceinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 0, 1, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer :"
		" Read Balance group of the Source", serviceinfo_flistp);
		
	getnewbalancesrc_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(serviceinfo_flistp, PIN_FLD_BAL_GRP_OBJ, getnewbalancesrc_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, getnewbalancesrc_in_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		
	fm_tab_utils_common_subscr_get_current_main_balance(ctxp, getnewbalancesrc_in_flistp, 
			&getnewbalancesrc_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			" Error getting target account current balance", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			" Error getting target account current balance input flist", getnewbalancesrc_in_flistp);
		goto cleanup;
	}
	

	PIN_FLIST_FLD_COPY(getnewbalancesrc_out_flistp, PIN_FLD_CURRENT_BAL, in_flistp, TAB_FLD_SOURCE_BALANCE, ebufp);

	/*********************************************************
	 * Getting the resource id and its current balance TARGET
	 *********************************************************/
	serviceinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 1, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, serviceinfo_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer :"
		" Read Balance group of the Target", serviceinfo_flistp);
		
	getnewbalancetrgt_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(serviceinfo_flistp, PIN_FLD_BAL_GRP_OBJ, getnewbalancetrgt_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, getnewbalancetrgt_in_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		
	fm_tab_utils_common_subscr_get_current_main_balance(ctxp, getnewbalancetrgt_in_flistp, 
			&getnewbalancetrgt_out_flistp, tgt_db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			" Error getting target account current balance", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			" Error getting target account current balance input flist", getnewbalancetrgt_in_flistp);
		goto cleanup;
	}
	
	PIN_FLIST_FLD_COPY(getnewbalancetrgt_out_flistp, PIN_FLD_CURRENT_BAL, in_flistp, TAB_FLD_TARGET_BALANCE, ebufp);

	/*********************************************************
	 * Get the Service Information to start getting balances TARGET
	 *********************************************************/
	serviceinfo_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_SERVICES, 0, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, serviceinfo_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	
	
	/************************************************************
	 * Record the transaction on /tab_event_balance_transfer  
	 ************************************************************/
	fm_tab_subscription_balance_transfer_create_obj(ctxp, in_flistp, &createobj_out_flistp, db_no, tgt_db_no, ebufp);
	
	/*********************************************************
	 * Create Object /tab_event_balance_transfer Execution Insanity check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer: "
			"Execution of Balance Transfer error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Execution of Balance Transfer error input flist", in_flistp);
		goto cleanup;
	}

	/*********************************************************
	 * Debug Create Object output flist
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		"Create Object output flist", createobj_out_flistp);
	
	/***********************************************************
	 *Prepare output
	 ***********************************************************/
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, *out_flistpp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, *out_flistpp, TAB_FLD_SOURCE_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_MSISDN, *out_flistpp, TAB_FLD_TARGET_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, *out_flistpp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SVC_VALIDITY_DATE, *out_flistpp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, *out_flistpp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_BALANCE, *out_flistpp, TAB_FLD_SOURCE_BALANCE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_BALANCE, *out_flistpp, TAB_FLD_TARGET_BALANCE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, *out_flistpp, TAB_FLD_TRANSFER_FEE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, *out_flistpp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, *out_flistpp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	
	/***********************************************************
	 *Prepare output
	 ***********************************************************/
	enrichresult_in_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichresult_in_flistp, *out_flistpp, PIN_FLD_OUT_FLIST, ebufp);

	if (baltransfer_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(enrichresult_in_flistp, baltransfer_out_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_balance_transfer: Enrich Results input flistp", enrichresult_in_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_BALANCE_TRANSFER_RESULTS , 0, enrichresult_in_flistp, 
			&enrichresult_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_balance_transfer: "
			"Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_balance_transfer:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer: "
		"Enrich Results output flistp", enrichresult_out_flistp);
	
	if (enrichresult_out_flistp != NULL)
	{
		*out_flistpp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		
	}
	ret_flistp = PIN_FLIST_COPY(*out_flistpp, ebufp);
	
	/***********************************************************
	 *PREPARE NOTIFICAION
	 ***********************************************************/
	
	if (baltransfer_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, baltransfer_out_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	}

	if (updateservice_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, updateservice_out_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}

	if (bal_rec_rnwl_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, bal_rec_rnwl_flistp, PIN_FLD_RESULTS_DATA, 2, ebufp);
	}

	if (loaninfo_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, loaninfo_out_flistp, PIN_FLD_RESULTS_DATA, 3, ebufp);
	}

	PIN_FLIST_SUBSTR_SET(in_flistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
		"Prepared Notification Enrichment Input FLIST ", in_flistp);

	/***********************************************************
	 *Execute Notification Preparation FLIST
	 ***********************************************************/
	fm_tab_notify_balance_transfer_prepare_notification(ctxp, in_flistp, db_no, &notify_out_flistp, ebufp);
	
	/*********************************************************
	 *Prepare Notification Function Insanity Check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:Prepare Notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer:"
			"Prepare Notification error error input flist", notify_out_flistp);
			
		*out_flistpp = notify_out_flistp;
		goto cleanup;
	}
	
	if(notify_out_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_out_flistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_out_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
					*out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_out_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

	/***********************************************************
	 * Cleanup
	 ***********************************************************/
	cleanup:
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer:"
		" output flist", *out_flistpp);
	
	PIN_FLIST_DESTROY_EX(&servicesource_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&servicetarget_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&baltransfer_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&baltansferenrich_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&baltransfer_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&createobj_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&serviceenrichsvcval_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&updateservice_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&updateservice_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&notify_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbalancesrc_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbalancesrc_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbalancetrgt_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbalancetrgt_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&bal_rec_rnwl_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_out_flistp, ebufp);
	return; 	
}

void
fm_tab_subscription_balance_transfer_create_obj(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int64			tgt_db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*read_in_flistp = NULL;
	pin_flist_t		*read_out_flistp = NULL;
	pin_flist_t		*createobj_in_flistp = NULL;
	pin_flist_t		*createobj_out_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*createobj_pdp = NULL;
	
	/*********************************************************
	 * Insanity Check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
		" input flist", in_flistp);
	
	read_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, read_in_flistp, PIN_FLD_POID, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
		"Read Event Object input flist", read_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, read_in_flistp, &read_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj: "
			"read event object error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj:"
			"read event object error input flist", in_flistp);
		goto cleanup;
	}
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_create_obj: Input FList", in_flistp);
	
	createobj_pdp = PIN_POID_CREATE(db_no, "/tab_event_balance_transfer", -1, ebufp);
	createobj_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(createobj_in_flistp, PIN_FLD_POID, createobj_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, createobj_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_ACCOUNT_OBJ, createobj_in_flistp, TAB_FLD_TARGET_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, createobj_in_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, createobj_in_flistp, TAB_FLD_SOURCE_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_MSISDN, createobj_in_flistp, TAB_FLD_TARGET_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, createobj_in_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, createobj_in_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_NAME, createobj_in_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, createobj_in_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FEE_FLAG, createobj_in_flistp, PIN_FLD_FEE_FLAG, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, createobj_in_flistp, TAB_FLD_TRANSFER_FEE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PERCENT, createobj_in_flistp, PIN_FLD_PERCENT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EFFECTIVE_DATE, createobj_in_flistp, TAB_FLD_EFFECTIVE_DATE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, createobj_in_flistp, PIN_FLD_CHANNEL, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_BALANCE, createobj_in_flistp, TAB_FLD_SOURCE_BALANCE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_BALANCE, createobj_in_flistp, TAB_FLD_TARGET_BALANCE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SVC_VALIDITY_DATE, createobj_in_flistp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, createobj_in_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, createobj_in_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, createobj_in_flistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, ebufp);
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
			" /tab_event_balance_transfer object input flist", createobj_in_flistp);
	
	PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, createobj_in_flistp, &createobj_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj: "
			"Error Creating the /tab_event_balance_transfer object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_create_obj:"
			" Error Creating the /tab_event_balance_transfer object input flist", createobj_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
			" /tab_event_balance_transfer object output flist", createobj_out_flistp);
	
	r_flistp = PIN_FLIST_COPY(createobj_out_flistp, ebufp);

	if (db_no != tgt_db_no)
	{
		// Create Custom object record in target
		// Schema also if it is multi-schema transfer
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_balance_transfer_create_obj: "
				"Creating Custom Object in Target Schema");
		PIN_FLIST_FLD_DROP(createobj_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_DROP(createobj_in_flistp, PIN_FLD_POID, ebufp);

                createobj_pdp = PIN_POID_CREATE(tgt_db_no, "/tab_event_balance_transfer", -1, ebufp);
                PIN_FLIST_FLD_PUT(createobj_in_flistp, PIN_FLD_POID, createobj_pdp, ebufp);
                PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TO_OBJ, createobj_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
                                " /tab_event_balance_transfer object input flist"
                                " in Target Schema ", createobj_in_flistp);

                PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, createobj_in_flistp, &createobj_out_flistp, ebufp);

                if (PIN_ERR_IS_ERR(ebufp))
                {
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_subscription_balance_transfer_create_obj: Error "
                                "Creating the /tab_event_balance_transfer object in Target Schema", ebufp);
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                                "fm_tab_subscription_balance_transfer_create_obj: Error "
                                "Creating the /tab_event_balance_transfer object in "
                                "Target Schema input flist", createobj_in_flistp);
                        goto cleanup;
                }
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_create_obj:"
                                " /tab_event_balance_transfer object output flist", createobj_out_flistp);

        }

	cleanup:
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&read_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&createobj_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&createobj_out_flistp, ebufp);
	
	return;
	
}

void
fm_tab_subscription_balance_transfer_mandatory_fields_check(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_errbuf_t		*ebufp)
{
	char			*sourcemsisdn_strp = NULL;
	char			*targetmsisdn_strp = NULL;
	char			*transid_strp = NULL;
	int32			*transferflag_ip = NULL;
	int32			*resourceid_ip = NULL;
	int32			resourceid_i = 0;
	int32			resourceidchk_i = 0;
	char			*resourcename_strp = NULL;
	char			log_msg[256]="";
	pin_decimal_t		*transferamt_dcmlp = NULL;
	pin_decimal_t		*zeroamt_dcmlp = NULL;
	
	
	/*********************************************************
	 * Insanity Check
	 *********************************************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			" input flist", in_flistp);
	
	/**********************************************************
	 * PIN_FLD_TRANS_ID
	 ***********************************************************/
	transid_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	
	if((transid_strp == NULL) || (transid_strp && strlen(transid_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_TRANS_ID Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error PIN_FLD_TRANS_ID Missing input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" PIN_FLD_TRANS_ID Success validation");
	
	/**********************************************************
	 * TAB_FLD_SOURCE_MSISDN
	 ***********************************************************/
	sourcemsisdn_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SOURCE_MSISDN, 0, ebufp);
	
	if((sourcemsisdn_strp == NULL) || (sourcemsisdn_strp && strlen(sourcemsisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_SOURCE_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error TAB_FLD_SOURCE_MSISDN Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error TAB_FLD_SOURCE_MSISDN Missing input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" TAB_FLD_SOURCE_MSISDN Success validation");
	
	
	/**********************************************************
	 * TAB_FLD_TARGET_MSISDN
	 ***********************************************************/
	targetmsisdn_strp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_TARGET_MSISDN, 1, ebufp);
	
	if((targetmsisdn_strp == NULL) || (targetmsisdn_strp && strlen(targetmsisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_TARGET_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error TAB_FLD_TARGET_MSISDN Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error TAB_FLD_TARGET_MSISDN Missing input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" TAB_FLD_TARGET_MSISDN Success validation");
	
	/**********************************************************
	 * Target MSISDN and Source MSISDN is same
	 ***********************************************************/
	if (strcmp(targetmsisdn_strp, sourcemsisdn_strp) == 0) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERROR_CODE_INVALID_TRANSFER_TO_MSISDN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error TAB_FLD_TARGET_MSISDN and TAB_FLD_SOURCE_MSISDN is same", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error TAB_FLD_TARGET_MSISDN and TAB_FLD_SOURCE_MSISDN is sam input flist", in_flistp);
		return;
	}
	
	/**********************************************************
	 * PIN_FLD_AMOUNT
	 **********************************************************/
	transferamt_dcmlp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 1, ebufp);
	
	if (pbo_decimal_is_null(transferamt_dcmlp, ebufp)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_AMOUNT Missing input flist", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error PIN_FLD_AMOUNT Missing input flist", in_flistp);
		return;
	}
	
	zeroamt_dcmlp = pbo_decimal_from_str("0.00",ebufp);
	
	if (pbo_decimal_compare(transferamt_dcmlp, zeroamt_dcmlp, ebufp) <= 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_AMOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_FEE_FLAG Missing", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error Invalid PIN_FLD_AMOUNT input flist", in_flistp);
		return;
	}
	
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" PIN_FLD_AMOUNT Success validation");
		
	/**********************************************************
	 * Target MSISDN and Source MSISDN is same
	 **********************************************************/
	transferflag_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_FEE_FLAG, 1, ebufp);
	
	if (transferflag_ip == NULL) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_FEE_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error TAB_FLD_SOURCE_MSISDN and TAB_FLD_TARGET_MSISDN is the same", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error TAB_FLD_SOURCE_MSISDN and TAB_FLD_TARGET_MSISDN is the same input flist", in_flistp);
		return;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" PIN_FLD_FEE_FLAG  Exist Success validation");
		
	sprintf(log_msg, "fm_tab_subscription_balance_transfer_mandatory_fields_check: PIN_FLD_FEE_FLAG value is %d", *transferflag_ip);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	/**********************************************************
	 * FLAG is not 1 2 or 3
	 **********************************************************/
	if (*transferflag_ip < 0 || *transferflag_ip > 3)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_FEE_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_FEE_FLAG Invalid", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
			"Error PIN_FLD_FEE_FLAG Invalid input flist", in_flistp);
		return;
	}
	
	resourceid_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
	resourcename_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_NAME, 1, ebufp);
	
	if (resourceid_ip == NULL)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" PIN_FLD_RESOURCE_ID is NULL");
		
		if (resourcename_strp == NULL)
		{
			PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency, ebufp);
			
			resourceidchk_i = fm_tab_subscription_validate_resourceid_check(ctxp, in_flistp, ebufp);
			
			if (PIN_ERR_IS_ERR(ebufp))
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_RESOURCE_ID Missing", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
						"Error PIN_FLD_RESOURCE_ID Missing input flist", in_flistp);
				return;
			}
			
			if (resourceidchk_i == 0)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_RESOURCE_ID Missing", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
						"Error PIN_FLD_RESOURCE_ID Missing input flist", in_flistp);
				return;
			}
		}
		else
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
				"Getting the new value of PIN_FLD_RESOURCE_ID from PIN_FLD_RESOURCE_NAME");
				
			resourceid_i = fm_tab_subscription_get_resourceid_by_name(ctxp, in_flistp, ebufp);
			
			if (resourceid_i == 0)
			{
				pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_RESOURCE_DOES_NOT_EXIST, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_RESOURCE_ID Not in Record", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
						"Error PIN_FLD_RESOURCE_ID Not in Record input flist", in_flistp);
				return;
			}
			
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
				"Setting value PIN_FLD_RESOURCE_ID");
				
			PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_RESOURCE_ID, &resourceid_i, ebufp);
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_mandatory_fields_check:"
		" PIN_FLD_RESOURCE_ID has a value");
		
		resourceidchk_i = fm_tab_subscription_validate_resourceid_check(ctxp, in_flistp, ebufp);
		
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_RESOURCE_ID Missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
					"Error PIN_FLD_RESOURCE_ID Missing input flist", in_flistp);
			return;
		}
		
		if (resourceidchk_i == 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RESOURCE_NOT_IN_RECORD, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check: Error PIN_FLD_RESOURCE_ID Missing", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_balance_transfer_mandatory_fields_check:"
					"Error PIN_FLD_RESOURCE_ID Missing input flist", in_flistp);
			return;
		}
	}

	if(zeroamt_dcmlp)
	{
		pbo_decimal_destroy(&zeroamt_dcmlp);
	}

	return;
	
}


static void
fm_tab_notify_balance_transfer_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	int64				db_no,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*notify_tflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	int32			error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_notify_balance_transfer_prepare_notification function entry error", ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_balance_transfer_prepare_notification: "
			"input flist", in_flistp);
	
	notify_flistp =PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_POID, ebufp); 
	
	/***************************************
	 * PIN_FLD_OUT_FLIST Preparation
	 ***************************************/
	notify_oflistp =  PIN_FLIST_SUBSTR_GET(in_flistp,PIN_FLD_OUT_FLIST,1,ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_balance_transfer_prepare_notification:"
			" notification  in flist ", notify_oflistp);
	
	/***************************************
	 * PIN_FLD_IN_FLIST Preparation
	 ***************************************/
	notify_iflistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_DROP (notify_iflistp, PIN_FLD_OUT_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_balance_transfer_prepare_notification:"
			" notification  in flist ", notify_iflistp);
	
	notify_tflistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, "/event/notification/custom/balancetransfer", -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_tflistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, notify_tflistp, PIN_FLD_TRANS_ID, ebufp); //TRANSACTIONID
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, notify_tflistp, TAB_FLD_SOURCE_MSISDN, ebufp); //TRANSFERORMSISDN
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_MSISDN, notify_tflistp, TAB_FLD_TARGET_MSISDN, ebufp); //TRANSFEREERMSISDN
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, notify_tflistp, PIN_FLD_RESOURCE_ID, ebufp); //RESOURCEID
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_NAME, notify_tflistp, PIN_FLD_RESOURCE_NAME, ebufp); //RESOURCENAME
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, notify_tflistp, PIN_FLD_AMOUNT, ebufp); //TRANSFERAMOUNT
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_BALANCE, notify_tflistp, TAB_FLD_SOURCE_BALANCE, ebufp); //TRANSFERORBALANCE
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_BALANCE, notify_tflistp, TAB_FLD_TARGET_BALANCE, ebufp); //TRANSFEREEBALANCE
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FEE_FLAG, notify_tflistp, PIN_FLD_FEE_FLAG, ebufp); //TRANSFERFEEFLAG
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PERCENT, notify_tflistp, PIN_FLD_PERCENT, ebufp); //TRANSFERFEEPERCENT
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, notify_tflistp, TAB_FLD_TRANSFER_FEE, ebufp); //TRANSFERFEE
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EFFECTIVE_DATE, notify_tflistp, TAB_FLD_EFFECTIVE_DATE, ebufp); //TRANSACTIONDATETIME
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, notify_tflistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp); //EXPIRYDATE
	
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_iflistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_oflistp, PIN_FLD_OUT_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_tflistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_balance_transfer_prepare_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_BALANCE_TRANSFER_NOTIFICATION input flist ", notify_flistp);
		
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_BALANCE_TRANSFER_NOTIFICATION, 0, notify_flistp, &enrich_notify_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_balance_transfer_prepare_notification:"
				" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_balance_transfer_prepare_notification:"
				" Error in Notification", ebufp);
				
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		r_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_balance_transfer_prepare_notification:"
			" TAB_OP_NOTIFY_POL_ENRICH_BALANCE_TRANSFER_NOTIFICATION output flist ", enrich_notify_flistp);
	
	r_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
	
	cleanup:
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_tflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_notify_balance_transfer_prepare_notification output flist", *out_flistpp);
	return;
}


static void
fm_tab_subscription_balance_transfer_error_response(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			*tempresult_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*r_flistp = NULL;
	pin_errbuf_t            local_ebuf = {0} ;
	pin_errbuf_t            *local_ebufp = &local_ebuf;
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_error_response :"
			"Input Flist", in_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_balance_transfer_error_response :"
			"Temporary Flist", tempresult_flistp);
	
	r_flistp = PIN_FLIST_CREATE(local_ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, local_ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, r_flistp, PIN_FLD_TRANS_ID, local_ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SOURCE_MSISDN, r_flistp, TAB_FLD_SOURCE_MSISDN, local_ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_TARGET_MSISDN, r_flistp, TAB_FLD_TARGET_MSISDN, local_ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, r_flistp, PIN_FLD_AMOUNT, local_ebufp);
	PIN_FLIST_FLD_COPY(tempresult_flistp, TAB_FLD_REQUEST_STATUS, r_flistp, TAB_FLD_REQUEST_STATUS, local_ebufp);
	PIN_FLIST_FLD_COPY(tempresult_flistp, PIN_FLD_ERROR_CODE, r_flistp, PIN_FLD_ERROR_CODE, local_ebufp);
	PIN_FLIST_FLD_COPY(tempresult_flistp, PIN_FLD_ERROR_DESCR, r_flistp, PIN_FLD_ERROR_DESCR, local_ebufp);
	
	*out_flistpp = r_flistp;
	return;
}


int32
fm_tab_subscription_validate_baltransfer_transid(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	int64				db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	poid_t				*search_pdp = NULL;
	int32				s_flags = 256;
	int32				retval_i = 0;
	char				*template_str = NULL;
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_validate_baltransfer_transid:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_validate_baltransfer_transid:"
			" Error entry at fm_tab_subscription_validate_baltransfer_transid", ebufp);
		retval_i = 0;
		goto cleanup;
	}
	
	search_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /tab_event_balance_transfer where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, args_flistp, PIN_FLD_TRANS_ID, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, 0, ebufp);
	
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_CLEAR_ERR(ebufp);
		retval_i = 0;
		goto cleanup;
	}
	
	if (PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp) <= 0) 
	{		
		retval_i = 0;
		goto cleanup;
	}
	
	retval_i = 1;
	
	cleanup:
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);	
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);	
	return retval_i;
}


int32
fm_tab_subscription_get_resourceid_by_name(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			elem_out_id = 0;
	char			*resourcename_in_strp = NULL;
	char			*balresourcename_strp = NULL;
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_resourceid_by_name:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_resourceid_by_name:"
			" Error in Notification", ebufp);
		return 0;
	}
			
	resourcename_in_strp  = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_NAME, 1, ebufp);
	
	if (resourcename_in_strp == NULL)
	{
		return 0;
	}
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
			
	{
		balresourcename_strp  = PIN_FLIST_FLD_GET(balances_flistp, PIN_FLD_NAME, 1, ebufp);
		
		if (balresourcename_strp != NULL)
		{			
			if (strcmp(resourcename_in_strp,balresourcename_strp) == 0)
			{
				elem_out_id  = elem_id;
				break;
			}
		}
	
	}
	
	return elem_out_id;
}


int32
fm_tab_subscription_validate_resourceid_check(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			result_ip = 0;
	int32			*inresourceid_ip = NULL;
	char			log_msg[256] = "";
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_validate_resourceid_check:"
			" Error input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_validate_resourceid_check:"
			" Error input", ebufp); 
		return 0;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_validate_resourceid_check:"
			" input flist ", in_flistp);
	
	inresourceid_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
	
	sprintf(log_msg,"fm_tab_subscription_validate_resourceid_check: Resource ID to validate = %d", *inresourceid_ip);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);
	
	if (inresourceid_ip == NULL)
		return 0;
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		if (*inresourceid_ip == elem_id)
		{
			result_ip = 1;
		}
	}
	
	return result_ip;
}

void
fm_tab_subscription_get_bal_transfer_loan_info(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*loaninfo_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*search_pdp = NULL;
	poid_t				*event_pdp = NULL;
	poid_t				*eventblldbt_pdp = NULL;
	int32				s_flags = 0;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	void				*template_str = NULL;

	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_bal_transfer_loan_info:"
				"Error input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_bal_transfer_loan_info:"
				" Error in input of getting balance transfer fee", ebufp);
		goto cleanup;
	}
	
	/*********************************************
	 * BILL DEBIT SEARCH LIST
	 *********************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_bal_transfer_loan_info:"
				" input flist ", in_flistp);
	
	search_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	event_pdp =  PIN_POID_CREATE(db_no, "/event/billing/debit", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /event where  F1.TYPE = V1 and F2 = V2 and F3 = V3 and F4 = V4";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, event_pdp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, args_flistp, PIN_FLD_LINK_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 4, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, args_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POID, NULL, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_ACCOUNT_OBJ, NULL, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_bal_transfer_loan_info:"
				"Search of Debit Event for Balance Transfer input flist ", search_in_flistp);
				
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_bal_transfer_loan_info: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bal_transfer_loan_info:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_bal_transfer_loan_info:"
				"Search of Debit Event for Balance Transfer input flist ", search_out_flistp);
				
	
	
	while ((result_flistp = PIN_FLIST_ELEM_GET_NEXT(search_out_flistp, PIN_FLD_RESULTS,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL && loaninfo_flistp == NULL)
	{
		fm_tab_subscription_get_target_loan_info(ctxp, result_flistp, &loaninfo_flistp, db_no, ebufp);
	}
	
	r_flistp = PIN_FLIST_COPY(loaninfo_flistp, ebufp);
	
	cleanup:
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_bal_transfer_loan_info:"
				" output flist ", r_flistp);
	
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	
	return;
}


void
fm_tab_subscription_get_target_loan_info(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t 		*r_flistp = NULL;
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t			*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*loaninfo_flistp = NULL;
	poid_t				*search_pdp = NULL;
	poid_t				*event_pdp = NULL;
	int32				s_flags = 0;
	void				*template_str = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_target_loan_info:"
				"Error input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_get_target_loan_info:"
				" Error in input of getting balance transfer fee", ebufp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_target_loan_info:"
				" input flist ", in_flistp);
	
	search_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	event_pdp =  PIN_POID_CREATE(db_no, "/event/billing/loan_recovery", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, (void *)search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_str =  (void *)"select X from /event where  F1 = V1 and F2 = V2 and F3.type = V3";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_str, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, args_flistp, PIN_FLD_LINK_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, event_pdp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_target_loan_info:"
				"Search of Loan Info for Balance Transfer input flist ", search_in_flistp);
				
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_target_loan_info: Error in getting tab_order object", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_target_loan_info:"
			" input flist", search_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_target_loan_info:"
				"Search of loan info for Balance Transfer output flist ", search_out_flistp);
	
	result_flistp = PIN_FLIST_ELEM_GET(search_out_flistp, PIN_FLD_RESULTS, 0, 1, ebufp);
	
	if (result_flistp != NULL)
	{
		loaninfo_flistp = PIN_FLIST_SUBSTR_GET(result_flistp, PIN_FLD_LOAN_INFO, 1, ebufp);
	}
	r_flistp = PIN_FLIST_COPY(loaninfo_flistp, ebufp);
	if (r_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	}
	
	cleanup: 
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_get_target_loan_info:"
				" output flist ", r_flistp);
				
	*out_flistpp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, NULL);
	return;
}

/*************************************************************
 *  This function will prepare the input flist for
 *  PCM_OP_SUBSCRIPTION_CYCLE_FORWARD and pass it to the
 *  Policy Opcode TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL
 *  Based on the return flist from
 *  TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL, the opcode
 *  PCM_OP_SUBSCRIPTION_CYCLE_FORWARD will be called
 *************************************************************/

static void
fm_tab_subscription_bal_transfer_recurring_renewal(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*recurring_cycle_fwd_flistp = NULL;
	pin_flist_t		*cycle_fwd_flistp = NULL;
	pin_flist_t		*out_cycle_fwd_flistp = NULL;
	pin_flist_t		*ret_cycle_fwd_flistp = NULL;
	int32			cycle_fwd_flg = PIN_RATE_FLG_PRO_NORMAL;
	int32			error_code = 0;
	time_t			now_t = pin_virtual_time(NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_bal_transfer_recurring_renewal function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_bal_transfer_recurring_renewal: "
					"input flist", i_flistp);

	/*********************************************************
	 * Prepare input flist for PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
	 *******************************************************/
	recurring_cycle_fwd_flistp = PIN_FLIST_COPY(i_flistp, ebufp);

	cycle_fwd_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, cycle_fwd_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, cycle_fwd_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BILLINFO_OBJ, cycle_fwd_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, cycle_fwd_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_FLAGS, &cycle_fwd_flg, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_END_T, &now_t, ebufp);

	PIN_FLIST_SUBSTR_SET(recurring_cycle_fwd_flistp, cycle_fwd_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			 "fm_tab_subscription_bal_transfer_recurring_renewal: "
			 "TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL"
					" input flist", recurring_cycle_fwd_flistp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL, 0,
				recurring_cycle_fwd_flistp, &ret_cycle_fwd_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_bal_transfer_recurring_renewal: Error in "
				"TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_bal_transfer_recurring_renewal :"
				       " TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL:"
					"input flist", recurring_cycle_fwd_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(ret_cycle_fwd_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_bal_transfer_recurring_renewal:"
		"TAB_OP_SUBSCRIPTION_POL_BALANCE_TRANSFER_RECURRING_RENEWAL return flist ", ret_cycle_fwd_flistp);

	if (ret_cycle_fwd_flistp != NULL)
	{
		/*******************************************************
		 * Call OOB opcode PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
		 *******************************************************/
		PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CYCLE_FORWARD, 0,
				ret_cycle_fwd_flistp, &out_cycle_fwd_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_bal_transfer_recurring_renewal: "
					"PCM_OP_SUBSCRIPTION_CYCLE_FORWARD return Error ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_bal_transfer_recurring_renewal :"
				       " TPCM_OP_SUBSCRIPTION_CYCLE_FORWARD:"
					"input flist", ret_cycle_fwd_flistp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_bal_transfer_recurring_renewal:"
				"No Recurring Renewal triggered");
	}

	*r_flistpp = PIN_FLIST_COPY(out_cycle_fwd_flistp, ebufp);

cleanup:

	PIN_FLIST_DESTROY_EX(&cycle_fwd_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_cycle_fwd_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&recurring_cycle_fwd_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&out_cycle_fwd_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_bal_transfer_recurring_renewal output flist", *r_flistpp);
	return;
}

// End of File
