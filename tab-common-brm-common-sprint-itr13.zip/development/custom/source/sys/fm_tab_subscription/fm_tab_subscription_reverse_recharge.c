/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 *******************************************************************************/

/*************************************************************************************************
 *  Change History
 *
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details
 *
 *                  | 1     | 19-JAN-2022   | Venu Padala       |               | Initial Version
 *
 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE operation.
 *******************************************************************/
#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "ops/bal.h"
#include "ops/ece.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "pin_group.h"
#include "pin_subscription.h"
#include "tab_common.h"
#include "tab_ops_flds.h"
#include "tab_utils_common.h"
#include "pbo_decimal.h"
#define TAB_FUNCTION_REVERSE_PAYMENT 2

PIN_IMPORT int32 *cfg_tab_system_currency;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_sub_reverse_recharge(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_sub_reverse_recharge(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

int32
fm_tab_prepaid_recharge_validate_status(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_reverse_recharge_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_update_recharge_record(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_prepaid_bill_debit(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

static void
fm_tab_sub_reverse_recharge_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*ret_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

PIN_IMPORT void
fm_tab_sub_fetch_recharge_records(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);
void
fm_tab_reverse_recharge_reverse_payment(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistp,
	pin_errbuf_t		*ebufp);


 /**
 *
 * New opcode TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE is implemented to
 * create Recharge for Prepaid Subscriber
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MEMBERS, PIN_FLD_NAME
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *      0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 *      0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
 *      0 PIN_FLD_MSISDN          STR [0] "service3"
 *      0 PIN_FLD_MEMBERS       ARRAY [0] allocated 20, used 1
 *      1     PIN_FLD_MSISDN          STR [0] "1631013011"
 *      0 PIN_FLD_OFFER         ARRAY [0] allocated 20, used 1
 *      1     PIN_FLD_DISCOUNT_INFO            STR [0] "DO_07092021"
 *      0 PIN_FLD_NAME            STR [0] "DSG_GRP_2000009"
 *      0 PIN_FLD_CORRELATION_ID    STR [0] "22112021_019"
 *      0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"
 *
 **/

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE operation.
 **************************************************************************/
void
op_tab_sub_reverse_recharge(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_reverse_recharge function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_reverse_recharge bad opcode error", ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_reverse_recharge input flist", in_flistp);
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if((PIN_ERR_IS_ERR(ebufp)) || (db_no == 0)) {

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);

		fm_tab_utils_common_request_set_error(ctxp, in_flistp,
			error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_tab_order_before:  input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_reverse_recharge:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 ) {

		cerror_code = TAB_ERR_CODE_API_REVERSE_RECHARGE;
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_REVERSE_RECHARGE, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_REVERSE_RECHARGE ) {

			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_REVERSE_RECHARGE, ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp)) {
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp)) {

			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_reverse_recharge: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_reverse_recharge:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_sub_reverse_recharge(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp)) {

			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_sub_reverse_recharge error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else {

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_sub_reverse_recharge:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_reverse_recharge: Error while Opening transaction",ebufp);

		fm_tab_utils_common_request_set_error(ctxp, in_flistp,
				error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp)) {

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_reverse_recharge:"
			" Error while creating /tab_order object", ebufp);
	
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_REVERSE_RECHARGE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_REVERSE_RECHARGE )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_REVERSE_RECHARGE, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);

	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

  	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_reverse_recharge output flist", *ret_flistpp);
	return;
}


/**
 * We use this function to create Recharge.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return out_flistpp.
 *
 **/

void
fm_tab_sub_reverse_recharge(
	pcm_context_t	*ctxp,
	pin_flist_t	*in_flistp,
	pin_flist_t	**out_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*bal_out_flistp = NULL;
	pin_flist_t	*enrich_flistp = NULL;
	pin_flist_t	*enrich_out_flistp = NULL;
	pin_flist_t	*rch_rev_flistp = NULL;
	pin_flist_t	*notify_iflistp = NULL;
	pin_flist_t	*notify_oflistp = NULL;
	pin_flist_t	*rev_flistp = NULL;
	pin_flist_t	*bal_res_flistp = NULL;
	pin_flist_t	*amts_flistp = NULL;
	pin_flist_t	*ret_flistp = NULL;
	pin_flist_t	*billinfo_flistp = NULL;
	pin_flist_t	*debit_rev_flistp = NULL;
	pin_flist_t	*context_info_flistp = NULL;
	pin_flist_t	*service_out_flistp = NULL;
	pin_flist_t	*out_rec_flistp = NULL;
	pin_flist_t	*res_flistp = NULL;
	pin_flist_t	*bal_flistp = NULL;
	pin_flist_t	*billreversepay_out_flistp = NULL;		
	pin_flist_t	*getnewbal_in_flistp = NULL;
	pin_flist_t	*getnewbal_out_flistp  = NULL;
	pin_flist_t	*enrichresult_in_flistp = NULL;
	pin_flist_t	*enrichresult_out_flistp = NULL;
	pin_flist_t 	*sub_balance_flistp = NULL;
	pin_decimal_t	*sub_current_bal = pbo_decimal_from_str("0.0", ebufp);;
	pin_decimal_t	*abs_current_bal = NULL;
	pin_decimal_t	*rch_actual_amt = NULL;
	pin_decimal_t	*abs_rch_actual_amt = NULL;
	pin_decimal_t	*rev_amt = NULL;
	//pin_decimal_t	*rev_tax = NULL;
	pin_decimal_t	*sub_rem_bal = NULL;
	pin_decimal_t	*debit_bal = NULL;
	pin_decimal_t 	*temp_sub_balp = NULL;
	pin_decimal_t 	*reserved_amtp = NULL;
	poid_t		*acct_pdp = NULL;
	time_t		now_t = pin_virtual_time(NULL);
	time_t		*validity_t = NULL;
	char		*svc_validity_dt = NULL;
	int32		sub_pay_type = 0;
	int32		is_reversed = PIN_BOOLEAN_FALSE;
	int32		is_partial = PIN_BOOLEAN_TRUE;
	int32		*sys_currency = cfg_tab_system_currency;
	int32		elemid = 0;
	int32		error_code = 0;
	int32		elem_balance=0;
	void		*vp = NULL;
	int 		mode = 1;
	int		sub_type = 0;
	pin_cookie_t 	cookie_balance = NULL;
	char		log_msg[512]= "";


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_reverse_recharge input flist", in_flistp);
	
	rev_flistp = PIN_FLIST_COPY(in_flistp, ebufp);

	fm_tab_sub_reverse_recharge_validate_input(ctxp, rev_flistp,db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_utils_common_get_billinfo input flist ", rev_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			"fm_tab_utils_common_get_billinfo error", ebufp);
		goto cleanup;
	}

        PIN_FLIST_FLD_DROP(rev_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_DROP(rev_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

        context_info_flistp =  PIN_FLIST_SUBSTR_ADD(rev_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	acct_pdp = PIN_FLIST_FLD_GET(rev_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	fm_tab_utils_common_get_billinfo(ctxp, acct_pdp, 1, &billinfo_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_utils_common_get_billinfo input flist ", rev_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			"fm_tab_utils_common_get_billinfo error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge: billinfo_flistp is ",billinfo_flistp);
	sub_pay_type = *(int32*)PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (sub_pay_type != PIN_PAY_TYPE_PREPAID)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_utils_common_get_billinfo input flist ", rev_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NOT_PREPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
		"Subscriber is not Prepaid account", ebufp);
		goto cleanup;
	}

	// To Fetch the Recharge record for the original recharge transaction
	rch_rev_flistp = PIN_FLIST_COPY(rev_flistp, ebufp);
	PIN_FLIST_FLD_DROP(rch_rev_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_SUB_TRANS_ID, rch_rev_flistp, PIN_FLD_TRANS_ID, ebufp);
	fm_tab_sub_fetch_recharge_records(ctxp, rch_rev_flistp, db_no,  &out_rec_flistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			"fm_tab_sub_fetch_recharge_records Return Flist", out_rec_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			"fm_tab_sub_fetch_recharge_records error", ebufp);
		goto cleanup;
	}
	PIN_FLIST_DESTROY_EX(&rch_rev_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge: "
		"fm_tab_sub_fetch_recharge_records Output Flist", out_rec_flistp);
	
	res_flistp = PIN_FLIST_ELEM_GET(out_rec_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);

	if (res_flistp == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_sub_fetch_recharge_records results flist ", res_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ORIG_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			"Subscriber Original recharge transaction not found ", ebufp);
		goto cleanup;
	}

	PIN_FLIST_ELEM_COPY(out_rec_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY,
		rev_flistp, PIN_FLD_RESULTS, 0, ebufp);

	is_reversed = *(int32*)PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_CANCEL_FLAGS, 1, ebufp);
	if (is_reversed == PIN_BOOLEAN_TRUE)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_sub_fetch_recharge_records results flist ", res_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_RECHARGE_IS_REVERSED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			"Subscriber Original recharge transaction is already Reversed ", ebufp);
		goto cleanup;
	}

	rch_actual_amt = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_CREDIT_AMOUNT, 1, ebufp);
	abs_rch_actual_amt = pbo_decimal_abs(rch_actual_amt, ebufp);

	vp = PIN_FLIST_FLD_GET(rev_flistp, PIN_FLD_CANCEL_FLAGS, 1, ebufp);
	if (vp)
	{
		is_partial = *(int32 *)vp;
	}
	if (is_partial == TAB_FUNCTION_REVERSE_PAYMENT)
	{
		PIN_FLIST_FLD_SET(rev_flistp, PIN_FLD_PENDING_BAL, abs_rch_actual_amt, ebufp);
		fm_tab_reverse_recharge_reverse_payment(ctxp, rev_flistp, &billreversepay_out_flistp, ebufp);
		if( PIN_ERR_IS_ERR( ebufp ))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
				"fm_tab_reverse_recharge_reverse_payment Return Flist", billreversepay_out_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
				"fm_tab_reverse_recharge_reverse_payment error", ebufp);
			goto cleanup;
		}
	}
	else
	{
	
		/*********************************************************
		* Execution of PCM_OP_BAL_GET_ECE_BALANCES
		**********************************************************/	
		bal_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_SERVICE_OBJ, bal_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_MSISDN, bal_flistp, PIN_FLD_LOGIN, ebufp);
		PIN_FLIST_FLD_SET(bal_flistp, PIN_FLD_START_T, &now_t, ebufp);
		PIN_FLIST_FLD_SET(bal_flistp, PIN_FLD_MODE, &mode, ebufp);

		vp = PIN_FLIST_SUBSTR_GET(rev_flistp, PIN_FLD_CONTEXT_INFO, 0, ebufp);
		PIN_FLIST_SUBSTR_SET(bal_flistp, vp, PIN_FLD_CONTEXT_INFO, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge:"
				" PCM_OP_BAL_GET_ECE_BALANCES input flist ", bal_flistp);
		PCM_OP(ctxp, PCM_OP_BAL_GET_ECE_BALANCES, 0, bal_flistp, &bal_out_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" PCM_OP_BAL_GET_ECE_BALANCES input flist ", bal_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" PCM_OP_BAL_GET_ECE_BALANCES returned error ", ebufp);
			goto cleanup;
		}

		if (bal_out_flistp == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" PCM_OP_BAL_GET_ECE_BALANCES input flist ", bal_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_ECE_BALANCE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				"PCM_OP_BAL_GET_ECE_BALANCES returned NULL flist ", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge:"
				" PCM_OP_BAL_GET_ECE_BALANCES return flist ", bal_out_flistp);

		bal_res_flistp = PIN_FLIST_ELEM_GET(bal_out_flistp, PIN_FLD_BAL_IMPACTS, *sys_currency, 1, ebufp);

		if(bal_res_flistp!=NULL)
		{
			while ((sub_balance_flistp = PIN_FLIST_ELEM_GET_NEXT(bal_res_flistp, PIN_FLD_SUB_BAL_IMPACTS,
						&elem_balance, 1, &cookie_balance, ebufp)) != (pin_flist_t*)NULL)
			{
				sub_type = *(int*)PIN_FLIST_FLD_GET(sub_balance_flistp, PIN_FLD_SUBTYPE, 0, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge:"
								" sub_balance_flistp flist ", sub_balance_flistp);
				if(sub_type==0)
				{
					temp_sub_balp = PIN_FLIST_FLD_GET(sub_balance_flistp, PIN_FLD_AMOUNT,0,ebufp);
					reserved_amtp = PIN_FLIST_FLD_GET(sub_balance_flistp, PIN_FLD_RESERVED_AMOUNT,1, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge:"
									" PCM_OP_BAL_GET_ECE_BALANCES return flist ", sub_balance_flistp);

					if (temp_sub_balp && !pbo_decimal_is_null(temp_sub_balp, ebufp))
					{
						pbo_decimal_add_assign(sub_current_bal,temp_sub_balp, ebufp);
					}

					if (reserved_amtp && !pbo_decimal_is_null(reserved_amtp, ebufp)!=NULL)
						pbo_decimal_subtract_assign(sub_current_bal,reserved_amtp,ebufp);
				}
			}
		}


		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" ECE Balance calculation flist ", bal_out_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" ECE Balance calculation returned error ", ebufp);
			goto cleanup;
		}

		sprintf(log_msg,"%s",pbo_decimal_to_str(reserved_amtp,ebufp));
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		sprintf(log_msg,"%s",pbo_decimal_to_str(sub_current_bal,ebufp));
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);

		abs_current_bal = pbo_decimal_abs(sub_current_bal, ebufp);

		sprintf(log_msg,"%s",pbo_decimal_to_str(abs_current_bal,ebufp));
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,log_msg);

		if (pbo_decimal_is_zero(abs_current_bal, ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" Reversal input flist ", rev_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_RCH_INSUFF_BALANCE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				"Insufficent Subscriber ECE Balance for Reversal ", ebufp);
			goto cleanup;
		}
	
		if (pbo_decimal_compare(abs_current_bal, abs_rch_actual_amt, ebufp) < 0)
		{
			if (is_partial == PIN_BOOLEAN_TRUE)
			{
				PIN_FLIST_FLD_SET(rev_flistp, PIN_FLD_PENDING_BAL, abs_current_bal, ebufp);
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
					" Reversal input flist ", rev_flistp);
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_RCH_INSUFF_BALANCE, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
					"Insufficent Subscriber Balance for Reversal ", ebufp);
				goto cleanup;
			}
		}
		else
		{
			PIN_FLIST_FLD_SET(rev_flistp, PIN_FLD_PENDING_BAL, abs_rch_actual_amt, ebufp);
		}

		enrich_flistp = PIN_FLIST_COPY(rev_flistp, ebufp);

		// Call the TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE to fetch the tax applicable
		PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE, 0, enrich_flistp, &enrich_out_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE input flist ", enrich_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE returned error ", ebufp);

			error_code = (ebufp)->pin_err;
			PIN_ERRBUF_CLEAR(ebufp);
			*out_flistpp = PIN_FLIST_COPY(enrich_out_flistp, ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					error_code, 0, 0, 0);
			goto cleanup;
		}

		if (enrich_out_flistp != NULL)
		{
			amts_flistp = PIN_FLIST_ELEM_GET(enrich_out_flistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY, 1, ebufp);

			if (amts_flistp != NULL)
			{
				rev_amt = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_RECVD, 1, ebufp);
				//rev_tax = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_TAX, 1, ebufp);
				PIN_FLIST_FLD_DROP(rev_flistp, PIN_FLD_PENDING_BAL, ebufp);
				PIN_FLIST_FLD_SET(rev_flistp, PIN_FLD_PENDING_BAL, rev_amt, ebufp);
			}
		}

		// Call PCM_OP_BILL_DEBIT to deduct the balance
		fm_tab_sub_prepaid_bill_debit(ctxp, rev_flistp, &debit_rev_flistp,db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" fm_tab_sub_prepaid_bill_debit input flist ", enrich_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
				" fm_tab_sub_prepaid_bill_debit returned error ", ebufp);
			goto cleanup;
		}
	}

	// call for function to get new balance
	getnewbal_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, getnewbal_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(getnewbal_in_flistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency, ebufp);
	
	fm_tab_utils_common_subscr_get_current_main_balance(ctxp, getnewbal_in_flistp, &getnewbal_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" error getting new balance input flist ", getnewbal_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			"  error getting new balance ", ebufp);
		goto cleanup;
	}

	sub_rem_bal = PIN_FLIST_FLD_GET(getnewbal_out_flistp, PIN_FLD_CURRENT_BAL, 1, ebufp);

	// To update  /tab_prepaid_subscriber_recharge object
	fm_tab_sub_update_recharge_record(ctxp, rev_flistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_sub_update_recharge_record input flist ", rev_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_sub_update_recharge_record returned error ", ebufp);
		goto cleanup;
	}

	ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_POID, ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_TRANS_ID, ret_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(rev_flistp, PIN_FLD_SUB_TRANS_ID, ret_flistp, PIN_FLD_SUB_TRANS_ID, ebufp);
	rev_amt = PIN_FLIST_FLD_GET(rev_flistp,PIN_FLD_PENDING_BAL, 1, ebufp);
	
	PIN_FLIST_FLD_SET(ret_flistp, PIN_FLD_AMOUNT, rev_amt, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge: "
			" fm_tab_utils_common_get_service_from_msisdn input is ", rev_flistp);
	fm_tab_utils_common_get_service_from_msisdn(ctxp, rev_flistp, &service_out_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_utils_common_get_service_from_msisdn output flist ", rev_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			" fm_tab_utils_common_get_service_from_msisdn error", ebufp);
		goto cleanup;
	}

	if (service_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERVICE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			" Service Not Found ", ebufp);
		goto cleanup;
	}

	validity_t = PIN_FLIST_FLD_GET(service_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 0, ebufp);
	svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, validity_t, ebufp);
	PIN_FLIST_FLD_SET(ret_flistp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt,  ebufp);
	PIN_FLIST_FLD_SET(ret_flistp, PIN_FLD_CURRENT_BAL, sub_rem_bal,  ebufp);

	free(svc_validity_dt);

	/***************************************************
	 * Enrichment of Return/Result
	 ****************************************************/
	enrichresult_in_flistp = PIN_FLIST_COPY(rev_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichresult_in_flistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Enrich Results input flistp", enrichresult_in_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_REVERSE_RECHARGE_RESULTS , 0, enrichresult_in_flistp, &enrichresult_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge: Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	/***************************************************
	 * Finalization of Return FLIST
	 ****************************************************/
	if (enrichresult_out_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Enrich Results output flistp", enrichresult_out_flistp);
		PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);		
		ret_flistp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
	}
	
	*out_flistpp = PIN_FLIST_COPY(ret_flistp, ebufp);

	elemid = 0;
	
	if (billreversepay_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, billreversepay_out_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}
	
	if (bal_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, bal_out_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}

	if (debit_rev_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(ret_flistp, debit_rev_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge:"
		" fm_tab_sub_reverse_recharge_enrich_notification input flist ", notify_iflistp);

	// Call function to enrich notification details
	fm_tab_sub_reverse_recharge_enrich_notification(ctxp, rev_flistp, ret_flistp, db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" fm_tab_sub_reverse_recharge_enrich_notification input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge: "
			" fm_tab_sub_reverse_recharge_enrich_notification error", ebufp);

		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(notify_oflistp, ebufp);
		vp = PIN_FLIST_FLD_GET(*out_flistpp, PIN_FLD_ERROR_CODE, 0, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				*(int32 *)vp, 0, 0, 0);
		goto cleanup;
	}

	if (notify_oflistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_reverse_recharge output flist", *out_flistpp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	PIN_FLIST_DESTROY_EX(&enrich_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&bal_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&out_rec_flistp, NULL);
	//PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&billreversepay_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&getnewbal_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&getnewbal_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichresult_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichresult_out_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_reverse_recharge output flist", *out_flistpp);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, NULL);
    PIN_FLIST_DESTROY_EX(&bal_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rev_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	if (abs_rch_actual_amt)
        {
                pbo_decimal_destroy(&abs_rch_actual_amt);
        }
	if (abs_current_bal)
        {
                pbo_decimal_destroy(&abs_current_bal);
        }
	if (sub_current_bal)
	{
		pbo_decimal_destroy(&sub_current_bal);
	}

	return;
}


/*************************************************************
 *  This function will validate the input fields in the flist
 *   and return error if any mandatory fields are missing 
 *************************************************************/

void
fm_tab_sub_reverse_recharge_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*in_rch_ref_id = NULL;
	char			*in_rch_origref_id = NULL;
	char			*in_rch_msisdn = NULL;
	int32			*in_rch_reversal = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge_validate_input function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_reverse_recharge_validate_input: "
		" input flist", i_flistp);

	in_rch_msisdn = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if((in_rch_msisdn == NULL) || (in_rch_msisdn && strlen(in_rch_msisdn) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge_validate_input:"
			"Recharge Reversal MSISDN is not passed/empty", ebufp);
		return;
	}
	
	in_rch_ref_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if((in_rch_ref_id == NULL) || (in_rch_ref_id && strlen(in_rch_ref_id) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge_validate_input:"
			"Recharge Reversal Reference ID is not passed/empty", ebufp);
		return;
	}
	
	in_rch_origref_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_SUB_TRANS_ID, 1, ebufp);

	if((in_rch_origref_id == NULL) || (in_rch_origref_id && strlen(in_rch_origref_id) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ORIG_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge_validate_input:"
			" Original Recharge Reference ID is not passed/empty", ebufp);
		return;
	}

	in_rch_reversal = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_CANCEL_FLAGS, 1, ebufp);

	if(in_rch_reversal == NULL) 
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_RCH_REVERSAL_FLAG_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge_validate_input:"
			" Recharge Reversal Flag is not passed", ebufp);
		return;
	}

	return;
}


/*************************************************************
 *  This function will prepare the flist to update recharge
 *  record and call PCM_OP_WRITE_FLDS opcode
 *************************************************************/

void
fm_tab_sub_update_recharge_record(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*updt_out_flistp = NULL;
	pin_flist_t	*updt_flistp = NULL;
	pin_flist_t	*rch_flistp = NULL;
	int32		is_reversed = PIN_BOOLEAN_TRUE;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_update_recharge_record function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_update_recharge_record input flist", i_flistp);
	
	/*********************************************************
	* Execution of PCM_OP_WRITE_FLDS
	**********************************************************/	
	updt_flistp = PIN_FLIST_CREATE(ebufp);
	rch_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_POID, updt_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PENDING_BAL, updt_flistp, PIN_FLD_REMIT_TOT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, updt_flistp, PIN_FLD_SUB_TRANS_ID, ebufp);
	PIN_FLIST_FLD_SET(updt_flistp, PIN_FLD_CANCEL_FLAGS, &is_reversed, ebufp);

	PCM_OP(ctxp, PCM_OP_WRITE_FLDS, 0, updt_flistp, &updt_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" PCM_OP_WRITE_FLDS results flist ", updt_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_reverse_recharge:"
			" PCM_OP_WRITE_FLDS returned error ", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&updt_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&updt_out_flistp, NULL);

	return;
}


/*************************************************************
 *  This function will prepare the flist
 *  and call PCM_OP_BILL_DEBIT opcode and return the flist.
 *************************************************************/

void
fm_tab_sub_prepaid_bill_debit(
	pcm_context_t	*ctxp,
	pin_flist_t	*i_flistp,
	pin_flist_t	**r_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp)
{
	pin_flist_t	*debit_iflistp = NULL;
	pin_flist_t	*debit_oflistp = NULL;
	pin_flist_t	*debit_flistp = NULL;
	int32		*s_currency = cfg_tab_system_currency;
	void		*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_prepaid_bill_debit function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_prepaid_bill_debit input flist", i_flistp);

        debit_iflistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, debit_iflistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, debit_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, debit_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BAL_GRP_OBJ, debit_iflistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, debit_iflistp, PIN_FLD_DESCR, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, debit_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
        debit_flistp =  PIN_FLIST_ELEM_ADD(debit_iflistp, PIN_FLD_DEBIT, *s_currency, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PENDING_BAL, debit_flistp, PIN_FLD_BAL_OPERAND, ebufp);

	vp = PIN_FLIST_SUBSTR_GET(i_flistp, PIN_FLD_CONTEXT_INFO, 0, ebufp);
	PIN_FLIST_SUBSTR_SET(debit_iflistp, vp, PIN_FLD_CONTEXT_INFO, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		" PCM_OP_BILL_DEBIT input flist", debit_iflistp);

        PCM_OP(ctxp, PCM_OP_BILL_DEBIT , 0, debit_iflistp, &debit_oflistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_bill_debit error", ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_bill_debit:"
                        " input flist", debit_iflistp);
                goto cleanup;
        }

        *r_flistpp = debit_oflistp;

cleanup:
        PIN_FLIST_DESTROY_EX(&debit_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_prepaid_bill_debit return flist", *r_flistpp);

        return;
}


/*************************************************************
 *  This function will prepare the notification flist
 *  based on the payload structure.
 *  Will call the Policy Opcode
 *  TAB_OP_NOTIFY_POL_ENRICH_REVERSE_RECHARGE_NOTIFICATION for
 *  enrichment and return notification flist
 *************************************************************/

static void
fm_tab_sub_reverse_recharge_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*ret_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*read_iflistp = NULL;
	pin_flist_t		*read_oflistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	void			*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge_enrich_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_reverse_recharge_enrich_notification: input flist", i_flistp);

	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);

	read_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, read_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(read_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge_enrich_notification : Read flds input flist", read_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_iflistp, &read_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" input flist ", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" Error while reading Account flds", ebufp);
		goto cleanup;
	}

	// Create Notification Flist

	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_REVERSE_RECHARGE_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, notify_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SUB_TRANS_ID, notify_flistp, PIN_FLD_SUB_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, PIN_FLD_CURRENT_BAL, notify_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, TAB_FLD_SVC_VALIDITY_DATE, notify_flistp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, PIN_FLD_AMOUNT, notify_flistp, PIN_FLD_AMOUNT, ebufp);

	PIN_FLIST_FLD_COPY(read_oflistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_REVERSE_RECHARGE_NOTIFICATION input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_REVERSE_RECHARGE_NOTIFICATION, 0,
				notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_sub_reverse_recharge_enrich_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_sub_reverse_recharge_enrich_notification:"
			" Error in Notification", ebufp);

		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		vp = PIN_FLIST_FLD_GET(*r_flistpp, PIN_FLD_ERROR_CODE, 0, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				*(int32 *)vp, 0, 0, 0);

		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_reverse_recharge_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_REVERSE_RECHARGE_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		out_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
	}

	*r_flistpp = out_flistp;

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_reverse_recharge_enrich_notification output flist", *r_flistpp);
	return;
}

void
fm_tab_reverse_recharge_reverse_payment(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistp,
	pin_errbuf_t		*ebufp)
{
	
	pin_flist_t			*read_in_flistp = NULL;
	pin_flist_t			*read_out_flisp = NULL;
	pin_flist_t			*rch_flistp = NULL;
	pin_flist_t			*payment_flistp = NULL;
	pin_flist_t			*reversepayment_in_flistp = NULL;
	pin_flist_t			*reversepayment_out_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_reverse_recharge_reverse_payment function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_reverse_recharge_reverse_payment input flist", in_flistp);

	rch_flistp = PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	
	if (rch_flistp == NULL)
	{
		goto cleanup;
	}
	
	read_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_EVENT_OBJ, read_in_flistp, PIN_FLD_POID,ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_reverse_recharge_reverse_payment: read event input flist", read_in_flistp);
		
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, read_in_flistp, &read_out_flisp, ebufp);
		
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_reverse_recharge_reverse_payment: read event object error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_reverse_recharge_reverse_payment: read event object input flist", read_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_reverse_recharge_reverse_payment: read event output flist", read_out_flisp);

	reversepayment_in_flistp  = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, reversepayment_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(read_out_flisp, PIN_FLD_ITEM_OBJ, reversepayment_in_flistp, PIN_FLD_ITEM_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, reversepayment_in_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	
	payment_flistp = PIN_FLIST_SUBSTR_GET(read_out_flisp, PIN_FLD_PAYMENT, 1,ebufp);
	if (payment_flistp == NULL)
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_reverse_recharge_reverse_payment: Cannot read payment list on the payment event", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_reverse_recharge_reverse_payment: Cannot read payment list on the payment event input flist", read_in_flistp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_TRANS_ID, reversepayment_in_flistp, PIN_FLD_PAYMENT_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(payment_flistp, PIN_FLD_PAY_TYPE, reversepayment_in_flistp, PIN_FLD_PAY_TYPE, ebufp);

	PCM_OP(ctxp, PCM_OP_BILL_REVERSE_PAYMENT, 0,reversepayment_in_flistp, &reversepayment_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_reverse_recharge_reverse_payment:"
			"bill payment reverse error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_reverse_recharge_reverse_payment:"
			"bill payment reverse input flist", reversepayment_in_flistp);
		goto cleanup;
	}

	r_flistp = PIN_FLIST_COPY(reversepayment_out_flistp, ebufp);

	cleanup:
	
	*out_flistp = r_flistp;
	
	PIN_FLIST_DESTROY_EX(&read_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_out_flisp, ebufp);
	PIN_FLIST_DESTROY_EX(&reversepayment_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&reversepayment_out_flistp, ebufp);
	return;
}

// End of File
