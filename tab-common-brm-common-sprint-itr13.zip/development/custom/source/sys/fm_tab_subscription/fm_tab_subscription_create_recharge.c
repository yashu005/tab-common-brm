/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 *********************************************************************************/

/*************************************************************************************************
 *  Change History
 *-----------------------------------------------------------------------------------------------
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details
 *-----------------------------------------------------------------------------------------------
 *                  | 1     | 19-JAN-2022   | Venu Padala       |               | Initial Version
 *
 **************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_RECHARGE operation.
 *******************************************************************/
#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_cust.h"
#include "pin_rate.h"
#include "pin_pymt.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/cust.h"
#include "ops/pymt.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "fm_bill_utils.h"
#include "pin_group.h"
#include "pin_subscription.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "tab_ops_flds.h"

PIN_IMPORT pin_flist_t *cfg_tab_prepaid_sub_states_flistp;

/*******************************************************************
 * Routines contained within.
 *******************************************************************/

EXPORT_OP void
op_tab_subscription_recharge(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_subscription_recharge(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

int32
fm_tab_sub_prepaid_recharge_validate_state(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_recharge_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_prepaid_enrich_recharge(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_update_prepaid_svc_validity(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_prepaid_create_recharge_record(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_recharge_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*ret_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_recharge_recurring_renewal(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_fetch_loan_recovery_event(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_fetch_recharge_records(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern Functions */
PIN_IMPORT void
fm_tab_cust_purchase_offer(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	int			notify_flag,
	pin_errbuf_t		*ebufp);

extern int32	*cfg_tab_system_currency;


 /**
 *
 * New opcode TAB_OP_SUBSCRIPTION_RECHARGE is implemented to
 * create Recharge for Prepaid Subscriber
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MEMBERS, PIN_FLD_NAME
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *      0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 *      0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
 *      0 PIN_FLD_MSISDN          STR [0] "service3"
 *      0 PIN_FLD_MEMBERS       ARRAY [0] allocated 20, used 1
 *      1     PIN_FLD_MSISDN          STR [0] "1631013011"
 *      0 PIN_FLD_OFFER         ARRAY [0] allocated 20, used 1
 *      1     PIN_FLD_DISCOUNT_INFO            STR [0] "DO_07092021"
 *      0 PIN_FLD_NAME            STR [0] "DSG_GRP_2000009"
 *      0 PIN_FLD_CORRELATION_ID    STR [0] "22112021_019"
 *      0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"
 *
 **/

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_RECHARGE operation.
 **************************************************************************/
void
op_tab_subscription_recharge(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*trans_order_oflistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;
	pin_flist_t		*i_flistp = NULL;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_recharge function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_RECHARGE)
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_recharge:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
			"op_tab_subscription_recharge bad opcode error", ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_recharge input flist", in_flistp);


	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if((PIN_ERR_IS_ERR(ebufp)) || (db_no == 0))
	{

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, 
			error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_tab_order_before:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_recharge:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{

			cerror_code = TAB_ERR_CODE_API_RECHARGE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RECHARGE, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RECHARGE )
		{

			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RECHARGE, ebufp);
		}
                
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, 
					&enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{

			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_recharge: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_recharge:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		i_flistp = PIN_FLIST_COPY(enrich_iflistp, ebufp);
		fm_tab_subscription_recharge(ctxp, i_flistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{

			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_recharge error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_recharge: Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_recharge: Error while Opening transaction",ebufp);

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
					cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUBSCRIPTION_RECHARGE", &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_recharge:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_RECHARGE;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);
		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_RECHARGE )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_RECHARGE, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
 
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_recharge output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&trans_order_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&i_flistp, NULL);
	return;
}

/**
 * We use this function to create Recharge.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return out_flistpp.
 *
 **/

void fm_tab_subscription_recharge(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*rch_flistp = NULL;
	pin_flist_t		*rch_record_flistp = NULL;
	pin_flist_t		*rch_ret_flistp = NULL;
	pin_flist_t		*pymt_topup_oflistp = NULL;
	pin_flist_t		*pymt_topup_iflistp = NULL;
	pin_flist_t		*o_flistp = NULL;
	pin_flist_t		*billinfo_flistp = NULL;
	pin_flist_t		*service_out_flistp = NULL;
	pin_flist_t		*create_rch_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*rch_valid_flistp = NULL;
	pin_flist_t		*resource_flistp = NULL;
	pin_flist_t		*res_ret_flistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*amts_flistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*offer_oflistp = NULL;
	pin_flist_t		*rch_offer_flistp = NULL;
	pin_flist_t		*rch_rec_flistp = NULL;
	pin_flist_t		*updt_svc_flistp = NULL;
	pin_flist_t		*rch_enrich_flistp = NULL;
	pin_flist_t		*inh_info_flistp = NULL;
	pin_flist_t		*topup_flistp = NULL;
	pin_flist_t		*cash_iflistp = NULL;
	pin_flist_t		*payinfo_flistp = NULL;
	pin_flist_t		*read_oflistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	pin_flist_t		*readaccnt_in_flistp = NULL;
	pin_flist_t		*readaccnt_out_flistp = NULL;
	pin_flist_t		*balances_iflistp = NULL;
	pin_flist_t		*balances_oflistp = NULL;
	pin_flist_t		*balances_arr_iflistp = NULL;
	pin_flist_t		*balances_arr_oflistp = NULL;
	pin_flist_t		*rch_rec_rnwl_flistp = NULL;
	pin_flist_t		*loan_recover_flistp = NULL;
	pin_flist_t		*loan_info_flistp = NULL;
	pin_flist_t		*enrichresult_in_flistp = NULL;
	pin_flist_t		*enrichresult_out_flistp = NULL;
	pin_flist_t		*enrichtopup_in_flistp = NULL;
	pin_flist_t		*enrichtopup_out_flistp = NULL;
	pin_flist_t		*enrichrechargerec_out_flistp = NULL;
	pin_flist_t		*rechargerecwithbal_out_flistp = NULL;
	pin_flist_t		*rechargerecwithbal_in_flistp = NULL;
	pin_decimal_t		*act_rch_amt = NULL;
	pin_decimal_t		*rch_amt = NULL;
	pin_decimal_t		*rch_tax = NULL;
	pin_decimal_t		*rch_tax_fed = NULL;
	pin_decimal_t		*rch_tax_sales = NULL;
	pin_decimal_t		*rch_tax_wht = NULL;
	pin_decimal_t		*topup_amt = NULL;
	pin_decimal_t		*loan_amt = NULL;
	pin_decimal_t		*zero_val = pbo_decimal_from_str("0.0",ebufp);
	pin_decimal_t		*enrichtax_dcmlp = NULL;
	pin_decimal_t		*creditamt_dcmlp = NULL;
	pin_decimal_t		*newcreditamt_dcmlp = NULL;
	pin_decimal_t		*taxamt_dcmlp = NULL;
	poid_t			*acct_pdp = NULL;
	poid_t			*topup_pymt_pdp = NULL;
	int32			sub_pay_type = 0;
	int32			is_sub_eligible = PIN_BOOLEAN_FALSE;
	int32			elemid = 0;
	int32			default_val = 0;
	int32			cash_rch = PIN_PAY_TYPE_CASH;
	int32			error_code = 0;
	int			notify_flag = TAB_NOTIFY_DISABLE;
	pin_cookie_t		cookie = NULL;
	char			*rch_req_dt = NULL;
	char			*svc_validity_dt = NULL;
	time_t			*rch_validity_t = NULL;
	time_t			rch_req_t = 0;
	void			*vp = NULL;
	pin_flist_t		*record_res_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge input flist", in_flistp);

	rch_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_FLD_DROP(rch_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_DROP(rch_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	acct_pdp = (poid_t*)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	context_info_flistp =  PIN_FLIST_SUBSTR_ADD(rch_flistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	fm_tab_sub_recharge_validate_input(ctxp, rch_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_sub_recharge_validate_input input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_sub_recharge_validate_input error", ebufp);
		goto cleanup;
	}

	/***************************************************
	 * Call Util function to fetch the Balances Array
	 ***************************************************/
	balances_arr_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_BAL_GRP_OBJ, balances_arr_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(balances_arr_iflistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency,ebufp);

	fm_tab_utils_common_subscr_get_balances_array(ctxp,
			balances_arr_iflistp, &balances_arr_oflistp, db_no, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_balances_array Input", balances_arr_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_balances_array Error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_BALANCE_NOT_FOUND, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_balances_array return Flist", balances_arr_oflistp);

	fm_tab_subscription_fetch_recharge_records(ctxp, rch_flistp, db_no, &rch_record_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_subscription_fetch_recharge_records input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_subscription_fetch_recharge_records error", ebufp);
		goto cleanup;
	}
	record_res_flistp = PIN_FLIST_ELEM_GET(rch_record_flistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if (record_res_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" Recharge Reference ID Exists ", rch_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_TRANSID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" Duplicate Recharge Reference ID ", ebufp);
		goto cleanup;
	}

	fm_tab_utils_common_get_billinfo(ctxp, acct_pdp, 0, &billinfo_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_utils_common_get_billinfo input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_get_billinfo error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge: billinfo_flistp is ",billinfo_flistp);
	if (billinfo_flistp == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" No Billinfo Associated to MSISDN ", rch_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" No Billinfo Associated to MSISDN", ebufp);
		goto cleanup;
	}

	vp = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp)
	{
		sub_pay_type = *(int32*)vp;
	}

	if (sub_pay_type != PIN_PAY_TYPE_PREPAID)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_utils_common_get_billinfo input flist ", rch_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NOT_PREPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			"Subscriber is not Prepaid account", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge: "
			" fm_tab_utils_common_get_service_from_msisdn input is ", rch_flistp);
	fm_tab_utils_common_get_service_from_msisdn(ctxp, rch_flistp, &service_out_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_utils_common_get_service_from_msisdn output flist ", service_out_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_utils_common_get_service_from_msisdn error", ebufp);
		goto cleanup;
	}

	if (service_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERVICE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" Service Not Found ", ebufp);
		goto cleanup;
	}

	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_ACCOUNT_OBJ, rch_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_BAL_GRP_OBJ, rch_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_SERVICE_OBJ, rch_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LOGIN, rch_flistp, PIN_FLD_LOGIN, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T,
				rch_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LIFECYCLE_STATE, rch_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_STATUS, rch_flistp, PIN_FLD_STATUS, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT input flist ", rch_flistp);

	// Call the HOOK opcode to validate BU specific fields 
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT, 0, rch_flistp, &rch_valid_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(rch_valid_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}
 	                                                                    	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_RECHARGE_VALIDATE_INPUT return flist ", rch_valid_flistp);

	is_sub_eligible = fm_tab_sub_prepaid_recharge_validate_state(ctxp,
							rch_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_sub_prepaid_recharge_validate_state input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_sub_prepaid_recharge_validate_state error", ebufp);
		goto cleanup;
	}

	if (is_sub_eligible != PIN_BOOLEAN_TRUE) {
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_RCH_STATE_NOT_ELIGIBLE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_recharge_validate_state:"
			"Subscriber State is not eligible for Recharge", ebufp);
		goto cleanup;
	}

	fm_tab_sub_prepaid_enrich_recharge(ctxp, rch_flistp, db_no, &rch_enrich_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_sub_prepaid_enrich_recharge input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_sub_prepaid_enrich_recharge error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(rch_enrich_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_FLIST_DESTROY_EX(&rch_flistp, NULL);

	rch_flistp = PIN_FLIST_COPY(rch_enrich_flistp, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" fm_tab_sub_prepaid_enrich_recharge return flist ", rch_flistp);

	pymt_topup_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_POID, pymt_topup_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_PROGRAM_NAME, pymt_topup_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	

	inh_info_flistp = PIN_FLIST_SUBSTR_ADD(pymt_topup_iflistp, PIN_FLD_INHERITED_INFO, ebufp);
	topup_flistp = PIN_FLIST_ELEM_ADD(inh_info_flistp, PIN_FLD_TOPUP_INFO, 0, ebufp);

	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_TRANS_ID, topup_flistp, PIN_FLD_AUTHORIZATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_SERVICE_OBJ, topup_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_BAL_GRP_OBJ, topup_flistp, PIN_FLD_BAL_GRP_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_POID, topup_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAYINFO_OBJ, topup_flistp, PIN_FLD_PAYINFO_OBJ, ebufp);

	amts_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY, 1, ebufp);
	if (amts_flistp != NULL)
	{
		rch_amt = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_RECVD, 1, ebufp);
	}

	if (pbo_decimal_is_null(rch_amt, ebufp))
	{
		PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_AMOUNT, topup_flistp, PIN_FLD_TOPUP_AMT, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(topup_flistp, PIN_FLD_TOPUP_AMT, rch_amt, ebufp);
	}

	rch_amt = PIN_FLIST_FLD_GET(topup_flistp, PIN_FLD_TOPUP_AMT, 0, ebufp);

	payinfo_flistp = PIN_FLIST_ELEM_ADD(topup_flistp, PIN_FLD_PAYINFO, 0, ebufp);
	PIN_FLIST_FLD_SET(payinfo_flistp, PIN_FLD_PAY_TYPE, &cash_rch, ebufp);

	cash_iflistp = PIN_FLIST_ELEM_ADD(payinfo_flistp, PIN_FLD_CASH_INFO, 0, ebufp);
	rch_req_dt = PIN_FLIST_FLD_GET(rch_flistp, PIN_FLD_AUTH_DATE, 1, ebufp);
	if (rch_req_dt)
	{
		rch_req_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_req_dt, ebufp);
		PIN_FLIST_FLD_SET(cash_iflistp, PIN_FLD_EFFECTIVE_T, &rch_req_t, ebufp);
	}

	vp = PIN_FLIST_SUBSTR_GET(rch_flistp, PIN_FLD_CONTEXT_INFO, 0, ebufp);
	PIN_FLIST_SUBSTR_SET(pymt_topup_iflistp, vp, PIN_FLD_CONTEXT_INFO, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" PCM_OP_PYMT_TOPUP input flist ", pymt_topup_iflistp);
	
	/**********************************************
	 * TOPUP Enrichment input flist
	 **********************************************/
	enrichtopup_in_flistp = PIN_FLIST_COPY(rch_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichtopup_in_flistp, pymt_topup_iflistp, PIN_FLD_IN_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" Enrichment topup input flist ", enrichtopup_in_flistp);
		
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_PYMT_TOPUP, 0, enrichtopup_in_flistp, &enrichtopup_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity: Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_adjust_ncr_balance_validity:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		rch_ret_flistp = PIN_FLIST_COPY(enrichtopup_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" Enrichment topup output flist ", pymt_topup_iflistp);
	
	/***************************************************
	 * Finalization of topup input Flist
	 ****************************************************/
	if (enrichtopup_out_flistp != NULL)
	{
		PIN_FLIST_DESTROY_EX(&pymt_topup_iflistp, ebufp);
		pymt_topup_iflistp = PIN_FLIST_COPY(enrichtopup_out_flistp, ebufp);
	}
	
	/***************************************************
	 * Call to PCM_OP_PYMT_TOPUP
	 ****************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" PCM_OP_PYMT_TOPUP final input flist ", pymt_topup_iflistp);

	/* Call PCM_OP_PYMT_TOPUP opcode for Recharge and Allocation of Loan Due */
	PCM_OP(ctxp, PCM_OP_PYMT_TOPUP, 0, pymt_topup_iflistp, &pymt_topup_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" PCM_OP_PYMT_TOPUP return flist ", pymt_topup_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" PCM_OP_PYMT_TOPUP error", ebufp);
		TAB_LOG_ERR(pymt_topup_iflistp,"fm_tab_subscription_recharge:"
				" PCM_OP_PYMT_TOPUP error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		" PCM_OP_PYMT_TOPUP output flist ", pymt_topup_oflistp);

	if (pymt_topup_oflistp != NULL)
	{
		t_flistp = PIN_FLIST_ELEM_GET(pymt_topup_oflistp,
						PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		topup_pymt_pdp = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_POID, 1, ebufp);
		PIN_FLIST_FLD_SET(rch_flistp, PIN_FLD_EVENT_OBJ, topup_pymt_pdp, ebufp);

		topup_amt = PIN_FLIST_FLD_GET(pymt_topup_oflistp, PIN_FLD_AMOUNT, 0, ebufp);

		loan_info_flistp =  PIN_FLIST_SUBSTR_GET(t_flistp, PIN_FLD_LOAN_INFO, 1, ebufp);
		if (loan_info_flistp != NULL)
		{
			loan_amt = PIN_FLIST_FLD_GET(loan_info_flistp, PIN_FLD_AMOUNT, 1, ebufp);

			if ((!pbo_decimal_is_null(loan_amt, ebufp)) && (!pbo_decimal_is_zero(loan_amt, ebufp)))
			{
				act_rch_amt = pbo_decimal_subtract(topup_amt, loan_amt, ebufp);
				pbo_decimal_negate_assign(act_rch_amt, ebufp);
				PIN_FLIST_FLD_PUT(rch_flistp, PIN_FLD_CREDIT_AMOUNT, act_rch_amt, ebufp);
			}
			else
			{
				PIN_FLIST_FLD_SET(rch_flistp, PIN_FLD_CREDIT_AMOUNT, topup_amt, ebufp);
			}

			fm_tab_subscription_fetch_loan_recovery_event(ctxp, t_flistp,
								db_no, &loan_recover_flistp, ebufp);
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
					" fm_tab_subscription_fetch_loan_recovery_event input flist ", t_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
				" fm_tab_subscription_fetch_loan_recovery_event error", ebufp);
				goto cleanup;
			}

			loan_info_flistp =  PIN_FLIST_SUBSTR_GET(loan_recover_flistp,
								PIN_FLD_LOAN_INFO, 1, ebufp);
			if (loan_info_flistp)
			{
				PIN_FLIST_SUBSTR_SET(rch_flistp, loan_info_flistp, PIN_FLD_LOAN_INFO, ebufp);
			}
		}
		else
		{
			act_rch_amt = pbo_decimal_negate(topup_amt, ebufp);
			PIN_FLIST_FLD_PUT(rch_flistp, PIN_FLD_CREDIT_AMOUNT, act_rch_amt, ebufp);
		}
	}
	else
	{
		TAB_LOG_SET_ERR(pymt_topup_iflistp, TAB_ERR_CODE_API_RECHARGE,
				"fm_tab_subscription_recharge: Payment Topup returned NULL ", ebufp);
		goto cleanup;
	}

	t_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_OVERRIDE_OFFERS, PIN_ELEMID_ANY, 1, ebufp);

	if (t_flistp != NULL)
	{
		fm_tab_sub_update_prepaid_svc_validity(ctxp, rch_flistp, db_no, &updt_svc_flistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
				" fm_tab_sub_update_prepaid_svc_validity return flist ", rch_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_sub_update_prepaid_svc_validity error", ebufp);
			goto cleanup;
		}

		// Pass the service validity to update in the recharge custom object
		PIN_FLIST_FLD_COPY(updt_svc_flistp, PIN_FLD_EFFECTIVE_END_T,
					rch_flistp, PIN_FLD_EFFECTIVE_END_T, ebufp);
	}

	rch_offer_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_IN_FLIST, PIN_ELEMID_ANY, 1, ebufp);

	if (rch_offer_flistp != NULL)
	{
		/***************************************************
		 * Read Account Object
		 ***************************************************/
		 
		readaccnt_in_flistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_ACCOUNT_OBJ, readaccnt_in_flistp, PIN_FLD_POID, ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
			" read account input flist ", readaccnt_in_flistp);
		
		PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, readaccnt_in_flistp, &readaccnt_out_flistp, ebufp);
		PIN_FLIST_DESTROY_EX(&readaccnt_in_flistp,ebufp);
		
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
				" error PCM_OP_READ_OBJ error input flist ", rch_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" read account obj error", ebufp);
			goto cleanup;
		}
		
		/***************************************************
		 * Copy account no field to the input for fm_tab_cust_purchase_offer
		 ***************************************************/
		if (readaccnt_out_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(readaccnt_out_flistp, PIN_FLD_ACCOUNT_NO, rch_offer_flistp, PIN_FLD_ACCOUNT_NO,ebufp);
		}

		/***************************************************
		 * Copy account no field to the input for fm_tab_cust_purchase_offer
		 ***************************************************/
		if (enrichtopup_out_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(enrichtopup_out_flistp, PIN_FLD_ZONEMAP_TARGET , rch_offer_flistp, PIN_FLD_ZONEMAP_TARGET, ebufp);
			PIN_FLIST_FLD_COPY(enrichtopup_out_flistp, PIN_FLD_ZONEMAP_NAME, rch_offer_flistp, PIN_FLD_ZONEMAP_NAME, ebufp);
		}
		// Call TAB_OP_CUST_PURCHASE_OFFER function to purchase offer
		// which grants Bonus resources or any other resource balances 
		fm_tab_cust_purchase_offer(ctxp, rch_offer_flistp, &o_flistp, db_no, notify_flag, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_cust_purchase_offer input flist ", rch_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
				" fm_tab_cust_purchase_offer error", ebufp);
			goto cleanup;
		}
	}

	/*********************************************************
	 * Prepare input flist and call OOB opcode
	 * PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
	 *******************************************************/
	fm_tab_subscription_recharge_recurring_renewal(ctxp, rch_flistp, db_no, &rch_rec_rnwl_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_subscription_recharge_recurring_renewal input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_subscription_recharge_recurring_renewal error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(rch_rec_rnwl_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	/***************************************************
	 * Call Util function to fetch the Balance
	 ***************************************************/
	balances_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_BAL_GRP_OBJ, balances_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(balances_iflistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency, ebufp);

	fm_tab_utils_common_subscr_get_current_main_balance(ctxp,
			balances_iflistp, &balances_oflistp, db_no, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_current_main_balance Input", balances_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_current_main_balance Error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_BALANCE_NOT_FOUND, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge: "
			"fm_tab_utils_common_subscr_get_current_main_balance return Flist", balances_oflistp);
	PIN_FLIST_FLD_COPY(balances_oflistp, PIN_FLD_CURRENT_BAL, rch_flistp, PIN_FLD_CURRENT_BAL, ebufp);

	/***************************************************
	 * Enhance before creating custom object
	 ***************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_recharge: Enrich Recharge Record input flistp", rch_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_RECORD , 0, rch_flistp, &enrichrechargerec_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge: Error processing Enrich Result  input flist", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		rch_ret_flistp = PIN_FLIST_COPY(enrichrechargerec_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_recharge: Enrich Recharge Record output flistp", enrichrechargerec_out_flistp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
							"fm_tab_subscription_recharge: Before Enrich Create Record input flistp", rch_flistp);
	
	if (enrichrechargerec_out_flistp != NULL)
	{
		enrichtax_dcmlp = PIN_FLIST_FLD_GET(enrichrechargerec_out_flistp, PIN_FLD_TAX, 1, ebufp);
			
		if (!pbo_decimal_is_null(enrichtax_dcmlp, ebufp))
		{
			if ((amts_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_AMOUNTS, 0, 1, ebufp)) == NULL)
			{
				amts_flistp = PIN_FLIST_ELEM_ADD(rch_flistp,PIN_FLD_AMOUNTS, 0, ebufp);
			}
			
			if ((taxamt_dcmlp = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_TAX, 1, ebufp)) != NULL)
			{
				PIN_FLIST_FLD_DROP(amts_flistp, PIN_FLD_TAX, ebufp);
			}
			
			PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, PIN_FLD_TAX, amts_flistp, PIN_FLD_TAX, ebufp);
			PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_WHT_TAX_AMT, amts_flistp, TAB_FLD_WHT_TAX_AMT, ebufp);
			PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_FED_TAX_AMT, amts_flistp, TAB_FLD_FED_TAX_AMT, ebufp);
			PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_SALES_TAX_AMT, amts_flistp, TAB_FLD_SALES_TAX_AMT, ebufp);
			creditamt_dcmlp =  PIN_FLIST_FLD_GET(rch_flistp, PIN_FLD_CREDIT_AMOUNT, 1, ebufp);
				
			if (pbo_decimal_is_null(creditamt_dcmlp, ebufp) == 0)
			{
				newcreditamt_dcmlp = pbo_decimal_add(creditamt_dcmlp, enrichtax_dcmlp, ebufp);
				
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_recharge : Calculation of the New Credit Amount Receives an error", ebufp);
					goto cleanup;
				}
				
				PIN_FLIST_FLD_DROP(rch_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
				PIN_FLIST_FLD_SET(rch_flistp, PIN_FLD_CREDIT_AMOUNT, newcreditamt_dcmlp, ebufp);
			}
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_recharge: After Enrich Create Record input flistp", rch_flistp);
	
	rechargerecwithbal_in_flistp = PIN_FLIST_COPY(rch_flistp, ebufp);
	if(balances_arr_oflistp != NULL)
	{
		if(PIN_FLIST_FLD_GET(balances_arr_oflistp, PIN_FLD_POID, 1, ebufp) != NULL)
		{
			PIN_FLIST_FLD_DROP(balances_arr_oflistp, PIN_FLD_POID, ebufp);
		}
		PIN_FLIST_CONCAT(rechargerecwithbal_in_flistp, balances_arr_oflistp, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge:"
		"After apending balances array input flistp", rechargerecwithbal_in_flistp);
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_RECHARGE_PREV_BALANCE, 0, rechargerecwithbal_in_flistp, &rechargerecwithbal_out_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge: Error in TAB_OP_SUBSCRIPTION_POL_RECHARGE_PREV_BALANCE input flist", rechargerecwithbal_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge:  Error TAB_OP_SUBSCRIPTION_POL_RECHARGE_PREV_BALANCE", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		rch_ret_flistp = PIN_FLIST_COPY(rechargerecwithbal_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_recharge: TAB_OP_SUBSCRIPTION_POL_RECHARGE_PREV_BALANCE output flistp", rechargerecwithbal_out_flistp);

	/***************************************************
	 * Create entry in Custom Object
	 ***************************************************/
	fm_tab_sub_prepaid_create_recharge_record(ctxp, rechargerecwithbal_out_flistp, db_no, &rch_rec_flistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_sub_prepaid_create_recharge_record input flist ", rch_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_sub_prepaid_create_recharge_record error", ebufp);
		goto cleanup;
	}

	if (rch_rec_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(rch_rec_flistp, PIN_FLD_POSTED_T, rch_flistp, PIN_FLD_POSTED_T, ebufp);
	}

	// Prepare Return Flist

	rch_ret_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_ACCOUNT_OBJ, rch_ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_MSISDN, rch_ret_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_TRANS_ID, rch_ret_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(rch_flistp, PIN_FLD_CREDIT_AMOUNT, rch_ret_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(balances_oflistp, PIN_FLD_CURRENT_BAL, rch_ret_flistp, PIN_FLD_CURRENT_BAL, ebufp);

	amts_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY, 1, ebufp);
	if (amts_flistp != NULL)
	{
		rch_tax = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_TAX, 1, ebufp);
		rch_tax_fed = PIN_FLIST_FLD_GET(amts_flistp, TAB_FLD_FED_TAX_AMT, 1, ebufp);
		rch_tax_sales = PIN_FLIST_FLD_GET(amts_flistp, TAB_FLD_SALES_TAX_AMT, 1, ebufp);
		rch_tax_wht = PIN_FLIST_FLD_GET(amts_flistp, TAB_FLD_WHT_TAX_AMT, 1, ebufp);
	}

	if (!pbo_decimal_is_null(rch_tax, ebufp))
	{
		PIN_FLIST_FLD_SET(rch_ret_flistp, PIN_FLD_TAX, rch_tax, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(rch_ret_flistp, PIN_FLD_TAX, zero_val, ebufp);
	}
	if (!pbo_decimal_is_null(rch_tax_fed, ebufp))
	{
		PIN_FLIST_FLD_SET(rch_ret_flistp, TAB_FLD_FED_TAX_AMT, rch_tax_fed, ebufp);
	}
	if (!pbo_decimal_is_null(rch_tax_sales, ebufp))
	{
		PIN_FLIST_FLD_SET(rch_ret_flistp, TAB_FLD_SALES_TAX_AMT, rch_tax_sales, ebufp);
	}
	if (!pbo_decimal_is_null(rch_tax_wht, ebufp))
	{
		PIN_FLIST_FLD_SET(rch_ret_flistp, TAB_FLD_WHT_TAX_AMT, rch_tax_wht, ebufp);
	}

	t_flistp = NULL;
	t_flistp = PIN_FLIST_ELEM_GET(rch_flistp, PIN_FLD_OVERRIDE_OFFERS, PIN_ELEMID_ANY, 1, ebufp);
	if (t_flistp)
	{
		rch_validity_t = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_EFFECTIVE_END_T, 1, ebufp);
		svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, rch_validity_t, ebufp);
		PIN_FLIST_FLD_SET(rch_ret_flistp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt, ebufp);
		PIN_FLIST_FLD_COPY(t_flistp, PIN_FLD_VALIDITY_IN_DAYS, rch_ret_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);
	}
	else
	{
		rch_validity_t = PIN_FLIST_FLD_GET(rch_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
		svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, rch_validity_t, ebufp);
		PIN_FLIST_FLD_SET(rch_ret_flistp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt, ebufp);
		PIN_FLIST_FLD_SET(rch_ret_flistp, PIN_FLD_VALIDITY_IN_DAYS, &default_val, ebufp);
	}

	free(svc_validity_dt);

	context_info_flistp =  PIN_FLIST_SUBSTR_GET(rch_flistp, PIN_FLD_CONTEXT_INFO, 0, ebufp);
	PIN_FLIST_FLD_COPY(context_info_flistp, PIN_FLD_CORRELATION_ID,
				rch_ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(context_info_flistp, PIN_FLD_EXTERNAL_USER,
				rch_ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	elemid = 0;
	cookie = NULL;
	while ((resource_flistp = PIN_FLIST_ELEM_GET_NEXT(rch_flistp,
		PIN_FLD_RESOURCE_INFO, &elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		res_ret_flistp = PIN_FLIST_ELEM_ADD(rch_ret_flistp, PIN_FLD_RESOURCE_INFO, elemid, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_ID,
					res_ret_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_NAME,
					res_ret_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_UNIT_STR,
					res_ret_flistp, PIN_FLD_UNIT_STR, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_CURRENT_BAL,
					res_ret_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	}
	if(enrichrechargerec_out_flistp != NULL)
	{	
		PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_BUNDLE_NAME,
				rch_ret_flistp, TAB_FLD_BUNDLE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, PIN_FLD_STATUS_STR,
				rch_ret_flistp, PIN_FLD_STATUS_STR, ebufp);
		PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_FCA_IND,
				rch_ret_flistp, TAB_FLD_FCA_IND, ebufp);
		PIN_FLIST_FLD_COPY(enrichrechargerec_out_flistp, TAB_FLD_SVC_FEE,
				rch_ret_flistp, TAB_FLD_SVC_FEE, ebufp);	
	}
	enrichresult_in_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichresult_in_flistp, rch_ret_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_recharge: Enrich Results input flistp", enrichresult_in_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_RESULTS , 0, enrichresult_in_flistp, &enrichresult_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge: Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		rch_ret_flistp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_recharge: Enrich Results output flistp", enrichresult_out_flistp);
				
	/***************************************************
	 * Finalization of return flist
	 ****************************************************/
	if (enrichresult_out_flistp != NULL)
	{
		PIN_FLIST_DESTROY_EX(&rch_ret_flistp, ebufp);
		rch_ret_flistp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
	}
	
	*out_flistpp = PIN_FLIST_COPY(rch_ret_flistp, ebufp);
	
	/***************************************************
	 * Preparation of input flistp for notification
	 ****************************************************/
	 
	elemid = 0;
	if (pymt_topup_oflistp != NULL)
	{
		PIN_FLIST_ELEM_SET(rch_ret_flistp, pymt_topup_oflistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	}

	if (updt_svc_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(rch_ret_flistp, updt_svc_flistp, PIN_FLD_RESULTS_DATA, 1, ebufp);
	}

	if (o_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(rch_ret_flistp, o_flistp, PIN_FLD_RESULTS_DATA, 2, ebufp);
	}

	if (rch_rec_rnwl_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(rch_ret_flistp, rch_rec_rnwl_flistp, PIN_FLD_RESULTS_DATA, 3, ebufp);
	}

	if (loan_recover_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(rch_ret_flistp, loan_recover_flistp, PIN_FLD_RESULTS_DATA, 4, ebufp);
	}

	// Call function to enrich notification details
	fm_tab_subscription_recharge_enrich_notification(ctxp, rch_flistp, rch_ret_flistp, db_no, &notify_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge:"
			" fm_tab_subscription_recharge_enrich_notification input flist ", notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge: "
			" fm_tab_subscription_recharge_enrich_notification error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(notify_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (notify_oflistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
								PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						*out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&create_rch_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&o_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_ret_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_rec_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&offer_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_valid_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_record_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&updt_svc_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&pymt_topup_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&pymt_topup_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&readaccnt_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_rec_rnwl_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&balances_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&balances_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichresult_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichresult_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichtopup_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichtopup_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrichrechargerec_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&balances_arr_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&balances_arr_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rechargerecwithbal_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rechargerecwithbal_out_flistp, NULL);

	pbo_decimal_destroy(&zero_val);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge output flist", *out_flistpp);
	return;
}


/*************************************************************
 *  This function will validate the subscriber lifecycle
 *  state with the recharge eligible life cycle states
 *  from Config object and return TRUE if eligible state
 *************************************************************/

int32
fm_tab_sub_prepaid_recharge_validate_state(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	pin_flist_t	*sub_status_flistp = NULL;
	int32		prepaid_rch_status = 0;
	int32		subscriber_status = 0;
	int32		elemid = 0;
	int32		is_valid = PIN_BOOLEAN_FALSE;
	pin_cookie_t	cookie = NULL;
	void		*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_prepaid_recharge_validate_state function entry error", ebufp);
		return is_valid;
	}

	if (cfg_tab_prepaid_sub_states_flistp == NULL)
	{
		TAB_LOG_SET_ERR(i_flistp, TAB_ERR_CODE_MISSING_RCH_CONFIG_DATA,
		"fm_tab_sub_prepaid_recharge_validate_state: Recharge Valid states config error", ebufp);
		return is_valid;
	}

	vp = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_LIFECYCLE_STATE, 1, ebufp);
	if (vp != NULL)
	{
		subscriber_status = *(int32 *)vp;
	}

	vp = NULL;
	elemid = 0;
	cookie = NULL;
	while ((sub_status_flistp = PIN_FLIST_ELEM_GET_NEXT(cfg_tab_prepaid_sub_states_flistp,
		PIN_FLD_SERVICE_CODES, &elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_prepaid_recharge_validate_state:"
				" Valid Recharge Status ", sub_status_flistp);
		vp = PIN_FLIST_FLD_GET(sub_status_flistp, PIN_FLD_STATUS, 0, ebufp);
		if (vp != NULL)
		{
			prepaid_rch_status = *(int32 *)vp;
		}

		if (subscriber_status == prepaid_rch_status)
		{
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_prepaid_recharge_validate_state:"
				" Subscriber Status is Valid");
			is_valid = PIN_BOOLEAN_TRUE;
			break ;
		}
	}

	return is_valid;
}


/*************************************************************
 *  This function will validate the input flist for any 
 *  missing mandatory fields expected as part of the input
 *  Return error in case of any missing fields
 *************************************************************/

void
fm_tab_sub_recharge_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{

	char			*in_rch_ref_id = NULL;
	char			*in_trade_type = NULL;
	char			*in_rch_msisdn = NULL;
	pin_decimal_t		*in_rch_amt = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_recharge_validate_input function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_recharge_validate_input: "
		"fm_tab_sub_recharge_validate_input_validate_input input flist", i_flistp);

	in_rch_msisdn = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_MSISDN, 1, ebufp);

	if((in_rch_msisdn == NULL) || (in_rch_msisdn && strlen(in_rch_msisdn) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_recharge_validate_input:"
			"Recharge MSISDN is not passed/empty", ebufp);
		return;
	}
	
	in_rch_ref_id = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if((in_rch_ref_id == NULL) || (in_rch_ref_id && strlen(in_rch_ref_id) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_recharge_validate_input:"
			"Recharge Reference ID is not passed/empty", ebufp);
		return;
	}
	
	in_rch_amt = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_AMOUNT, 1, ebufp);

	if( pbo_decimal_is_null(in_rch_amt, ebufp) )
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_recharge_validate_input:"
			"Recharge Amount is not passed/empty", ebufp);
		return;
	}

	in_trade_type = PIN_FLIST_FLD_GET(i_flistp, TAB_FLD_TRADE_TYPE, 1, ebufp);

	if((in_trade_type == NULL) || (in_trade_type && strlen(in_trade_type) == 0))
	{

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_RECHARGE_TYPE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_recharge_validate_input:"
			"Recharge Type / Trade Type is not passed/empty", ebufp);
		return;
	}

	return;
}


/*************************************************************
 *  This function will call BU specific Policy Hook opcodes
 *  to enrich the recharge details to proceed with recharge
 *  transaction and return the flist
 *************************************************************/

void
fm_tab_sub_prepaid_enrich_recharge(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*rch_purchase_oflistp = NULL;
	pin_flist_t		*purchase_flistp = NULL;
	pin_flist_t		*enrich_flistp = NULL;
	pin_flist_t		*temp_i_flistp = NULL; 
	pin_flist_t		*rch_tax_oflistp = NULL;
	pin_flist_t		*rch_val_oflistp = NULL;
	pin_flist_t		*resource_flistp = NULL;
	pin_flist_t		*amts_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_cookie_t		cookie = NULL;
	int32			elemid = 0;
	int32			error_code = 0;
	void			*vp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_prepaid_enrich_recharge function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_prepaid_enrich_recharge: "
					"input flist", i_flistp);

	enrich_flistp = PIN_FLIST_COPY(i_flistp, ebufp);
	temp_i_flistp = PIN_FLIST_COPY(enrich_flistp, ebufp); 

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_prepaid_enrich_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX input flist ", temp_i_flistp);

	// Call the HOOK opcode to fetch recharge amount and tax amount
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX, 0, temp_i_flistp , &rch_tax_oflistp, ebufp); //Leak fix Recharge 6

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX return flist ", temp_i_flistp ); //Leak fix Recharge 6
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX return flist ", rch_tax_oflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge: "
			 " TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(rch_tax_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_prepaid_enrich_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_TAX return flist ", rch_tax_oflistp);

	if (rch_tax_oflistp != NULL)
	{
		amts_flistp = PIN_FLIST_ELEM_GET(rch_tax_oflistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY, 1, ebufp);
	}

	if (amts_flistp != NULL)
	{
		PIN_FLIST_ELEM_COPY(rch_tax_oflistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY,
					temp_i_flistp, PIN_FLD_AMOUNTS, 0, ebufp);

		PIN_FLIST_ELEM_COPY(rch_tax_oflistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY,
					enrich_flistp, PIN_FLD_AMOUNTS, 0, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_prepaid_enrich_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY input flist ", temp_i_flistp);

	// Call the HOOK opcode to fetch recharge validity and deal to purchase
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY, 0, temp_i_flistp, &rch_val_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY return flist ", enrich_flistp);

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge: "
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(rch_val_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_prepaid_enrich_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_OFFER_VALIDITY return flist ", rch_val_oflistp);

	if (rch_val_oflistp != NULL)
	{
		res_flistp = PIN_FLIST_ELEM_GET(rch_val_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	}

	if (res_flistp != NULL)
	{

		PIN_FLIST_ELEM_COPY(rch_val_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY,
					enrich_flistp, PIN_FLD_OVERRIDE_OFFERS, 0, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_prepaid_enrich_recharge:"
		" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_PREP_PURCHASE_OFFER input flist ", enrich_flistp);

	// Call the HOOK opcode to fetch deal to purchase and grant resources
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_PREP_PURCHASE_OFFER, 0,
					enrich_flistp, &rch_purchase_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_PREP_PURCHASE_OFFER return flist ", enrich_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_prepaid_enrich_recharge: "
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_RECHARGE_PREP_PURCHASE_OFFER error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(rch_purchase_oflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}
	 	                                                  
	if (rch_purchase_oflistp != NULL)
	{
		purchase_flistp = PIN_FLIST_SUBSTR_GET(rch_purchase_oflistp, PIN_FLD_IN_FLIST, 1, ebufp);
		if (purchase_flistp != NULL)
		{
			vp = PIN_FLIST_SUBSTR_GET(rch_purchase_oflistp, PIN_FLD_IN_FLIST, 1, ebufp);
			PIN_FLIST_SUBSTR_SET(enrich_flistp, vp, PIN_FLD_IN_FLIST, ebufp);
		}

		elemid = 0;
		cookie = NULL;
		while ((resource_flistp = PIN_FLIST_ELEM_GET_NEXT(rch_purchase_oflistp,
			PIN_FLD_RESOURCE_INFO, &elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_FLIST_ELEM_COPY(rch_purchase_oflistp, PIN_FLD_RESOURCE_INFO, elemid,
						enrich_flistp, PIN_FLD_RESOURCE_INFO, elemid, ebufp);
		}
	}

	*r_flistpp = PIN_FLIST_COPY(enrich_flistp, ebufp); 

cleanup:
	PIN_FLIST_DESTROY_EX(&temp_i_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_purchase_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_val_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&rch_tax_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		" fm_tab_sub_prepaid_enrich_recharge: output flist", *r_flistpp);
	return;
}


/*************************************************************
 *  This function will prepare the flist and call
 *  PCM_OP_CREATE_OBJ to create record in custom object 
 *  for recharge and return the flist
 *************************************************************/

void
fm_tab_sub_prepaid_create_recharge_record(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*create_rch_iflistp = NULL;
	pin_flist_t		*create_rch_oflistp = NULL;
	pin_flist_t		*resource_flistp = NULL;
	pin_flist_t		*res_ret_flistp = NULL;
	pin_flist_t		*amts_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*loan_info_flistp = NULL;
	poid_t			*rch_pdp = NULL;
	pin_decimal_t		*rch_tax = NULL;
	int32			*validity = NULL;
	int32			record_status = 0;
	int32			elemid = 0;
	pin_cookie_t		cookie = NULL;
	time_t			now_t = pin_virtual_time(NULL);
	time_t			*validity_t = NULL;
	time_t			rch_req_t = 0;
	char			*rch_req_dt = NULL;
	char			*svc_validity_dt = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_prepaid_create_recharge_record function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_prepaid_create_recharge_record: "
					"input flist", i_flistp);

	// Call CREATE_OBJ opcode to create /tab_prepaid_subscriber_recharge object
	create_rch_iflistp = PIN_FLIST_CREATE(ebufp);
	rch_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_PREPAID_SUB_RECHARGE, -1, ebufp);
	PIN_FLIST_FLD_PUT(create_rch_iflistp, PIN_FLD_POID, rch_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, create_rch_iflistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, create_rch_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, create_rch_iflistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_TRADE_TYPE, create_rch_iflistp, TAB_FLD_TRADE_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_TRADE_CHANNEL, create_rch_iflistp, TAB_FLD_TRADE_CHANNEL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CARD_NUM, create_rch_iflistp, TAB_FLD_CARD_NUM, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CHANNEL, create_rch_iflistp, PIN_FLD_CHANNEL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_MODE, create_rch_iflistp, TAB_FLD_PYMT_MODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_CATEGORY, create_rch_iflistp, TAB_FLD_PYMT_CATEGORY, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_METHOD, create_rch_iflistp, TAB_FLD_PYMT_METHOD, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_AGENT_ID, create_rch_iflistp, TAB_FLD_AGENT_ID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_AGENT_NAME, create_rch_iflistp, TAB_FLD_AGENT_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BANK_CODE, create_rch_iflistp, PIN_FLD_BANK_CODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EXT_INFO_STR, create_rch_iflistp, PIN_FLD_EXT_INFO_STR, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_RECEIPT_NO, create_rch_iflistp, PIN_FLD_RECEIPT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_OFFER_NAME, create_rch_iflistp, PIN_FLD_OFFER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_EVENT_OBJ, create_rch_iflistp, PIN_FLD_EVENT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BRANCH_NO, create_rch_iflistp, PIN_FLD_BRANCH_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_OPEN_BAL, create_rch_iflistp, PIN_FLD_OPEN_BAL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CLOSE_BAL, create_rch_iflistp, PIN_FLD_CLOSE_BAL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CREDIT_AMOUNT, create_rch_iflistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LOCATION, create_rch_iflistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NODE_LOCATION, create_rch_iflistp, PIN_FLD_NODE_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CURRENT_BAL, create_rch_iflistp, PIN_FLD_BALANCE_AMOUNT, ebufp);

	rch_req_dt = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_AUTH_DATE, 1, ebufp);
	if (rch_req_dt)
	{
		rch_req_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_req_dt, ebufp);
		PIN_FLIST_FLD_SET(create_rch_iflistp, PIN_FLD_REQ_DATE_T, &rch_req_t, ebufp);
	}

	PIN_FLIST_FLD_SET(create_rch_iflistp, PIN_FLD_CANCEL_FLAGS, &record_status, ebufp);

	amts_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_AMOUNTS, PIN_ELEMID_ANY, 1, ebufp);
	if (amts_flistp != NULL)
	{
		rch_tax = PIN_FLIST_FLD_GET(amts_flistp, PIN_FLD_TAX, 1, ebufp);
	}

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, create_rch_iflistp, PIN_FLD_AMOUNT, ebufp);

	if  (!pbo_decimal_is_null(rch_tax, ebufp))
	{
		PIN_FLIST_FLD_SET(create_rch_iflistp, PIN_FLD_TAX, rch_tax, ebufp);
	}

	PIN_FLIST_FLD_SET(create_rch_iflistp, PIN_FLD_POSTED_T, &now_t, ebufp);

	res_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_OVERRIDE_OFFERS, PIN_ELEMID_ANY, 1, ebufp);
	if (res_flistp != NULL)
	{
		validity = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_VALIDITY_IN_DAYS, 1, ebufp);
		PIN_FLIST_FLD_SET(create_rch_iflistp, PIN_FLD_VALIDITY_IN_DAYS, validity, ebufp);
		validity_t = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_EFFECTIVE_END_T, 1, ebufp);
		if (validity_t == NULL)
		{
			validity_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_EFFECTIVE_END_T, 1, ebufp);
		}
	}
	else
	{
		validity_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
	}
	
	svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, validity_t, ebufp);
	PIN_FLIST_FLD_SET(create_rch_iflistp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt, ebufp);

	elemid = 0;
	cookie = NULL;
	while ((resource_flistp = PIN_FLIST_ELEM_GET_NEXT(i_flistp,
		PIN_FLD_RESOURCE_INFO, &elemid, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		res_ret_flistp = PIN_FLIST_ELEM_ADD(create_rch_iflistp, PIN_FLD_RESOURCE_INFO, elemid, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_ID,
					res_ret_flistp, PIN_FLD_RESOURCE_ID, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_NAME,
					res_ret_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_UNIT_STR,
					res_ret_flistp, PIN_FLD_UNIT_STR, ebufp);
		PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_CURRENT_BAL,
					res_ret_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	}

	loan_info_flistp = PIN_FLIST_SUBSTR_GET(i_flistp, PIN_FLD_LOAN_INFO, 1, ebufp);
	if (loan_info_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(loan_info_flistp, PIN_FLD_AMOUNT,
					create_rch_iflistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, ebufp);
		PIN_FLIST_FLD_COPY(loan_info_flistp, PIN_FLD_OUTSTANDING_AMOUNT,
					create_rch_iflistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_sub_prepaid_create_recharge_record:"
		" PCM_OP_CREATE_OBJ input flist ", create_rch_iflistp);
	PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, create_rch_iflistp, &create_rch_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_sub_prepaid_create_recharge_record:"
			" PCM_OP_CREATE_OBJ input flist ", create_rch_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_sub_prepaid_create_recharge_record: "
			" PCM_OP_CREATE_OBJ error", ebufp);
		goto cleanup;
	}

	// Send the below fields in return flist for further processing
	PIN_FLIST_FLD_SET(create_rch_oflistp, PIN_FLD_POSTED_T, &now_t, ebufp);
	PIN_FLIST_FLD_SET(create_rch_oflistp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt, ebufp);

cleanup:
	PIN_FLIST_DESTROY_EX(&create_rch_iflistp, NULL);
	free(svc_validity_dt);

	*r_flistpp = create_rch_oflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_prepaid_create_recharge_record output flist", *r_flistpp);
	return;
}


/*************************************************************
 *  This function will prepare the flist and call
 *  PCM_OP_CUST_UPDATE_SERVICES to update the service 
 *  valididty and return the flist
 *************************************************************/

void
fm_tab_sub_update_prepaid_svc_validity(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*updt_svc_iflistp = NULL;
	pin_flist_t		*updt_svc_oflistp = NULL;
	pin_flist_t		*services_flistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	time_t			*rch_validity_t = NULL;
	time_t			*svc_validity_t = NULL;
	int32 			*rch_life_state = NULL;
	int32           *existing_life_state = NULL;
	int32 			rch_valid_days = 0;
	void			*vp = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_update_prepaid_svc_validity function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_update_prepaid_svc_validity: "
					"input flist", i_flistp);

	t_flistp = PIN_FLIST_ELEM_GET(i_flistp, PIN_FLD_OVERRIDE_OFFERS, PIN_ELEMID_ANY, 1, ebufp);
	if (t_flistp)
	{
		rch_validity_t = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_EFFECTIVE_END_T, 1, ebufp);
		rch_life_state = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_NEW_STATE, 1, ebufp);
		existing_life_state = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_LIFECYCLE_STATE, 1, ebufp);
		vp = PIN_FLIST_FLD_GET(t_flistp, PIN_FLD_VALIDITY_IN_DAYS, 1, ebufp);
		if (vp)
			rch_valid_days = *(int32 *)vp;

		svc_validity_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
		if ((rch_validity_t == NULL) && (rch_valid_days != 0) )
		{
			fm_utils_add_n_days(rch_valid_days, svc_validity_t);
			rch_validity_t = svc_validity_t;
			PIN_FLIST_FLD_SET(t_flistp, PIN_FLD_EFFECTIVE_END_T, svc_validity_t, ebufp);
		}
	}

	// Call PCM_OP_CUST_UPDATE_SERVICES opcode to update the subscriber validity
	if ( (rch_validity_t != NULL) || ((rch_life_state != NULL) && (*rch_life_state != 0)) )
	{
		//updt_svc_iflistp = PIN_FLIST_CREATE(ebufp);
		//PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, updt_svc_iflistp, PIN_FLD_POID, ebufp);
		//PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, updt_svc_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
		//PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, updt_svc_iflistp, PIN_FLD_DESCR, ebufp);
		//services_flistp =  PIN_FLIST_ELEM_ADD(updt_svc_iflistp, PIN_FLD_SERVICES, 1, ebufp);
		//PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, services_flistp, PIN_FLD_POID, ebufp);

		if (rch_validity_t)
			PIN_FLIST_FLD_SET(i_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, rch_validity_t, ebufp);

		if (rch_life_state)
		{	
			PIN_FLIST_FLD_SET(i_flistp, PIN_FLD_LIFECYCLE_STATE, rch_life_state, ebufp);
		}
		else
		{
			PIN_FLIST_FLD_SET(i_flistp, PIN_FLD_LIFECYCLE_STATE, existing_life_state, ebufp);
		}

		//vp = PIN_FLIST_SUBSTR_GET(i_flistp, PIN_FLD_CONTEXT_INFO, 0, ebufp);
		//PIN_FLIST_SUBSTR_SET(updt_svc_iflistp, vp, PIN_FLD_CONTEXT_INFO, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_update_prepaid_svc_validity:"
			" PCM_OP_CUST_UPDATE_SERVICES input flist ", updt_svc_iflistp);

		//PCM_OP(ctxp, PCM_OP_CUST_UPDATE_SERVICES, 0, updt_svc_iflistp, &updt_svc_oflistp, ebufp);

		fm_tab_utils_common_resume_service(ctxp, i_flistp, &updt_svc_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_prepaid_svc_validity:"
				" PCM_OP_CUST_UPDATE_SERVICES input flist ", updt_svc_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_update_prepaid_svc_validity: "
				" PCM_OP_CUST_UPDATE_SERVICES error", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_update_prepaid_svc_validity:"
		" PCM_OP_CUST_UPDATE_SERVICES return flist ", updt_svc_oflistp);

		// Update the validity in the return flist to use in next step
		PIN_FLIST_FLD_SET(updt_svc_oflistp, PIN_FLD_EFFECTIVE_END_T, rch_validity_t, ebufp);
	}

cleanup:
	PIN_FLIST_DESTROY_EX(&updt_svc_iflistp, NULL);

	*r_flistpp = updt_svc_oflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_update_prepaid_svc_validity output flist", *r_flistpp);
	return;
}


/*************************************************************
 *  This function will prepare the notification flist
 *  based on the payload structure.
 *  Will call the Policy Opcode 
 *  TAB_OP_NOTIFY_POL_ENRICH_RECHARGE_NOTIFICATION for
 *  enrichment and return notification flist
 *************************************************************/

static void
fm_tab_subscription_recharge_enrich_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*ret_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*read_iflistp = NULL;
	pin_flist_t		*read_oflistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	char			*rch_evt_date = NULL;
	time_t			*rch_time_t = NULL;
	int32			error_code = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge_enrich_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_recharge_enrich_notification: "
					"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, notify_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);

	rch_time_t = PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_POSTED_T, 1, ebufp);
	if (rch_time_t)
	{
		rch_evt_date = fm_tab_utils_common_convert_timestamp_to_date(ctxp, rch_time_t, ebufp);
	}

	read_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, read_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(read_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge_enrich_notification : Read flds input flist", read_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_iflistp, &read_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" input flist ", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
			" Error while reading Account flds", ebufp);
		goto cleanup;
	}
	
	if (read_oflistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PCM_OP_READ_FLDS, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge_enrich_notification:"
			" input flist", read_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, 
			"fm_tab_subscription_recharge_enrich_notification return error", ebufp);
	}

	// Create Notification Flist 
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_RECHARGE_NOTIFICATION, -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_TRADE_TYPE, notify_flistp, TAB_FLD_TRADE_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_CARD_NUM, notify_flistp, TAB_FLD_CARD_NUM, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CHANNEL, notify_flistp, PIN_FLD_CHANNEL, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_MODE, notify_flistp, TAB_FLD_PYMT_MODE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_CATEGORY, notify_flistp, TAB_FLD_PYMT_CATEGORY, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, TAB_FLD_PYMT_METHOD, notify_flistp, TAB_FLD_PYMT_METHOD, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AUTH_DATE, notify_flistp, PIN_FLD_AUTH_DATE, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, notify_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, notify_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	PIN_FLIST_FLD_COPY(read_oflistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	PIN_FLIST_FLD_COPY(ret_flistp, PIN_FLD_CREDIT_AMOUNT, notify_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, PIN_FLD_TAX, notify_flistp, PIN_FLD_TAX, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, PIN_FLD_CURRENT_BAL, notify_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	PIN_FLIST_FLD_COPY(ret_flistp, TAB_FLD_SVC_VALIDITY_DATE, notify_flistp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);

	PIN_FLIST_FLD_SET(notify_flistp, PIN_FLD_MOD_TIME, rch_evt_date, ebufp);
	free(rch_evt_date);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_RECHARGE_NOTIFICATION input flist ", notify_iflistp);
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_RECHARGE_NOTIFICATION, 0,
				notify_iflistp, &enrich_notify_flistp, ebufp);

	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_recharge_enrich_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_recharge_enrich_notification:"
			" Error in Notification", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge_enrich_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_RECHARGE_NOTIFICATION output flist ", enrich_notify_flistp);

	if (enrich_notify_flistp != NULL)
	{
		out_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);

	}
	*r_flistpp = out_flistp;

cleanup:
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge_enrich_notification output flist", *r_flistpp);
	return;
}


/*************************************************************
 *  This function will prepare the input flist for
 *  PCM_OP_SUBSCRIPTION_CYCLE_FORWARD and pass it to the
 *  Policy Opcode TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL
 *  Based on the return flist from
 *  TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL, the opcode
 *  PCM_OP_SUBSCRIPTION_CYCLE_FORWARD will be called
 *************************************************************/

static void
fm_tab_subscription_recharge_recurring_renewal(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*recurring_cycle_fwd_flistp = NULL;
	pin_flist_t		*cycle_fwd_flistp = NULL;
	pin_flist_t		*out_cycle_fwd_flistp = NULL;
	pin_flist_t		*ret_cycle_fwd_flistp = NULL;
	int32			cycle_fwd_flg = PIN_RATE_FLG_PRO_NORMAL;
	int32			error_code = 0;
	time_t			now_t = pin_virtual_time(NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_recharge_recurring_renewal function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_recharge_recurring_renewal: "
					"input flist", i_flistp);

	/*********************************************************
	 * Prepare input flist for PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
	 *******************************************************/
	recurring_cycle_fwd_flistp = PIN_FLIST_COPY(i_flistp, ebufp);

	cycle_fwd_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, cycle_fwd_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, cycle_fwd_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_BILLINFO_OBJ, cycle_fwd_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_PROGRAM_NAME, cycle_fwd_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_FLAGS, &cycle_fwd_flg, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_END_T, &now_t, ebufp);

	PIN_FLIST_SUBSTR_PUT(recurring_cycle_fwd_flistp, cycle_fwd_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			 "fm_tab_subscription_recharge_recurring_renewal: "
			 "TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL"
					" input flist", recurring_cycle_fwd_flistp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL, 0,
				recurring_cycle_fwd_flistp, &ret_cycle_fwd_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_recharge_recurring_renewal: Error in "
				"TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge_recurring_renewal :"
				       " TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL:"
					"input flist", recurring_cycle_fwd_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*r_flistpp = PIN_FLIST_COPY(ret_cycle_fwd_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge_recurring_renewal:"
		"TAB_OP_SUBSCRIPTION_POL_RECHARGE_RECURRING_RENEWAL return flist ", ret_cycle_fwd_flistp);

	if (ret_cycle_fwd_flistp != NULL)
	{
		/*******************************************************
		 * Call OOB opcode PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
		 *******************************************************/
		PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CYCLE_FORWARD, 0,
				ret_cycle_fwd_flistp, &out_cycle_fwd_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_recharge_recurring_renewal: "
					"PCM_OP_SUBSCRIPTION_CYCLE_FORWARD return Error ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_recharge_recurring_renewal :"
				       " TPCM_OP_SUBSCRIPTION_CYCLE_FORWARD:"
					"input flist", ret_cycle_fwd_flistp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge_recurring_renewal:"
				"No Recurring Renewal triggered");
		goto cleanup;
	}

	*r_flistpp = PIN_FLIST_COPY(out_cycle_fwd_flistp, ebufp);

cleanup:

	PIN_FLIST_DESTROY_EX(&ret_cycle_fwd_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&recurring_cycle_fwd_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&out_cycle_fwd_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_recharge_recurring_renewal output flist", *r_flistpp);
	return;
}

/*************************************************************
 *  This function will prepare search flist and 
 *  call PCM_OP_SEARCH opcode to fetch the Loan Recovery
 *  event details to store the details in custom object 
 *************************************************************/

static void
fm_tab_subscription_fetch_loan_recovery_event(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp =NULL;
	pin_flist_t		*r_flistp =NULL;
	pin_flist_t		*t_flistp =NULL;
	poid_t			*loan_recovery_pdp = NULL;
	poid_t			*srchp = NULL;
	void			*vp = NULL;
	int32			s_flags = SRCH_DISTINCT;
	int32			count = 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_fetch_loan_recovery_event function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_fetch_loan_recovery_event: input flist", in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /event where  F1 = V1 and F2.type like V2 and F3 = V3 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	loan_recovery_pdp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_EVENT_LOAN_RECOVERY, -1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_PUT(args_flistp, PIN_FLD_POID, (void *)loan_recovery_pdp, ebufp);

	vp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_LINK_OBJ, vp, ebufp);

	PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_fetch_loan_recovery_event Search flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_fetch_loan_recovery_event: "
			"PCM_OP_SEARCH Input Flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_fetch_loan_recovery_event: "
			"PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_fetch_loan_recovery_event: "
		"PCM_OP_SEARCH Output Flist", r_flistp);

	count = PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_RESULTS, ebufp);
	if(count > 0)
	{
		t_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if (t_flistp)
		{
			*ret_flistpp = PIN_FLIST_COPY(t_flistp, ebufp);
		}
	}
	else {
		*ret_flistpp = NULL;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_fetch_loan_recovery_event: return flist", *ret_flistpp);

	return;
}

	void
fm_tab_subscription_fetch_recharge_records (
	pcm_context_t           *ctxp,
	pin_flist_t             *in_flistp,
	int64                   db_no,
	pin_flist_t             **ret_flistpp,
	pin_errbuf_t            *ebufp)
{
	pin_flist_t             *transid_srch_iflistp = NULL;
	pin_flist_t             *transid_srch_rflistp = NULL;
	char                    *trans_id =NULL;
	poid_t                  *srchp  = NULL;
	int32                   s_flags = 256;
	void                    *vp = NULL;
	pin_flist_t             *args_flistp = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_fetch_recharge_records:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_fetch_recharge_records function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_fetch_recharge_records:"
			"input flist",in_flistp);
	trans_id=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	transid_srch_iflistp = PIN_FLIST_CREATE(ebufp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	PIN_FLIST_FLD_PUT(transid_srch_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /tab_prepaid_subscriber_recharge where  F1 = V1";
	PIN_FLIST_FLD_SET(transid_srch_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_TRANS_ID , trans_id, ebufp);

	PIN_FLIST_ELEM_ADD(transid_srch_iflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_fetch_recharge_records Search:"
			"input flist", transid_srch_iflistp);
	/***************Perform the search*************************/
	PCM_OP (ctxp, PCM_OP_SEARCH, 0, transid_srch_iflistp, &transid_srch_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
	  PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_fetch_recharge_records:"
			" input flist ", transid_srch_iflistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_RECHARGE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_fetch_recharge_records:"
			"Error while doing search", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_fetch_recharge_records Search:"
			"return flist", transid_srch_rflistp);

cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	*ret_flistpp = PIN_FLIST_COPY(transid_srch_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX (&transid_srch_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&transid_srch_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_fetch_recharge_records final flist", *ret_flistpp);
	return;
}

// End of File
