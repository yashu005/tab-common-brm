/*******************************************************************************
 *
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 ********************************************************************************/

/********************************************************************************
 * Change History
 *
 * No | Date       | Programmer      		| Req/bug/Gap  	 	| Change details
 *
 * 1  | 23/Dec/2021 | Dandi Madhavi		| 			| New opcode implementation to
 *                                               			| add and remove the multi SIM
 *
 *********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_ADD_REMOVE_MULTI_SIM operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_subscription_add_remove_mutli_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_add_remove_mutli_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_subscription_find_deviceid(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_profile_read_obj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_subscription_multisim_find_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_subscription_create_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_modify_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


void
fm_tab_subscription_delete_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*i_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);


/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			status,
	poid_t			*account_pdp,
	char			*opcode_name,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern unsigned long
fm_tab_utils_common_get_max_elemid(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			fld_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

/**
 *
 * New opcode TAB_OP_SUBSCRIPTION_ADD_REMOVE_MULTI_SIM is implemented to 
 * add or delete SIM as secondary SIM
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_ACCOUNTS, PIN_FLD_ACTION
 * PIN_FLD_STATUS
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID          POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_DEVICE_ID      STR [0] " 44446283737"
 * 0 PIN_FLD_MSISDN         STR [0] " 59064563"
 * 0 PIN_FLD_DESCR          STR [0] " Secondary SIM - 44446283737"
 * 0 PIN_FLD_ACTION         STR [0] “add”
 * 0 PIN_FLD_CORRELATION_ID STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER  STR [0] "CRM"

 */

void
op_tab_subscription_add_remove_mutli_sim(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	poid_t			*account_pdp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no=0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
                        "input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_add_remove_mutli_sim function entry error", ebufp);
		return;
	}
	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_ADD_REMOVE_MULTI_SIM) {
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_add_remove_mutli_sim bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_add_remove_mutli_sim input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
			"input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp,in_flistp,error_clear_flag,cerror_code,
			&r_flistp,db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_mutli_sim:"
				" Error while searching /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp,db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM)
		{
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_CODE,log_msg,ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_ADD_REMOVE_MULTISIM,ebufp);
		}

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if(!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
				"input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_mutli_sim: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_add_remove_mutli_sim:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_add_remove_mutli_sim(ctxp, flags, enrich_iflistp, &r_flistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
				"input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_add_remove_mutli_sim:"
				" error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
        
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_mutli_sim:"
			"Error Opening transaction");
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_add_remove_mutli_sim:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_add_remove_mutli_sim: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
		 	&r_flistp, db_no,ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUBSCRIPTION_ADD_REMOVE_MULTI_SIM", &r_flistp, db_no,ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_mutli_sim:"
				" Error while creating /tab_order object", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no,ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM)
		{
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_CODE,log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp,PIN_FLD_ERROR_DESCR,TAB_ERR_DESCR_API_ADD_REMOVE_MULTISIM,ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

	}
        
	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_subscription_add_remove_mutli_sim output flist",*ret_flistpp);
	return;
}

/**
 * We use this function to modify the profile information.
 * If Service array containing alias_list array present in the input
 * call the update service. 
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
static void
fm_tab_subscription_add_remove_mutli_sim(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*secondary_msisdn = NULL;
	char			*action = NULL;
	pin_flist_t		*multisim_find_profile_rflistp = NULL;
	pin_flist_t		*create_profile_rflistp = NULL;
	pin_flist_t		*modify_profile_rflistp = NULL;
	pin_flist_t		*delete_profile_rflistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t 		*profile_readobj_rflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*dup_check_flistp = NULL;
	char			*msisdn = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_add_remove_mutli_sim:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_add_remove_mutli_sim function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_add_remove_mutli_sim: input flist", in_flistp);

	/* Validate the input arguments */
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if ((msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_mutli_sim:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
			" Error PIN_FLD_MSISDN-Input is missing", ebufp);
		goto cleanup;
	}

	secondary_msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_DEVICE_ID, 1, ebufp);
	if ((secondary_msisdn == NULL || strlen(secondary_msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_add_remove_mutli_sim:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			 TAB_ERR_CODE_SECONDARY_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
			" Error PIN_FLD_DEVICE_ID - Input is missing", ebufp);
		goto cleanup;
	}

	action = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACTION, 1, ebufp);
	if ((action == NULL || strlen(action) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_add_remove_mutli_sim:"
			" input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACTION_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
			" Error PIN_FLD_ACTION - Input is missing", ebufp);
		goto cleanup;
	}
		
	if(action && !((strcmp(action, TAB_ACTION_ADD) == 0) || (strcmp(action, TAB_ACTION_DELETE) == 0)))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_add_remove_mutli_sim:"
			" input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_ACTION_CODE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
			" Error Invalid Action Code passed in request", ebufp);
		goto cleanup;
	}

	/*ADD MULTI_SIM*/
	if(action && (strcmp(action, TAB_ACTION_ADD) == 0))
	{
		/*Duplicate Secondary MSISDN check*/
		fm_tab_subscription_find_deviceid(ctxp, flags, in_flistp, &r_flistp, db_no,ebufp);
		if (r_flistp && (dup_check_flistp=PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS,
				PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_add_remove_mutli_sim:"
	 			"input flist", in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUP_DEVICE_ID, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
				"Error Duplicate PIN_FLD_DEVICE_ID found", ebufp);
			goto cleanup;
		}

		/*Multi_Sim Profile Search*/
		fm_tab_subscription_multisim_find_profile(ctxp, flags, in_flistp, 
						&multisim_find_profile_rflistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"MULTISIM_FIND_PROFILE"
                                        " input flist ", in_flistp);	
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"MULTISIM_FIND_PROFILE:"
					" Error while searching profile", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_multisim_find_profile:"
			"return flist",multisim_find_profile_rflistp);

		res_flistp = PIN_FLIST_ELEM_GET(multisim_find_profile_rflistp,PIN_FLD_RESULTS,
				PIN_ELEMID_ANY,1,ebufp);
		if(res_flistp != NULL)
		{
			/* To Read_obj of Profile poid */
			fm_tab_subscription_profile_read_obj(ctxp, flags,res_flistp,
						&profile_readobj_rflistp, db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_profile_read_obj:"
						"input flist", res_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_profile_read_obj:"
						"Modify Profile-READ_OBJ  error ", ebufp);
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Modify Profile READ_OBJ:"
				"return flist", profile_readobj_rflistp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEVICE_ID, profile_readobj_rflistp,
				PIN_FLD_DEVICE_ID,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, profile_readobj_rflistp,
				PIN_FLD_DESCR,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, profile_readobj_rflistp,
				PIN_FLD_CORRELATION_ID,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, profile_readobj_rflistp,
				PIN_FLD_EXTERNAL_USER,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_modify_profile:"
				" input flist", in_flistp);
			/*Modify MULTI_SIM*/
			fm_tab_subscription_modify_profile(ctxp,flags,profile_readobj_rflistp,
					&modify_profile_rflistp,db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_modify_profile:"
						"Modify Profile ", profile_readobj_rflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_modify_profile: "
						"Modify Profile MultiSIM  error ", ebufp);
				goto cleanup;
			}
		}
		else
		{	
			/*Add MULTI_SIM*/
			fm_tab_subscription_create_profile(ctxp,flags,in_flistp,&create_profile_rflistp,db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_profile:"
						"input flist ",in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_profile:"
						"Error while Creating profile", ebufp);
				goto cleanup;
			}

		}
	}

	/*DELETE MULTI_SIM*/
	if(action && (strcmp(action, TAB_ACTION_DELETE) == 0))
	{
		fm_tab_subscription_find_deviceid(ctxp, flags, in_flistp, &r_flistp, db_no,ebufp);
		if (r_flistp && (dup_check_flistp=PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS,
				PIN_ELEMID_ANY, 1, ebufp)) == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_find_deviceid:"
				"input flist ",in_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DEL_PROFILE_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_add_remove_multi_sim:"
				" Error DEVICE_ID trying to delete is not found", ebufp);
			goto cleanup;
		}

		fm_tab_subscription_multisim_find_profile(ctxp, flags, in_flistp, 
						&multisim_find_profile_rflistp, db_no,ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"MULTISIM_FIND_PROFILE"
					" input flist ",in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"MULTISIM_FIND_PROFILE:"
					" Error while searching profile", ebufp);
			goto cleanup;
		}
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_multisim_find_profile:"
			"return flist",multisim_find_profile_rflistp);
		res_flistp=PIN_FLIST_ELEM_GET(multisim_find_profile_rflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,1,ebufp);
		if(res_flistp != NULL)
		{
			/* To Read_obj of Profile poid */
			fm_tab_subscription_profile_read_obj(ctxp,flags,res_flistp,
						&profile_readobj_rflistp, db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_profile_read_obj:"
						"Delete Profile ", res_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_profile_read_obj:"
						"Delete Profile-READ_OBJ  error ", ebufp);
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Delete Profile READ_OBJ return flist",
				profile_readobj_rflistp);
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_DEVICE_ID,profile_readobj_rflistp,
				PIN_FLD_DEVICE_ID,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_CORRELATION_ID,profile_readobj_rflistp,
				PIN_FLD_CORRELATION_ID,ebufp);
			PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_EXTERNAL_USER,profile_readobj_rflistp, 
				PIN_FLD_EXTERNAL_USER,ebufp);
			/*Delete SIM*/
			fm_tab_subscription_delete_profile(ctxp, flags, profile_readobj_rflistp,
				&delete_profile_rflistp,db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{	
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_profile_read_obj:"
					"Delete Profile ", profile_readobj_rflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_profile"
					":Error while Deleting profile", ebufp);
				goto cleanup;
			}
		}		
	}
	/*******************************************************************
	 *          *  Memory Cleanup
	 *******************************************************************/
cleanup:
	PIN_FLIST_DESTROY_EX (&multisim_find_profile_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&profile_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&create_profile_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&modify_profile_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&delete_profile_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	return;
}


void 
fm_tab_subscription_create_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*create_profile_iflistp = NULL;
	pin_flist_t		*create_profile_rflistp = NULL;
	poid_t			*a_pdp = NULL;
	pin_flist_t		*profiles_flistp = NULL;
	pin_flist_t		*inherited_info_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*context_flistp = NULL;

	
	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /profile/tab_multisim_map -1 0
	0 PIN_FLD_ACCOUNT_OBJ    POID [0] 0.0.0.1 /account 18578834 0
	0 PIN_FLD_SERVICE_OBJ    POID [0] 0.0.0.1 /service/telco/gsm 18576978 1
	0 PIN_FLD_NAME            STR [0] "Add Remove Multi SIM"
	0 PIN_FLD_PROFILES       ARRAY [0]  
	1 PIN_FLD_PROFILE_OBJ          POID [0] 0.0.0.1 /profile/tab_multisim_map -1 0
	1 PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 2
	2     PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
	3         PIN_FLD_MISISDN        STR [0] "59064563"
	3         PIN_FLD_DESCR            STR [0] "Secondary SIM - 44446283737"
	3        PIN_FLD_SERVICE_OBJ           POID [0] 0.0.0.1 /service/telco/gsm 16567522 0 
	0 PIN_FLD_CONTEXT_INFO SUBSTRUCT [0] allocated 20, used 2
	1        PIN_FLD_CORRELATION_ID          STR [0] "45344534"
	1        PIN_FLD_EXTERNAL_USER           STR [0] "CRM"*/
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_profile:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_create_profile function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_profile: input flist",in_flistp);

	create_profile_iflistp = PIN_FLIST_CREATE(ebufp);
	
	a_pdp = PIN_POID_CREATE(db_no, "/profile/tab_multisim_map", -1, ebufp);
	PIN_FLIST_FLD_SET(create_profile_iflistp, PIN_FLD_POID, a_pdp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, create_profile_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, create_profile_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_SET(create_profile_iflistp, PIN_FLD_NAME, "Add Remove Multi SIM", ebufp);
	profiles_flistp = PIN_FLIST_ELEM_ADD(create_profile_iflistp, PIN_FLD_PROFILES, 0, ebufp);
	PIN_FLIST_FLD_SET(profiles_flistp, PIN_FLD_PROFILE_OBJ, a_pdp, ebufp);
	inherited_info_flistp = PIN_FLIST_SUBSTR_ADD(profiles_flistp,PIN_FLD_INHERITED_INFO, ebufp);
	data_array_flistp = PIN_FLIST_ELEM_ADD(inherited_info_flistp, PIN_FLD_DATA_ARRAY,1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEVICE_ID, data_array_flistp , PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, data_array_flistp , PIN_FLD_DESCR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, data_array_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	context_flistp = PIN_FLIST_SUBSTR_ADD(create_profile_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_CORRELATION_ID, context_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, context_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Create Profile input flist",create_profile_iflistp );
	/*Call PCM_OP_CUST_CREATE_PROFILE*/
	PCM_OP (ctxp, PCM_OP_CUST_CREATE_PROFILE, 0, create_profile_iflistp, &create_profile_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_CREATE_PROFILE:"
			"input flist ",create_profile_iflistp );
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_CREATE_PROFILE:"
			" Error while creating Profile", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Create Profile return flist",create_profile_rflistp);

cleanup:
	/******************************************************************
	*            * Clean up.
	******************************************************************/
	PIN_POID_DESTROY(a_pdp, NULL);
		PIN_FLIST_DESTROY_EX (&create_profile_iflistp, NULL);

	*ret_flistpp = create_profile_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_create_profile final flist", create_profile_rflistp);
	return;
	}


void 
fm_tab_subscription_modify_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*modify_profile_iflistp = NULL;
	pin_flist_t		*modify_profile_rflistp = NULL;
	poid_t			*profile_pdp = NULL;
	pin_flist_t		*inherited_info_flistp = NULL;
	pin_flist_t		*data_array_flistp = NULL;
	pin_flist_t		*context_flistp = NULL;
	unsigned long		dataarray_max = 0;

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /profile/tab_multisim_map 14547851 0
	0 PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 2
	1     PIN_FLD_DATA_ARRAY    ARRAY [1] allocated 20, used 4
	2         PIN_FLD_MISISDN        STR [0] "59064563"
	2         PIN_FLD_DESCR            STR [0] "Secondary SIM - 44446283737"
	2        PIN_FLD_SERVICE_OBJ           POID [0] 0.0.0.1 /service/telco/gsm 16567522 0 
	0 PIN_FLD_CONTEXT_INFO      SUBSTRUCT [0] 
	1 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
	1 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"*/

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_profile:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_modify_profile function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_modify_profile: input flist",in_flistp);

	modify_profile_iflistp = PIN_FLIST_CREATE(ebufp);

	profile_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	PIN_FLIST_FLD_SET(modify_profile_iflistp, PIN_FLD_POID, profile_pdp, ebufp);

	inherited_info_flistp = PIN_FLIST_SUBSTR_ADD(modify_profile_iflistp,PIN_FLD_INHERITED_INFO, ebufp);
	/* Get max members array elem */
	if (in_flistp != NULL)
	{
		dataarray_max = fm_tab_utils_common_get_max_elemid(ctxp, in_flistp, PIN_FLD_DATA_ARRAY, ebufp);
	}
	data_array_flistp = PIN_FLIST_ELEM_ADD(inherited_info_flistp, PIN_FLD_DATA_ARRAY, ++dataarray_max, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEVICE_ID, data_array_flistp , PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DESCR, data_array_flistp , PIN_FLD_DESCR, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, data_array_flistp, PIN_FLD_SERVICE_OBJ, ebufp);

	context_flistp = PIN_FLIST_SUBSTR_ADD(modify_profile_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_CORRELATION_ID, context_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, context_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Modify Profile input flist",modify_profile_iflistp );
	/*Call PCM_OP_CUST_MODIFY_PROFILE */
	PCM_OP (ctxp, PCM_OP_CUST_MODIFY_PROFILE ,32, modify_profile_iflistp, &modify_profile_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_MODIFY_PROFILE"
			"input flist ",modify_profile_iflistp );
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_MODIFY_PROFILE"
				" Error while modifying the Profile", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Modify Profile return flist",modify_profile_rflistp);

cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&modify_profile_iflistp, NULL);

	*ret_flistpp = modify_profile_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_modify_profile final flist", modify_profile_rflistp);
	return;
}


void 
fm_tab_subscription_delete_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*delete_profile_iflistp = NULL;
	pin_flist_t		*delete_profile_rflistp = NULL;
	char			*secondary_msisdn = NULL;
	pin_flist_t		*res_flistp= NULL;
	pin_flist_t		*data_array_flistp = NULL;
	char			*read_obj_msisdn = NULL;
	pin_flist_t		*inherited_info_flistp = NULL;
	pin_flist_t		*context_flistp = NULL;
	pin_cookie_t		cookie = NULL;
	int32			elem_id = 0;



	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /profile/tab_multisim_map 14547851 0
	0 PIN_FLD_INHERITED_INFO SUBSTRUCT [0] allocated 20, used 3
	1     PIN_FLD_DATA_ARRAY    ARRAY [4]     NULL array ptr
	0 PIN_FLD_CONTEXT_INFO      SUBSTRUCT [0] 
	1 PIN_FLD_CORRELATION_ID      STR [0] "er2345"
	1 PIN_FLD_EXTERNAL_USER      STR [0] "CRM"*/

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_profile:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_delete_profile function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_delete_profile: input flist",in_flistp);
	secondary_msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_DEVICE_ID, 1, ebufp);

	delete_profile_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_POID, delete_profile_iflistp, PIN_FLD_POID, ebufp);

	if(in_flistp && (res_flistp = PIN_FLIST_ELEM_GET(in_flistp,
			PIN_FLD_DATA_ARRAY, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		elem_id = 0;
		cookie = NULL;
		while(in_flistp && (data_array_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp,
				PIN_FLD_DATA_ARRAY,&elem_id,1,&cookie,ebufp)) != (pin_flist_t *)NULL)
		{
			read_obj_msisdn = PIN_FLIST_FLD_GET(data_array_flistp, PIN_FLD_MSISDN, 1, ebufp);
			if (strcmp(secondary_msisdn, read_obj_msisdn) == 0)
			{
				inherited_info_flistp = PIN_FLIST_SUBSTR_ADD(delete_profile_iflistp,
					PIN_FLD_INHERITED_INFO,ebufp);
				PIN_FLIST_ELEM_SET(inherited_info_flistp, NULL, PIN_FLD_DATA_ARRAY, elem_id, ebufp);
			}
		}
	}

	context_flistp = PIN_FLIST_SUBSTR_ADD(delete_profile_iflistp,PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_CORRELATION_ID, context_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY (in_flistp,PIN_FLD_EXTERNAL_USER, context_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Delete Profile input flist",delete_profile_iflistp );
	/*Call PCM_OP_CUST_MODIFY_PROFILE */
	PCM_OP (ctxp, PCM_OP_CUST_MODIFY_PROFILE , 0, delete_profile_iflistp, &delete_profile_rflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_MODIFY_PROFILE:DELETE"
			" input flist ",delete_profile_iflistp );
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_CUST_MODIFY_PROFILE:DELETE"
			" Error while deleting the Profile", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Delete Profile return flist",delete_profile_rflistp);

cleanup:
	/******************************************************************
	 *            * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&delete_profile_iflistp, NULL);

	*ret_flistpp = delete_profile_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_delete_profile final flist", delete_profile_rflistp);
	return;
}


void
fm_tab_subscription_find_deviceid(	
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*dataarray_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	
	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] "select X from /profile/tab_multisim_map where F1 = V1 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_DATA_ARRAY    ARRAY [0] allocated 20, used 3
	2     PIN_FLD_MSISDN          STR [0] "66612202103"
	0 PIN_FLD_RESULTS       ARRAY [0]     NULL array ptr*/	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_find_deviceid input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_find_deviceid function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_find_deviceid: input flist",in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /profile/tab_multisim_map where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	dataarray_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_DATA_ARRAY, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_DEVICE_ID, dataarray_flistp, PIN_FLD_MSISDN, ebufp);

	PIN_FLIST_ELEM_SET(search_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Duplicate_Secondary_MSISDN Search input flist", search_flistp);
	/******Perform the search******/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_find_deviceid input flist", search_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_find_deviceid: Error in getting profile/multisim object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Duplicate_Secondary_MSISDN Search return flist", r_flistp);

cleanup:
	/******************************************************************
	*          * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_find_deviceid final flist", r_flistp);
	return;
}


void
fm_tab_subscription_profile_read_obj(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*profile_readobj_iflistp = NULL;
	pin_flist_t		*profile_readobj_rflistp = NULL;

        /*0 PIN_FLD_POID           POID [0] 0.0.0.1 /profile/tab_multisim_map 1897609 1*/

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_profile_read_obj input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_profile_read_obj function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_profile_read_obj: input flist",in_flistp);

	profile_readobj_iflistp = PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, profile_readobj_iflistp, PIN_FLD_POID, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Read_Obj input flist", profile_readobj_iflistp);
	PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, profile_readobj_iflistp, &profile_readobj_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_profile_read_obj input flist", profile_readobj_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_profile_read_obj: Error while doing profile read_obj", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Read_Obj return flist",profile_readobj_rflistp);

cleanup:
	/******************************************************************
	*          * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&profile_readobj_iflistp, NULL);

	*ret_flistpp = profile_readobj_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_profile_read_obj final flist", profile_readobj_rflistp);
	return;
}


void
fm_tab_subscription_multisim_find_profile(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*multisim_find_profile_iflistp = NULL;
	pin_flist_t		*dataarray_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*multisim_find_profile_rflistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;

	/*0 PIN_FLD_POID           POID [0] 0.0.0.1 /search -1 0
	0 PIN_FLD_FLAGS           INT [0] 256
	0 PIN_FLD_TEMPLATE        STR [0] "select X from /profile/tab_multisim_map where F1 = V1 "
	0 PIN_FLD_ARGS          ARRAY [1] allocated 20, used 1
	1 PIN_FLD_DATA_ARRAY    ARRAY [0] allocated 20, used 3
	2     PIN_FLD_SERVICE_OBJ          POID [0] 0.0.0.1 /service/telco/gsm/telephony 14477444 0
	0 PIN_FLD_RESULTS       ARRAY [0]     NULL array ptr*/

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_multisim_find_profile:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_multisim_find_profile function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_multisim_find_profile:input flist",in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	multisim_find_profile_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(multisim_find_profile_iflistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(multisim_find_profile_iflistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /profile/tab_multisim_map where  F1 = V1 ";

	PIN_FLIST_FLD_SET(multisim_find_profile_iflistp, PIN_FLD_TEMPLATE, vp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(multisim_find_profile_iflistp, PIN_FLD_ARGS, 1, ebufp);
	dataarray_flistp = PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_DATA_ARRAY, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, dataarray_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_ELEM_SET(multisim_find_profile_iflistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"MULTI_SIM Profile Search input flist", multisim_find_profile_iflistp);
	/******Perform the search******/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, multisim_find_profile_iflistp, &multisim_find_profile_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_multisim_find_profile input flist",
			 multisim_find_profile_iflistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_ADD_REMOVE_MULTISIM , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_multisim_find_profile:"
			" Error in getting profile/multisim object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"MULTI_SIM Profile Search return flist",multisim_find_profile_rflistp);

cleanup:
	/******************************************************************
	*          * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&multisim_find_profile_iflistp, NULL);

	*ret_flistpp = multisim_find_profile_rflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_multisim_find_profile final flist", multisim_find_profile_rflistp);
	return;
}
