/*************************************************************************************************
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
**************************************************************************************************/
/*************************************************************************************************
 *  Change History
 *         
 * No | Date        | Programmer                | Req/bug/Gap          | Change details
 *
 * 1  | 30/Dec/2021 | Madhavi Dandi            |                       | New opcode implementation to
 *                                                                     |get sharing groups
 
*************************************************************************************************/
#ifndef lint
static const char Sccs_id[] = "@(#)%Portal Version:fm_tab_subscription_get_sharing_groups.c:2021-Dec-30%";
#endif

#include <stdio.h>
#include "pcm.h"
#include "pcm_ops.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_pymt.h"
#include "pin_errs.h"
#include "pin_cust.h"
#include "pinlog.h"
#include "ops/bill.h"
#include "ops/bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"

EXPORT_OP void
op_tab_subscription_get_sharing_groups(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void 
fm_tab_subscription_get_sharing_groups(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_sharing_group_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_parent_acc_info(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/****************************************************************
 *  *  *  *  *External Routines Refered.
 ******************************************************************/
extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);


extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void 
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			cerror_code,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
	pcm_context_t           *ctxp,
	pin_flist_t             *i_flistp,
	pin_errbuf_t            *ebufp);

/**
 * 
 * New opcode TAB_OP_SUBSCRIPTION_GET_SHARING_GROUPS is implemented to
 * getSharingGroups as a Member
 *    *
 *  @param connp The connection pointer.
 *  @param opcode This opcode.
 *  @param flags The opcode flags.
 *  @param in_flistp The input flist contains PIN_FLD_ACCOUNT_NO
 *  @param ret_flistpp The output flist with account poid information.
 *  @param ebufp The error buffer.
 *  @return nothing.
 *  
 *  * Sample Input Flist
 *  0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 *  0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
 *  0 PIN_FLD_MSISDN            STR [0] "68748927495"
 *  0 PIN_FLD_CORRELATION_ID    STR [0] "02122021_60005"
 *  0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM3"
* */

void
op_tab_subscription_get_sharing_groups (
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t			*r_flistp = NULL;
	int32				status = PIN_BOOLEAN_TRUE;
	pin_flist_t			*enrich_iflistp = NULL;
	int32				error_clear_flag = 1;
	int32				cerror_code = 0;
	char				log_msg[512]= "";
	int64				db_no= 0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_get_sharing_groups error",ebufp);
		return ;
	}

	*ret_flistpp = NULL;

	/***********************************************************
	 *  *  *         * Insanity check.
	 ***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_GET_SHARING_GROUPS) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,PIN_ERR_BAD_OPCODE,0,0,opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_sharing_groups BAD opcode error",ebufp);
		return;
	}
	/*******************************************************************
 	       * Check for the input flist details
	*******************************************************************/

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"op_tab_subscription_get_sharing_groups input flist",in_flistp);
	 
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}


	/* Common_input_validation */
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_sharing_groups:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/* call main function */
	fm_tab_subscription_get_sharing_groups(ctxp, flags, enrich_iflistp, &r_flistp,db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_get_sharing_groups error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
			" Error while getting Get Group sharing details", ebufp);
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_SUB_SHARING_GROUPS, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, 
			&r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_SUB_SHARING_GROUPS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}

	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_sharing_groups:"
		"output flist", *ret_flistpp);
	return;
}


/**
 *  We use this function to get groups sharing as a member information.
 *  @param ctxp The context pointer.
 *  @param in_flistp in the input flist.
 *  @param ebufp The error buffer.
 *  @return flistp. 
 *    
 *  */

void
fm_tab_subscription_get_sharing_groups (
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)

{
	poid_t			*group_pdp=NULL;
	char			*group_typep = NULL;
	pin_flist_t		*srch_rflistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*custom_res_flistp = NULL;
	pin_flist_t		*grp_sharing_flistp = NULL;
	int32			elem_id = 0;
	pin_cookie_t		cookie = NULL;
	char			*group_name = NULL;
	pin_flist_t		*sponsors_flistp = NULL;
	poid_t			*sponsor_obj = NULL;
	pin_flist_t		*sponsor_readobj_iflistp = NULL;
	pin_flist_t		*sponsor_readobj_rflistp = NULL;
	pin_flist_t		*discounts_flistp = NULL;
	poid_t			*discount_obj = NULL;
	pin_flist_t		*discount_readobj_iflistp = NULL;
	pin_flist_t		*discount_readobj_rflistp = NULL;
	pin_flist_t		*prnt_srch_iflistp = NULL;
	pin_flist_t		*prnt_srch_rflistp = NULL;
	char			*offer_name = NULL;
	pin_flist_t		*groups_flistp = NULL;
	pin_flist_t		*offers_flistp = NULL;
	pin_flist_t		*prnt_res_flistp = NULL;
	pin_flist_t		*nameinfo_array_flistp = NULL;
	pin_flist_t		*sponsor_res_flistp = NULL;
	int32			offer_elemid = 0;
	pin_cookie_t		offer_cookie = NULL;
	pin_cookie_t		nameinfo_cookie = NULL;
	int32			nameinfo_elem_id = 0;
	char			*acct_no = NULL;
	char			*msisdn = NULL;
	pin_flist_t		*hook_rflistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	int32                   error_code = 0;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_group_details:"
				"input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_groups:"
				"function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);

	/* Validate the input arguments */
	acct_no = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	if((acct_no == NULL || strlen(acct_no) == 0) && (msisdn == NULL || strlen(msisdn) == 0))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
			"Account Number/MSISDN is missing in request", ebufp);
		goto cleanup;
	}
	/*Policy Opcode for DTAC Mandatory field Validation*/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_sharing_groups:Hook input flist", in_flistp);
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_GET_SHARING_GROUPS, 0, in_flistp, &hook_rflistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
			"Hook opcode  flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
			"Hook opcode flist error", ebufp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(hook_rflistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_sharing_groups:Hook return flist",
			hook_rflistp);


	/*Search sharing groups*/
	fm_tab_subscription_get_sharing_group_details(ctxp,flags,in_flistp,&srch_rflistp,db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_group_details:"
			"Group search result", srch_rflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_group_details:"
			"getting group details error ", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_sharing_group_details:"
		"return flist", srch_rflistp);

	res_flistp = PIN_FLIST_ELEM_GET(srch_rflistp,PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	if (res_flistp != NULL)
	{
		custom_res_flistp = PIN_FLIST_CREATE(ebufp);
		elem_id = 0;
		cookie = NULL;
		while(srch_rflistp && (grp_sharing_flistp = PIN_FLIST_ELEM_GET_NEXT(srch_rflistp,
			PIN_FLD_RESULTS,&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			groups_flistp = PIN_FLIST_ELEM_ADD(custom_res_flistp, PIN_FLD_GROUPS, elem_id, ebufp);
			group_pdp = PIN_FLIST_FLD_GET(grp_sharing_flistp, PIN_FLD_POID, 0, ebufp);
			group_typep = (char *)PIN_POID_GET_TYPE(group_pdp);

			if (group_typep && strcmp (group_typep, TAB_GROUP_CHARGE_SHARING) == 0)
			{
				group_name = PIN_FLIST_FLD_GET(grp_sharing_flistp, PIN_FLD_NAME, 0, ebufp);
				PIN_FLIST_FLD_SET(groups_flistp, PIN_FLD_GROUP_NAME, group_name, ebufp);
				sponsors_flistp = PIN_FLIST_ELEM_GET(grp_sharing_flistp, PIN_FLD_SPONSORS,
							PIN_ELEMID_ANY,1,ebufp);
				if(sponsors_flistp != NULL)
				{
					offer_elemid = 0;
					offer_cookie = NULL;
					while(grp_sharing_flistp && (sponsor_res_flistp = PIN_FLIST_ELEM_GET_NEXT(
						grp_sharing_flistp,PIN_FLD_SPONSORS,&offer_elemid, 1, &offer_cookie,
							ebufp)) != (pin_flist_t *)NULL)
					{
						offers_flistp = PIN_FLIST_ELEM_ADD(groups_flistp, PIN_FLD_OFFER, 
							offer_elemid,ebufp);
						sponsor_obj = PIN_FLIST_FLD_GET(sponsor_res_flistp, 
							PIN_FLD_SPONSOR_OBJ, 0, ebufp);
						/*Read_Obj of Sponsor_obj*/
						sponsor_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_SET(sponsor_readobj_iflistp,PIN_FLD_POID,sponsor_obj,
							ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SPONSOR Read_Obj input flist",
								sponsor_readobj_iflistp);
						PCM_OP(ctxp,PCM_OP_READ_OBJ,0,sponsor_readobj_iflistp,
								&sponsor_readobj_rflistp,ebufp);
						if (PIN_ERR_IS_ERR(ebufp))
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Sponsor_read_obj:"
								"input flist", sponsor_readobj_iflistp);
							pin_set_err(ebufp,PIN_ERRLOC_FM,PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS, 0, 0, 0);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Sponsor_read_obj:"
								"Error while doing sponsor read_obj", ebufp);
							goto cleanup;
						}
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," SPONSOR Read_Obj return flist",
								sponsor_readobj_rflistp);
						offer_name =PIN_FLIST_FLD_GET(sponsor_readobj_rflistp, PIN_FLD_NAME,
							0, ebufp);
						PIN_FLIST_FLD_SET(offers_flistp, PIN_FLD_NAME, offer_name, ebufp);
					}
				}
			}	
			else if (group_typep && strcmp (group_typep, TAB_GROUP_DISCOUNT_SHARING) == 0)
			{
				group_name = PIN_FLIST_FLD_GET(grp_sharing_flistp, PIN_FLD_NAME, 0, ebufp);
				discounts_flistp = PIN_FLIST_ELEM_GET(grp_sharing_flistp, PIN_FLD_DISCOUNTS,
					PIN_ELEMID_ANY,1,ebufp);
				if(discounts_flistp != NULL)
				{
					discount_obj = PIN_FLIST_FLD_GET(discounts_flistp,PIN_FLD_DISCOUNT_OBJ,0,ebufp);
					/*Read_Obj of Discount_obj*/
					discount_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_SET(discount_readobj_iflistp,PIN_FLD_POID, discount_obj, ebufp);
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," DISCOUNT Read_Obj input flist", 
						discount_readobj_iflistp);
					PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, discount_readobj_iflistp, 
						&discount_readobj_rflistp, ebufp);
					if (PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Discount_read_obj input flist",
							discount_readobj_iflistp);
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"Discount_read_obj:"
							"Error while doing discount read_obj", ebufp);
						goto cleanup;
					}
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," DISCOUNT Read_Obj return flist", 
						discount_readobj_rflistp);
					offer_name =PIN_FLIST_FLD_GET(discount_readobj_rflistp,PIN_FLD_NAME,0,ebufp);
					offers_flistp = PIN_FLIST_ELEM_ADD(groups_flistp, PIN_FLD_OFFER, 0, ebufp);
					PIN_FLIST_FLD_SET(offers_flistp, PIN_FLD_NAME, offer_name, ebufp);
				}
				PIN_FLIST_FLD_SET(groups_flistp, PIN_FLD_GROUP_NAME, group_name, ebufp);	
			}

			/*Get Parent account information*/
			prnt_srch_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(grp_sharing_flistp,PIN_FLD_ACCOUNT_OBJ,prnt_srch_iflistp,
				PIN_FLD_ACCOUNT_OBJ,ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parent Search input flist",prnt_srch_iflistp);
			fm_tab_subscription_get_parent_acc_info(ctxp,flags,prnt_srch_iflistp, 
				&prnt_srch_rflistp,db_no,ebufp);
			if (PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_parent_acc_info:"
						"Parent Account Information", prnt_srch_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_parent_acc_info:"
						"getting Parent Account details error ", ebufp);
				goto cleanup;
			}
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_parent_acc_info:"
				"return flist",prnt_srch_rflistp);
			prnt_res_flistp=PIN_FLIST_ELEM_GET(prnt_srch_rflistp,PIN_FLD_RESULTS,PIN_ELEMID_ANY,0,ebufp);
			PIN_FLIST_FLD_COPY(prnt_res_flistp,PIN_FLD_ACCOUNT_NO,groups_flistp,PIN_FLD_ACCOUNT_NO,ebufp);

			nameinfo_elem_id=0;
			nameinfo_cookie = NULL;
			while( NULL != (nameinfo_array_flistp = PIN_FLIST_ELEM_GET_NEXT(prnt_res_flistp,PIN_FLD_NAMEINFO,
				&nameinfo_elem_id, 1, &nameinfo_cookie, ebufp) ) )
			{
				PIN_FLIST_ELEM_SET(groups_flistp, nameinfo_array_flistp, PIN_FLD_NAMEINFO, 
					nameinfo_elem_id, ebufp);
			}
		}
		if(custom_res_flistp == NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_sharing_groups:"
				"input flist", grp_sharing_flistp);
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_CHARGE_DISCOUNT_POID_TYPE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
				"Group Sharing Poid type is other than Charge and Discount sharing Type", ebufp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_sharing_groups:"
			"input flist",in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SHARING_GROUP_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_groups:"
			"No Sharing groups associated with the given Account Number/MSISDN as a member", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_sharing_groups:"
			"input flist", in_flistp);
	r_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if(custom_res_flistp != NULL)
        {
                if(PIN_FLIST_FLD_GET(custom_res_flistp, PIN_FLD_POID, 1, ebufp) != NULL)
                {
                        PIN_FLIST_FLD_DROP(custom_res_flistp, PIN_FLD_POID, ebufp);
                }

                PIN_FLIST_CONCAT(r_flistp, custom_res_flistp, ebufp);
        }

	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&sponsor_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&sponsor_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&discount_readobj_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&discount_readobj_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&srch_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&prnt_srch_iflistp, NULL);
	PIN_FLIST_DESTROY_EX (&prnt_srch_rflistp, NULL);
	PIN_FLIST_DESTROY_EX (&custom_res_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&hook_rflistp, NULL);
	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;

}	

void
fm_tab_subscription_get_sharing_group_details(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	pin_flist_t		*members_flistp = NULL;

	/*0 PIN_FLD_POID           	POID [0] 0.0.0.1 /search -1 0
 * 	0 PIN_FLD_FLAGS           	 INT [0] 256
 * 	0 PIN_FLD_TEMPLATE               STR [0] "select X from /group/sharing where F1 = V1 "
 * 	0 PIN_FLD_ARGS                 ARRAY [1] allocated 20, used 1
 * 	1 PIN_FLD_MEMBERS       ARRAY [0]
 * 	2     PIN_FLD_ACCOUNT_OBJ       POID [0] 0.0.0.1 /account 23029733  0 
 * 	0 PIN_FLD_RESULTS	       ARRAY [0]     NULL array ptr*/	

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_sharing_group_details:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_sharing_group_details function entry error", ebufp);
		return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_sharing_group_details:input flist",in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /group/sharing where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	members_flistp =  PIN_FLIST_ELEM_ADD(args_flistp, PIN_FLD_MEMBERS, 0, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, members_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);

	PIN_FLIST_ELEM_SET(search_flistp, NULL, PIN_FLD_RESULTS, 0, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Group Search input flist", search_flistp);
	/******Perform the search******/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_group_details:"
			"input flist", search_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_sharing_group_details:"
			"Error in getting /group/sharing object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Group Search return flist", r_flistp);
	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	*  Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_group final flist", *ret_flistpp);
	return;
}


void
fm_tab_subscription_get_parent_acc_info(
	pcm_context_t		*ctxp,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	void			*vp = NULL;
	poid_t			*srchp = NULL;
	int32			s_flags = 0;
	pin_flist_t		*result_flistp = NULL;
	pin_flist_t		*nameinfo_flistp = NULL;
       
	/*0 PIN_FLD_POID                POID [0] 0.0.0.1 /search -1 0
	 * 0 PIN_FLD_FLAGS                  INT [0] 256
	 * 0 PIN_FLD_TEMPLATE               STR [0] "select X from /account where F1 = V1 "
	 * 0 PIN_FLD_ARGS                 ARRAY [1] allocated 20, used 1
	 * 1     PIN_FLD_POID      POID [0] 0.0.0.1 /account 23029733  0
	 * 0 PIN_FLD_RESULTS              ARRAY [0]     NULL array ptr*/

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_parent_acc_info:"
			"input flist",in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_parent_acc_info function entry error", ebufp);
	return;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_parent_acc_info:"
		"input flist",in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	vp =  (void *)"select X from /account where  F1 = V1 ";

	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_POID, ebufp);

	result_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, 0, ebufp);
	PIN_FLIST_FLD_SET(result_flistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);
	nameinfo_flistp = PIN_FLIST_ELEM_ADD(result_flistp, PIN_FLD_NAMEINFO, PIN_ELEMID_ANY, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_CONTACT_TYPE, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_SALUTATION, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_FIRST_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_MIDDLE_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_LAST_NAME, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_ADDRESS, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_CITY, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_STATE, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_ZIP, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_COUNTRY, NULL, ebufp);
	PIN_FLIST_FLD_SET(nameinfo_flistp, PIN_FLD_EMAIL_ADDR, NULL, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parent Account Details Search input flist", search_flistp);
	/******Perform the search******/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_parent_acc_info:"
			"input flist", search_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_SUB_SHARING_GROUPS , 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_parent_acc_info:"
			"Error in getting /account object", ebufp);
		goto cleanup;
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Parent Account Details Search return flist", r_flistp);
	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	*  Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_parent_acc_info", *ret_flistpp);
	return;
}
