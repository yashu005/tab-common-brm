/*******************************************************************************
 * 
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 *********************************************************************************/

/********************************************************************************
 * Change History
 *-------------------------------------------------------------------------------
 * No | Date        | Programmer         | Req/bug/Gap        | Change details
 *-------------------------------------------------------------------------------
 * 1  | 19-JAN-2022 | Venu Padala        |                    | Initial Version
 *                                                            | 
 *
 **********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_GET_RECHARGE_HISTORY operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "tab_utils_common.h"


EXPORT_OP void
op_tab_sub_get_recharge_history(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_sub_get_recharge_history(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_sub_fetch_recharge_records(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);


/**
 * 
 * New opcode TAB_OP_SUBSCRIPTION_GET_RECHARGE_HISTORY is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "0.0.0.1-14435750"
 * 0 PIN_FLD_MSISDN          STR [0] "9818888000"
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 * */

void
op_tab_sub_get_recharge_history(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_get_recharge_history function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_GET_RECHARGE_HISTORY) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_get_recharge_history bad opcode error", ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_get_recharge_history input flist", in_flistp);


	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_get_recharge_history: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
        }

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_get_recharge_history:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);


	/* call main function */
	fm_tab_sub_get_recharge_history(ctxp, enrich_iflistp, db_no, &r_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_sub_get_recharge_history error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_sub_get_recharge_history:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_get_recharge_history:"
			" Error while getting recharge history", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_RECHARGE_HISTORY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_RECHARGE_HISTORY, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp,
				error_clear_flag, cerror_code, &r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_RECHARGE_HISTORY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_RECHARGE_HISTORY, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
    PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_get_recharge_history output flist", *ret_flistpp);
	return;
}

/**
 * We use this function to get Recharge information.
 * If MSISDN have Recharge Transactions 
 * Those Recharges are returned in output flist
 **
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 **
 **/

static void
fm_tab_sub_get_recharge_history(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*resource_flistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*or_flistp =NULL;
	pin_flist_t		*r_flistp =NULL;
	pin_flist_t		*o_flistp =NULL;
	pin_cookie_t		cookie = NULL;
	pin_cookie_t		res_cookie = NULL;
	pin_decimal_t		*cancel_amt = NULL;
	int32			elem_id = 0;
	int32			res_elemid = 0;
	time_t			*rch_posted_t = NULL;
	time_t			rch_req_t = 0;
	char			*rch_req_dt = NULL;
	char			*in_rch_msisdn = NULL;
	void			*vp = NULL;
	char            *in_rch_acctno = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_get_recharge_history function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_sub_get_recharge_history: input flist", in_flistp);

	in_rch_msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	in_rch_acctno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if(((in_rch_msisdn == NULL) || (in_rch_msisdn && strlen(in_rch_msisdn) == 0)) &&
			((in_rch_acctno == NULL) || (in_rch_acctno && strlen(in_rch_acctno) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_get_recharge_history:"
			"Recharge MSISDN/ACCOUNT NO is not passed/empty", ebufp);
		return;
	}

	fm_tab_sub_fetch_recharge_records(ctxp, in_flistp, db_no, &r_flistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records: "
			"PCM_OP_SEARCH Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records: "
			"PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_get_recharge_history: "
			"PCM_OP_SEARCH Output Flist", r_flistp);

	if (r_flistp == NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records: "
			"PCM_OP_SEARCH Input Flist", in_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_RECHARGE_DATA_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_get_recharge_history:"
			"No Records found for the Input Data", ebufp);
		goto cleanup;
	}

	out_flistp = PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, out_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, out_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, out_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, out_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, out_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	elem_id = 0;
	cookie = NULL;
	while ((res_flistp = PIN_FLIST_ELEM_GET_NEXT(r_flistp, PIN_FLD_RESULTS,
							&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{

		o_flistp = PIN_FLIST_ELEM_ADD(out_flistp, PIN_FLD_RECHARGE_CARDS, elem_id, ebufp);

		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_TRANS_ID, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_TRADE_TYPE, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_TRADE_TYPE, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_TRADE_CHANNEL, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_TRADE_CHANNEL, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_CARD_NUM, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_CARD_NUM, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_CHANNEL, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_CHANNEL, vp, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_AMOUNT,
					o_flistp, PIN_FLD_AMOUNT, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_TAX,
					o_flistp, PIN_FLD_TAX, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_CREDIT_AMOUNT,
					o_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_BALANCE_AMOUNT,
					o_flistp, PIN_FLD_BALANCE_AMOUNT, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_OPEN_BAL,
                                        o_flistp, PIN_FLD_OPEN_BAL, ebufp);


		rch_req_t = *(time_t*)PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_REQ_DATE_T, 1, ebufp);
		if (rch_req_t)
		{
			rch_req_dt = (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp, &rch_req_t, ebufp);
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_AUTH_DATE, rch_req_dt, ebufp);
			free(rch_req_dt);
		}

		rch_posted_t = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_POSTED_T, 1, ebufp);
		if (rch_posted_t)
		{
			rch_req_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, rch_posted_t, ebufp);
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_EFFECTIVE_DATE, rch_req_dt, ebufp);
		}

		if(rch_req_dt!=NULL)
		{
			free(rch_req_dt);
		}

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_VALIDITY_IN_DAYS,
					o_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_SVC_VALIDITY_DATE, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_SVC_VALIDITY_DATE, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_PYMT_MODE, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_PYMT_MODE, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_PYMT_CATEGORY, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_PYMT_CATEGORY, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_PYMT_METHOD, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_PYMT_METHOD, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_AGENT_ID, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_AGENT_ID, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_AGENT_NAME, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_AGENT_NAME, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_BANK_CODE, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_BANK_CODE, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_BRANCH_NO, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_BRANCH_NO, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_RECEIPT_NO, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_RECEIPT_NO, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_OFFER_NAME, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_OFFER_NAME, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_EXT_INFO_STR, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_EXT_INFO_STR, vp, ebufp);

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_SUB_TRANS_ID, 1, ebufp);
		if (strlen ((char*)(vp)) > 0)
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_SUB_TRANS_ID, vp, ebufp);

		PIN_FLIST_FLD_COPY(res_flistp, PIN_FLD_CANCEL_FLAGS,
					o_flistp, PIN_FLD_CANCEL_FLAGS, ebufp);

		cancel_amt = PIN_FLIST_FLD_GET(res_flistp, PIN_FLD_REMIT_TOT_AMOUNT, 1, ebufp);
		if(!pbo_decimal_is_zero(cancel_amt, ebufp) || !pbo_decimal_is_null(cancel_amt, ebufp) )
		{
			PIN_FLIST_FLD_SET(o_flistp, PIN_FLD_REMIT_TOT_AMOUNT, cancel_amt, ebufp);
		}

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, 1, ebufp);
		if (!pbo_decimal_is_null(vp, ebufp))
		{
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_LOAN_AMOUNT_RECOVERED, vp, ebufp);
		}

		vp = NULL;
		vp = PIN_FLIST_FLD_GET(res_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, 1, ebufp);
		if (!pbo_decimal_is_null(vp, ebufp))
		{
			PIN_FLIST_FLD_SET(o_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, vp, ebufp);
		}

		res_elemid = 0;
		res_cookie = NULL;
		while ((resource_flistp = PIN_FLIST_ELEM_GET_NEXT(res_flistp, PIN_FLD_RESOURCE_INFO,
			&res_elemid, 1, &res_cookie, ebufp)) != (pin_flist_t *)NULL)
		{

			or_flistp = PIN_FLIST_ELEM_ADD(o_flistp, PIN_FLD_RESOURCE_INFO, res_elemid, ebufp);

			PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_ID,
						or_flistp, PIN_FLD_RESOURCE_ID, ebufp);
			PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_RESOURCE_NAME,
						or_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_UNIT_STR,
						or_flistp, PIN_FLD_UNIT_STR, ebufp);
			PIN_FLIST_FLD_COPY(resource_flistp, PIN_FLD_CURRENT_BAL,
						or_flistp, PIN_FLD_CURRENT_BAL, ebufp);

		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_get_recharge_history: result flist", out_flistp);
	*ret_flistpp = PIN_FLIST_COPY(out_flistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_get_recharge_history: result flist", r_flistp);

		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_get_recharge_history:"
			"Error in Results processing", ebufp);
		goto cleanup;
	}


cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&out_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_get_recharge_history return flist", *ret_flistpp);

	return;
}


/*************************************************************
 *  This function will prepare search flist and 
 *  call PCM_OP_SEARCH opcode to fetch the Recharge records
 *  from custom object /tab_prepaid_subscriber_recharge
 *************************************************************/

void
fm_tab_sub_fetch_recharge_records(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp =NULL;
	pin_flist_t		*r_flistp =NULL;
	poid_t			*srchp = NULL;
	char			*rch_ref_id = NULL;
	char			*rch_start_dt = NULL;
	char			*rch_end_dt = NULL;
	void			*vp = NULL;
	int32			s_flags = SRCH_DISTINCT;
	int32			count = 0;
	time_t			start_t = 0;
	time_t			end_t = 0;
	time_t          now_t = pin_virtual_time((time_t *)NULL);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_fetch_recharge_records function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_fetch_recharge_records: input flist", in_flistp);

	srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	search_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	rch_ref_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if ((rch_ref_id != NULL) && (strlen(rch_ref_id) != 0))
	{
		vp =  (void *)"select X from /tab_prepaid_subscriber_recharge where  F1 = V1 and F2 = V2";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_TRANS_ID, rch_ref_id, ebufp);
		
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
        PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	}
	else 
	{
		rch_start_dt = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp);
		rch_end_dt = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp);

		if (((rch_start_dt == NULL) || (rch_start_dt && strlen(rch_start_dt) == 0))
			&& ((rch_end_dt != NULL) || (rch_end_dt && strlen(rch_end_dt) != 0)))
		{
			end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_end_dt, ebufp);
			start_t=end_t-TAB_VAL_ONE_MONTH_DAYS_IN_SEC;
		}
		else if (((rch_start_dt != NULL) || (rch_start_dt && strlen(rch_start_dt) != 0))
			&& ((rch_end_dt == NULL) || (rch_end_dt && strlen(rch_end_dt) == 0)))
		{
			end_t=now_t;
			start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_start_dt, ebufp);
		}
		else if (((rch_start_dt == NULL) || (rch_start_dt && strlen(rch_start_dt) == 0))
			&& ((rch_end_dt == NULL) || (rch_end_dt && strlen(rch_end_dt) == 0)))
		{
			end_t=now_t;
			start_t=end_t-TAB_VAL_ONE_MONTH_DAYS_IN_SEC;
		}
		else
		{
			start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_start_dt, ebufp);
			end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, rch_end_dt, ebufp);
		}
		
		if (start_t <= 0 || end_t <= 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INVALID_DATE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records:"
				"Invalid Start Date / End Date in Input ", ebufp);
			goto cleanup;
		}

		if ((( end_t - start_t) > TAB_VAL_ONE_MONTH_DAYS_IN_SEC) || (start_t > end_t))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INPUT_BEYOND_MAXIMUM_RANGE, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records:"
				" Input Date Range Beyond allowed duration ", ebufp);
			goto cleanup;
		}

		vp =  (void *)"select X from /tab_prepaid_subscriber_recharge where F1 = V1 and F2 >= V2 and F3 <= V3 ";
		PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		
		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 2, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POSTED_T, &start_t, ebufp);

		args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 3, ebufp);
		PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_POSTED_T, &end_t, ebufp);

        }

	PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_sub_fetch_recharge_records Search flist", search_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records: "
			"PCM_OP_SEARCH Input Flist", search_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_sub_fetch_recharge_records: "
			"PCM_OP_SEARCH error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_sub_fetch_recharge_records: "
		"PCM_OP_SEARCH Output Flist", r_flistp);

	count = PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_RESULTS, ebufp);
	if(count > 0)
	{
		*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	}
	else {
		*ret_flistpp = NULL;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_sub_get_recharge_history: return flist", *ret_flistpp);

	return;
}

// End of File
