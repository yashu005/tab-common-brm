/*******************************************************************************
 *
 *   This material is the confidential property of Telenor/Oracle Corporation or its
 *   licensors and may be used, reproduced, stored or transmitted only in
 *   accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *  Change History
 *
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details
 *
 *                  | 1     | 20-DEC-2021   | Piyush           |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_GET_BALANCES operation.
 *******************************************************************/

#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "ops/ece.h"
#include "fm_bill_utils.h"
#define PIN_PAYTYPE_POSTPAID 10001
#define PIN_SUBS_ROLLOVER_COUNT_BIT_SHIFT 	0
#define PIN_SUBS_ROLLOVER_COUNT_MASK		0x00FFFF


/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_subscription_get_balances(
	cm_nap_connection_t *connp,
	int           	opcode,
	int             flags,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp);

static void
fm_tab_subscription_get_balances(
	pcm_context_t  	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static void
fm_tab_get_balances_for_daterange(
	pcm_context_t 	*ctxp,
	time_t 		start_date,
	time_t		end_date,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

static void
fm_tab_get_balances_prepare_output(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);


static void
fm_tab_get_balances_ece_enrichment(
	pcm_context_t 	*ctxp,
	int 		currency_flag,
	int64		db_no,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp);

static void
fm_tab_get_balances_get_rollover_amount(
	pcm_context_t	*ctxp,
	int64		db_no,
	poid_t		*grantor_obj,
	poid_t 		*balance_grp_pdp,
	int32 		balances_elemid,
	int32		sub_balances_elemid,
	pin_flist_t	**out_flistpp,
	pin_errbuf_t	*ebufp);

static void
fm_tab_get_balances_search_bill(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

/* Extern functions */

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t   *ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t   *ctxp,
	pin_flist_t     *i_flistp,
	int32           flag,
	int32           customErrorCode,
	pin_flist_t     **err_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp);

extern pin_flist_t*
fm_tab_utils_common_prep_simple_search_flist(
	char            *template,
	field_t         args_struct[],
	int             n_args,
	field_t         result_struct[],
	int             n_results,
	int64 		db_no,
	int 		flags,
	pin_errbuf_t    *ebufp);

extern int
fm_tab_utils_common_call_opcode(
	pcm_context_t   *ctxp,
	u_int           opcode,
	u_int           flags,
	pin_flist_t     *in_flistp,
	pin_flist_t     **ret_flistpp,
	char		*log_info,
	int		set_error,
	pin_errbuf_t    *ebufp);

extern void fm_tab_utils_common_get_billinfo (
	pcm_context_t	*ctxp,
	poid_t		*acc_pdp,
	int32		active_flag,
	pin_flist_t	**r_flistpp,
	int64		db_no,
	pin_errbuf_t	*ebufp);

extern int64
fm_tab_utils_common_get_db_no(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_errbuf_t		*ebufp);

extern time_t fm_tab_utils_common_convert_date_to_timestamp(
	pcm_context_t		*ctxp,
	char			*str_timestamp,
	pin_errbuf_t		*ebufp);

char *fm_tab_utils_common_convert_timestamp_to_date(
	pcm_context_t		*ctxp,
	time_t			*input_time_t,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

int32 fm_tab_get_balances_count_bits(int32 rollover_data);

extern pin_flist_t *config_beid_out_flistp;

/**
 *
 * New opcode TAB_OP_SUB_GET_BALANCES is implemented to
 * get the balance details for the account object.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN & PIN_FLD_ACCOUNT_NO
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 0 PIN_FLD_MSISDN                STR [0] "msisdn5554598126"
 0 PIN_FLD_ACCOUNT_NO                    STR [0] "OGC_12345rah126"
 0 TAB_FLD_START_DATE                    STR [0] "01-JAN-2021 12:40:50"
 0 TAB_FLD_END_DATE                      STR [0] "01-FEB-2022 12:40:50"
 0 PIN_FLD_BILL_NO                               STR [0] "B1-137"
 0 PIN_FLD_CORRELATION_ID                STR [0] "12345"
 0 PIN_FLD_CURRENCY_ONLY INT [0] 0
 0 PIN_FLD_EXTERNAL_USER         STR [0] "CRM"
 *
 */
/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_GET_BALANCES operation.
 *************************************************************************/
void
op_tab_subscription_get_balances(
	cm_nap_connection_t   	*connp,
	int                     opcode,
	int                     flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **ret_flistpp,
	pin_errbuf_t            *ebufp)
{
	pcm_context_t           *ctxp = connp->dm_ctx;
	pin_flist_t             *r_flistp = NULL;
	int32                   status = PIN_BOOLEAN_TRUE;
	pin_flist_t             *enrich_iflistp = NULL;
	int32                   error_clear_flag = 1;
	int32                   cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_subscription_get_balances function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_GET_BALANCES) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_get_balances bad opcode error",
				ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_balances input flist", in_flistp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_ar_get_balances input flist", in_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			 "Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code,
				&r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*******************************************************************
	 * Normalize the input flist
	 *******************************************************************/

	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "fm_tab_bal_sub_get_balances:"
				" fm_tab_utils_common_validate_and_normalize_input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_bal_sub_get_balances: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_bal_sub_get_balances:"
			"fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	/*******************************************************************
	 * call the main routin
	 *******************************************************************/
	fm_tab_subscription_get_balances(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_get_balances error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}


cleanup:

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_bal_sub_get_balances:"
				"input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances:"
				" Error while  fetching the balances", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_BALANCES;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_BALANCES )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_BALANCES, ebufp);
		}
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp)
	}
	else
	{
		status = TAB_SUCCESS;
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
        PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_balances output flist", *ret_flistpp);
	return;
}


/***********************************************************
 * fm_tab_subscription_get_balances()
 * This is the core function which checks bill, dates and accordingly
 * calls standard opcode to get balances ,then enrich balance  for the  and
 * logs the input and output flist.
 * @param opcode, opcode name/number.
 * @param opcode, Flags for the execution.
 * @param in_flistp, Input Flist
 * @param ret_flistpp, retured flist after the execution.
 * @param log_info, Function loggin information.
 * @param ebufp The error buffer.
 * @returns a integer value with success or failure response.
 ***********************************************************/

static void
fm_tab_subscription_get_balances(
	pcm_context_t   *ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	pin_flist_t		*return_flistp=NULL;
	time_t			start_date=0;
	time_t			end_date=0;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bal_sub_get_balances input flist", in_flistp);

	pin_flist_t	*rbillinfo_flistp= NULL;
	pin_flist_t 	*bill_result_flistp=NULL;
	
	pin_flist_t 	*get_balance_iflistp=NULL;
	pin_flist_t	*get_balance_oflistp = NULL;
	pin_flist_t 	*formated_out_flistp= NULL;
	pin_flist_t 	*get_balance_ece_iflistp = NULL;
	pin_flist_t	*get_balance_ece_oflistp = NULL;
	pin_flist_t  	*get_balance_ece_enrich_oflistp=NULL;
	pin_flist_t 	*hide_attrib_oflistp=NULL;	
	pin_flist_t	*bill_flistp=NULL;		
	
	char 		*input_start_date=NULL;
	char 		*input_end_date=NULL;
		
	int		pay_type=0;
	poid_t		*account_pdp=NULL;
	poid_t		*service_pdp=NULL;
	poid_t		*bal_grp_pdp=NULL;
	char 		*login=NULL;
	

	int 		currency_flag=0;	
	int		bal_flags=0;
	time_t          now_t = pin_virtual_time((time_t *)NULL);
	char		*acct_nop = NULL;
	char		*msisdnp = NULL;

	acct_nop =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	msisdnp =  PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);	
	
	if((acct_nop == NULL || strlen(acct_nop ) == 0) && (msisdnp == NULL || strlen(msisdnp) == 0)) 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances:"
			"account number/msisdn is not passed", ebufp);
		return;
	}

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);

	/*******************************************************************
	 * get the pay type details
	 *******************************************************************/
	fm_tab_utils_common_get_billinfo(ctxp,account_pdp,0,&rbillinfo_flistp,db_no,ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_billinfo_details: "
				"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_BALANCES, 0, 0, 0);
		goto cleanup;
	}

	pay_type = *(int *)PIN_FLIST_FLD_GET(rbillinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	PIN_FLIST_FLD_SET(in_flistp,PIN_FLD_PAY_TYPE,&pay_type,ebufp);

	/*******************************************************************
	 * Validate the bill numer and start and end date
	 *******************************************************************/
	fm_tab_get_balances_search_bill(ctxp,in_flistp,&bill_result_flistp,db_no,ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_search_bill: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_search_bill: "
				"error", ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
		goto cleanup;
	}

	/*******************************************************************
	 * Validate start and end date
	 *******************************************************************/

	if(bill_result_flistp !=NULL && (bill_flistp = PIN_FLIST_ELEM_GET(bill_result_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		start_date = *(time_t*)PIN_FLIST_FLD_GET(bill_flistp, PIN_FLD_START_T, 1, ebufp);
		end_date = *(time_t*) PIN_FLIST_FLD_GET(bill_flistp, PIN_FLD_END_T, 1, ebufp);
	}
	else
	{

		if((input_start_date = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp))!=NULL)
		{
			start_date=fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_start_date,ebufp);
		}

		if((input_end_date=PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp))!=NULL)
		{
			end_date= fm_tab_utils_common_convert_date_to_timestamp(ctxp,input_end_date,ebufp);
		}
	}

	/*******************************************************************
	 * Validate currency flag
	 *******************************************************************/
	
	if((PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_CURRENCY_ONLY,1, ebufp))!=NULL)
	{		
		currency_flag=*(int*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_CURRENCY_ONLY,1, ebufp);
		
		if (currency_flag!=1 && currency_flag!=0)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"Input Flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"Invalid flag in input", ebufp);

			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_INVALID_FLAG, 0, 0, 0);
			goto cleanup;
		}		
	}

	service_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
	bal_grp_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BAL_GRP_OBJ, 1, ebufp);


	/*******************************************************************
	 * setting the end date to one month from start date
	 *******************************************************************/
	if(!start_date)
	{
		if(!end_date)
			end_date=now_t;

		start_date=end_date-ONEDAY*30;
	}

	if(!end_date)
	{
		if(!start_date)
			start_date=now_t-ONEDAY*30;

		end_date=start_date+ONEDAY*30;
	}

	/*******************************************************************
	 * Error handling if the duration is more than the 32 days
	 *******************************************************************/
	if ((start_date ||end_date) && (end_date-start_date)/ONEDAY>32)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
				"Date range is more than a month error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INCORRECT_DATE_RANGE, 0, 0, 0);
		goto cleanup;
	}

	if (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_NO,1,ebufp)!=NULL)
	{
		start_date=now_t;
		end_date=now_t;
	}

	/*******************************************************************
	 * Based on start and end date fire get balance opcode.
	 *******************************************************************/

	if (PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp)==NULL &&
			PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,1,ebufp)!=NULL)
	{

		bal_flags=1;
		get_balance_ece_iflistp = PIN_FLIST_CREATE(ebufp);
		service_pdp = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_SERVICE_OBJ,0,ebufp);
		if((login = PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_MSISDN,0,ebufp))==NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ECE_BALANCES: "
					"Input Flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_BAL_GET_ECE_BALANCES: "
					"MSISDN is mandatory for ECE balance", ebufp);
			PIN_FLIST_DESTROY_EX(&get_balance_ece_iflistp, NULL);
			goto cleanup;
		}

		PIN_FLIST_FLD_SET(get_balance_ece_iflistp,PIN_FLD_POID,service_pdp,ebufp);
		PIN_FLIST_FLD_SET(get_balance_ece_iflistp,PIN_FLD_MODE,&bal_flags,ebufp);
		PIN_FLIST_FLD_SET(get_balance_ece_iflistp,PIN_FLD_LOGIN,login,ebufp);
		PIN_FLIST_FLD_SET(get_balance_ece_iflistp, PIN_FLD_START_T, &now_t, ebufp);

		/*******************************************************************
		 * Call PCM_OP_BAL_GET_ECE_BALANCES
		 *******************************************************************/
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_BAL_GET_ECE_BALANCES  input flist", get_balance_ece_iflistp);

		PCM_OP(ctxp, PCM_OP_BAL_GET_ECE_BALANCES , 0, get_balance_ece_iflistp, &get_balance_ece_oflistp, ebufp);

		PIN_FLIST_DESTROY_EX(&get_balance_ece_iflistp, NULL);

		if( PIN_ERR_IS_ERR( ebufp ))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"PCM_OP_BAL_GET_ECE_BALANCES  Input Flist", get_balance_ece_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"PCM_OP_BAL_GET_ECE_BALANCES  error", ebufp);

			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GET_ECE_BALANCE, 0, 0, 0);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balances: "
				"PCM_OP_BAL_GET_ECE_BALANCES  Output Flist", get_balance_ece_oflistp);

		PIN_FLIST_FLD_COPY(in_flistp,PIN_FLD_BAL_GRP_OBJ,get_balance_ece_oflistp,PIN_FLD_BAL_GRP_OBJ,ebufp);
		
		fm_tab_get_balances_ece_enrichment(ctxp,currency_flag,db_no,get_balance_ece_oflistp,&get_balance_ece_enrich_oflistp,ebufp);

		if( PIN_ERR_IS_ERR( ebufp ))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_ece_enrichment: "
					"Input Flist", get_balance_ece_oflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_ece_enrichment: "
					"error", ebufp);

			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_BALANCES, 0, 0, 0);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balances: "
				"get_balance_ece_enrich_oflistp Output Flist", get_balance_ece_enrich_oflistp);

		PIN_FLIST_CONCAT(in_flistp,get_balance_ece_enrich_oflistp,ebufp);

	}
	else
	{		
		//bal_flags=PIN_BAL_GET_ALL_BARE_RESULTS;commented and added 22 as flag 4 is not listing all the balances. 
		bal_flags=22;
		get_balance_iflistp = PIN_FLIST_CREATE(ebufp);

		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_POID,account_pdp,ebufp);
		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_BAL_GRP_OBJ,bal_grp_pdp,ebufp);
		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_SERVICE_OBJ,service_pdp,ebufp);
		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_START_T,&start_date,ebufp);
		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_END_T,&end_date,ebufp);
		PIN_FLIST_FLD_SET(get_balance_iflistp,PIN_FLD_FLAGS,&bal_flags,ebufp);
		PIN_FLIST_ELEM_SET(get_balance_iflistp, NULL, PIN_FLD_BALANCES, PIN_ELEMID_ANY, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "PCM_OP_BAL_GET_BALANCES input flist", get_balance_iflistp);

		/*******************************************************************
		 * Call PCM_OP_BAL_GET_BALANCES
		 *******************************************************************/

		PCM_OP(ctxp, PCM_OP_BAL_GET_BALANCES, 0, get_balance_iflistp, &get_balance_oflistp, ebufp);

		PIN_FLIST_DESTROY_EX(&get_balance_iflistp, NULL);

		if(get_balance_oflistp==NULL || PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"PCM_OP_BAL_GET_BALANCES Input Flist", get_balance_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"PCM_OP_BAL_GET_BALANCES error", ebufp);

			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_API_GET_BALANCES, 0, 0, 0);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balances: "
				"PCM_OP_BAL_GET_BALANCES Output Flist", get_balance_oflistp);

		fm_tab_get_balances_for_daterange(ctxp,start_date,end_date,get_balance_oflistp,&return_flistp,db_no,ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_balances: "
				"PCM_OP_BAL_GET_BALANCES Output Flist", return_flistp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_for_daterange: "
					"Input Flist", get_balance_oflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_for_daterange: "
					"error", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,TAB_ERR_CODE_GET_BALANCE_DATE_RANGE, 0, 0, 0);
			PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
			goto cleanup;
		}
		
		
		if( !PIN_FLIST_ELEM_COUNT(return_flistp,PIN_FLD_BALANCES,ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: "
					"Input Flist", get_balance_oflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_balances: balance element not found"
					"error", ebufp);
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,TAB_ERR_CODE_GET_BALANCE_NOT_FOUND, 0, 0, 0);
			PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
			goto cleanup;
		}		

		PIN_FLIST_CONCAT(in_flistp,return_flistp,ebufp);
	}

	/*******************************************************************
	 * Prepare output for the main opcode.
	 *******************************************************************/
	
	fm_tab_get_balances_prepare_output(ctxp,in_flistp,&formated_out_flistp,db_no,ebufp);

	if(!PIN_FLIST_ELEM_COUNT(formated_out_flistp,PIN_FLD_BALANCES,ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_get_balances_prepare_output output flist", formated_out_flistp);
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_BALANCE_NOT_FOUND, 0, 0, 0);
		goto cleanup;
	}

	if(formated_out_flistp == NULL || PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_prepare_output: "
				"Input Flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_prepare_output: "
				"error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_GET_BALANCES, 0, 0, 0);
		goto cleanup;
	}


	/*******************************************************************
	 * Call Hook opcode for BU
	 *******************************************************************/
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_HIDE_ATTRIBUTE_GET_BALANCES, 0, formated_out_flistp, &hide_attrib_oflistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_SUBSCRIPTION_POL_ENRICH_HIDE_ATTRIBUTE_GET_BALANCES: "
				"Input flist", formated_out_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"TAB_OP_SUBSCRIPTION_POL_ENRICH_HIDE_ATTRIBUTE_GET_BALANCES: "
				"error", ebufp);
		goto cleanup;
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	 PIN_FLIST_DESTROY_EX(&get_balance_iflistp, NULL);
         PIN_FLIST_DESTROY_EX(&rbillinfo_flistp, NULL);
         PIN_FLIST_DESTROY_EX(&bill_result_flistp, NULL);
	 PIN_FLIST_DESTROY_EX(&get_balance_ece_enrich_oflistp, NULL);
	 PIN_FLIST_DESTROY_EX(&formated_out_flistp, NULL);
	 PIN_FLIST_DESTROY_EX(&return_flistp, NULL);
	 PIN_FLIST_DESTROY_EX(&get_balance_ece_oflistp, NULL);
         PIN_FLIST_DESTROY_EX(&get_balance_oflistp, NULL);

	*out_flistpp= hide_attrib_oflistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_bal_sub_get_balances output flist", *out_flistpp);

	return;
}

/**************************************************************************
 * Routine for the fm_tab_get_balances_for_daterange operation.
 * Filters the sub balances for given dates.
 *************************************************************************/
static void
fm_tab_get_balances_for_daterange(
	pcm_context_t 	*ctxp,
	time_t 		start_date,
	time_t		end_date,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{
	int		elem_sub_balance=0;
	pin_cookie_t 	cookie_sub_balance = NULL;
	int		elem_balance=0;
	pin_cookie_t 	cookie_balance= NULL;

	time_t		valid_from =0;
	time_t		valid_to = 0 ;

	pin_flist_t	*return_bal_flistp= PIN_FLIST_CREATE(ebufp);
	pin_flist_t	*balance_flistp=NULL;
	pin_flist_t	*sub_balance_flistp=NULL;
	pin_flist_t *ret_balance_flistp=NULL;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_for_daterange input", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_for_daterange error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_for_daterange:"
				" input flist", in_flistp);
		return;
	}
	
	/*******************************************************************
	 * Balance traversing
	 *******************************************************************/
	while ((balance_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_BALANCES,
					&elem_balance, 1, &cookie_balance, ebufp)) != (pin_flist_t*)NULL)
	{
		elem_sub_balance=0;
		cookie_sub_balance = NULL;

		/*******************************************************************
		 * Sub Balance traversing
		 *******************************************************************/
		while ((sub_balance_flistp = PIN_FLIST_ELEM_GET_NEXT(balance_flistp,
						PIN_FLD_SUB_BALANCES, &elem_sub_balance, 1, &cookie_sub_balance, ebufp)) != (pin_flist_t*)NULL)
		{
			valid_from = *(time_t*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_FROM,0, ebufp);
			valid_to = *(time_t*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_TO,0, ebufp);
			
			//changed as part of CDIGI-2970								
			if (((valid_from<=end_date ) && (valid_to>=start_date ||valid_to==0 )))
			{				
				if(PIN_FLIST_ELEM_GET(return_bal_flistp,PIN_FLD_BALANCES,elem_balance,1,ebufp)==NULL)
				{
					ret_balance_flistp=PIN_FLIST_ELEM_ADD(return_bal_flistp,PIN_FLD_BALANCES,elem_balance,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_RESERVED_AMOUNT,ret_balance_flistp,PIN_FLD_RESERVED_AMOUNT,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_CONSUMED_RESERVED_AMOUNT,ret_balance_flistp,PIN_FLD_CONSUMED_RESERVED_AMOUNT,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_NEXT_BAL,ret_balance_flistp,PIN_FLD_NEXT_BAL,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_DELTA_CREDIT_LIMIT,ret_balance_flistp,PIN_FLD_DELTA_CREDIT_LIMIT,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_OUTSTANDING_AMOUNT,ret_balance_flistp,PIN_FLD_OUTSTANDING_AMOUNT,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_CREDIT_PROFILE,ret_balance_flistp,PIN_FLD_CREDIT_PROFILE,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_CONSUMPTION_RULE,ret_balance_flistp,PIN_FLD_CONSUMPTION_RULE,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_CURRENT_BAL,ret_balance_flistp,PIN_FLD_CURRENT_BAL,ebufp);
					PIN_FLIST_FLD_COPY(balance_flistp,PIN_FLD_GRANTED_BAL,ret_balance_flistp,PIN_FLD_GRANTED_BAL,ebufp);
				}	
				
				PIN_FLIST_ELEM_COPY(balance_flistp,PIN_FLD_SUB_BALANCES,elem_sub_balance,ret_balance_flistp,PIN_FLD_SUB_BALANCES,elem_sub_balance,ebufp); 				
			}	
		}

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_get_balances_for_daterange input flist", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_get_balances_for_daterange: Error in date range selection", ebufp);
		}
	}

	*out_flistpp = return_bal_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_for_daterange output flist", *out_flistpp);

	return;
}

/**************************************************************************
 * Routine for the fm_tab_get_balances_prepare_output operation.
 * Prepare the output as per the specification.
 *************************************************************************/
static void
fm_tab_get_balances_prepare_output(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_prepare_output input", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_prepare_output error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_prepare_output:"
				" input flist", in_flistp);
		return;
	}


	pin_flist_t	*return_bal_flistp= NULL;
	pin_flist_t	*balance_flistp=NULL;
	pin_flist_t	*sub_balance_flistp=NULL;
	pin_flist_t	*config_beid_bal_flistp=NULL;
	pin_flist_t	*return_sub_bal_flistp = NULL;
	pin_flist_t	*input_enrich_flistp=NULL;
	pin_flist_t 	*enrich_output_flistp=NULL;
	
	int		elem_balance=0;
	int		elem_sub_balance=0;
	int		elem_conf_bal=0;
	int32 		rollover_data = 0;
	int 		rollover_flag=1;
	int 		currency_flag = 0;
	int 		sub_type=0;
	void 		*vp=NULL;
	
	pin_cookie_t 	cookie_balance= NULL;
	pin_cookie_t 	cookie_conf_bal= NULL;	
	pin_cookie_t 	cookie_sub_balance = NULL;
	poid_t 			*grantor_objp=NULL;
	
	time_t 		valid_from=0;
	time_t 		valid_to=0;
	char 		*output_start_datep =NULL;
	char 		*output_end_datep=NULL;
	
	pin_decimal_t *current_balp=NULL;
	pin_decimal_t *granter_balp=NULL;
	
	char			log_msg[512]= "";

	/*******************************************************************
	 * Global config config_beid_out_flistp
	 *******************************************************************/

	/*******************************************************************
	 * Prepare return flist
	 *******************************************************************/
	pin_flist_t		*return_flistp=PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, return_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, return_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, return_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, return_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, return_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	/*******************************************************************
	 * Verify currency flag
	 *******************************************************************/
	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_CURRENCY_ONLY,1, ebufp)!=NULL)
	{
		currency_flag=*(int*)PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_CURRENCY_ONLY,1, ebufp);
	}


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_prepare_output config beid", config_beid_out_flistp);

	/*******************************************************************
	 * Balance traverse
	 *******************************************************************/
	while ((balance_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_BALANCES,
					&elem_balance, 1, &cookie_balance, ebufp)) != (pin_flist_t*)NULL)
	{

		/*******************************************************************
		 * Verify currency check
		 *******************************************************************/
		if ( currency_flag && elem_balance>1000 )
			continue ;

		/*******************************************************************
		 * add resource in return flist
		 *******************************************************************/
		return_bal_flistp=PIN_FLIST_ELEM_ADD(return_flistp,PIN_FLD_BALANCES,elem_balance,ebufp);

		PIN_FLIST_FLD_SET(return_bal_flistp, PIN_FLD_RESOURCE_ID, &elem_balance, ebufp);


		cookie_conf_bal=NULL;
		elem_conf_bal=0;

		/*******************************************************************
		 * Beid Balance traverse and compare with Balances
		 *******************************************************************/
		while ((config_beid_bal_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
						&elem_conf_bal, 1, &cookie_conf_bal, ebufp)) != (pin_flist_t*)NULL)
		{

			if(elem_balance!=elem_conf_bal)
				continue;

			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_NAME, return_bal_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
			PIN_FLIST_FLD_COPY(config_beid_bal_flistp, PIN_FLD_SYMBOL, return_bal_flistp, PIN_FLD_NAME, ebufp);
			
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "After Config beid");
		}

		elem_sub_balance=0;
		cookie_sub_balance = NULL;

		/*******************************************************************
		 * Add sub balance for the added balance element
		 *******************************************************************/
		while ((sub_balance_flistp = PIN_FLIST_ELEM_GET_NEXT(balance_flistp,
						PIN_FLD_SUB_BALANCES, &elem_sub_balance, 1, &cookie_sub_balance, ebufp)) != (pin_flist_t*)NULL)
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_prepare_output subbalance flist", sub_balance_flistp);
			current_balp=PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_CURRENT_BAL,0, ebufp);

			if (PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_SUBTYPE,1, ebufp)!=NULL)
			{
				sub_type=*(int*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_SUBTYPE,1, ebufp);

				if(sub_type==2)
					continue;
			}

			granter_balp=PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_GRANTED_BAL,0, ebufp);
						
			return_sub_bal_flistp=PIN_FLIST_ELEM_ADD(return_bal_flistp,PIN_FLD_SUB_BALANCES,elem_sub_balance,ebufp);
			PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_CURRENT_BAL, current_balp, ebufp);

			PIN_FLIST_FLD_SET(return_sub_bal_flistp, TAB_FLD_INSTANCE_ID,&elem_sub_balance, ebufp);

			if((PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_FROM,1, ebufp))!=NULL)
				valid_from = *(time_t*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_FROM,1, ebufp);
			else 
				valid_from=0;

			if((PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_TO,1, ebufp))!=NULL)
				valid_to = *(time_t*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_VALID_TO,1, ebufp);
			else
				valid_to=0;

			output_start_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&valid_from,ebufp);
			PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_VALID_FROM_STR, output_start_datep, ebufp);
			free(output_start_datep);

			output_end_datep= (char*)fm_tab_utils_common_convert_timestamp_to_date(ctxp,&valid_to,ebufp);
			PIN_FLIST_FLD_SET(return_sub_bal_flistp,PIN_FLD_VALID_TO_STR,output_end_datep,ebufp);
			free(output_end_datep);	

			/*Should be added after new patch installation.*/			
			
			PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_GRANTED_BAL, granter_balp, ebufp);
			
			if ((PIN_FLIST_FLD_GET(balance_flistp,PIN_FLD_RESERVED_AMOUNT,1,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_COPY(balance_flistp, PIN_FLD_RESERVED_AMOUNT, return_sub_bal_flistp, PIN_FLD_RESERVED_AMOUNT, ebufp);
			}
			else
			{				
				PIN_FLIST_FLD_COPY(sub_balance_flistp, PIN_FLD_RESERVED_AMOUNT, return_sub_bal_flistp, PIN_FLD_RESERVED_AMOUNT, ebufp);
			}
			
			PIN_FLIST_FLD_COPY(sub_balance_flistp,PIN_FLD_SUBTYPE,return_sub_bal_flistp,PIN_FLD_SUBTYPE,ebufp);

			rollover_flag=0;
			rollover_data=0;
			
			vp= (void*)PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_ROLLOVER_DATA,1,ebufp);	
			
			if (vp)
			{	
				rollover_data =*(int*)vp;

				sprintf(log_msg,"Rollover data value %d",rollover_data);
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

				if(rollover_data>31) //In case of ECE flag value is already set to 1.
				{
					rollover_flag = fm_tab_get_balances_count_bits(rollover_data);

					sprintf(log_msg,"Rollover Flag value %d",rollover_flag);
					PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

					if (rollover_flag)
						rollover_flag=1;
					else
						rollover_flag=0;
				}
				else
					rollover_flag = rollover_data;

				sprintf(log_msg,"Rollover Flag value after bit shift %d",rollover_flag);
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

				PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
				//Commented for DTAC-14460
				/*if(rollover_data>0)
				{
					rollover_flag=1;
					PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
				}
				else 
				{
					rollover_flag=0;
					PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
				}*/
			}
			else
			{
				rollover_flag=0;
				PIN_FLIST_FLD_SET(return_sub_bal_flistp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
			}

			if (elem_balance>1000)
			{
				if ((PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_GRANTOR_OBJ,1,ebufp))!=NULL)
				{				
					grantor_objp = PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_GRANTOR_OBJ,1, ebufp);

					if(!PIN_POID_IS_NULL(grantor_objp))
					{						
						input_enrich_flistp=PIN_FLIST_CREATE(ebufp);			
						PIN_FLIST_FLD_COPY(sub_balance_flistp, PIN_FLD_GRANTOR_OBJ,input_enrich_flistp, PIN_FLD_POID, ebufp);						
						PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES, 0, input_enrich_flistp, &enrich_output_flistp, ebufp);
						PIN_FLIST_DESTROY_EX(&input_enrich_flistp, NULL);

                                                if( PIN_ERR_IS_ERR( ebufp ))
						{	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_BALANCES: Input flist", input_enrich_flistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_offering_details: "
									"error", ebufp);
							goto cleanup;
						}
						PIN_FLIST_DESTROY_EX(&input_enrich_flistp, NULL);
						PIN_FLIST_CONCAT(return_sub_bal_flistp,enrich_output_flistp,ebufp);
					}
				}
			}
			/*******************************************************************
			 * Drop the grantor obj from the flist
			 *******************************************************************/
			if((PIN_FLIST_FLD_GET(sub_balance_flistp,PIN_FLD_GRANTOR_OBJ,1,ebufp))!=NULL)
			{
				PIN_FLIST_FLD_DROP(sub_balance_flistp,PIN_FLD_GRANTOR_OBJ,ebufp);
			}
		}
	}

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_get_balances_prepare_output input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_get_balances_prepare_output: Error in date range selection", ebufp);
		goto cleanup;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_get_balances_prepare_output output flist", return_flistp);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	*out_flistpp= return_flistp;
	return;
}


/**************************************************************************
 * Routine for the fm_tab_get_balances_ece_enrichment operation.
 * Rename the ECE sub balances as per the GET_BALANCE Opcode output.
 *************************************************************************/
static void
fm_tab_get_balances_ece_enrichment(
	pcm_context_t 	*ctxp,
	int 		currency_flag,
	int64		db_no,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_ece_enrichment input flistp", in_flistp);

	int32		sub_balances_elemid = 0;
	int32		balances_elemid = 0;
	pin_cookie_t	balances_cookie = NULL;
	pin_cookie_t	sub_balances_cookie = NULL;
	pin_flist_t	*sub_bal_impacts_flistp = NULL;
	poid_t 		*grantor_objp=NULL;
	poid_t 		*balance_grp_pdp=NULL;
	pin_flist_t 	*ece_grantor_flistp=NULL;
	pin_flist_t 	*balances_flistp=NULL;
	pin_flist_t	*return_bal_flistp= PIN_FLIST_CREATE(ebufp);;


	balance_grp_pdp= PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_BAL_GRP_OBJ,1, ebufp);

	if (PIN_FLIST_ELEM_GET(in_flistp, PIN_FLD_BAL_IMPACTS,
				PIN_ELEMID_ANY, 1, ebufp) != NULL)
	{
		PIN_FLIST_FLD_RENAME(in_flistp, PIN_FLD_BAL_IMPACTS, PIN_FLD_BALANCES, ebufp);


		while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_BALANCES,
						&balances_elemid, 1, &balances_cookie, ebufp)) != (pin_flist_t *)NULL)
		{

			PIN_FLIST_FLD_RENAME(balances_flistp, PIN_FLD_SUB_BAL_IMPACTS,PIN_FLD_SUB_BALANCES, ebufp);

			if(currency_flag && balances_elemid>1000)
				continue ;

			sub_balances_elemid = 0;
			sub_balances_cookie = NULL;

			while ((sub_bal_impacts_flistp = PIN_FLIST_ELEM_GET_NEXT(balances_flistp,
							PIN_FLD_SUB_BALANCES, &sub_balances_elemid, 1, &sub_balances_cookie, ebufp))
					!= (pin_flist_t *)NULL)
			{

				PIN_FLIST_FLD_RENAME(sub_bal_impacts_flistp, PIN_FLD_AMOUNT,
						PIN_FLD_CURRENT_BAL, ebufp);

				if(PIN_FLIST_FLD_GET(sub_bal_impacts_flistp, PIN_FLD_VALID_TO, 1, ebufp) == NULL)
				{
					PIN_FLIST_FLD_SET(sub_bal_impacts_flistp, PIN_FLD_VALID_TO, NULL, ebufp);
				}

				if (balances_elemid>1000)
				{
					grantor_objp = PIN_FLIST_FLD_GET(sub_bal_impacts_flistp,PIN_FLD_GRANTOR_OBJ,1, ebufp);

					if(grantor_objp!=NULL)
					{

						fm_tab_get_balances_get_rollover_amount(ctxp,db_no,grantor_objp,balance_grp_pdp,balances_elemid, 
						sub_balances_elemid,&ece_grantor_flistp,ebufp);

						if( PIN_ERR_IS_ERR( ebufp ))
						{

							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_get_rollover_amount input poid",
									grantor_objp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_get_rollover_amount: "
									"error", ebufp);
							goto cleanup;
						}

						//PIN_FLIST_CONCAT(sub_bal_impacts_flistp,ece_grantor_flistp,ebufp);
						PIN_FLIST_FLD_COPY(ece_grantor_flistp, PIN_FLD_ROLLOVER_DATA,sub_bal_impacts_flistp, PIN_FLD_ROLLOVER_DATA,ebufp);
					}
				}
				
				PIN_FLIST_ELEM_SET(return_bal_flistp, balances_flistp, PIN_FLD_BALANCES,balances_elemid, ebufp);
				PIN_FLIST_ELEM_SET(balances_flistp, sub_bal_impacts_flistp, PIN_FLD_SUB_BALANCES,sub_balances_elemid, ebufp);
			}
		}

	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*out_flistpp= return_bal_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_ece_enrichment output flist", *out_flistpp);
	return;
}

/**************************************************************************
 * Routine for the fm_tab_get_balances_get_rollover_amount operation.
 * Get the rollover amount for the given grantor object if nothing present then.
 * setting it to zero.
 *************************************************************************/
static void
fm_tab_get_balances_get_rollover_amount(
	pcm_context_t	*ctxp,
	int64		db_no,
	poid_t		*grantor_obj,
	poid_t 		*balance_grp_pdp,
	int32 		balances_elemid,
	int32		sub_balances_elemid,
	pin_flist_t	**out_flistpp,
	pin_errbuf_t	*ebufp)
{

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}
	PIN_ERRBUF_RESET(ebufp);

	if ((*out_flistpp == NULL) &&
			PIN_POID_IS_NULL(grantor_obj))
	{
		return;
	}

	pin_flist_t	*search_iflistp = NULL;
	pin_flist_t	*search_oflistp = NULL;
	pin_flist_t *bal_flistp = NULL;
	pin_flist_t *sub_bal_flistp = NULL;
	int			rollover_flag=0;
	poid_t 		*bal_grp_grant_objp=NULL;


	*out_flistpp = PIN_FLIST_CREATE(ebufp);

	/*******************************************************************
	 * read balance group and put the balance's sub balance rollover data
	 *******************************************************************/

	search_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_SET(search_iflistp,PIN_FLD_POID,balance_grp_pdp,ebufp);
	bal_flistp=PIN_FLIST_ELEM_ADD(search_iflistp,PIN_FLD_BALANCES,balances_elemid,ebufp);
	sub_bal_flistp=PIN_FLIST_ELEM_ADD(bal_flistp,PIN_FLD_SUB_BALANCES,sub_balances_elemid,ebufp);
	PIN_FLIST_FLD_SET(sub_bal_flistp, PIN_FLD_ROLLOVER_DATA, NULL, ebufp);
	PIN_FLIST_FLD_SET(sub_bal_flistp, PIN_FLD_GRANTOR_OBJ, NULL, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_get_rollover_amount:"
			" read balance input", search_iflistp);

	PCM_OP(ctxp, PCM_OP_READ_FLDS,0, search_iflistp, &search_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_get_rollover_amount:"
				"read balance input", search_iflistp);
		PIN_ERR_LOG_EBUF( PIN_ERR_LEVEL_ERROR,
				"fm_tab_get_balances_get_rollover_amount read balance", ebufp );
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_get_rollover_amount: read balance Output ", search_oflistp);

	if ((search_oflistp != NULL) && (bal_flistp = PIN_FLIST_ELEM_GET(search_oflistp, PIN_FLD_BALANCES, PIN_ELEMID_ANY, 1, ebufp ))!=NULL
		&& (sub_bal_flistp = PIN_FLIST_ELEM_GET(bal_flistp, PIN_FLD_SUB_BALANCES, PIN_ELEMID_ANY, 1, ebufp ))!=NULL)
	{

			bal_grp_grant_objp=PIN_FLIST_FLD_GET(sub_bal_flistp,PIN_FLD_GRANTOR_OBJ,1, ebufp);
			
			if(!PIN_POID_COMPARE(grantor_obj,bal_grp_grant_objp,0,ebufp))
				PIN_FLIST_FLD_COPY(sub_bal_flistp, PIN_FLD_ROLLOVER_DATA,*out_flistpp, PIN_FLD_ROLLOVER_DATA,ebufp);
			else
				PIN_FLIST_FLD_SET(*out_flistpp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_SET(*out_flistpp, PIN_FLD_ROLLOVER_DATA, &rollover_flag, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_get_rollover_amount *out_flistpp", *out_flistpp);

cleanup:
	PIN_FLIST_DESTROY_EX(&search_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&search_oflistp, NULL);
	return;
}

/**************************************************************************
 * Routine for the fm_tab_get_balances_search_bill operation.
 * searching the given bill number with the help of generic util functions.
 *************************************************************************/
static void
fm_tab_get_balances_search_bill(
	pcm_context_t 	*ctxp,
	pin_flist_t     *in_flistp,
	pin_flist_t     **out_flistpp,
	int64		db_no,
	pin_errbuf_t    *ebufp)
{

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_search_bill input flistp", in_flistp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_search_bill error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_get_balances_search_bill:"
				" in_flistp", in_flistp);
		return;
	}

	pin_flist_t	*search_input_flistp=NULL;
	pin_flist_t 	*search_out_flistp=NULL;
	char		*bill_nop= NULL;
	poid_t		*account_pdp=NULL;
	field_t		args_struct[1];
	field_t		result_struct[2];
	int		n_args = 2;
	int		n_results = 2;
	char		*template= "select X from /bill where F1 = V1 and F2 = V2 ";
	int 		flags=0;	
	
	bill_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_BILL_NO, 1, ebufp);

	if(PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,1, ebufp)!=NULL)
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_ACCOUNT_OBJ,0, ebufp);
	else
		account_pdp=PIN_FLIST_FLD_GET(in_flistp,PIN_FLD_POID,0,	ebufp);

	int pay_type = *(int*) PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);

	if ((bill_nop!= NULL && strlen(bill_nop) != 0) && pay_type != PIN_BILL_TYPE_PREPAID)
	{
		//Setting the arguments
		args_struct[0].fld_name = PIN_FLD_BILL_NO;
		args_struct[0].fld_value = bill_nop;

		args_struct[1].fld_name = PIN_FLD_ACCOUNT_OBJ;
		args_struct[1].fld_value = account_pdp;

		//Setting the results
		result_struct[0].fld_name = PIN_FLD_START_T;
		result_struct[0].fld_value = NULL;

		result_struct[1].fld_name = PIN_FLD_END_T;
		result_struct[1].fld_value = NULL;

		search_input_flistp = fm_tab_utils_common_prep_simple_search_flist(template, args_struct, n_args,result_struct, n_results,db_no,flags, ebufp);

		int	opcode_result= 0 ;

		opcode_result = fm_tab_utils_common_call_opcode(ctxp, PCM_OP_SEARCH, 0, search_input_flistp,
				&search_out_flistp, "fm_tab_get_balances_search_bill bill search", 1, ebufp);

		if (opcode_result != 0) {

			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_BILL_NOT_FOUND, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_get_balances_search_bill"
					"error search bill failed", ebufp);
			goto cleanup;
		}

		PIN_FLIST_DESTROY_EX(&search_input_flistp, NULL);
	}

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/

	*out_flistpp= search_out_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_get_balances_search_bill output flist", *out_flistpp);
	return;
}


int32 fm_tab_get_balances_count_bits(int32 rollover_data)
{
    int32 roll_count=0;
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Inside Bit Count");

	roll_count = (rollover_data >> PIN_SUBS_ROLLOVER_COUNT_BIT_SHIFT) &
                         PIN_SUBS_ROLLOVER_COUNT_MASK;
	return roll_count;
}
