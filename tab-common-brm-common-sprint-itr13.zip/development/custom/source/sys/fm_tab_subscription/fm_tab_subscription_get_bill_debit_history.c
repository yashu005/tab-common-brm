/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 01-APR-2022   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_GET_BILL_DEBIT_HISTORY operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#define FILE_SOURCE_ID "fm_tab_subscription_get_bill_debit_history.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_get_bill_debit_history(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void fm_tab_subscription_get_bill_debit_history(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
void
fm_tab_subscription_get_billdebit_history_via_daterange(
	pcm_context_t       *ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_billdebit_history_via_transid(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);

	
 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_GET_BILL_DEBIT_HISTORY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_GET_BILL_DEBIT_HISTORY operation.
 *************************************************************************/
void
op_tab_subscription_get_bill_debit_history(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int64			db_no = 0;
	int32			cerror_code = 0;
	int32			error_clear_flag = 1;
	
	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_bill_debit_history error",ebufp);
		return ;
	}
	
	/***********************************************************
	* Opcode check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_GET_BILL_DEBIT_HISTORY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_bill_debit_history opcode error",ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_bill_debit_history: Input FList", in_flistp);
	
	/***********************************************************
	* Get the Database Number
	***********************************************************/
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
        
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*out_flistpp = r_flistp;
		return;
	}
	
	/***********************************************************
	* Validate and Normalized Input
	***********************************************************/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_bill_debit_history: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_get_bill_debit_history:"
			" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_bill_debit_history:"
		" Validation and Normalization output flist", enrich_iflistp);

	/***********************************************************
	* Main Function Call
	***********************************************************/
	fm_tab_subscription_get_bill_debit_history(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_bill_debit_history: "
			"fm_tab_subscription_get_bill_debit_history error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_get_bill_debit_history:"
			" fm_tab_subscription_get_bill_debit_history input flist", in_flistp);
		status = TAB_FAIL;
		goto cleanup;
	}
	
	cleanup:
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_bill_debit_history:"
				"Error input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_bill_debit_history:"
				"Error", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_GET_BALTRANSFER_HISTORY, 0, 0, 0);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);
			
		PIN_ERR_CLEAR_ERR(ebufp);

	}
	else
	{
		status = TAB_SUCCESS;

		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*out_flistpp = r_flistp;
	PIN_FLIST_DESTROY_EX(&enrich_iflistp,ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_bill_debit_history output flist", *out_flistpp);

	return;
}

void 
fm_tab_subscription_get_bill_debit_history(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	
	pin_flist_t			*r_flistp = NULL;
	pin_flist_t			*transactions_out_flistp = NULL;
	pin_flist_t			*translist_flistp = NULL;
	pin_flist_t			*result_flistp = NULL;
	pin_flist_t			*debitinfo_flistp = NULL;
	char				*transid_strp = NULL;
	char				*indate_strp = NULL;
	char				*msisdn_strp = NULL;
	time_t				startdate_tmst = 0;
	time_t				enddate_tmst = 0;
	int32				elem_id = 0;
	pin_cookie_t		cookie = 0;
	int32				elem_id1 = 0;
	pin_cookie_t		cookie1 = 0;
	time_t				*created_tmstp = NULL;
	char 				*adjdate_strp = NULL;
	int32				*transtype_ip = NULL;	
	int32				*validitydays_ip = NULL;
	char                *acctno_strp = NULL;
	
	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			"error input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_CLEAR_ERR(ebufp);
	
	/*********************************
	 * Debug Input Flist
	 *********************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_bill_debit_history:"
			" input flist", in_flistp);
	
	/*********************************
	 * MSISDN check
	 *********************************/
	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	acctno_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if(((msisdn_strp == NULL) || (msisdn_strp && strlen(msisdn_strp) == 0)) &&
			((acctno_strp == NULL) || (acctno_strp && strlen(acctno_strp) == 0)))
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
		TAB_ERR_CODE_ACCT_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:Missing Acct/MSISDN input flist", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
		"Missing Acct/MSISDN input flist", in_flistp);
		goto cleanup;
	}
		
	/*********************************
	 * TransID check
	 *********************************/
	
	transid_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);
	
	if (transid_strp != NULL)
	{
		fm_tab_subscription_get_billdebit_history_via_transid(ctxp, in_flistp, &transactions_out_flistp, db_no, ebufp);
	}
	else
	{		
		indate_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp);
		if((indate_strp == NULL) || (indate_strp && strlen(indate_strp) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_VALID_FROM, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history: Missing Start Date error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			"Missing Start Date input flist", in_flistp);
			goto cleanup;
		}
		
		startdate_tmst= fm_tab_utils_common_convert_date_to_timestamp(ctxp,indate_strp,ebufp);
		if (startdate_tmst < 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_VALID_FROM, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history: Missing Start Date error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			"Missing Start Date input flist", in_flistp);
			goto cleanup;
		}
		
		PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_START_T, &startdate_tmst, ebufp);
		
		
		indate_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp);
		if((indate_strp == NULL) || (indate_strp && strlen(indate_strp) == 0))
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_MISSING_VALID_TO, 0, 0, 0); //Update Error Code Here
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history: Missing End Date error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			"Missing End Date input flist", in_flistp);
			goto cleanup;
		}
		
		enddate_tmst= fm_tab_utils_common_convert_date_to_timestamp(ctxp,indate_strp,ebufp);
		if (enddate_tmst < 0)
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_VALID_TO, 0, 0, 0); 
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:Valid to Date error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			"Valid to Date Error input flist", in_flistp);
			goto cleanup;
		}
		
		if ((enddate_tmst - startdate_tmst) > TAB_VAL_ONE_MONTH_DAYS_IN_SEC)
		{
			pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INPUT_BEYOND_MAXIMUM_RANGE, 0, 0, 0); 
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history: Exceed Maximum number of days error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			" Exceed Maximum number of days error input flist", in_flistp);
			goto cleanup;
		}
		
		
		PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_END_T, &enddate_tmst, ebufp);
		
		fm_tab_subscription_get_billdebit_history_via_daterange(ctxp, in_flistp, &transactions_out_flistp, db_no, ebufp);
	}
	
	/***************************************************
	 *Results Check
	 ***************************************************/
	if (PIN_FLIST_ELEM_COUNT(transactions_out_flistp, PIN_FLD_RESULTS, ebufp) <= 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_NO_RECORDS_FOUND, 0, 0, 0); 
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:No Transaction Records Found error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_bill_debit_history:"
			" No Transaction Records Found input flist", in_flistp);
		goto cleanup;
	}
	
	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	while ((result_flistp = PIN_FLIST_ELEM_GET_NEXT(transactions_out_flistp, PIN_FLD_RESULTS,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
	{
		translist_flistp = PIN_FLIST_COPY(result_flistp, ebufp);
		
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_bill_debit_history:"
			"Transaction Information flist", translist_flistp);
			
		adjdate_strp = (char *)fm_tab_utils_common_convert_timestamp_to_date(ctxp,  PIN_FLIST_FLD_GET(translist_flistp,PIN_FLD_CREATED_T,1,ebufp), ebufp);
		PIN_FLIST_FLD_SET(translist_flistp,TAB_FLD_ADJUSTMENT_DATE,adjdate_strp,ebufp);
		free(adjdate_strp);
		
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_CREATED_T, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_MOD_T, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_READ_ACCESS, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_WRITE_ACCESS, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_EVENT_OBJ, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, TAB_FLD_LOC_GROUP_CODE, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_LOCATION, ebufp);
		PIN_FLIST_FLD_DROP(translist_flistp, PIN_FLD_MSISDN, ebufp);
		
		transtype_ip = PIN_FLIST_FLD_GET(translist_flistp, PIN_FLD_PARAM_TYPE, 1, ebufp);
																				   
		elem_id1 = 0;
		cookie1 = 0;
		while ((debitinfo_flistp = PIN_FLIST_ELEM_GET_NEXT(translist_flistp, TAB_FLD_DEBIT_INFO,
			&elem_id1, 1, &cookie1, ebufp)) != (pin_flist_t*)NULL)
		{
			PIN_FLIST_FLD_COPY(debitinfo_flistp, PIN_FLD_AMOUNT, debitinfo_flistp, PIN_FLD_AMOUNT_ADJUSTED, ebufp);

			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_AMOUNT, ebufp);
			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_ELEMENT_ID, ebufp);
			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_FLAGS, ebufp);
			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_NOTIFY_FLAG, ebufp);
			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_VALIDITY_FLAGS, ebufp);
			PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_ACTION_MODE, ebufp);
			if (transtype_ip != NULL)
			{
				if (*transtype_ip == 3)
				{
					PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_CURRENT_BAL, ebufp);
					PIN_FLIST_FLD_DROP(debitinfo_flistp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);
				}
				else 
				{
					if (*transtype_ip == 1)
					{
						PIN_FLIST_FLD_DROP(debitinfo_flistp, TAB_FLD_EFFECTIVE_DATE, ebufp)
					}
					PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_CLOSE_BAL, ebufp)
				}
				
				validitydays_ip =  PIN_FLIST_FLD_GET(debitinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, 1, ebufp);
			
				if (validitydays_ip == NULL || *validitydays_ip == 0)
				{
					PIN_FLIST_FLD_DROP(debitinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);
				}
			}
		}
		
		PIN_FLIST_ELEM_SET(r_flistp, translist_flistp, PIN_FLD_ADJUSTMENT_INFO, elem_id, ebufp);
		PIN_FLIST_DESTROY_EX(&translist_flistp, NULL);
	}
	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	cleanup:
	
	*out_flistpp= PIN_FLIST_COPY(r_flistp, ebufp);
        PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&result_flistp, ebufp);
	
	PIN_FLIST_DESTROY_EX(&transactions_out_flistp, ebufp);
	
	return;
}



void
fm_tab_subscription_get_billdebit_history_via_transid(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	poid_t			*search_pdp = NULL;
	int32			s_flags = 256;
	char			*template_strp = NULL;
	
	
	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_transid error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_transid:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*********************************
	 * Debug Input Flist 
	 *********************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_transid:"
			"Search input flist", in_flistp);
	
	/*********************************
	 * Prepare Search Input Flist
	 *********************************/
	 
	search_pdp = PIN_POID_CREATE(db_no, "/search/pin", 0, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_strp =  (void *)"select X from /tab_event_bill_debit_info where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_strp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, args_flistp, PIN_FLD_TRANS_ID, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_transid:"
			"Search input flist", search_in_flistp);
			
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_transid: Search Execution error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_transid:"
			"Search Execution input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_transid:"
			"Search output flist", search_out_flistp);
	
	
	cleanup:
	*out_flistpp = search_out_flistp;

	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_transid:"
			"output flist", *out_flistpp);
	
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	return;
}


void
fm_tab_subscription_get_billdebit_history_via_daterange(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*search_in_flistp = NULL;
	pin_flist_t		*search_out_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	poid_t			*search_pdp = NULL;
	int32			s_flags = 256;
	char			*template_strp = NULL;
	
	
	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_daterange error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_daterange:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*********************************
	 * Debug Input Flist 
	 *********************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_daterange:"
			"Search input flist", in_flistp);
	
	/*********************************
	 * Prepare Search Input Flist
	 *********************************/
	 
	search_pdp = PIN_POID_CREATE(db_no, "/search/pin", 0, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);
	template_strp =  (void *)"select X from /tab_event_bill_debit_info where F1 = V1 and F2 >= V2 and F3 <= V3 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_strp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, args_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 2, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_START_T, args_flistp, PIN_FLD_CREATED_T, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 3, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_END_T, args_flistp, PIN_FLD_CREATED_T, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_daterange:"
			"Search input flist", search_in_flistp);
			
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_daterange: Search Execution error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_billdebit_history_via_daterange:"
			"Search Execution input flist", in_flistp);
		goto cleanup;
	}
	
	r_flistp = PIN_FLIST_COPY(search_out_flistp, ebufp);
	
	cleanup:
	
	*out_flistpp = r_flistp;
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_billdebit_history_via_daterange:"
			"output flist", r_flistp);
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	return;
}
