/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *	Change History
 *			
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details 
 *			
 *					| 1		| 16-NOV-2021	| Darshan			|				| New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_GET_GRP_SHARING_MEMBERS operation. 
 *******************************************************************/


#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "pin_subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_get_grp_sharing_members(
	cm_nap_connection_t *connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void 
fm_tab_subscription_get_grp_sharing_members(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);

void 
fm_tab_subscription_get_group_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	char			*offer_flagp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/* Extern functions */	
extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistp,
	int64				db_no,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t			*i_flistp,
	int32				flag,
	int32				customErrorCode,
	pin_flist_t			**err_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp);
	
extern void
fm_tab_utils_common_subscr_get_all_groups(
	pcm_context_t			*ctxp,
	pin_flist_t				*i_flistp,
	pin_flist_t				**r_flistpp,
	int64				db_no,
	pin_errbuf_t			*ebufp);
	
extern void
fm_tab_utils_common_subscr_get_group_details(
	pcm_context_t			*ctxp,
	pin_flist_t				*i_flistp,
	pin_flist_t				**r_flistpp,
	int64				db_no,
	pin_errbuf_t			*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_SUBSCRIPTION_GET_GRP_SHARING_MEMBERS is implemented to 
 * get CSG/DSG details based on group name and offer flag.
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_NAME & TAB_FLD_SUB_OFFER_FLAG
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID			POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO		 STR [0] "CH_112"
 * 0 PIN_FLD_NAME		   STR [0] "CSG_GRP_421"
 * 0 TAB_FLD_SUB_OFFER_FLAG	   STR [0] "false"
 *
 */
 
/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_GET_GRP_SHARING_MEMBERS operation.
 *************************************************************************/
void
op_tab_subscription_get_grp_sharing_members(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**out_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t				*r_flistp = NULL;
	char					log_msg[512]= "";
	int32					status = TAB_SUCCESS;
	int32					error_clear_flag = 1;
	int32					cerror_code = 0;
	int64					db_no = 0;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_grp_sharing_members error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_GET_GRP_SHARING_MEMBERS) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_grp_sharing_members opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	* Debug: Input Flist
	***********************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"op_tab_subscription_get_grp_sharing_members input flist", in_flistp);
		
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*out_flistpp = r_flistp;
		return;
	}
	
	fm_tab_subscription_get_grp_sharing_members(ctxp, in_flistp, &r_flistp, db_no, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_grp_sharing_members:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_grp_sharing_members error", ebufp);
		
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_SHARING_MEMBERS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_SHARING_MEMBERS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_SHARING_MEMBERS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*out_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"op_tab_subscription_get_grp_sharing_members output flist", *out_flistpp);
	return;
}

/**
 * We use this function as a wrapper
 * to call the main functions to get 
 *CSG/DSG details.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
 
void fm_tab_subscription_get_grp_sharing_members(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	int64				db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*get_group_details_iflistp = NULL;
	pin_flist_t			*get_group_details_oflistp = NULL;
	pin_flist_t			*api_validate_oflistp = NULL;
	pin_flist_t			*get_all_group_oflistp = NULL;
	char				*grp_namep = NULL;
	char				*offer_flagp = NULL;
	char				*account_nop = NULL;
	char				*offer_flags [] = { TAB_FLAG_TRUE, TAB_FLAG_FALSE };
	int					i;
	int					offer_flag_found = 0;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}
	
	PIN_ERRBUF_RESET(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_subscription_get_grp_sharing_members input flist", in_flistp);
		
	/*If group Name not passed in input*/
	grp_namep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);
	if(grp_namep && strlen(grp_namep) == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GRP_NAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			"Group Name is not passed in input", ebufp);
		goto cleanup;
	}
	
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);

	/*Check if account no is passed in input*/
	if((account_nop && strlen(account_nop) == 0) ||
	(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
			"Account no is mandatory and not passed in input", ebufp);
		goto cleanup;
	}
	
	if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp) == NULL && PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SUB_OFFER_FLAG, 1, ebufp) == NULL)
	{
		PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_SUB_OFFER_FLAG, TAB_FLAG_FALSE, ebufp);
	}
	/*Check for custom offer flag */
	offer_flagp = PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SUB_OFFER_FLAG, 1, ebufp);
	
	if((offer_flagp && strlen(offer_flagp) == 0) || 
	(PIN_FLIST_FLD_GET(in_flistp, TAB_FLD_SUB_OFFER_FLAG, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_OFFER_FLAG_NOT_PASSED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
			"Offer Flag is not passed", ebufp);
		goto cleanup;
	}
	
	/*Check for valid offer flag value*/
	for(i = 0; i < sizeof(offer_flags)/sizeof(offer_flags[0]); ++i)
	{
		if(!strncmp(offer_flags[i], offer_flagp, strlen(offer_flagp)))
		{
			offer_flag_found = 1;
		}
	}
	
	/*If the offer flag value passed is incorrect*/
	if (offer_flag_found == 0)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_INVALID_OFFER_FLAG, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
			"Invalid Offer Flag Value", ebufp);
		goto cleanup;
	}
	
	if (offer_flagp && !strncmp(offer_flagp, TAB_FLAG_TRUE, 
		strlen(TAB_FLAG_TRUE)))
	{
		if((grp_namep && strlen(grp_namep) == 0) || PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GRP_NAME_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
				"Group Name is mandatory and not passed", ebufp);
			goto cleanup;
		}
	}
	
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &api_validate_oflistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_grp_sharing_members: fm_tab_utils_common_verify_normalize_input error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_verify_normalize_input:"
			" input flist", in_flistp);
		return;
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_get_grp_sharing_members: fm_tab_utils_common_verify_normalize_input output flist", api_validate_oflistp);
	}
	
	if (api_validate_oflistp != NULL)
	{
		get_group_details_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(api_validate_oflistp, PIN_FLD_POID, get_group_details_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NAME, get_group_details_iflistp, PIN_FLD_NAME, ebufp);
		
		if(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp) == NULL)
		{
			fm_tab_utils_common_subscr_get_all_groups(ctxp, get_group_details_iflistp, 
				&get_group_details_oflistp, db_no, ebufp);
			PIN_FLIST_DESTROY_EX(&get_group_details_iflistp, NULL);
			
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_all_groups:"
					" input flist ", in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
					" Error while getting sharing group details", ebufp);
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
					"fm_tab_utils_common_subscr_get_all_groups output flist", get_group_details_oflistp);
					
				if (get_group_details_oflistp && PIN_FLIST_ELEM_GET(get_group_details_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp) == NULL)
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_NO_GROUPS_FOUND, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
						"No groups are associated with the input account/MSISDN", ebufp);
					goto cleanup;
				}
				else
				{
					fm_tab_subscription_get_group_details(ctxp, get_group_details_oflistp, offer_flagp, 
					&get_all_group_oflistp, db_no,ebufp);
						
					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_group_details:"
							" input flist ", get_group_details_oflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_group_details:"
							" Error while getting sharing group details", ebufp);
						goto cleanup;
					}
					else
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
							"fm_tab_subscription_get_group_details output flist", get_all_group_oflistp);
							
						if(get_all_group_oflistp != NULL)
						{
							PIN_FLIST_FLD_COPY(get_group_details_oflistp, PIN_FLD_POID, get_all_group_oflistp, PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, get_all_group_oflistp, PIN_FLD_ACCOUNT_NO, ebufp);
							PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, get_all_group_oflistp, PIN_FLD_MSISDN, ebufp);
						}
					}
				}
			}
		}
		else
		{
			fm_tab_utils_common_subscr_get_group_details(ctxp, get_group_details_iflistp, 
				&get_group_details_oflistp, db_no, ebufp);
			PIN_FLIST_DESTROY_EX(&get_group_details_iflistp, NULL);
			
			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_group_details:"
					" input flist ", in_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
					" Error while getting sharing group details", ebufp);
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
					"fm_tab_utils_common_subscr_get_group_details output flist", get_group_details_oflistp);
			}
		
			if (get_group_details_oflistp && (PIN_FLIST_ELEM_GET(get_group_details_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				fm_tab_subscription_get_group_details(ctxp, get_group_details_oflistp, offer_flagp, 
					&get_all_group_oflistp,db_no, ebufp);
						
				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_group_details:"
						" input flist ", get_group_details_oflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_group_details:"
						" Error while getting sharing group details", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
						"fm_tab_subscription_get_group_details output flist", get_all_group_oflistp);
						
					if(get_all_group_oflistp != NULL)
					{
						PIN_FLIST_FLD_COPY(get_group_details_oflistp, PIN_FLD_POID, get_all_group_oflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, get_all_group_oflistp, PIN_FLD_ACCOUNT_NO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, get_all_group_oflistp, PIN_FLD_MSISDN, ebufp);
						//*out_flistpp = PIN_FLIST_COPY(get_all_group_oflistp, ebufp);
					}
				}
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_GRP_NAME_NOT_FOUND, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
					"Group Name is not present in BRM DB", ebufp);
				goto cleanup;
			}
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_grp_sharing_members output flist", *out_flistpp);
		
	*out_flistpp = PIN_FLIST_COPY(get_all_group_oflistp, ebufp);
	
	cleanup:
	/******************************************************************
	 * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_group_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_all_group_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_group_details_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&api_validate_oflistp, NULL);
	
	return;
}

/**
 * We use this function to get all
 * group details.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void fm_tab_subscription_get_group_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	char			*offer_flagp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t			*group_read_iflistp = NULL;
	pin_flist_t			*group_read_oflistp = NULL;
	pin_flist_t			*sponsor_flistp = NULL;
	pin_flist_t			*sponsor_read_iflistp = NULL;
	pin_flist_t			*sponsor_read_oflistp = NULL;
	pin_flist_t			*all_group_details_oflistp = NULL;
	pin_flist_t			*results_flistp = NULL;
	pin_flist_t			*chrg_groups_flistp = NULL;
	pin_flist_t			*disc_groups_flistp = NULL;
	pin_flist_t			*chrg_offer_flistp = NULL;
	pin_flist_t			*disc_offer_flistp = NULL;
	pin_flist_t			*discount_flistp = NULL;
	pin_flist_t			*discount_read_iflistp = NULL;
	pin_flist_t			*discount_read_oflistp = NULL;
	pin_flist_t			*service_read_iflistp = NULL;
	pin_flist_t			*service_read_oflistp = NULL;
	pin_flist_t			*alias_flistp = NULL;
	pin_flist_t			*members_flistp = NULL;
	pin_flist_t			*member_flistp = NULL;
	int32				discount_elemid = 0;
	int32				sponsor_elemid = 0;
	pin_cookie_t		sponsor_cookie = NULL;
	pin_cookie_t		discount_cookie = NULL;
	poid_t				*sponsor_pdp = NULL;
	poid_t				*discount_pdp = NULL;
	poid_t				*group_pdp = NULL;
	poid_t				*service_pdp = NULL;
	unsigned long		groups_count = 0;
	unsigned long		offer_count = 0;
	unsigned long		member_count = 0;
	pin_cookie_t		groups_cookie = NULL;
	int32				groups_elemid = 0;
	pin_cookie_t		member_cookie = NULL;
	int32				member_elemid = 0;
	char				*group_typep = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		return;
	}
	
	PIN_ERRBUF_RESET(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
		"fm_tab_subscription_get_group_details input flist", in_flistp);
		
	all_group_details_oflistp = PIN_FLIST_CREATE(ebufp);
		
	while ((results_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_RESULTS, 
		&groups_elemid, 1, &groups_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		group_pdp = PIN_FLIST_FLD_GET(results_flistp, PIN_FLD_POID, 1, ebufp);
								
		if(!PIN_POID_IS_NULL(group_pdp))
		{
			group_typep = (char *)PIN_POID_GET_TYPE(group_pdp);
			
			if(group_typep != NULL)
			{
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Resource Sharing Type");
				PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, group_typep);
			}
			if (group_typep && (!strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_CHARGES, 
					strlen(PIN_OBJ_TYPE_GRP_SHARING_CHARGES)) || !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS, 
				strlen(PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS))))
			{
				group_read_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_POID, group_read_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_SET(group_read_iflistp, PIN_FLD_NAME, NULL, ebufp);
				
				if (group_typep && !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_CHARGES, 
					strlen(PIN_OBJ_TYPE_GRP_SHARING_CHARGES)))
				{
					PIN_FLIST_ELEM_SET(group_read_iflistp, NULL, PIN_FLD_SPONSORS, PCM_RECID_ALL , ebufp);
				}
				
				if (group_typep && !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS, 
				strlen(PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS)))
				{
					PIN_FLIST_ELEM_SET(group_read_iflistp, NULL, PIN_FLD_DISCOUNTS, PCM_RECID_ALL , ebufp);
				}
				
				if (offer_flagp && !strncmp(offer_flagp, TAB_FLAG_TRUE, 
					strlen(TAB_FLAG_TRUE)))
				{
					PIN_FLIST_ELEM_SET(group_read_iflistp, NULL, PIN_FLD_MEMBERS, PCM_RECID_ALL , ebufp);
				}
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_subscription_get_group_details : Read charge sharing group input flist", group_read_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, group_read_iflistp, &group_read_oflistp, ebufp);
				PIN_FLIST_DESTROY_EX(&group_read_iflistp, NULL);
				
				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Resource sharing object PCM_OP_READ_FLDS:"
						" input flist ", group_read_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
						" Error while reading charge sharing group", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_subscription_get_group_details: Read charge sharing group output flist", group_read_oflistp);
					
					if (group_typep && !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_CHARGES, 
					strlen(PIN_OBJ_TYPE_GRP_SHARING_CHARGES)))
					{
						//Shubha|changed for fetching getSharingMembers after deleting the DSG offer name through addRemoveOfferDSG|DBSS-13855 
						chrg_groups_flistp = PIN_FLIST_ELEM_ADD(all_group_details_oflistp, PIN_FLD_GROUPS, groups_count++, ebufp);
							PIN_FLIST_FLD_COPY(group_read_oflistp, PIN_FLD_NAME, chrg_groups_flistp, PIN_FLD_GROUP_NAME, ebufp);
							
						if(group_read_oflistp != NULL && PIN_FLIST_ELEM_COUNT(group_read_oflistp, PIN_FLD_SPONSORS, ebufp) > 0 )
						{
							
							sponsor_elemid = 0;
							sponsor_cookie = NULL;
							while ((sponsor_flistp = PIN_FLIST_ELEM_GET_NEXT(group_read_oflistp, PIN_FLD_SPONSORS, 
								&sponsor_elemid, 1, &sponsor_cookie, ebufp)) != (pin_flist_t *)NULL)
							{
								sponsor_pdp = PIN_FLIST_FLD_GET(sponsor_flistp, PIN_FLD_SPONSOR_OBJ, 1, ebufp);
								
								if(!PIN_POID_IS_NULL(sponsor_pdp))
								{
									sponsor_read_iflistp = PIN_FLIST_CREATE(ebufp);
									PIN_FLIST_FLD_SET(sponsor_read_iflistp, PIN_FLD_POID, sponsor_pdp, ebufp);
									PIN_FLIST_FLD_SET(sponsor_read_iflistp, PIN_FLD_NAME, NULL, ebufp);
									
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
										"fm_tab_subscription_get_group_details : Read sponsor object input flist", sponsor_read_iflistp);
									PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, sponsor_read_iflistp, &sponsor_read_oflistp, ebufp);
									PIN_FLIST_DESTROY_EX(&sponsor_read_iflistp, NULL);
									
									if(PIN_ERR_IS_ERR(ebufp))
									{
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Sponsor object PCM_OP_READ_FLDS:"
											" input flist ", sponsor_read_iflistp);
										PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
											" Error while reading sponsor object", ebufp);
										goto cleanup;
									}
									else
									{
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
											"fm_tab_subscription_get_group_details: Read sponsor object output flist", sponsor_read_oflistp);
										
										if(sponsor_read_oflistp != NULL)
										{
											chrg_offer_flistp = PIN_FLIST_ELEM_ADD(chrg_groups_flistp, PIN_FLD_OFFER, offer_count++, ebufp);
											PIN_FLIST_FLD_COPY(sponsor_read_oflistp, PIN_FLD_NAME, chrg_offer_flistp, PIN_FLD_OFFER_NAME, ebufp);
										}
										
										PIN_FLIST_DESTROY_EX(&sponsor_read_oflistp, NULL);
									}
								}
							}
						}
							if (offer_flagp && !strncmp(offer_flagp, TAB_FLAG_TRUE, 
								strlen(TAB_FLAG_TRUE)) && PIN_FLIST_ELEM_COUNT(group_read_oflistp, PIN_FLD_MEMBERS, ebufp) > 0)
							{
								member_elemid = 0;
								member_cookie = NULL;
								while ((members_flistp = PIN_FLIST_ELEM_GET_NEXT(group_read_oflistp, PIN_FLD_MEMBERS, 
								&member_elemid, 1, &member_cookie, ebufp)) != (pin_flist_t *)NULL)
								{
									service_pdp = PIN_FLIST_FLD_GET(members_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
									
									if(!PIN_POID_IS_NULL(service_pdp))
									{
										service_read_iflistp = PIN_FLIST_CREATE(ebufp);
										PIN_FLIST_FLD_SET(service_read_iflistp, PIN_FLD_POID, service_pdp, ebufp);
										PIN_FLIST_ELEM_SET(service_read_iflistp, NULL, PIN_FLD_ALIAS_LIST, 0 , ebufp);
										
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
											"fm_tab_subscription_get_group_details : Read service object input flist", service_read_iflistp);
										PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, service_read_iflistp, &service_read_oflistp, ebufp);
										PIN_FLIST_DESTROY_EX(&service_read_iflistp, NULL);
										
										if(PIN_ERR_IS_ERR(ebufp))
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Service object PCM_OP_READ_FLDS:"
												" input flist ", service_read_iflistp);
											PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
												" Error while reading service object", ebufp);
											goto cleanup;
										}
										else
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
												"fm_tab_subscription_get_group_details: Read service object output flist", service_read_oflistp);
											
											if(service_read_oflistp != NULL && (alias_flistp = PIN_FLIST_ELEM_GET(service_read_oflistp,		PIN_FLD_ALIAS_LIST, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
											{
												member_flistp = PIN_FLIST_ELEM_ADD(chrg_groups_flistp, PIN_FLD_MEMBERS, member_count++, ebufp);
												PIN_FLIST_FLD_COPY(alias_flistp, PIN_FLD_NAME, member_flistp, PIN_FLD_MSISDN, ebufp);
											}
											
											PIN_FLIST_DESTROY_EX(&service_read_oflistp, NULL);
										}
									}
								}
							}
						/*
						//Shubha|commented for fetching getSharingMembers after deleting the DSG offer name through addRemoveOfferDSG|DBSS-13855 
						else
                        {
                            PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                                "fm_tab_subscription_get_group_details", group_read_oflistp);
                            pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_NO_GRP_SHARING_MEMBERS, 0, 0, 0);
                            PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
                                "No sharing group members found for the given request", ebufp);
                            goto cleanup;
                        }*/
					}
					else if (group_typep && !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS, 
                        strlen(PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS)))
                    {
						//Shubha|changed for fetching getSharingMembers after deleting the DSG offer name through addRemoveOfferDSG|DBSS-13855 
						disc_groups_flistp = PIN_FLIST_ELEM_ADD(all_group_details_oflistp, PIN_FLD_GROUPS, groups_count++, ebufp);
							PIN_FLIST_FLD_COPY(group_read_oflistp, PIN_FLD_NAME, disc_groups_flistp, PIN_FLD_GROUP_NAME, ebufp);
						
						if(group_read_oflistp != NULL && PIN_FLIST_ELEM_COUNT(group_read_oflistp, PIN_FLD_DISCOUNTS, ebufp) > 0 )
						{
							
							discount_elemid = 0;
							discount_cookie = NULL;
							while ((discount_flistp = PIN_FLIST_ELEM_GET_NEXT(group_read_oflistp, PIN_FLD_DISCOUNTS, 
								&discount_elemid, 1, &discount_cookie, ebufp)) != (pin_flist_t *)NULL)
							{
								discount_pdp = PIN_FLIST_FLD_GET(discount_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);
							
								if(!PIN_POID_IS_NULL(discount_pdp))
								{
									discount_read_iflistp = PIN_FLIST_CREATE(ebufp);
									PIN_FLIST_FLD_SET(discount_read_iflistp, PIN_FLD_POID, discount_pdp, ebufp);
									PIN_FLIST_FLD_SET(discount_read_iflistp, PIN_FLD_NAME, NULL, ebufp);
								
									PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
										"fm_tab_subscription_get_group_details : Read discount object input flist", discount_read_iflistp);
									PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, discount_read_iflistp, &discount_read_oflistp, ebufp);
									PIN_FLIST_DESTROY_EX(&discount_read_iflistp, NULL);
								
									if(PIN_ERR_IS_ERR(ebufp))
									{
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Discount object PCM_OP_READ_FLDS:"
											" input flist ", discount_read_iflistp);
										PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
											" Error while reading discount object", ebufp);
										goto cleanup;
									}
									else
									{
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
											"fm_tab_subscription_get_group_details: Read discount object output flist", discount_read_oflistp);
									
										if(discount_read_oflistp != NULL)
										{
											disc_offer_flistp = PIN_FLIST_ELEM_ADD(disc_groups_flistp, PIN_FLD_OFFER, offer_count++, ebufp);
											PIN_FLIST_FLD_COPY(discount_read_oflistp, PIN_FLD_NAME, disc_offer_flistp, PIN_FLD_OFFER_NAME, ebufp);
										}
									
										PIN_FLIST_DESTROY_EX(&discount_read_oflistp, NULL);
									}
								}
							}
						}
						
							if (offer_flagp && !strncmp(offer_flagp, TAB_FLAG_TRUE, 
								strlen(TAB_FLAG_TRUE)) && PIN_FLIST_ELEM_COUNT(group_read_oflistp, PIN_FLD_MEMBERS, ebufp) > 0)
							{
								member_elemid = 0;
								member_cookie = NULL;
								while ((members_flistp = PIN_FLIST_ELEM_GET_NEXT(group_read_oflistp, PIN_FLD_MEMBERS, 
								&member_elemid, 1, &member_cookie, ebufp)) != (pin_flist_t *)NULL)
								{
									service_pdp = PIN_FLIST_FLD_GET(members_flistp, PIN_FLD_SERVICE_OBJ, 1, ebufp);
								
									if(!PIN_POID_IS_NULL(service_pdp))
									{
										service_read_iflistp = PIN_FLIST_CREATE(ebufp);
										PIN_FLIST_FLD_SET(service_read_iflistp, PIN_FLD_POID, service_pdp, ebufp);
										PIN_FLIST_ELEM_SET(service_read_iflistp, NULL, PIN_FLD_ALIAS_LIST, 0 , ebufp);
									
										PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
											"fm_tab_subscription_get_dsg_details : Read service object input flist", service_read_iflistp);
										PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, service_read_iflistp, &service_read_oflistp, ebufp);
										PIN_FLIST_DESTROY_EX(&service_read_iflistp, NULL);
									
										if(PIN_ERR_IS_ERR(ebufp))
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Service object PCM_OP_READ_FLDS:"
												" input flist ", service_read_iflistp);
											PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
												" Error while reading service object", ebufp);
											goto cleanup;
										}
										else
										{
											PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
												"fm_tab_subscription_get_dsg_details: Read service object output flist", service_read_oflistp);
										
											if(service_read_oflistp != NULL && (alias_flistp = PIN_FLIST_ELEM_GET(service_read_oflistp,		PIN_FLD_ALIAS_LIST, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
											{
												member_flistp = PIN_FLIST_ELEM_ADD(disc_groups_flistp, PIN_FLD_MEMBERS, member_count++, ebufp);
												PIN_FLIST_FLD_COPY(alias_flistp, PIN_FLD_NAME, member_flistp, PIN_FLD_MSISDN, ebufp);
											}
										
											PIN_FLIST_DESTROY_EX(&service_read_oflistp, NULL);
										}
									}
								}
							}
						
						/*
						//Shubha|commented for fetching getSharingMembers after deleting the DSG offer name through addRemoveOfferDSG|DBSS-13855 
						else
						{
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                                "fm_tab_subscription_get_group_details", group_read_oflistp);
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_NO_GRP_SHARING_MEMBERS, 0, 0, 0);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
								"No sharing group members found for the given request", ebufp);
							goto cleanup;
						}*/
					}
					else
                    {
                        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                            "fm_tab_subscription_get_group_details", group_read_oflistp);
                        pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            TAB_ERR_CODE_NO_GRP_SHARING_MEMBERS, 0, 0, 0);
                        PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
                            "No sharing group members found for the given request", ebufp);
                        goto cleanup;
                    }
				}
				
				PIN_FLIST_DESTROY_EX(&group_read_oflistp, NULL);
			}
			else
            {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                    "fm_tab_subscription_get_group_details", results_flistp);
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                    TAB_ERR_CODE_NO_GRP_SHARING_MEMBERS, 0, 0, 0);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_grp_sharing_members:"
                    "ACCT/MSISDN is not under sharing group and no sharing grp members found", ebufp);
                goto cleanup;
            }
		}
	}
	
	*out_flistpp = PIN_FLIST_COPY(all_group_details_oflistp, ebufp);
	
	cleanup:
	/******************************************************************
	 * Clean up.
	******************************************************************/
	PIN_FLIST_DESTROY_EX(&group_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&all_group_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&discount_read_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&sponsor_read_oflistp, NULL);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_group_details output flist", *out_flistpp);
	return;
}
