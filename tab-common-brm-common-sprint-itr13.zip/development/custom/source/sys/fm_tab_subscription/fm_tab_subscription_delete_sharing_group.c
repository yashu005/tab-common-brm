/*******************************************************************************
 *
 *	This material is the confidential property of Telenor/Oracle Corporation or its
 *	licensors and may be used, reproduced, stored or transmitted only in
 *	accordance with a valid agreement.
 *
 ********************************************************************************/

/*************************************************************************************************
 *	Change History
 *
 *	Delivery Code	| No	| Date			| Programmer		| Req/bug/Gap	| Change details
 *
 *			| 1	| 11-OCT-2021		| Darshan		|		| New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP operation.
 *******************************************************************/
#include <stdio.h>
#include <string.h>
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "pin_subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void
op_tab_subscription_delete_sharing_group(
	cm_nap_connection_t 	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_delete_sharing_group(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subs_delete_sharing_grp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*opresp_flistp,
	pin_flist_t		*notify_flistp,	
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t		*ctxp,
	poid_t			*pdp,
	pin_errbuf_t		*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   status,
        poid_t                  *account_pdp,
        char                    *opcode_name,
        pin_flist_t             **r_flistpp,
        int64                   db_no,
        pin_errbuf_t            *ebufp);

extern char *
fm_tab_utils_common_convert_timestamp_to_date(
        pcm_context_t           *ctxp,
        time_t                  *input_time_t,
        pin_errbuf_t            *ebufp);

extern void
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_subscr_get_group_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	int32			flag,
	int32			customErrorCode,
	pin_flist_t		**err_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_NAME
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID			POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO		 STR [0] "CH_112"
 * 0 PIN_FLD_NAME			 STR [0] "DSG_GRP_2000005"
 *
 */
/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP operation.
 *************************************************************************/
void
op_tab_subscription_delete_sharing_group(
	cm_nap_connection_t	*connp,
	int			opcode,
	int			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	poid_t			*account_pdp = NULL;
	char			log_msg[512]= "";
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	int32			tab_order_flag = 0;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_delete_sharing_group function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_delete_sharing_group bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_delete_sharing_group input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_DELETE_SHARING_GROUP;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_DELETE_SHARING_GROUP )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_DELETE_SHARING_GROUP, ebufp);
		}
        fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_delete_sharing_group:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_delete_sharing_group(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_delete_sharing_group error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_delete_sharing_group:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_delete_sharing_group: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_delete_sharing_group:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_DELETE_SHARING_GROUP;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_DELETE_SHARING_GROUP )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_DELETE_SHARING_GROUP, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_delete_sharing_group output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to delete CSG/DSG
 * based on the passed group name.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */
void fm_tab_subscription_delete_sharing_group(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		**out_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	char			*grp_namep = NULL;
	char			*group_typep = NULL;
	char			*account_nop = NULL;
	char			*created_strp = NULL;
	pin_flist_t		*get_group_details_oflistp = NULL;
	pin_flist_t		*sharing_grp_delete_iflistp = NULL;
	pin_flist_t		*sharing_grp_delete_oflistp = NULL;
	pin_flist_t		*context_info_flistp = NULL;
	pin_flist_t		*group_flistp = NULL;
	pin_flist_t		*common_notification_flistp = NULL;
	pin_flist_t		*delete_sharing_rdata_flistp = NULL;
	pin_flist_t		*results_flistp = NULL;
	pin_flist_t		*read_event_iflistp = NULL;
	pin_flist_t		*read_event_oflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	poid_t			*group_pdp = NULL;
	poid_t			*notify_pdp = NULL;
	time_t			*created_t = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_delete_sharing_group "
		"input flist", in_flistp);
		
	/*Account Number not passed in input*/	
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
		
	if((account_nop && strlen(account_nop) == 0) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
			"Account Number is not passed in request", ebufp);
		goto cleanup;
	}

	grp_namep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);

	/*Group Name not passed in input*/
	if((grp_namep && strlen(grp_namep) == 0) ||
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GRP_NAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			"Group Name is not passed in input", ebufp);
		goto cleanup;
	}
	
	if(grp_namep && strlen(grp_namep) != 0)
	{
		/*Function to get group details based on PIN_FLD_NAME*/
		fm_tab_utils_common_subscr_get_group_details(ctxp, in_flistp,
			&get_group_details_oflistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_group_details:"
				" input flist ", in_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
				" Error while getting sharing group details", ebufp);
			goto cleanup;
		}
		else
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_subscr_get_group_details "
				"output flist", get_group_details_oflistp);

			if (get_group_details_oflistp && (group_flistp = PIN_FLIST_ELEM_GET(get_group_details_oflistp, 
				PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
			{
				common_notification_flistp = PIN_FLIST_CREATE(ebufp);
				delete_sharing_rdata_flistp = PIN_FLIST_CREATE(ebufp);
	
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
					common_notification_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
					common_notification_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
				PIN_FLIST_FLD_SET(common_notification_flistp, 
					PIN_FLD_GROUP_NAME, grp_namep, ebufp);
				
				notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_DELETE_SHARING_GROUP, -1, ebufp);
				PIN_FLIST_FLD_PUT(common_notification_flistp, PIN_FLD_POID, notify_pdp, ebufp);
	
				group_pdp = PIN_FLIST_FLD_GET(group_flistp, PIN_FLD_POID, 1, ebufp);

				if(!PIN_POID_IS_NULL(group_pdp))
				{
					group_typep = (char *)PIN_POID_GET_TYPE(group_pdp);

					if(group_typep != NULL)
					{
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "Resource Sharing Type");
						PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, group_typep);
					}

					if (group_typep &&
						(!strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_CHARGES,
						  strlen(PIN_OBJ_TYPE_GRP_SHARING_CHARGES)) ||
						 !strncmp(group_typep, PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS,
						 strlen(PIN_OBJ_TYPE_GRP_SHARING_DISCOUNTS))))
					{
						/* Frame the input flist for PCM_OP_SUBSCRIPTION_SHARING_GROUP_DELETE opcode call*/
						sharing_grp_delete_iflistp = PIN_FLIST_CREATE(ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, 
								sharing_grp_delete_iflistp, PIN_FLD_POID, ebufp);
						PIN_FLIST_FLD_COPY(group_flistp, PIN_FLD_POID, 
								sharing_grp_delete_iflistp, PIN_FLD_GROUP_OBJ, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
								sharing_grp_delete_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);

						context_info_flistp = PIN_FLIST_SUBSTR_ADD(sharing_grp_delete_iflistp, 
								PIN_FLD_CONTEXT_INFO, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
								context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
						PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
								context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_delete_sharing_group: "
							"PCM_OP_SUBSCRIPTION_SHARING_GROUP_DELETE input", sharing_grp_delete_iflistp);

						PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SHARING_GROUP_DELETE, 0, sharing_grp_delete_iflistp, 
								&sharing_grp_delete_oflistp, ebufp);

						if(PIN_ERR_IS_ERR(ebufp))
						{
							pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
									TAB_ERR_CODE_API_DELETE_SHARING_GROUP, 0, 0, 0);
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SHARING_GROUP_DELETE:"
									" input flist ", sharing_grp_delete_iflistp);
							PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SHARING_GROUP_DELETE:"
									" Error while deleting resource sharing group", ebufp);
							goto cleanup;
						}
						
						if(sharing_grp_delete_oflistp != NULL && (results_flistp = PIN_FLIST_ELEM_GET(sharing_grp_delete_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
						{
							PIN_FLIST_ELEM_SET(delete_sharing_rdata_flistp, sharing_grp_delete_oflistp, 
								PIN_FLD_RESULTS_DATA, PIN_ELEMID_ASSIGN, ebufp);
								
							PIN_FLIST_FLD_COPY(sharing_grp_delete_oflistp, PIN_FLD_POID, 
								common_notification_flistp, PIN_FLD_GROUP_OBJ, ebufp);
							PIN_FLIST_FLD_SET(common_notification_flistp, 
								PIN_FLD_POID_TYPE, group_typep, ebufp);
							PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_POID, 
								common_notification_flistp, PIN_FLD_EVENT_OBJ, ebufp);
								
							read_event_iflistp = PIN_FLIST_CREATE(ebufp);

							PIN_FLIST_FLD_COPY(results_flistp, PIN_FLD_POID, read_event_iflistp,
									PIN_FLD_POID, ebufp);
							PIN_FLIST_FLD_SET(read_event_iflistp, 
								PIN_FLD_CREATED_T, NULL, ebufp);
							PIN_FLIST_FLD_SET(read_event_iflistp, 
								PIN_FLD_DESCR, NULL, ebufp);
								
							PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"Event PCM_OP_READ_FLDS: "
								" input flist", read_event_iflistp);

							/* Call for PCM_OP_READ_FLDS to read event object */
							PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_event_iflistp, &read_event_oflistp,
									ebufp);

							if(PIN_ERR_IS_ERR(ebufp))
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"Event PCM_OP_READ_FLDS: "
									" input flist ", read_event_iflistp);
								PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS: "
									" Error while reading event object", ebufp);
								goto cleanup;
							}

							else
							{
								PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "Event PCM_OP_READ_FLDS: "
									" return flist", read_event_oflistp);
									
								if(read_event_oflistp != NULL)
								{
									PIN_FLIST_FLD_COPY(read_event_oflistp, PIN_FLD_DESCR, 
										common_notification_flistp, PIN_FLD_EVENT_DESCR, ebufp);
										
									created_t = PIN_FLIST_FLD_GET(read_event_oflistp, 
										PIN_FLD_CREATED_T, 1, ebufp);
										
									if(created_t && *created_t != 0)
									{
										created_strp = fm_tab_utils_common_convert_timestamp_to_date(ctxp, 
												created_t, ebufp);
										PIN_FLIST_FLD_PUT(common_notification_flistp, TAB_FLD_CREATED_T_STR, 
												created_strp, ebufp);
									}
								}
							}
						}
					}
					else
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
								TAB_ERR_CODE_INVALID_RES_SHARING_GROUP, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
								"Invalid Resource Sharing Group", ebufp);
						goto cleanup;
					}
				}
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_GRP_NAME_NOT_FOUND, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
						"Group Name is not present in BRM DB", ebufp);
				goto cleanup;
			}
			
			// Call function to enrich notification details
			fm_tab_subs_delete_sharing_grp_notification(ctxp, in_flistp, delete_sharing_rdata_flistp, common_notification_flistp, db_no, &notify_oflistp, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group:"
					" fm_tab_subs_delete_sharing_grp_notification input flist ", common_notification_flistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_delete_sharing_group: "
					" fm_tab_subs_delete_sharing_grp_notification error", ebufp);
				goto cleanup;
			}

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_delete_sharing_group:"
				" fm_tab_subs_delete_sharing_grp_notification output flist ", notify_oflistp);

			if (notify_oflistp)
			{
				if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
					PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
				}
				else
				{
					PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
				}
			}
		}
	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&get_group_details_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&sharing_grp_delete_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&sharing_grp_delete_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	//PIN_FLIST_DESTROY_EX(&common_notification_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_event_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&read_event_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&delete_sharing_rdata_flistp, NULL);	

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_delete_sharing_group output flist", *out_flistpp);
	return;
}

/**
 * We use this function to generate
 * custom notification on delete  
 * sharing group.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void
fm_tab_subs_delete_sharing_grp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*opresp_flistp,
	pin_flist_t		*notify_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*temp_input_iflistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subs_delete_sharing_grp_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subs_delete_sharing_grp_notification:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subs_delete_sharing_grp_notification: "
		"input flist", i_flistp);

	notify_iflistp = PIN_FLIST_CREATE(ebufp);
	temp_input_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, temp_input_iflistp, PIN_FLD_IN_FLIST, ebufp);

	if(opresp_flistp != NULL)
	{
		PIN_FLIST_SUBSTR_SET(notify_iflistp, opresp_flistp, PIN_FLD_OUT_FLIST, ebufp);
	}

	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_delete_sharing_group:"
			" fm_tab_subs_delete_sharing_grp_notification input flist ", notify_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subs_delete_sharing_grp_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_DELETE_SHARING_GROUP input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_DELETE_SHARING_GROUP, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subs_delete_sharing_grp_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subs_delete_sharing_grp_notification:"
			" Error in delete sharing group notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subs_delete_sharing_grp_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_DELETE_SHARING_GROUP output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subs_delete_sharing_grp_notification output flist", *r_flistpp);
	return;
}
