/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 16-02-2022    | Rashmi Shete      |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_REQUEST_LOAN operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_bill.h"
#include "pin_rate.h"
#include "pin_cust.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/loan.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#define FILE_SOURCE_ID "fm_tab_subscription_request_loan.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_request_loan(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void fm_tab_subscription_request_loan(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
static void
fm_tab_subscription_request_loan_enrich_notification(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             *ret_flistp,
        int64                   db_no,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp);

	
extern int32	*cfg_tab_system_currency;

 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_REQUEST_LOAN is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                          POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN                    STR [0] "981999999"
 * 0 PIN_FLD_TRANS_ID                STR [0] "test1111"
 * 0 PIN_FLD_AMOUNT        STR [0] 25
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 * 0 PIN_FLD_RESOURCE_ID       STR [0] "21321"
 * 0 PIN_FLD_LOCATION             STR [0] " AF4345"

 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_REQUEST_LOAN operation.
 *************************************************************************/
void
op_tab_subscription_request_loan(
	cm_nap_connection_t		*connp,
	int				opcode,
	int				flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t			*r_flistp = NULL;
	int32				tab_order_flag = 0;
	int32				error_clear_flag = 1;
	int32				cerror_code = 0;
	char				log_msg[512]= "";
	int64				db_no = 0;
	poid_t				*account_pdp = NULL;
	int32				status = PIN_BOOLEAN_TRUE;
	pin_flist_t			*enrich_iflistp = NULL;
	pin_decimal_t			*amt_dcmlp = NULL;
	char				*transid_strp = NULL;
	char				*msisdn_strp = NULL;
	pin_flist_t			*i_flistp = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_request_loan error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_REQUEST_LOAN) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_request_loan opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	* Debug: Input Flist
	***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_request_loan input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);


	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
				" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_REQUEST_LOAN;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_REQUEST_LOAN )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_REQUEST_LOAN, ebufp);
		}
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/***********************************************************
		 * Mandatory Fields Validation
		 ***********************************************************/
		amt_dcmlp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_AMOUNT, 0, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error in the input flist ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan:"
				"Error in the input flist", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);
			/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
			 * in the response with the errorCode coming from the return flist*/
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

			*ret_flistpp = r_flistp;
			return;
		}

		if (pbo_decimal_is_null(amt_dcmlp,ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_AMOUNT_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error getting the Amount", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error getting the Amount in input flist", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);

			/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
			 * in the response with the errorCode coming from the return flist*/
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

			*ret_flistpp = r_flistp;
			return;
		}

		transid_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 0, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error in the input flist ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan:"
				"Error in the input flist", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);

			/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
			 * in the response with the errorCode coming from the return flist*/
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

			*ret_flistpp = r_flistp;
			return;
		}
		if (transid_strp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error getting the Loan Ref Id", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Error getting the Loan Ref Id  input flist", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);

			/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
			 * in the response with the errorCode coming from the return flist*/
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

			*ret_flistpp = r_flistp;
			return;
		}

		/***********************************************************
		 *PIN_FLD_MSISDN
		 ***********************************************************/
		msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 0, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Missing PIN_FLD_MSISDN ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Missing PIN_FLD_MSISDN", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);
			*ret_flistpp = PIN_FLIST_COPY(r_flistp,ebufp);
			PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
			return;
		}
		if (msisdn_strp == NULL)
		{
			pin_set_err(ebufp, PIN_ERRLOC_FLIST, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Missing PIN_FLD_MSISDN", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"op_tab_sub_request_loan: Missing PIN_FLD_MSISDN", in_flistp);

			fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
			PIN_ERR_CLEAR_ERR(ebufp);

			/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
			 * in the response with the errorCode coming from the return flist*/
			fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

			*ret_flistpp = r_flistp;
			return;
		}

		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_sub_request_loan:"
				" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_request_loan:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		i_flistp = PIN_FLIST_COPY(enrich_iflistp, ebufp);
		fm_tab_subscription_request_loan(ctxp, i_flistp, &r_flistp, db_no, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_sub_request_loan error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR, "op_tab_sub_request_loan:"
				" fm_tab_subscription_request_loan input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_request_loan: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		 * in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

		*ret_flistpp = r_flistp;
		return;
	}

cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
			"TAB_OP_SUB_REQUEST_LOAN", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_request_loan:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_REQUEST_LOAN;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_REQUEST_LOAN )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_REQUEST_LOAN, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);

		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	 * in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;

	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&i_flistp, NULL);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_request_loan output flist", *ret_flistpp);
	return;
}

void fm_tab_subscription_request_loan(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*ecebalances_ret_flistp = NULL;
	pin_flist_t			*billinfo_flistp= NULL;
	pin_flist_t			*service_out_flistp = NULL;
	pin_flist_t			*service2_out_flistp = NULL;
	pin_flist_t			*billdebit_out_flistp = NULL;
	pin_flist_t			*extendvalidity_flistp = NULL;
	pin_flist_t			*enrich_iflistp = NULL;
	pin_flist_t			*ret_apply_loan_flistp = NULL;
	pin_flist_t			*res_ret_apply_loan_flistp = NULL;
	pin_flist_t			*apply_loan_flistp = NULL;
	pin_flist_t			*loan_res_flistp = NULL;
	pin_flist_t			*tab_prepaid_loan_info_iflistp = NULL;
	pin_flist_t			*enrich_apply_loan_flistp = NULL;
	pin_flist_t			*create_tab_prepaid_loan_info_iflistp = NULL;
	pin_flist_t			*update_service_flistp = NULL;
	pin_flist_t			*notify_iflistp = NULL;
	pin_flist_t			*notify_oflistp = NULL;
	pin_flist_t			*bal_impact_flistp = NULL;
	pin_flist_t			*loanfee_readobj_iflistp = NULL;
	pin_flist_t			*loanfee_readobj_rflistp = NULL;
	pin_flist_t			*balances_iflistp = NULL;
	pin_flist_t			*balances_oflistp = NULL;
	pin_flist_t			*recurring_cycle_fwd_flistp = NULL;
	pin_flist_t			*cycle_fwd_flistp = NULL;
	pin_flist_t			*ret_cycle_fwd_flistp = NULL;
	pin_flist_t			*out_cycle_fwd_flistp = NULL;
	pin_flist_t			*loan_svc_flistp = NULL;
	pin_flist_t			*ret_loan_svc_flistp = NULL;
	pin_flist_t			*enrichresult_in_flistp = NULL;
	pin_flist_t			*enrichresult_out_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	poid_t				*account_pdp = NULL;
	poid_t				*tab_prepaid_loan_infop = NULL;
	poid_t				*loan_fee_obj = NULL;
	char				log_msg[256]="";
	int32				active_flag = 1;
	int32				paytype_i = 0;
	int32				loan_request_status = 0;
	time_t				*srvcexpirydate_cp = NULL;
	int32				elemid = 0;
	int32				cycle_fwd_flg = PIN_RATE_FLG_PRO_NORMAL;
	char				*svc_validity_dt = NULL;
	void				*vp = NULL;
	int32				error_code = 0;
	time_t				now_t = pin_virtual_time(NULL);
	pin_errbuf_t                    local_ebuf = {0};
	pin_errbuf_t                    *local_ebufp = &local_ebuf;
	
	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan:"
			" input flist", in_flistp);
		return;
	}
	
	PIN_ERR_CLEAR_ERR(ebufp);
						
	/*********************************************************
	 * Getting information of service from the PIN_FLD_MSISDN
	 *********************************************************/
	sprintf(log_msg,"fm_tab_subscription_request_loan: "
					"Start getting the Service information from PIN_FLD_MSISDN");
					
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	fm_tab_utils_common_get_service_from_msisdn(ctxp, in_flistp, &service_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            		"fm_tab_subscription_request_loan: Error in getting service from msisdn", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
		"fm_tab_subscription_request_loan input flist", in_flistp);

		goto cleanup;
	}

	if (service_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            TAB_ERR_CODE_SERVICE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_request_loan: Error in getting service from msisdn", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_request_loan: "
			"Failed checking the service with input flist", in_flistp);
		goto cleanup; 
	}

	sprintf(log_msg,"fm_tab_subscription_request_loan:"
					"After getting the service from MSISDN");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_request_loan:"
			" get servive from msisdn return flist", service_out_flistp);
	
	
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_POID, in_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LOGIN, in_flistp, PIN_FLD_LOGIN, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LIFECYCLE_STATE, in_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_STATUS, in_flistp, PIN_FLD_STATUS, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_request_loan: enhance input flist", in_flistp);
	
	/*********************************************************
	 * Getting the Service Information after getting the Service
	 *********************************************************/
	sprintf(log_msg,"fm_tab_subscription_request_loan:"
					" Get Service information from MSISDN Search Result");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);
	
	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_subscription_request_loan:"
					" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan input flist", in_flistp);
		goto cleanup;
	}
	
	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan input flist", in_flistp);
		goto cleanup;
	}
	
	sprintf(log_msg,"fm_tab_subscription_request_loan:"
					" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)
	
	/*********************************************************
	 * Validation if the account is prepaid
	 *********************************************************/
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	paytype_i = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	
	if (paytype_i != PIN_BILL_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_PREPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_request_loan: Error Paytype is not prepaid", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_request_loan: Error Paytype is not prepaid input flist", billinfo_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
            "Validated to be prepaid account");
	
	/*********************************************************
	 * Validation if the service is active
	 *********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_get_service_from_msisdn return flist", service_out_flistp);

	/* CDTAC-13314 Removed validation and to be done at BU Hook level
	vp =PIN_FLIST_FLD_GET(service_out_flistp, PIN_FLD_STATUS, 1, ebufp);
	if (vp != NULL)
	{
		status_i = *(int32 *)vp;
		
		if (status_i != PIN_STATUS_CLOSED)
		{
			 pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_SERVICE_IS_CLOSED, 0, 0, 0);

			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_request_loan: Error Service or Lifecycle state cannot be processed", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_request_loan: Error input flist", in_flistp);
			goto cleanup;
		}
	
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
			"Validated to be Active Service");
	}*/


	/*********************************************************
     * Flist creation of PCM_OP_LOAN_APPLY_LOAN
     *********************************************************/
    /*********************************************************
     *Sample Input Flist to call the opcode:
	 * 0 PIN_FLD_POID            POID [0] 0.0.0.1 /account 2239770 0
	 * 0 PIN_FLD_PROGRAM_NAME          STR [0] "er2345|CRM"
	 * 0 PIN_FLD_SERVICE_OBJ           POID [0] 0.0.0.1 /service/telco/gsm 2238106 0
	 * 0 PIN_FLD_AMOUNT     DECIMAL [0] 20
     *********************************************************/

	apply_loan_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, apply_loan_flistp, PIN_FLD_POID, ebufp); //ACCOUNT_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, apply_loan_flistp, PIN_FLD_SERVICE_OBJ, ebufp); //SERVICE_OBJ
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, apply_loan_flistp, PIN_FLD_PROGRAM_NAME, ebufp); //PROGRAM_NAME
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT, apply_loan_flistp, PIN_FLD_AMOUNT, ebufp); //AMOUNT

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_request_loan: before calling TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN opcode , apply_loan_flist input",apply_loan_flistp);
	PIN_FLIST_SUBSTR_PUT(in_flistp, apply_loan_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_request_loan: before calling TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN opcode , enrichment input",in_flistp);

	/*********************************************************
	 * Policy Opcode hookup for the enhancement of information
	 * or additional business policy
	 *********************************************************/
	

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN, 0, in_flistp, &enrich_apply_loan_flistp, ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan : TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN:"
			"Enrich input flist", in_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrich_apply_loan_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	if (enrich_apply_loan_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN enrich_iflistp is NULL.", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan:"
		"Enrich input flist : TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN : ", in_flistp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
		"TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN : After Enrich output flist :", enrich_apply_loan_flistp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
		" PCM_OP_LOAN_APPLY_LOAN input flist ", enrich_apply_loan_flistp);

	/***************************************
	 * PCM_OP_LOAN_APPLY_LOAN  Opcode Call
	 ***************************************/
	PCM_OP(ctxp, PCM_OP_LOAN_APPLY_LOAN , 0, enrich_apply_loan_flistp, &ret_apply_loan_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);


		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
			" input flist ", enrich_apply_loan_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
			" Error in PCM_OP_LOAN_APPLY_LOAN", ebufp);
		goto cleanup;
	}        

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
		" PCM_OP_LOAN_APPLY_LOAN output flist ", ret_apply_loan_flistp);

	if (ret_apply_loan_flistp && (loan_res_flistp=PIN_FLIST_ELEM_GET(ret_apply_loan_flistp, PIN_FLD_RESULTS,
		PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		vp = PIN_FLIST_FLD_GET(loan_res_flistp, PIN_FLD_RESULT, 0, ebufp);
		
		if (vp != NULL)
		{
			loan_request_status = *(int32 *)vp;

			if (loan_request_status==PIN_LOAN_RES_SUCCESS )
			{
				tab_prepaid_loan_info_iflistp=PIN_FLIST_CREATE(ebufp);
				tab_prepaid_loan_infop = PIN_POID_CREATE(db_no, "/tab_prepaid_loan_info", -1, ebufp);
				PIN_FLIST_FLD_PUT(tab_prepaid_loan_info_iflistp, PIN_FLD_POID, (void *)tab_prepaid_loan_infop, ebufp);
				PIN_FLIST_FLD_COPY(loan_res_flistp, PIN_FLD_EVENT_OBJ, tab_prepaid_loan_info_iflistp, PIN_FLD_EVENT_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID , tab_prepaid_loan_info_iflistp, PIN_FLD_TRANS_ID , ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN , tab_prepaid_loan_info_iflistp, PIN_FLD_MSISDN , ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID , tab_prepaid_loan_info_iflistp, PIN_FLD_RESOURCE_ID , ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_AMOUNT  , tab_prepaid_loan_info_iflistp, PIN_FLD_AMOUNT  , ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ , tab_prepaid_loan_info_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(loan_res_flistp, PIN_FLD_CREDIT_LIMIT , tab_prepaid_loan_info_iflistp, PIN_FLD_CREDIT_LIMIT , ebufp);
				PIN_FLIST_FLD_COPY(loan_res_flistp, PIN_FLD_AVAILABLE_LOAN_LIMIT, tab_prepaid_loan_info_iflistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
				PIN_FLIST_FLD_COPY(loan_res_flistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, tab_prepaid_loan_info_iflistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, ebufp);

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_subscription_request_loan : create /tab_prepaid_loan_info "
					"object input flist", tab_prepaid_loan_info_iflistp);

				PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, tab_prepaid_loan_info_iflistp, &create_tab_prepaid_loan_info_iflistp, ebufp);
				PIN_FLIST_DESTROY_EX(&tab_prepaid_loan_info_iflistp, NULL);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
						"fm_tab_subscription_request_loan: Error in creating /tab_prepaid_loan_info object", ebufp);
					goto cleanup;
				}

				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
					"fm_tab_subscription_request_loan: create /tab_prepaid_loan_info "
					"object output flist", create_tab_prepaid_loan_info_iflistp);
					
				/*Read_Obj of loan_fee_obj*/
				loan_fee_obj = PIN_FLIST_FLD_GET(loan_res_flistp,PIN_FLD_LINK_OBJ,0,ebufp);
				loanfee_readobj_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_SET(loanfee_readobj_iflistp,PIN_FLD_POID, loan_fee_obj, ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," LAON FEE Read_Obj input flist",
						loanfee_readobj_iflistp);
				PCM_OP(ctxp, PCM_OP_READ_OBJ, 0, loanfee_readobj_iflistp,&loanfee_readobj_rflistp, ebufp);
				if (PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"loanfee_read_obj input flist",
						loanfee_readobj_iflistp);
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"loanfee_read_obj:"
						"Error while doing LAON FEE read_obj", ebufp);
					goto cleanup;
				}
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," LAON FEE Read_Obj return flist",
						loanfee_readobj_rflistp);
				
				if (loanfee_readobj_rflistp !=NULL)
				{
					if (PIN_FLIST_ELEM_COUNT(loanfee_readobj_rflistp,PIN_FLD_BAL_IMPACTS,ebufp))
					{
						bal_impact_flistp=PIN_FLIST_ELEM_GET(loanfee_readobj_rflistp,PIN_FLD_BAL_IMPACTS,PIN_ELEMID_ANY,1,ebufp);
						PIN_FLIST_FLD_COPY(bal_impact_flistp, PIN_FLD_AMOUNT, *out_flistpp,PIN_FLD_LOAN_FEE,ebufp);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," ret_flist with LAON FEE Read_Obj return flist",
						*out_flistpp);
					}
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"loanfee_read_obj input flist",
						loanfee_readobj_iflistp);
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"loanfee_read_obj:"
						"Error while doing LAON FEE read_obj", ebufp);
					goto cleanup;
				}
			}
			else 
			{
				switch(loan_request_status)
				{
					case PIN_LOAN_RES_MAX_AMOUNT_EXCEEDED:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_MAX_AMOUNT_EXCEEDED, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_NO_OF_TIMES_LOAN_GRANT_EXCEEDED:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_NO_OF_TIMES_LOAN_GRANT_EXCEEDED, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_LOCATION_NOT_ELIGIBLE_FOR_LOAN:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_LOCATION_NOT_ELIGIBLE_FOR_LOAN, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_REJECTED_BY_EXTERNAL_ENTITY:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_REJECTED_BY_EXTERNAL_ENTITY, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_AMOUNT_REQUESTED_LESS_THAN_MIN_AMOUNT:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_AMOUNT_REQUESTED_LESS_THAN_MIN_AMOUNT, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_ACCT_OR_SERVICE_IS_UNDERAGE:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_ACCT_OR_SERVICE_IS_UNDERAGE, 0, 0, 0);
						break;
						
					case PIN_LOAN_RES_ACCT_NOT_ACTIVE:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_ACCT_NOT_ACTIVE, 0, 0, 0);
						break;		
						
					case PIN_LOAN_RES_FAILURE:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_FAILURE, 0, 0, 0);
						break;	
						
					case PIN_LOAN_RES_OPT_OUT:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_OPT_OUT, 0, 0, 0);
						break;	
						
					case PIN_LOAN_RES_ACTIVE_LOANS_EXCEEDED:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_LOAN_RES_ACTIVE_LOANS_EXCEEDED, 0, 0, 0);
						break;	
						
					default:
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);
						break;
				}	

				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_request_loan: Error in loan request, cannot be processed", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
					"fm_tab_subscription_request_loan: Error input flist", enrich_apply_loan_flistp);
				goto cleanup;
			}
		}
		else
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);


			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
				" input flist ", enrich_apply_loan_flistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
				" Error in PCM_OP_LOAN_APPLY_LOAN , Error in getting  result status.", ebufp);
			goto cleanup;

		}
	}
	else 
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
			" input flist ", enrich_apply_loan_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan:"
			" Error in PCM_OP_LOAN_APPLY_LOAN , Error in getting result.", ebufp);
		goto cleanup;
	}


	/*********************************************************
	 * Prepare input flist for PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
	 *******************************************************/
	recurring_cycle_fwd_flistp=PIN_FLIST_COPY(in_flistp, ebufp);

	cycle_fwd_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, cycle_fwd_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, cycle_fwd_flistp, PIN_FLD_SERVICE_OBJ, ebufp);       
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BILLINFO_OBJ, cycle_fwd_flistp, PIN_FLD_BILLINFO_OBJ, ebufp);       
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, cycle_fwd_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_FLAGS, &cycle_fwd_flg, ebufp);
	PIN_FLIST_FLD_SET(cycle_fwd_flistp, PIN_FLD_END_T, &now_t, ebufp);
	PIN_FLIST_SUBSTR_PUT(recurring_cycle_fwd_flistp, cycle_fwd_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_request_loan: TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT"
		" input flist", recurring_cycle_fwd_flistp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT, 0,
		recurring_cycle_fwd_flistp, &ret_cycle_fwd_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan :"
			" TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT:"
			"input flist", recurring_cycle_fwd_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(ret_cycle_fwd_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	if (ret_cycle_fwd_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
			"TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT : return flist :", ret_cycle_fwd_flistp);

		/*******************************************************
		 * Call OOB opcode PCM_OP_SUBSCRIPTION_CYCLE_FORWARD
		 *******************************************************/
		PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_CYCLE_FORWARD, 0,
			ret_cycle_fwd_flistp, &out_cycle_fwd_flistp, ebufp);

		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_request_loan: "
				"PCM_OP_SUBSCRIPTION_CYCLE_FORWARD return Error ", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan :"
				" TPCM_OP_SUBSCRIPTION_CYCLE_FORWARD:"
				"input flist", ret_cycle_fwd_flistp);
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
			"TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT : return flist :", ret_cycle_fwd_flistp);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
			"No recurring Purchase triggered");
	}

	loan_svc_flistp=PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(loan_svc_flistp, ret_apply_loan_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_request_loan: TAB_OP_SUBSCRIPTION_POL_LOAN_UPDT_SVC_VALIDITY"
			"input flist", loan_svc_flistp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_LOAN_UPDT_SVC_VALIDITY, 0, loan_svc_flistp, &ret_loan_svc_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_request_loan: Error in "
			"TAB_OP_SUBSCRIPTION_POL_LOAN_UPDT_SVC_VALIDITY  ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan :"
			" TAB_OP_SUBSCRIPTION_POL_LOAN_UPDT_SVC_VALIDITY:"
			"input flist", loan_svc_flistp);

		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(ret_loan_svc_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
		"TAB_OP_SUBSCRIPTION_POL_ALLOCATE_LOAN_AMOUNT : output flist :", ret_loan_svc_flistp);

	if (ret_loan_svc_flistp != NULL)
	{
		srvcexpirydate_cp = PIN_FLIST_FLD_GET(ret_loan_svc_flistp,
					PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
		svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, srvcexpirydate_cp, ebufp);
		PIN_FLIST_FLD_SET(*out_flistpp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt,  ebufp);

		if (srvcexpirydate_cp && srvcexpirydate_cp  != NULL)
		{     
			/*******************************************************
			 * Call to the PCM_OP_CUST_UPDATE_SERVICES
			 *******************************************************/

			update_service_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ,
					update_service_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ,
					update_service_flistp,PIN_FLD_SERVICE_OBJ, ebufp);       
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME,
					update_service_flistp, PIN_FLD_PROGRAM_NAME, ebufp);
			PIN_FLIST_FLD_COPY(ret_loan_svc_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T,
					update_service_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
			if(PIN_FLIST_FLD_GET(ret_loan_svc_flistp,
				PIN_FLD_LIFECYCLE_STATE, 1, ebufp)!=NULL)
			{
				PIN_FLIST_FLD_COPY(ret_loan_svc_flistp, PIN_FLD_LIFECYCLE_STATE,
				update_service_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
			}
			else
			{
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LIFECYCLE_STATE,
					update_service_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
			}
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID,
					update_service_flistp, PIN_FLD_CORRELATION_ID, ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER,
					update_service_flistp, PIN_FLD_EXTERNAL_USER, ebufp);                

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
					"PCM_OP_CUST_UPDATE_SERVICES : input flist :",update_service_flistp);

			fm_tab_utils_common_update_service(ctxp, update_service_flistp,
						&service_out_flistp, db_no, ebufp);
	
			if (PIN_ERR_IS_ERR(ebufp)) 
			{
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan Update Services Error", ebufp);
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan - Update Services Error:"
				" input flist", update_service_flistp);

				goto cleanup;
			}

			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
				"PCM_OP_CUST_UPDATE_SERVICES : output flist :", service_out_flistp);
		}

	}
	else
	{
		srvcexpirydate_cp = PIN_FLIST_FLD_GET(in_flistp,
					PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp);
		svc_validity_dt = fm_tab_utils_common_convert_timestamp_to_date(ctxp, srvcexpirydate_cp, ebufp);
		PIN_FLIST_FLD_SET(*out_flistpp, TAB_FLD_SVC_VALIDITY_DATE, svc_validity_dt,  ebufp);
	}
	if(svc_validity_dt!= NULL)
         {
                free(svc_validity_dt);
         }

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			" ret_flist with TAB_FLD_SVC_VALIDITY_DATE ", *out_flistpp);

	/*******************************************************
	 * Fetch the main balance of the subscriber
	 *******************************************************/
	balances_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ,balances_iflistp,PIN_FLD_POID, ebufp);       
	PIN_FLIST_FLD_SET(balances_iflistp,PIN_FLD_RESOURCE_ID, cfg_tab_system_currency,ebufp);
	fm_tab_utils_common_subscr_get_current_main_balance(ctxp,balances_iflistp, &balances_oflistp, db_no, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan: "
		"fm_tab_utils_common_subscr_get_current_main_balance Input", balances_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_request_loan: "
		"fm_tab_utils_common_subscr_get_current_main_balance Error", ebufp);

		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        TAB_ERR_CODE_GET_ECE_BALANCE, 0, 0, 0);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan: "
		"fm_tab_utils_common_subscr_get_current_main_balance return Flist", balances_oflistp);

	res_ret_apply_loan_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(apply_loan_flistp, PIN_FLD_ACCOUNT_OBJ, res_ret_apply_loan_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(apply_loan_flistp, PIN_FLD_MSISDN, res_ret_apply_loan_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, res_ret_apply_loan_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(apply_loan_flistp, PIN_FLD_CREDIT_AMOUNT, res_ret_apply_loan_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(*out_flistpp, PIN_FLD_LOAN_FEE, apply_loan_flistp,PIN_FLD_LOAN_FEE,ebufp);
	
	if (balances_oflistp != NULL)
	{
		PIN_FLIST_FLD_COPY(balances_oflistp, PIN_FLD_CURRENT_BAL,
					res_ret_apply_loan_flistp, PIN_FLD_CURRENT_BAL, ebufp);
		PIN_FLIST_FLD_COPY(balances_oflistp, PIN_FLD_CURRENT_BAL,
					*out_flistpp, PIN_FLD_CURRENT_BAL, ebufp);
	}
	
	/***************************************************
	 * Enrichment of Return/Result
	 ****************************************************/
	enrichresult_in_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(enrichresult_in_flistp, *out_flistpp, PIN_FLD_OUT_FLIST, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Enrich Results input flistp", enrichresult_in_flistp);
	
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_REQUEST_LOAN_RESULTS , 0, enrichresult_in_flistp, &enrichresult_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge: Error processing Enrich Result  input flist", enrichresult_in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_sub_reverse_recharge:  Error processing Enrich Result", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Enrich Results output flistp", enrichresult_out_flistp);
	
	/***************************************************
	 * Finalization of Return FLIST
	 ****************************************************/
	if (enrichresult_out_flistp != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Enrichment Result flistp", enrichresult_out_flistp);
		*out_flistpp = PIN_FLIST_COPY(enrichresult_out_flistp, ebufp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_sub_reverse_recharge: Finalized Result flistp", *out_flistpp);
				
	elemid = 0;
    if (ret_apply_loan_flistp != NULL)
    {
		PIN_FLIST_ELEM_SET(res_ret_apply_loan_flistp, ret_apply_loan_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
    }

    if (out_cycle_fwd_flistp != NULL)
    {
		PIN_FLIST_ELEM_SET(res_ret_apply_loan_flistp, out_cycle_fwd_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
    }

    if (service_out_flistp != NULL)
    {
		PIN_FLIST_ELEM_SET(res_ret_apply_loan_flistp, service_out_flistp, PIN_FLD_RESULTS_DATA, elemid, ebufp);
		elemid++;
    }

	 /* NOTIFICATION GENERATION
	 ********************************************************/
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan:"
		"Notification Input FLIST ", apply_loan_flistp);

	fm_tab_subscription_request_loan_enrich_notification(ctxp, in_flistp, res_ret_apply_loan_flistp, db_no, &notify_oflistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan_enrich_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan_enrich_notification:"
			" Error in Notification", ebufp);
		*out_flistpp = PIN_FLIST_COPY(notify_oflistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		goto cleanup;
	}

	if (notify_oflistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
							PIN_ELEMID_ANY, 1, ebufp)) != NULL)
                {
			 PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
					 	*out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	 
	PIN_FLIST_DESTROY_EX(&ecebalances_ret_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&service2_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billdebit_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&extendvalidity_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_apply_loan_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_apply_loan_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&res_ret_apply_loan_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&loanfee_readobj_rflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_cycle_fwd_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&out_cycle_fwd_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&recurring_cycle_fwd_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&balances_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&balances_oflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrichresult_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_loan_svc_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&loan_svc_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&create_tab_prepaid_loan_info_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&loanfee_readobj_iflistp, ebufp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_request_loan output flist", *out_flistpp);
	return;
}



static void
fm_tab_subscription_request_loan_enrich_notification(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_flist_t             *ret_flistp,
        int64                   db_no,
        pin_flist_t             **r_flistpp,
        pin_errbuf_t            *ebufp)
{
        pin_flist_t             *enrich_notify_flistp = NULL;
        pin_flist_t             *notify_iflistp = NULL;
        pin_flist_t             *notify_flistp = NULL;
        pin_flist_t             *read_iflistp = NULL;
        pin_flist_t             *read_oflistp = NULL;
        pin_flist_t             *out_flistp = NULL;
        poid_t                  *notify_pdp = NULL;
	time_t                  now_t = pin_virtual_time(NULL);
	pin_errbuf_t            local_ebuf = {0};
	pin_errbuf_t            *local_ebufp = &local_ebuf;

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_subscription_request_loan_enrich_notification function entry error", ebufp);
                return;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_request_loan_enrich_notification: "
                                        "input flist", i_flistp);

        notify_iflistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, notify_iflistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);
        PIN_FLIST_SUBSTR_SET(notify_iflistp, ret_flistp, PIN_FLD_OUT_FLIST, ebufp);


        read_iflistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID ,read_iflistp, PIN_FLD_POID, ebufp);
        PIN_FLIST_FLD_SET(read_iflistp, PIN_FLD_ACCOUNT_NO, NULL, ebufp);


	 PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_subscription_loan_request_enrich_notification : Read flds input flist", read_iflistp);
        PCM_OP(ctxp, PCM_OP_READ_FLDS, 0, read_iflistp, &read_oflistp, ebufp);
        PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);

        if(PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
                        " input flist ", read_iflistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_READ_FLDS:"
                        " Error while reading Account flds", ebufp);
                goto cleanup;
        }

        if (read_oflistp == NULL)
        {
                pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                        PCM_OP_READ_FLDS, 0, 0, 0);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_loan_request_enrich_notification:"
                        " input flist", read_iflistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
                        "fm_tab_subscription_loan_request_enrich_notification return error", ebufp);
        }



		  // Create Notification Flist


        notify_flistp = PIN_FLIST_CREATE(ebufp);
        notify_pdp = PIN_POID_CREATE(db_no, TAB_OBJ_TYPE_REQUEST_LOAN_NOTIFICATION, -1, ebufp);
        PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);
        PIN_FLIST_FLD_COPY(read_oflistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_AMOUNT, notify_flistp, PIN_FLD_AMOUNT, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CURRENT_BAL, notify_flistp, PIN_FLD_CURRENT_BAL, ebufp);
        PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LOAN_FEE, notify_flistp, PIN_FLD_LOAN_FEE, ebufp);
	PIN_FLIST_FLD_SET(notify_flistp, PIN_FLD_POSTED_T, &now_t, ebufp);

        PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);



        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan_enrich_notification:"
                " TAB_OP_NOTIFY_POL_ENRICH_REQUEST_LOAN_NOTIFICATION input flist ", notify_iflistp);
        PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_REQUEST_LOAN_NOTIFICATION, 0,
                                notify_iflistp, &enrich_notify_flistp, ebufp);

        if (PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_CLEAR_ERR(ebufp);
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan_enrich_notification:"
                        " input flist ", notify_iflistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_request_loan_enrich_notification:"
                        " Error in Loan Notification", ebufp);

                *r_flistpp = PIN_FLIST_COPY(enrich_notify_flistp, local_ebufp);
		PIN_ERR_CLEAR_ERR(local_ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                                TAB_ERR_CODE_API_REQUEST_LOAN, 0, 0, 0);

                goto cleanup;
        }


        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_request_loan_enrich_notification:"
                " TAB_OP_NOTIFY_POL_ENRICH_REQUEST_LOAN_NOTIFICATION output flist ", enrich_notify_flistp);

        if (enrich_notify_flistp != NULL)
        {
                out_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);

        }
        *r_flistpp = out_flistp;

cleanup:
        PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
        PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
        PIN_FLIST_DESTROY_EX(&read_iflistp, NULL);
        PIN_FLIST_DESTROY_EX(&read_oflistp, NULL);
        PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_subscription_request_loan_enrich_notification output flist", *r_flistpp);
        return;
}




