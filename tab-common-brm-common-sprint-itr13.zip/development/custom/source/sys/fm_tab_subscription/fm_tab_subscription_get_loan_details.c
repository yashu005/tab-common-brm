/*******************************************************************************
 * 
 *  This material is the confidential property of Oracle Corporation or its
 *  licensors and may be used, reproduced, stored or transmitted only in
 *  accordance with a valid agreement.
 *
 *********************************************************************************/

/********************************************************************************
 * Change History
 *-------------------------------------------------------------------------------
 * No | Date        | Programmer         | Req/bug/Gap        | Change details
 *-------------------------------------------------------------------------------
 * 1  | 11-MAR-2022 | Venu Padala        |                    | Initial Version
 *                                                            | 
 *
 **********************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_GET_LOAN_DETAILS operation.
 *******************************************************************/
#include "pcm.h"
#include "ops/bal.h"
#include "ops/cust.h"
#include "ops/loan.h"
#include "cm_fm.h"
#include "pin_cust.h"
#include "pin_pymt.h"
#include "fm_bal.h"
#include "tab_ops_flds.h"
#include "tab_common.h"
#include "tab_utils_common.h"

EXPORT_OP void
op_tab_subscription_get_loan_details(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_get_loan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_loan_details_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_enrich_loan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		*res_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

static void
fm_tab_subscription_get_addtl_loan_info(
	pcm_context_t		*ctxp,
	poid_t			*loan_pdp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_get_loan_profile(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

/**
 * 
 * New opcode TAB_OP_SUBSCRIPTION_GET_LOAN_DETAILS is implemented to manage msisdn
 * and imsi details
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MSISDN
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_ACCOUNT_NO      STR [0] "0.0.0.1-14435750"
 * 0 PIN_FLD_MSISDN          STR [0] "9818888000"
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 * */

void
op_tab_subscription_get_loan_details(
	cm_nap_connection_t	*connp,
	int32			opcode,
	int32			flags,
	pin_flist_t		*in_flistp,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pcm_context_t		*ctxp = connp->dm_ctx;
	pin_flist_t		*r_flistp = NULL;
	int32			status = PIN_BOOLEAN_TRUE;
	pin_flist_t		*enrich_iflistp = NULL;
	int32			error_clear_flag = 1;
	int32			cerror_code = 0;
	char			log_msg[512]= "";
	int64			db_no = 0;


	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_loan_details function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;

	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_GET_LOAN_DETAILS) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_get_loan_details bad opcode error", ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_loan_details input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag,
				cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/****Common Input Validation****/
	fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no,ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_loan_details: "
			"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
        }

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_loan_details:"
		" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

	PIN_FLIST_DESTROY_EX(&r_flistp, NULL);

	/* call main function */
	fm_tab_subscription_get_loan_details(ctxp, enrich_iflistp, db_no, &r_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_get_loan_details error", ebufp);
		status = TAB_FAIL;
		goto cleanup;
	}

cleanup:
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_get_loan_details:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_loan_details:"
			" Error while getting Loan history", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_GET_LOAN_DETAILS;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_LOAN_DETAILS, ebufp);
		}

		fm_tab_utils_common_request_set_error(ctxp, in_flistp,
				error_clear_flag, cerror_code, &r_flistp,db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_GET_LOAN_DETAILS )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_GET_LOAN_DETAILS, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
	}
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_get_loan_details output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to get Recharge information.
 * If MSISDN have Recharge Transactions 
 * Those Recharges are returned in output flist
 **
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 **
 **/

static void
fm_tab_subscription_get_loan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*out_flistp = NULL;
	pin_flist_t		*res_flistp =NULL;
	pin_flist_t		*r_flistp =NULL;
	pin_flist_t		*t_flistp =NULL;
	pin_flist_t		*loan_flistp =NULL;
	pin_flist_t		*enrich_loan_flistp =NULL;
	pin_flist_t		*qry_flistp =NULL;
	pin_flist_t		*enrich_flistp =NULL;
	pin_flist_t		*enrich_out_flistp =NULL;
	pin_flist_t		*loan_in_flistp =NULL;
	pin_flist_t		*loan_out_flistp =NULL;
	pin_flist_t		*billinfo_flistp =NULL;
	pin_flist_t		*profile_flistp =NULL;
	pin_cookie_t		cookie = NULL;
	pin_decimal_t		*avl_loan_limit = NULL;
	int32			count = 0;
	int32			elem_id = 0;
	int32			active_flag = 0;
	int32			is_eligible = 0;
	int32			error_code = 0;
	int32			sub_pay_type = 0;
	char			*loan_ref_id = NULL;
	time_t			*start_t = NULL;
	time_t			*end_t = NULL;
	poid_t			*acct_pdp = NULL;
	void			*vp = NULL;
	pin_decimal_t           *count_zero = pbo_decimal_from_str("0.0", ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_loan_details function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_get_loan_details: input flist", in_flistp);

	fm_tab_subscription_get_loan_details_validate_input(ctxp, in_flistp, db_no, &r_flistp, ebufp);

	if( PIN_ERR_IS_ERR( ebufp ))
	{
		TAB_LOG_ERR(in_flistp, "fm_tab_subscription_get_loan_details:"
		" fm_tab_subscription_get_loan_details_validate_input error", ebufp);

		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details: "
		"fm_tab_subscription_get_loan_details_validate_input Output Flist", r_flistp);

        if (r_flistp == NULL)
        {
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_API_GET_LOAN_DETAILS, "fm_tab_subscription_get_loan_details:"
			" TAB_ERR_CODE_API_GET_LOAN_DETAILS error", ebufp);
		goto cleanup;
        }

	acct_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	fm_tab_utils_common_get_billinfo(ctxp, acct_pdp, 0, &billinfo_flistp, db_no, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(in_flistp, "fm_tab_subscription_get_loan_details:"
			" fm_tab_utils_common_get_billinfo error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_recharge: billinfo_flistp is ",billinfo_flistp);
	if (billinfo_flistp == NULL)
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_BILLINFO_NOT_FOUND,
			"fm_tab_subscription_get_loan_details: No Billinfo Associated to MSISDN", ebufp);
		goto cleanup;
	}

	vp = PIN_FLIST_FLD_GET(billinfo_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	if (vp)
	{
		sub_pay_type = *(int32*)vp;
	}

	if (sub_pay_type != PIN_PAY_TYPE_PREPAID)
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_NOT_PREPAID_ACCOUNT,
			"fm_tab_subscription_get_loan_details: Subscriber is not Prepaid account", ebufp);
		goto cleanup;
	}

	loan_ref_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	qry_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, qry_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, qry_flistp, PIN_FLD_SERVICE_OBJ, ebufp);

	if (loan_ref_id != NULL)
	{
		PIN_FLIST_FLD_COPY(r_flistp, PIN_FLD_TRANS_ID, qry_flistp, PIN_FLD_TRANS_ID, ebufp);
	}
	else
	{
		PIN_FLIST_FLD_COPY(r_flistp, PIN_FLD_START_T, qry_flistp, PIN_FLD_START_T, ebufp);
		PIN_FLIST_FLD_COPY(r_flistp, PIN_FLD_END_T, qry_flistp, PIN_FLD_END_T, ebufp);
	}
	start_t = PIN_FLIST_FLD_GET(r_flistp, PIN_FLD_START_T, 1, ebufp);
	end_t = PIN_FLIST_FLD_GET(r_flistp, PIN_FLD_END_T, 1, ebufp);

	if ((start_t == NULL) && (end_t == NULL) && (loan_ref_id == NULL))
	{
		PIN_FLIST_FLD_SET(qry_flistp, PIN_FLD_FLAGS, &active_flag, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_details PCM_OP_LOAN_GET_LOAN input flist", qry_flistp);

	/***********************************************************
	 * Perform the search.
	 ***********************************************************/
	PCM_OP(ctxp, PCM_OP_LOAN_GET_LOAN, 0, qry_flistp, &res_flistp, ebufp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(in_flistp, "fm_tab_subscription_get_loan_details:"
			" PCM_OP_LOAN_GET_LOAN error", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details: "
		"PCM_OP_LOAN_GET_LOAN Output Flist", res_flistp);

	if (res_flistp == NULL)
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_LOAN_NO_RESULTS_FOUND,
			"fm_tab_subscription_get_loan_details: No Results found for the input Data", ebufp);
		goto cleanup;
	}

	fm_tab_subscription_get_loan_profile(ctxp, in_flistp,
		&profile_flistp, db_no, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details: "
			"fm_tab_subscription_get_loan_profile return Flist", profile_flistp);

	if( PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(in_flistp, "fm_tab_subscription_get_loan_details:"
				" fm_tab_subscription_get_loan_profile error", ebufp);
		goto cleanup;
	}
	if (profile_flistp == NULL)
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_API_GET_LOAN_DETAILS,
				"fm_tab_subscription_get_loan_details:"
				" fm_tab_subscription_get_loan_profile error", ebufp);
		goto cleanup;
	}


	if ((t_flistp = PIN_FLIST_ELEM_GET(res_flistp, PIN_FLD_RESULTS,
	      		PIN_ELEMID_ANY, 1, ebufp)) != NULL)
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details: "
			"PCM_OP_LOAN_GET_LOAN Flist", t_flistp);
		count = PIN_FLIST_ELEM_COUNT(t_flistp, PIN_FLD_EVENTS, ebufp);

		if (count > 0)
		{
			fm_tab_subscription_enrich_loan_details(ctxp, r_flistp,
				t_flistp, db_no, &enrich_loan_flistp, ebufp);

			if( PIN_ERR_IS_ERR(ebufp))
			{
				TAB_LOG_ERR(res_flistp, "fm_tab_subscription_get_loan_details:"
					" fm_tab_subscription_enrich_loan_details error", ebufp);
				goto cleanup;
			}
		}
		else if ((start_t != NULL) && (end_t != NULL))
		{
			TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_LOAN_NO_RESULTS_FOUND,
				"fm_tab_subscription_get_loan_details: No Results found for the input Data", ebufp);
			goto cleanup;
		}
	}

	// Call the TAB_OP_SUBSCRIPTION_POL_ENRICH_ELIGIBLE_LOANS to 
	// enrich the Eligible loans for the input MSISDN
	enrich_flistp = PIN_FLIST_COPY(res_flistp, ebufp);
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_ELIGIBLE_LOANS , 0, enrich_flistp, &enrich_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(enrich_flistp, "fm_tab_subscription_get_loan_details:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_ELIGIBLE_LOANS error", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(enrich_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);

		goto cleanup;
	}

	// Prepare the Return Flist for this opcode
	out_flistp = PIN_FLIST_CREATE(ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, out_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, out_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, out_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, out_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, out_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	if (profile_flistp != NULL && enrich_loan_flistp == NULL)
	{
		PIN_FLIST_FLD_COPY(profile_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING,
				out_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, ebufp);
		PIN_FLIST_FLD_COPY(profile_flistp, TAB_FLD_TOTAL_LOAN_FEE, 
				out_flistp, TAB_FLD_TOTAL_LOAN_FEE, ebufp);
	}

	if (enrich_out_flistp != NULL)
	{
		elem_id = 0;
		cookie = NULL;
		while ((loan_flistp = PIN_FLIST_ELEM_GET_NEXT(enrich_out_flistp, TAB_FLD_LOAN_INFO,
							&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			PIN_FLIST_ELEM_SET(out_flistp, loan_flistp, TAB_FLD_LOAN_INFO, elem_id, ebufp);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_details: result flist", out_flistp);

	if ( res_flistp != NULL)
	{
		PIN_FLIST_CONCAT(out_flistp, enrich_loan_flistp, ebufp);
		if(t_flistp != NULL)
		{
			PIN_FLIST_FLD_COPY(t_flistp, PIN_FLD_CREDIT_LIMIT,
				out_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
			PIN_FLIST_FLD_COPY(t_flistp, PIN_FLD_AVAILABLE_LOAN_LIMIT,
				out_flistp, PIN_FLD_AVAILABLE_LOAN_LIMIT, ebufp);
		}
	}

	/** Check eligibility **/
	avl_loan_limit = PIN_FLIST_FLD_GET(out_flistp, PIN_FLD_AVAILABLE_LOAN_LIMIT, 1, ebufp);
	if (!pbo_decimal_is_null(avl_loan_limit, ebufp)
		&& (pbo_decimal_compare(avl_loan_limit, count_zero, ebufp) == 1))
	{
		is_eligible = 1;
	}

	PIN_FLIST_FLD_SET(out_flistp, PIN_FLD_VALIDITY_FLAGS, &is_eligible, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_details: return flist", *ret_flistpp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(enrich_flistp, "fm_tab_subscription_get_loan_details:"
			" Error in Results processing ", ebufp);
		goto cleanup;
	}

	// Call the TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_LOAN_DETAILS to 
	// enrich the Eligible loans for the input MSISDN
	loan_in_flistp = PIN_FLIST_COPY(in_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(loan_in_flistp, out_flistp, PIN_FLD_IN_FLIST, ebufp);

	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_LOAN_DETAILS , 0, loan_in_flistp, &loan_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		TAB_LOG_ERR(enrich_flistp, "fm_tab_subscription_get_loan_details:"
			" TAB_OP_SUBSCRIPTION_POL_ENRICH_GET_LOAN_DETAILS error", ebufp);
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*ret_flistpp = PIN_FLIST_COPY(loan_out_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}

	*ret_flistpp = PIN_FLIST_COPY(loan_out_flistp, ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&out_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&profile_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&qry_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&enrich_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&enrich_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&loan_in_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&loan_out_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&enrich_loan_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&billinfo_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&res_flistp, NULL);

	if (count_zero)
	{
		pbo_decimal_destroy(&count_zero);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_details return flist", *ret_flistpp);

	return;
}


/*************************************************************
 *  This function will validate the mandatory input fields
 *  for the opcode and return error if any field missing
 *  convert the date field in string to epoch format
 *************************************************************/

void
fm_tab_subscription_get_loan_details_validate_input(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*r_flistp =NULL;
	char			*inp_msisdn = NULL;
	char			*loan_ref_id = NULL;
	char			*start_dt = NULL;
	char			*end_dt = NULL;
	time_t			start_t = 0;
	time_t			end_t = 0;
	char			*inp_acctno = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_loan_details_validate_input function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_details_validate_input: input flist", in_flistp);

	inp_msisdn = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 1, ebufp);
	inp_acctno = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
	if(((inp_msisdn == NULL) || (inp_msisdn && strlen(inp_msisdn) == 0)) &&
	  	((inp_acctno == NULL) || (inp_acctno && strlen(inp_acctno) == 0)))
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_ACCT_MSISDN_MISSING,
			"fm_tab_subscription_get_loan_details_validate_input:"
					" ACCT/MSISDN is missing in the Input ", ebufp);
		goto cleanup;
	}

	r_flistp = PIN_FLIST_COPY(in_flistp, ebufp);

	loan_ref_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if ((loan_ref_id != NULL) && (strlen(loan_ref_id) != 0))
	{
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_TRANS_ID, loan_ref_id, ebufp);
	}
	else 
	{
		start_dt = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_FROM_STR, 1, ebufp);
		end_dt = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_VALID_TO_STR, 1, ebufp);

		if ((start_dt == NULL) || (start_dt && strlen(start_dt) == 0))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details_validate_input: "
			"Start Date is not passed/empty ", r_flistp);
			goto cleanup;
		}

		if ((end_dt == NULL) || (end_dt && strlen(end_dt) == 0))
		{
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details_validate_input: "
			"End Date is not passed/empty ", r_flistp);
			goto cleanup;
		}

		/*Convert date in string format to unix timestamp*/
		start_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, start_dt, ebufp);
		end_t = fm_tab_utils_common_convert_date_to_timestamp(ctxp, end_dt, ebufp);
		if ((start_t == 0) || (end_t == 0))
		{
			TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_INVALID_DATE,
				"fm_tab_subscription_get_loan_details_validate_input:"
					" Invalid Start Date / End Date in Input ", ebufp);
			goto cleanup;
		}

		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_START_T, &start_t, ebufp);
		PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_END_T, &end_t, ebufp);
        }

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_loan_details_validate_input: "
		"Modified input Flist", r_flistp);


cleanup:
	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_get_loan_details_validate_input: return flist", *ret_flistpp);

	return;
}


/*************************************************************
 *  This function loop through the Loan results flist of
 *  PCM_OP_LOAN_GET_LOAN and enrich additional details as
 *  required
 *************************************************************/

void
fm_tab_subscription_enrich_loan_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*in_flistp,
	pin_flist_t		*res_flistp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*loan_flistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	pin_flist_t		*out_flistp = NULL;
	poid_t			*loan_pdp = NULL;
	pin_decimal_t		*loan_due = NULL;
	pin_decimal_t		*loan_amt = NULL;
	pin_decimal_t		*loan_fee = NULL;
	pin_decimal_t		*total_loan = NULL;
	pin_decimal_t		*loan_balance = NULL;
	pin_decimal_t		*total_loan_due = pbo_decimal_from_str("0.00",ebufp);
	pin_decimal_t		*total_loan_fee = pbo_decimal_from_str("0.00",ebufp);
	int32			loan_unpaid = 0;
	int32			loan_repaid = 1;
	int32			loan_partial = 2;
	int32			elem_id = 0;
	pin_cookie_t		cookie = NULL;
	char			*loan_ref_id = NULL;
	char			*loan_trans_id = NULL;
	char			*loan_id = NULL;
	char			*loan_dt_str = NULL;
	time_t			*loan_t = NULL;


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_enrich_loan_details function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_enrich_loan_details: input flist", in_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_enrich_loan_details: results flist", res_flistp);

	loan_ref_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 1, ebufp);

	if ((loan_ref_id != NULL) && (strlen(loan_ref_id) != 0))
	{
		loan_id = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 0, ebufp);
	}

	r_flistp = PIN_FLIST_CREATE(ebufp);
	elem_id = 0;
	cookie = NULL;
	while ((loan_flistp = PIN_FLIST_ELEM_GET_NEXT(res_flistp, PIN_FLD_EVENTS,
		&elem_id, 1, &cookie, ebufp)) != (pin_flist_t *)NULL)
	{

		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_enrich_loan_details: Inside While Loop");
		loan_pdp = PIN_FLIST_FLD_GET(loan_flistp, PIN_FLD_EVENT_OBJ, 1, ebufp);

		fm_tab_subscription_get_addtl_loan_info(ctxp, loan_pdp, db_no, &out_flistp, ebufp);

		if( PIN_ERR_IS_ERR( ebufp ))
		{
			TAB_LOG_ERR(res_flistp, "fm_tab_subscription_enrich_loan_details:"
			" fm_tab_subscription_get_addtl_loan_details error", ebufp);

			PIN_FLIST_DETSROY_EX(&out_flistp, NULL);
			goto cleanup;
		}

		if (out_flistp != NULL)
		{
			loan_trans_id = PIN_FLIST_FLD_GET(out_flistp, PIN_FLD_TRANS_ID, 0, ebufp);
			if (loan_id != NULL)
			{
				if (strcmp(loan_id, loan_trans_id) == 0)
				{
					PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_subscription_enrich_loan_details: Loan RefID matches");
				}
				else
				{
					PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
						"fm_tab_subscription_enrich_loan_details: Loan RefID does not match");
					continue;
				}
			}

			t_flistp = PIN_FLIST_ELEM_ADD(r_flistp, PIN_FLD_EVENTS, elem_id, ebufp);

			PIN_FLIST_FLD_COPY(out_flistp, PIN_FLD_TRANS_ID,
				t_flistp, PIN_FLD_TRANS_ID, ebufp);
			PIN_FLIST_FLD_COPY(out_flistp, PIN_FLD_CREDIT_LIMIT,
				t_flistp, PIN_FLD_CREDIT_LIMIT, ebufp);
			PIN_FLIST_FLD_COPY(out_flistp, PIN_FLD_CREDIT_AMOUNT,
				t_flistp, PIN_FLD_CREDIT_AMOUNT, ebufp);

			loan_t = PIN_FLIST_FLD_GET(out_flistp, PIN_FLD_POSTED_T, 0, ebufp);
			loan_dt_str = fm_tab_utils_common_convert_timestamp_to_date(ctxp, loan_t, ebufp);
			PIN_FLIST_FLD_SET(t_flistp, TAB_FLD_EFFECTIVE_DATE, loan_dt_str, ebufp);
			free(loan_dt_str);

			loan_balance = PIN_FLIST_FLD_GET(out_flistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, 1, ebufp);
			if (!pbo_decimal_is_null(loan_balance, ebufp))
			{
				PIN_FLIST_FLD_SET(t_flistp, PIN_FLD_AVAILABLE_LOAN_BALANCE, loan_balance, ebufp);
			}


			PIN_FLIST_FLD_COPY(loan_flistp, PIN_FLD_AMOUNT,
					t_flistp, PIN_FLD_AMOUNT, ebufp);
			PIN_FLIST_FLD_COPY(loan_flistp, PIN_FLD_TAX,
					t_flistp, PIN_FLD_TAX, ebufp);
			PIN_FLIST_FLD_COPY(loan_flistp, PIN_FLD_LOAN_FEE,
					t_flistp, PIN_FLD_LOAN_FEE, ebufp);
			PIN_FLIST_FLD_COPY(loan_flistp, PIN_FLD_OUTSTANDING,
					t_flistp, PIN_FLD_OUTSTANDING, ebufp);
			PIN_FLIST_FLD_COPY(loan_flistp, PIN_FLD_TYPE,
					t_flistp, PIN_FLD_TYPE, ebufp);

			loan_due = PIN_FLIST_FLD_GET(loan_flistp, PIN_FLD_OUTSTANDING, 1, ebufp);
			loan_amt = PIN_FLIST_FLD_GET(loan_flistp, PIN_FLD_AMOUNT, 1, ebufp);
			loan_fee = PIN_FLIST_FLD_GET(loan_flistp, PIN_FLD_LOAN_FEE, 1, ebufp);
			total_loan = pbo_decimal_add(loan_amt, loan_fee, ebufp);

			if (pbo_decimal_is_zero(loan_due, ebufp))
			{
				PIN_FLIST_FLD_SET(t_flistp, PIN_FLD_STATUS_FLAGS, &loan_repaid, ebufp);
			}
			else if (pbo_decimal_compare(loan_due, total_loan, ebufp) < 0)
			{
				PIN_FLIST_FLD_SET(t_flistp, PIN_FLD_STATUS_FLAGS, &loan_partial, ebufp);
			}
			else
			{
				PIN_FLIST_FLD_SET(t_flistp, PIN_FLD_STATUS_FLAGS, &loan_unpaid, ebufp);
			}

			if (!pbo_decimal_is_zero(loan_due, ebufp))
			{
				pbo_decimal_add_assign(total_loan_due, loan_due, ebufp);
				pbo_decimal_add_assign(total_loan_fee, loan_fee, ebufp);
			}

			pbo_decimal_destroy(&total_loan);

		}
		// Destroy the return flist
		PIN_FLIST_DESTROY_EX (&out_flistp, NULL);
	}

        if (( PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_EVENTS, ebufp) == 0)
			&& (loan_id != NULL))
	{
		TAB_LOG_SET_ERR(in_flistp, TAB_ERR_CODE_INVALID_LOAN_TRANS_ID, "fm_tab_subscription_get_loan_details:"
			" Loan Trans ID Not Found error", ebufp);
		goto cleanup;
	}

        if ( PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_EVENTS, ebufp) > 0)
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_enrich_loan_details: Adding Outstanding Credit Limit details ");

		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, total_loan_due, ebufp);
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_TOTAL_LOAN_FEE, total_loan_fee, ebufp);
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_enrich_loan_details: out flist", r_flistp);

	*ret_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);

cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);
	if(total_loan_fee)
        {
                pbo_decimal_destroy(&total_loan_fee);
        }
	if(total_loan_due)
        {
                pbo_decimal_destroy(&total_loan_due);
        }


	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_enrich_loan_details: return flist", *ret_flistpp);

	return;
}

/*************************************************************
 *  This function will search the custom Loan Object
 *  /tab_prepaid_loan_info and fetch the additional details 
 *  based on the Loan Event Poid
 *************************************************************/

void
fm_tab_subscription_get_addtl_loan_info(
	pcm_context_t		*ctxp,
	poid_t			*loan_pdp,
	int64			db_no,
	pin_flist_t		**ret_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*r_flistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	pin_flist_t		*search_flistp = NULL;
	pin_flist_t		*args_flistp = NULL;
	poid_t			*srchp = NULL;
	void			*vp = NULL;
	int32			count = 0;
	int32			s_flags = SRCH_DISTINCT;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_addtl_loan_info function entry error", ebufp);
		return;
	}

	if (PIN_POID_IS_NULL(loan_pdp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_get_addtl_loan_info: Input Loan Poid is NULL");
		return;
	}

        srchp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
        search_flistp = PIN_FLIST_CREATE(ebufp);
        PIN_FLIST_FLD_PUT(search_flistp, PIN_FLD_POID, (void *)srchp, ebufp);
        PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_FLAGS, &s_flags, ebufp);

	vp =  (void *)"select X from /tab_prepaid_loan_info where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_flistp, PIN_FLD_TEMPLATE, vp, ebufp);

	args_flistp = PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_SET(args_flistp, PIN_FLD_EVENT_OBJ, loan_pdp, ebufp);

        PIN_FLIST_ELEM_ADD(search_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
                "fm_tab_subscription_get_addtl_loan_info Search flist", search_flistp);

        /***********************************************************
         * Perform the search.
         ***********************************************************/
        PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_flistp, &r_flistp, ebufp);

        if( PIN_ERR_IS_ERR(ebufp))
        {
                PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_addtl_loan_info: "
                        "PCM_OP_SEARCH Input Flist", search_flistp);
                PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_addtl_loan_info: "
                        "PCM_OP_SEARCH error", ebufp);
                goto cleanup;
        }

        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_get_addtl_loan_info: "
                "PCM_OP_SEARCH Output Flist", r_flistp);

        count = PIN_FLIST_ELEM_COUNT(r_flistp, PIN_FLD_RESULTS, ebufp);

	if(count == 1)
	{
		t_flistp = PIN_FLIST_ELEM_GET(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if(t_flistp)
			*ret_flistpp = PIN_FLIST_ELEM_TAKE(r_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
	}
cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX (&search_flistp, NULL);
	PIN_FLIST_DESTROY_EX (&r_flistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_addtl_loan_info: return flist", *ret_flistpp);

	return;
}


/*************************************************************
 *  This function will search the Loan Profile Object
 *  and fetch the Profile details 
 *************************************************************/

void
fm_tab_subscription_get_loan_profile(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*profile_flistp = NULL;
	pin_flist_t		*res_flistp = NULL;
	pin_flist_t		*limit_flistp = NULL;
	pin_flist_t		*credit_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	pin_flist_t		*t_flistp = NULL;
	pin_flist_t		*l_flistp = NULL;
	pin_flist_t		*loan_flistp = NULL;
	pin_flist_t		*loan_prof_flistp = NULL;
	pin_decimal_t		*avail_loan = NULL;
	pin_decimal_t		*loan_amt = NULL;
	pin_decimal_t		*loan_credit = NULL;
	pin_decimal_t		*zero_val = pbo_decimal_from_str("0.00",ebufp);
	char			loan_profile[] = "/profile/loan";

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_loan_profile error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_get_loan_profile:"
			" input flist", i_flistp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_get_loan_profile input", i_flistp);

	profile_flistp = PIN_FLIST_CREATE(ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, profile_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_SERVICE_OBJ, profile_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_OBJ, profile_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_SET(profile_flistp, PIN_FLD_TYPE_STR, loan_profile, ebufp);
	res_flistp = PIN_FLIST_ELEM_ADD(profile_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	l_flistp = PIN_FLIST_SUBSTR_ADD(res_flistp, PIN_FLD_LOAN_INFO, ebufp);
	PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_CREDIT_AMOUNT, NULL, ebufp);
	PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_CONFIG_LOAN_OBJ, NULL, ebufp);
	PIN_FLIST_FLD_SET(l_flistp, PIN_FLD_EXTERNAL_ELIGIBILITY, NULL, ebufp);
	credit_flistp = PIN_FLIST_ELEM_ADD(res_flistp, PIN_FLD_LIMIT, PIN_ELEMID_ANY, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_get_loan_profile input flist", profile_flistp);

	/***********************************************************
	 ** Call PCM_OP_CUST_FIND_PROFILE 
	 ************************************************************/
	PCM_OP(ctxp, PCM_OP_CUST_FIND_PROFILE, 0, profile_flistp, &ret_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_loan_profile input flist", profile_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_get_loan_profile: Error in getting Loan profile ", ebufp);
	}
	else
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
				"fm_tab_subscription_get_loan_profile output flist", ret_flistp);
		t_flistp = PIN_FLIST_ELEM_GET(ret_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp);
		if (t_flistp != NULL)
		{
			loan_flistp = PIN_FLIST_SUBSTR_GET(t_flistp, PIN_FLD_LOAN_INFO, 1, ebufp);
			if (loan_flistp != NULL)
			{
				loan_amt = PIN_FLIST_FLD_GET(loan_flistp, PIN_FLD_CREDIT_AMOUNT, 0, ebufp);
			}

			limit_flistp = PIN_FLIST_ELEM_GET(t_flistp, PIN_FLD_LIMIT, 0, 1, ebufp);
			if (limit_flistp != NULL)
			{
				loan_credit = PIN_FLIST_FLD_GET(limit_flistp, PIN_FLD_CREDIT_LIMIT, 0, ebufp);
			}
		}

		if (!pbo_decimal_is_null(loan_credit, ebufp)
				&& !pbo_decimal_is_null(loan_amt, ebufp))
		{
			avail_loan = pbo_decimal_subtract(loan_credit, loan_amt, ebufp);
			loan_prof_flistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_SET(loan_prof_flistp, PIN_FLD_CREDIT_LIMIT, loan_credit, ebufp);
			PIN_FLIST_FLD_PUT(loan_prof_flistp, PIN_FLD_AVAILABLE_LOAN_LIMIT, avail_loan, ebufp);
			PIN_FLIST_FLD_SET(loan_prof_flistp, TAB_FLD_TOTAL_LOAN_OUTSTANDING, zero_val, ebufp);
			PIN_FLIST_FLD_SET(loan_prof_flistp, TAB_FLD_TOTAL_LOAN_FEE, zero_val, ebufp);
			*r_flistpp = loan_prof_flistp;
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_get_loan_profile return flist", *r_flistpp);

	PIN_FLIST_DESTROY_EX(&profile_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&ret_flistp, NULL);
	pbo_decimal_destroy(&zero_val);

	return;
}

// End of File
