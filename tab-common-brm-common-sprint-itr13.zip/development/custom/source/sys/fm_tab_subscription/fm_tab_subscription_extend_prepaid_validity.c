/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 21-DEC-2021   | Sherwin           |               | New file.
 
*************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_EXTEND_PREPAID_VALIDITY operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "tab_ops_flds.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/cust.h"
#include "ops/bill.h"
#include "ops/ece.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "tab_common.h"
#include "tab_utils_common.h"
#include "pin_subscription.h"
#define FILE_SOURCE_ID "fm_tab_subscription_extend_prepaid_validity.c"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_extend_prepaid_validity(
	cm_nap_connection_t	*connp,
	int					opcode,
	int					flags,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void fm_tab_subscription_extend_prepaid_validity(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
static void
fm_tab_notify_adjust_balance_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*i_flistp,
	int64				db_no,
	pin_flist_t			**r_flistpp,
	pin_errbuf_t		*ebufp);

void
fm_tab_subscription_extprepaid_mandatory_flds_chck(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	int64				db_no,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_extprepbalval_get_resourcename_by_id(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp);
	
void
fm_tab_subscription_extprepbalval_create_event_bill_debit(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp);
	
int32
fm_tab_subscription_extprepbalval_transid_check(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	int64				db_no,
	pin_errbuf_t        *ebufp);

extern int32	*cfg_tab_system_currency;
extern pin_flist_t *config_beid_out_flistp;
 /**************************************************************************
 *
 * New opcode TAB_OP_SUBSCRIPTION_EXTEND_PREPAID_VALIDITY is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 * 0 PIN_FLD_POID                          POID [0] 0.0.0.1 /account -1 0
 * 0 PIN_FLD_MSISDN                    STR [0] "981999999"
 * 0 PIN_FLD_TRANS_ID                STR [0] "test1111"
 * 0 PIN_FLD_CHARGE_AMT        STR [0] 25
 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
 *
 *************************************************************************/
	

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_EXTEND_PREPAID_VALIDITY operation.
 *************************************************************************/
void
op_tab_subscription_extend_prepaid_validity(
	cm_nap_connection_t		*connp,
	int						opcode,
	int						flags,
	pin_flist_t				*in_flistp,
	pin_flist_t				**ret_flistpp,
	pin_errbuf_t			*ebufp)
{
	pcm_context_t			*ctxp = connp->dm_ctx;
	pin_flist_t				*r_flistp = NULL;
	int32					tab_order_flag = 0;
	int32					error_clear_flag = 1;
	int32					cerror_code = 0;
	char					log_msg[512]= "";
	int64					db_no = 0;
	poid_t					*account_pdp = NULL;
	int32					status = PIN_BOOLEAN_TRUE;
	pin_flist_t				*enrich_iflistp = NULL;

	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_extend_prepaid_validity error",ebufp);
		return ;
	}
	
	PIN_ERRBUF_CLEAR(ebufp);

	/***********************************************************
	* Insanity check.
	***********************************************************/
	if (opcode != TAB_OP_SUBSCRIPTION_EXTEND_PREPAID_VALIDITY) 
	{
		pin_set_err(ebufp,PIN_ERRLOC_FM,
			PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE,0,0,opcode);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_extend_prepaid_validity opcode error",ebufp);
		return;
	}
	
	/***********************************************************
	* Debug: Input Flist
	***********************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_extend_prepaid_validity input flist", in_flistp);

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	
	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
        	PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}
	
	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" Error while searching /tab_order object", ebufp);
        
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_EXTEND_PREPAID_VALIDITY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
			cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_EXTEND_PREPAID_VALIDITY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_EXTEND_PREPAID_VALIDITY, ebufp);
		}
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
                return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
	if(PIN_POID_IS_NULL(account_pdp))
	{
		account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
	}

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
 		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
       
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_extend_prepaid_validity: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_extend_prepaid_validity:"
				" fm_tab_utils_common_validate_and_normalize_input input flist", in_flistp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_extend_prepaid_validity:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_extend_prepaid_validity(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
			
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_sub_extend_prepaid_validity error", ebufp);
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_extend_prepaid_validity:"
				" fm_tab_subscription_extend_prepaid_validity input flist", in_flistp);
			status = TAB_FAIL;
		goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_sub_extend_prepaid_validity:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_extend_prepaid_validity: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUB_EXTEND_PREPAID_VALIDITY", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"op_tab_sub_extend_prepaid_validity:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_sub_extend_prepaid_validity:"
			" Error while creating /tab_order object", ebufp);
		
		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_EXTEND_PREPAID_VALIDITY;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
		cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_EXTEND_PREPAID_VALIDITY )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_EXTEND_PREPAID_VALIDITY, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
    }
    fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
    *ret_flistpp = r_flistp;
	
    PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_sub_extend_prepaid_validity output flist", *ret_flistpp);
    return;
}

void fm_tab_subscription_extend_prepaid_validity(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*ecebalances_ret_flistp = NULL;
	pin_flist_t			*balimpacts_ret_flistp = NULL;
	pin_flist_t			*billinfo_flistp= NULL;
	pin_flist_t			*ret_flistp = NULL;
	pin_flist_t			*service_out_flistp = NULL;
	pin_flist_t			*service2_out_flistp = NULL;
	pin_flist_t			*billdebit_out_flistp = NULL;
	pin_flist_t			*extendvalidity_flistp = NULL;
	pin_flist_t			*enrich_iflistp = NULL;
	pin_flist_t			*notify_out_flistp = NULL;
	pin_flist_t			*r_flistp = NULL;
	pin_flist_t			*billdebitevt_out_flistp = NULL;
	pin_flist_t			*resource_out_flistp = NULL;
	pin_flist_t			*getnewbal_in_flistp = NULL;
	pin_flist_t			*getnewbal_out_flistp = NULL;
	poid_t				*account_pdp = NULL;
	pin_decimal_t		*chargeamt_dcmlp = NULL;
	pin_decimal_t		*balanceamt_dcmlp = NULL;
	pin_decimal_t       *zero = pbo_decimal_from_str("0",ebufp);
	char				*srvcexpirydate_cp = NULL;
	char				log_msg[256]="";
	int32				active_flag = 1;
	int32				paytype_i = 0;
	int32				status_i = 0;
	int32				resdataelemid_i = 0;
	int32				error_code=0;
	time_t				effective_tmst = 0;
	char				*effective_strp = NULL;

	
	/*********************************
	 * Insanity Check 
	 *********************************/
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_CLEAR_ERR(ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
			" input flist", in_flistp);
	
	/**************************************************************************
	 * Debug System Currency Configuration
	 **************************************************************************/
	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity: System Currency code %d", *cfg_tab_system_currency);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	/*********************************************************
	 * Getting and Setting Resource Information
	 *********************************************************/
	PIN_FLIST_FLD_SET(in_flistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency, ebufp);
	
	
	fm_tab_subscription_extprepbalval_get_resourcename_by_id(ctxp, in_flistp, &resource_out_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			" input flist", in_flistp);
		return;
	}
	
	if ( resource_out_flistp != NULL)
	{
		PIN_FLIST_FLD_COPY(resource_out_flistp, PIN_FLD_NAME, in_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
		PIN_FLIST_FLD_COPY(resource_out_flistp, PIN_FLD_SYMBOL, in_flistp, PIN_FLD_UNIT_STR, ebufp);
	}
	
	/*********************************************************
	 * Mandatory Fields Check
	 *********************************************************/

	fm_tab_subscription_extprepaid_mandatory_flds_chck(ctxp, in_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity: Mandatory Fields Check error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			" Mandatory Fields Check error input flist", in_flistp);
		goto cleanup;
	}
	
	
	/*********************************************************
	 * Getting information of service from the PIN_FLD_MSISDN
	 *********************************************************/
	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity: "
					"Start getting the Service information from PIN_FLD_MSISDN");
					
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	fm_tab_utils_common_get_service_from_msisdn(ctxp, in_flistp, &service_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            		"fm_tab_subscription_extend_prepaid_validity: Error in getting service from msisdn", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
		"fm_tab_subscription_extend_prepaid_validity input flist", in_flistp);

		goto cleanup;
	}

	if (service_out_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            TAB_ERR_CODE_SERVICE_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_extend_prepaid_validity: Error in getting service from msisdn", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_extend_prepaid_validity: "
			"Failed checking the service with input flist", in_flistp);
		goto cleanup; 
	}

	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity:"
					"After getting the service from MSISDN");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_extend_prepaid_validity:"
			" get servive from msisdn return flist", service_out_flistp);
	
	
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LOGIN, in_flistp, PIN_FLD_LOGIN, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_LIFECYCLE_STATE, in_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	PIN_FLIST_FLD_COPY(service_out_flistp, PIN_FLD_STATUS, in_flistp, PIN_FLD_STATUS, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_extend_prepaid_validity: enhance input flist", in_flistp);
	
	/*********************************************************
	 * Getting the Service Information after getting the Service
	 *********************************************************/
	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity:"
					" Get Service information from MSISDN Search Result");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1 , ebufp);
	
	/*********************************************************
	 * Get the paytype from billinfo given the account poid
	 *********************************************************/	
	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity:"
					" Start Getting Billinfo Information from Account Poid");
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	fm_tab_utils_common_get_billinfo(ctxp, account_pdp, active_flag, &billinfo_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity input flist", in_flistp);
		goto cleanup;
	}
	
	if (billinfo_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                            TAB_ERR_CODE_BILLINFO_NOT_FOUND, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error in getting billinfo details", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity input flist", in_flistp);
		goto cleanup;
	}
	
	sprintf(log_msg,"fm_tab_subscription_extend_prepaid_validity:"
					" Getting the paytype from the billinfo information");	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_utils_common_get_billinfo return flist", billinfo_flistp)
	
	/*********************************************************
	 * Validation if the account is prepaid
	 *********************************************************/
	PIN_FLIST_FLD_COPY(billinfo_flistp, PIN_FLD_PAY_TYPE, in_flistp, PIN_FLD_PAY_TYPE, ebufp);
	paytype_i = *(int *)PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_PAY_TYPE, 1, ebufp);
	
	if (paytype_i != PIN_BILL_TYPE_PREPAID)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_NOT_PREPAID_ACCOUNT, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_extend_prepaid_validity: Error Paytype is not prepaid", ebufp);
        PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
            "fm_tab_subscription_extend_prepaid_validity: Error Paytype is not prepaid input flist", billinfo_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
            "Validated to be prepaid account");
	
	/*********************************************************
	 * Validation if the service is active
	 *********************************************************/
	 
	/* commented for CDIGI-9845
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_utils_get_service_from_msisdn return flist", service_out_flistp)
			
	status_i = *(int *)PIN_FLIST_FLD_GET(service_out_flistp, PIN_FLD_STATUS, 1, ebufp); 
		
	if (status_i != PIN_STATUS_ACTIVE)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_SERVICE_IS_CLOSED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error Service or Lifecycle state cannot be processed", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error input flist", in_flistp);
		goto cleanup;
	}
	*/
			
	/*********************************************************
	 * Execution of PCM_OP_BAL_GET_ECE_BALANCES
	 *********************************************************/	
	fm_tab_utils_common_get_ece_balances (ctxp, in_flistp, &ecebalances_ret_flistp,db_no, ebufp);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances input flist", in_flistp);
		goto cleanup;
	}
	
	if (ecebalances_ret_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_ECE_BALANCE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances input flist", ecebalances_ret_flistp);
		goto cleanup;
	}
	
	/*********************************************************
	 * Get the balances from the return FLIST
	 *********************************************************/	
	 
	balimpacts_ret_flistp = PIN_FLIST_ELEM_GET(ecebalances_ret_flistp, PIN_FLD_BAL_IMPACTS, *cfg_tab_system_currency, 1, ebufp);
	if (balimpacts_ret_flistp == NULL)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_GET_ECE_BALANCE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the ECE Balances input flist", ecebalances_ret_flistp);
		goto cleanup;
	}
	
	balanceamt_dcmlp = PIN_FLIST_FLD_GET(balimpacts_ret_flistp, PIN_FLD_CURRENT_BAL, 1, ebufp);
	
	/*********************************************************
	 * Get the balances from the return FLIST
	 *********************************************************/	
	if (pbo_decimal_is_null(balanceamt_dcmlp,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting Ece balance amount ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			" Error getting Ece balance amount input flist", ecebalances_ret_flistp);
		goto cleanup;
	}
	
	/*********************************************************
	 * Get the charge amount from the input FLIST
	 *********************************************************/	
	chargeamt_dcmlp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CHARGE_AMT, 0, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the Adjustment Amount ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			"Error getting the Adjustment Amount", in_flistp);
		goto cleanup;
	}
	
	if (pbo_decimal_is_null(chargeamt_dcmlp,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_extend_prepaid_validity: Error getting the Adjustment Amount", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"op_tab_sub_extend_prepaid_validity: Error getting the Adjustment Amount input flist", in_flistp);
		goto cleanup;

	}

	/*********************************************************
	 * Validation if the PIN_FLD_CHARGE_AMT or request amount
	 * is less than the remaining balance of the account
	 *********************************************************/	
	if ((pbo_decimal_compare(balanceamt_dcmlp,zero,ebufp) > 0) ||
                (pbo_decimal_compare(chargeamt_dcmlp,pbo_decimal_abs(balanceamt_dcmlp,ebufp),ebufp) > 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_INSUFFICIENT_BALANCE, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the Validation Amount", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error getting the Validation Amount input flist", in_flistp);
		goto cleanup;
	}
	
	
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
		"Requested CHARGE Amount can be accomodated by current balance");

	/*********************************************************
	 * Policy Opcode hookup for the enhancement of information
	 * or additional business policy
	 *********************************************************/	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
            "fm_tab_subscription_extend_prepaid_validity: before enrichment input", in_flistp);
	
	PIN_ERR_CLEAR_ERR(ebufp);
			
	PCM_OP(ctxp, TAB_OP_SUBSCRIPTION_POL_ENRICH_EXTEND_PREPAID_VALIDITY, 0, in_flistp, &extendvalidity_flistp, ebufp);


	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error in enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			"Enrich input flist", in_flistp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		*out_flistpp = PIN_FLIST_COPY(extendvalidity_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}
	
	if (extendvalidity_flistp == NULL)
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Error in enrich_iflistp ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			"Enrich input flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
                        "After Enrich output flist", in_flistp);
	/*********************************************************
	 * Call to the PCM_OP_CUST_UPDATE_SERVICES
	 *********************************************************/	
	PIN_FLIST_FLD_COPY(extendvalidity_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, ebufp);
	PIN_FLIST_FLD_COPY(extendvalidity_flistp, PIN_FLD_LIFECYCLE_STATE, in_flistp, PIN_FLD_LIFECYCLE_STATE, ebufp);
	PIN_FLIST_FLD_COPY(extendvalidity_flistp, PIN_FLD_VALIDITY_IN_DAYS, in_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);
	
	fm_tab_utils_common_resume_service(ctxp,in_flistp, &service2_out_flistp,db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity Update Services Error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity - Update Services Error:"
			" input flist", in_flistp);
		goto cleanup;
	}
	
	/*********************************************************
	 * Call to the PCM_OP_BILL_DEBIT
	 *********************************************************/	
	fm_tab_utils_common_subscr_bill_debit(ctxp, in_flistp, &billdebit_out_flistp, *cfg_tab_system_currency, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity Bill Debit Error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity - Bill Debit Error:"
			" input flist", in_flistp);
		goto cleanup;
	}
	/*********************************************************
	 * NOTIFICATION GENERATION
	 *********************************************************/		
	getnewbal_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_BAL_GRP_OBJ, getnewbal_in_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(getnewbal_in_flistp, PIN_FLD_RESOURCE_ID, cfg_tab_system_currency, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
			" get new balance input flist", getnewbal_in_flistp);
	
	fm_tab_utils_common_subscr_get_current_main_balance (ctxp, getnewbal_in_flistp, &getnewbal_out_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extend_prepaid_validity: Getting new balance amount error ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity:"
			" Getting new balance amount error input flist", getnewbal_in_flistp);
		goto cleanup;
	}
	
	PIN_FLIST_FLD_PUT(in_flistp ,PIN_FLD_CURRENT_BAL,balanceamt_dcmlp,ebufp);
	PIN_FLIST_FLD_COPY(getnewbal_out_flistp, PIN_FLD_CURRENT_BAL, in_flistp,PIN_FLD_NEXT_BAL,ebufp);
	srvcexpirydate_cp = (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, (time_t *) PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_SERVICE_STATE_EXPIRATION_T, 1, ebufp),ebufp);
	PIN_FLIST_FLD_PUT(in_flistp,TAB_FLD_SVC_VALIDITY_DATE,srvcexpirydate_cp,ebufp);
	effective_tmst = pin_virtual_time(NULL);
	effective_strp =  (char *) fm_tab_utils_common_convert_timestamp_to_date(ctxp, &effective_tmst, ebufp);
	PIN_FLIST_FLD_PUT(in_flistp,TAB_FLD_EFFECTIVE_DATE,effective_strp,ebufp);
	
	/*********************************************************
	 * Create Object  /tab_event_bill_debit_info
	 *********************************************************/	
	fm_tab_subscription_extprepbalval_create_event_bill_debit(ctxp, in_flistp, &billdebitevt_out_flistp, db_no, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
                        "Notification Input FLIST ", in_flistp);
	
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
                        "before output -  input flist", in_flistp);
	/*********************************************************
	 * Preparation of the Results flist
	 * 0 PIN_FLD_POID            POID [0] 0.0.0.1 /account 123 0
	 * 0 PIN_FLD_MSISDN          STR  [0] "981999999"
	 * 0 TAB_FLD_SVC_VALIDITY_DATE  STR [0] "26-OCT-2021 20:20:20"
	 * 0 PIN_FLD_VALIDITY_IN_DAYS   INT [0] 5
	 * 0 PIN_FLD_CURRENT_BAL     DECIMAL [0] 20
	 * 0 PIN_FLD_TRANS_ID        STR [0] "test1111"
	 * 0 PIN_FLD_CORRELATION_ID  STR [0] "er2345"
	 * 0 PIN_FLD_EXTERNAL_USER   STR [0] "CRM"
	 *********************************************************/	
	
	ret_flistp =  PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, ret_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, ret_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, ret_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_SET(ret_flistp,TAB_FLD_SVC_VALIDITY_DATE,srvcexpirydate_cp,ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NEXT_BAL, ret_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VALIDITY_IN_DAYS, ret_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, ret_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, ret_flistp, PIN_FLD_EXTERNAL_USER, ebufp);
	
	r_flistp = PIN_FLIST_COPY(ret_flistp, ebufp);
	
	resdataelemid_i = 0;
	
	if (service2_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(r_flistp, service2_out_flistp, PIN_FLD_RESULTS_DATA,resdataelemid_i, ebufp);
		resdataelemid_i = resdataelemid_i + 1;
	}
	
	if (billdebit_out_flistp != NULL)
	{
		PIN_FLIST_ELEM_SET(r_flistp, billdebit_out_flistp, PIN_FLD_RESULTS_DATA,resdataelemid_i, ebufp);
	}
	
	PIN_FLIST_SUBSTR_SET(in_flistp, r_flistp, PIN_FLD_OUT_FLIST, ebufp);
		
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
                        "Prepared Output FLIST ", in_flistp);
	
	fm_tab_notify_adjust_balance_prepare_notification(ctxp, in_flistp, db_no, &notify_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity - Notification Error:"
			" output flist", notify_out_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extend_prepaid_validity Notification Error", ebufp);
		
		*out_flistpp = notify_out_flistp;
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
			" output flist", notify_out_flistp);

	if (notify_out_flistp != NULL)
	{
		if ( ( PIN_FLIST_ELEM_GET(notify_out_flistp, TAB_FLD_NOTIFICATION,
						PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_out_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY,
						ret_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(ret_flistp, notify_out_flistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_extend_prepaid_validity:"
			"final output flist", ret_flistp);
			
	
	*out_flistpp = PIN_FLIST_COPY(ret_flistp, ebufp);
	
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	
	PIN_FLIST_DESTROY_EX(&ecebalances_ret_flistp,ebufp);
	PIN_FLIST_DESTROY_EX(&billinfo_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&service2_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&billdebit_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&extendvalidity_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, ebufp);
	PIN_FLIST_DESTROY_EX(&service_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbal_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&getnewbal_out_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&ret_flistp, ebufp);
    PIN_FLIST_DESTROY_EX(&resource_out_flistp, ebufp);
	pbo_decimal_destroy(&zero);
	return;
}

static void
fm_tab_notify_adjust_balance_prepare_notification(
	pcm_context_t		*ctxp,
	pin_flist_t			*i_flistp,
	int64				db_no,
	pin_flist_t			**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_oflistp = NULL;
	pin_flist_t		*notify_tflistp = NULL;
	pin_flist_t		*notify_flistp = NULL;
	pin_flist_t		*ret_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	int32			error_code = 0;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_notify_adjust_balance_prepare_notification function entry error", ebufp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_notify_adjust_balance_prepare_notification: "
					"input flist", i_flistp);
	
	/***************************************
	 * Preparation Enrichment Input FLIST Preparation
	 ***************************************/
	notify_flistp =PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_POID, notify_flistp, PIN_FLD_POID, ebufp); 
	
	/***************************************
	 * PIN_FLD_OUT_FLIST Preparation
	 ***************************************/
	notify_oflistp =  PIN_FLIST_SUBSTR_GET(i_flistp,PIN_FLD_OUT_FLIST,1,ebufp);
	
	/***************************************
	 * PIN_FLD_IN_FLIST Preparation
	 ***************************************/
	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
	PIN_FLIST_SUBSTR_DROP (notify_iflistp, PIN_FLD_OUT_FLIST, ebufp);

	/***************************************
	 * TAB_FLD_NOTIFICATION Preparation
	 ***************************************/
	notify_tflistp = PIN_FLIST_CREATE(ebufp);
	notify_pdp = PIN_POID_CREATE(db_no, "/event/notification/custom/extendvalidity", -1, ebufp);
	PIN_FLIST_FLD_PUT(notify_tflistp, PIN_FLD_POID, notify_pdp, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_tflistp, PIN_FLD_MSISDN, ebufp); //MSISDN
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_TRANS_ID, notify_tflistp, PIN_FLD_TRANS_ID, ebufp); //TRANSACTION ID
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CHARGE_AMT, notify_tflistp, PIN_FLD_AMOUNT_ADJUSTED, ebufp); //Adjustment Amount
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_LIFECYCLE_STATE, notify_tflistp, PIN_FLD_LIFECYCLE_STATE, ebufp); //StatusAfter
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_CURRENT_BAL, notify_tflistp, PIN_FLD_CURRENT_BAL, ebufp); //StatusAfter
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NEXT_BAL, notify_tflistp, PIN_FLD_NEXT_BAL, ebufp); //BalanceAfter
	
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_iflistp, PIN_FLD_IN_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_oflistp, PIN_FLD_OUT_FLIST, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_flistp, notify_tflistp, TAB_FLD_NOTIFICATION, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_balance_prepare_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_NOTIFICATION input flist ", notify_flistp);
		
	/***************************************
	 * Notification Enrichment Opcode Call
	 ***************************************/
	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_EXTEND_VALIDTY_NOTIFICATION, 0, notify_flistp, &enrich_notify_flistp, ebufp);
	
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_balance_prepare_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_balance_prepare_notification:"
			" Enrich Extend Validity Output", enrich_notify_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_notify_adjust_balance_prepare_notification:"
			" Error in Notification", ebufp);
			
		error_code = (ebufp)->pin_err;
		PIN_ERRBUF_CLEAR(ebufp);
		ret_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				error_code, 0, 0, 0);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_notify_adjust_balance_prepare_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_NOTIFICATION output flist ", enrich_notify_flistp);
	
	ret_flistp = PIN_FLIST_COPY(enrich_notify_flistp, ebufp);
	
	cleanup:
		
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_tflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&enrich_notify_flistp, NULL);

	*r_flistpp = ret_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_notify_adjust_balance_prepare_notification output flist", *r_flistpp);
	return;
}

void
fm_tab_subscription_extprepaid_mandatory_flds_chck(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	int64				db_no,
	pin_errbuf_t		*ebufp)

{
	char 				*transid_strp = NULL;
	char 				*msisdn_strp = NULL;
	pin_decimal_t		*chargeamt_dcmlp = NULL;
	int32				transidchck_i = 0;
	
	
	/***********************************************************
	 *Insanity Check
	 ***********************************************************/
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Adjustment Amount Missing", in_flistp);
		return;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_extprepaid_mandatory_flds_chck: "
					"input flist", in_flistp);
	
	/***********************************************************
	 * Mandatory Fields Validation
	 ***********************************************************/
	chargeamt_dcmlp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_CHARGE_AMT, 0, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Adjustment Amount Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Adjustment Amount Missing", in_flistp);
		return;
	}
	
	if (pbo_decimal_is_null(chargeamt_dcmlp,ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MISSING_AMOUNT_ADJUSTED, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Adjustment Amount Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Adjustment Amount Missing input flist", in_flistp);
		return;
	}
	
	transid_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_TRANS_ID, 0, ebufp);
	
	if((transid_strp == NULL) || (transid_strp && strlen(transid_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_TRANS_ID_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Transaction ID Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Transaction ID Missing input flist", in_flistp);
		return;
	}
	
	transidchck_i = fm_tab_subscription_extprepbalval_transid_check(ctxp, in_flistp, db_no, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUPLICATE_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Transaction ID Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Transaction ID Missing input flist", in_flistp);
		return;
	}
	
	if (transidchck_i == 1)
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_DUPLICATE_TRANS_ID, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Transaction ID Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Transaction ID Missing input flist", in_flistp);
		return;
	}
	
	
	msisdn_strp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_MSISDN, 0, ebufp);
		
	if((msisdn_strp == NULL) || (msisdn_strp && strlen(msisdn_strp) == 0))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepaid_mandatory_flds_chck: Transaction ID Missing ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_extprepaid_mandatory_flds_chck:"
			"Transaction ID Missing input flist", in_flistp);
		return;
	}
	
	return;
}

int32
fm_tab_subscription_extprepbalval_transid_check(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*search_in_flistp = NULL;
	pin_flist_t 		*search_out_flistp = NULL;
	pin_flist_t			*args_flistp = NULL;
	poid_t				*search_pdp = NULL;
	char				*template_strp = NULL;
	int32				sflags_i = 0;
	int32				elemcnt_i = 0;
	int32				retval_i = 0;
	char				log_msg[256] = "";
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_transid_check: Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_transid_check: Error in input - Input Flist", in_flistp);
		retval_i = 0;
		goto cleanup;
	}
	
	search_pdp = PIN_POID_CREATE(db_no, "/search", -1, ebufp);
	
	search_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(search_in_flistp, PIN_FLD_POID, search_pdp, ebufp);
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_FLAGS, &sflags_i, ebufp);
	template_strp =  (void *)"select X from /tab_event_bill_debit_info where  F1 = V1 ";
	PIN_FLIST_FLD_SET(search_in_flistp, PIN_FLD_TEMPLATE, template_strp, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_ARGS, 1, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, args_flistp, PIN_FLD_TRANS_ID, ebufp);
	args_flistp = PIN_FLIST_ELEM_ADD(search_in_flistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_extprepbalval_transid_check :"
			" Trans ID search input flist", search_in_flistp);
			
	PCM_OP(ctxp, PCM_OP_SEARCH, 0, search_in_flistp, &search_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_transid_check: Error in Search Trans ID ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_transid_check: Error in Search Trans ID Input Flist", search_in_flistp);
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_extprepbalval_transid_check :"
			" Trans ID search output flist", search_out_flistp);
	
	elemcnt_i =  PIN_FLIST_ELEM_COUNT(search_out_flistp, PIN_FLD_RESULTS, ebufp);
	
	sprintf(log_msg, "fm_tab_subscription_extprepbalval_transid_check: transid check element count %d", elemcnt_i);
	PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
	
	if (elemcnt_i == 0)
	{ 
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_extprepbalval_transid_check: transid check return 0");
		retval_i = 0;
	} else {
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_extprepbalval_transid_check: transid check return 1");
		retval_i = 1;
	}
	
	
	cleanup:
	
	PIN_FLIST_DESTROY_EX(&search_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&search_out_flistp, ebufp);
	
	return retval_i;
}

void
fm_tab_subscription_extprepbalval_create_event_bill_debit(
	pcm_context_t       *ctxp,
	pin_flist_t         *in_flistp,
	pin_flist_t         **out_flistpp,
	int64				db_no,
	pin_errbuf_t        *ebufp)
{
	pin_flist_t			*create_in_flistp = NULL;
	pin_flist_t			*create_out_flistp = NULL;
	pin_flist_t			*debitinfo_flistp = NULL;
	pin_flist_t			*createobj_pdp = NULL;
	int32				opcode_idp = 1;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: Error in input - Input Flist", in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: input flist", in_flistp);
	
	createobj_pdp = PIN_POID_CREATE(db_no, "/tab_event_bill_debit_info", -1, ebufp);
	
	create_in_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_PUT(create_in_flistp, PIN_FLD_POID, createobj_pdp, ebufp);
	PIN_FLIST_FLD_SET(create_in_flistp, PIN_FLD_PARAM_TYPE, &opcode_idp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EVENT_OBJ, create_in_flistp, PIN_FLD_EVENT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, create_in_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXT_INFO_STR, create_in_flistp, PIN_FLD_EXT_INFO_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_LOCATION, create_in_flistp, PIN_FLD_LOCATION, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, create_in_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_REASON_CODE, create_in_flistp, PIN_FLD_REASON_CODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_TRANS_ID, create_in_flistp, PIN_FLD_TRANS_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_USER_NAME, create_in_flistp, PIN_FLD_USER_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_LOC_GROUP_CODE, create_in_flistp, TAB_FLD_LOC_GROUP_CODE, ebufp);
	debitinfo_flistp = PIN_FLIST_ELEM_ADD(create_in_flistp, TAB_FLD_DEBIT_INFO,0, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACTION_MODE, debitinfo_flistp, PIN_FLD_ACTION_MODE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ADJUSTMENT_TYPE, debitinfo_flistp, PIN_FLD_ADJUSTMENT_TYPE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CHARGE_AMT, debitinfo_flistp, PIN_FLD_AMOUNT, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NEXT_BAL, debitinfo_flistp, PIN_FLD_CURRENT_BAL, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ELEMENT_ID, debitinfo_flistp, PIN_FLD_ELEMENT_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_FLAGS, debitinfo_flistp, PIN_FLD_FLAGS, ebufp);	
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NOTIFY_FLAG, debitinfo_flistp, PIN_FLD_NOTIFY_FLAG, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_ID, debitinfo_flistp, PIN_FLD_RESOURCE_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_RESOURCE_NAME, debitinfo_flistp, PIN_FLD_RESOURCE_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_UNIT_STR, debitinfo_flistp, PIN_FLD_UNIT_STR, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VALIDITY_FLAGS, debitinfo_flistp, PIN_FLD_VALIDITY_FLAGS, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_EFFECTIVE_DATE, debitinfo_flistp, TAB_FLD_EFFECTIVE_DATE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, TAB_FLD_SVC_VALIDITY_DATE, debitinfo_flistp, TAB_FLD_SVC_VALIDITY_DATE, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_VALIDITY_IN_DAYS, debitinfo_flistp, PIN_FLD_VALIDITY_IN_DAYS, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: create object input flist", create_in_flistp);

	PCM_OP(ctxp, PCM_OP_CREATE_OBJ, 0, create_in_flistp, &create_out_flistp, ebufp);
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: Create Object Error in input ", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: Create Object Error in input - Input Flist", create_in_flistp);
		goto cleanup;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
			"fm_tab_subscription_extprepbalval_create_event_bill_debit: create object input flist", create_out_flistp);
	
	cleanup:
	
	*out_flistpp = NULL;
	
	PIN_FLIST_DESTROY_EX(&create_in_flistp, ebufp);
	PIN_FLIST_DESTROY_EX(&create_out_flistp, ebufp);
	
	return;
}


void
fm_tab_subscription_extprepbalval_get_resourcename_by_id(
	pcm_context_t		*ctxp,
	pin_flist_t			*in_flistp,
	pin_flist_t			**out_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*balances_flistp = NULL;
	pin_flist_t		*r_flistp = NULL;
	pin_cookie_t	cookie = 0;
	int32			elem_id = 0;
	int32			*resourceid_in_ip = NULL;
	
	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_extprepbalval_get_resourcename_by_id:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subscription_extprepbalval_get_resourcename_by_id:"
			" Error in Notification", ebufp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_extprepbalval_get_resourcename_by_id:"
			" input flist ", in_flistp);
	
	resourceid_in_ip = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_RESOURCE_ID, 1, ebufp);
	
	if (resourceid_in_ip == NULL)
	{
		return;
	}
	
	while ((balances_flistp = PIN_FLIST_ELEM_GET_NEXT(config_beid_out_flistp, PIN_FLD_BALANCES,
			&elem_id, 1, &cookie, ebufp)) != (pin_flist_t*)NULL)
			
	{
		if (elem_id == *resourceid_in_ip)
		{
			r_flistp = PIN_FLIST_COPY(balances_flistp, ebufp);
		}
	
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG," fm_tab_subscription_extprepbalval_get_resourcename_by_id:"
			" output flist ", r_flistp);
	
	*out_flistpp = PIN_FLIST_COPY(r_flistp, ebufp);
     PIN_FLIST_DESTROY_EX(&r_flistp, NULL);
	return;
}
