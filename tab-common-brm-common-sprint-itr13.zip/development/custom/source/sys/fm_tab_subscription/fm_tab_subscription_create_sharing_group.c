/*******************************************************************************
*
*   This material is the confidential property of Telenor/Oracle Corporation or its
*   licensors and may be used, reproduced, stored or transmitted only in
*   accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
 *  Change History
 *          
 *  Delivery Code   | No    | Date          | Programmer        | Req/bug/Gap   | Change details 
 *          
 *                  | 1     | 11-OCT-2021   | Darshan           |               | New file.

 *************************************************************************************************/

/*******************************************************************
 * Contains the TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP operation. 
 *******************************************************************/
#include <stdio.h> 
#include <string.h> 
#include "pcm.h"
#include "cm_fm.h"
#include "pin_errs.h"
#include "pinlog.h"
#include "pin_bal.h"
#include "pin_cust.h"
#include "ops/bal.h"
#include "ops/bill.h"
#include "ops/subscription.h"
#include "fm_bal.h"
#include "pin_group.h"
#include "pin_subscription.h"
#include "tab_common.h"
#include "tab_ops_flds.h"

/*******************************************************************
 * Routines contained within.
 *******************************************************************/
EXPORT_OP void 
op_tab_subscription_create_sharing_group(
	cm_nap_connection_t 	*connp,
	int                 	opcode,
	int                 	flags,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	pin_errbuf_t        	*ebufp);

void fm_tab_subscription_create_sharing_group(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

void fm_tab_subscription_list_update_ordered_bg(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);
	
void
fm_tab_subs_create_sharing_grp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp);

/* Extern functions */
extern int64
fm_tab_utils_common_get_db_no(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);

extern unsigned long
fm_tab_utils_common_get_max_elemid(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        int32                   fld_no,
        pin_errbuf_t            *ebufp);
extern int32
fm_tab_utils_common_trans_open(
	pcm_context_t       	*ctxp,
	poid_t              	*pdp,
	pin_errbuf_t        	*ebufp);

extern void 
fm_tab_utils_common_validate_and_normalize_input(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_get_poid_from_msisdn_sim(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**r_flistpp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern void
fm_tab_utils_common_subscr_get_discount_offer(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*i_flistp,
	pin_flist_t         	**r_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_request_set_error(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*i_flistp,
	int32               	flag,
	int32               	customErrorCode,
	pin_flist_t         	**err_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern int32
fm_tab_utils_common_get_tab_order_before(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*i_flistp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void
fm_tab_utils_common_subscr_get_chargeshare_offer(
	pcm_context_t        	*ctxp,
	pin_flist_t          	*i_flistp,
	pin_flist_t          	**r_flistpp,
	int64			db_no,
	pin_errbuf_t         	*ebufp);

extern void
fm_tab_utils_common_trans_manage_order(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*i_flistp,
	int32               	status,
	poid_t              	*account_pdp,
	char                	*opcode_name,
	pin_flist_t         	**r_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp);

extern void 
fm_tab_utils_common_subscr_get_ordered_bg_details(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		**out_flistp,
	int64			db_no,
	pin_errbuf_t		*ebufp);

extern int64
fm_tab_utils_common_compare_db_no(
    pcm_context_t           *ctxp,
    pin_flist_t             *i_flistp,
    int64                   db_no,
    pin_errbuf_t            *ebufp);
 
extern void
fm_tab_utils_common_error_ebuf(
        pcm_context_t           *ctxp,
        pin_flist_t             *i_flistp,
        pin_errbuf_t            *ebufp);
/**
 *
 * New opcode TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP is implemented to 
 * create CSG/DSG.
 *
 * @param connp The connection pointer.
 * @param opcode This opcode.
 * @param flags The opcode flags.
 * @param in_flistp The input flist contains PIN_FLD_MEMBERS, PIN_FLD_NAME 
 *                  and PIN_FLD_OFFER .
 * @param ret_flistpp The output flist with account poid information.
 * @param ebufp The error buffer.
 * @return nothing.
 *
 * Sample Input Flist
 *	0 PIN_FLD_POID           POID [0] 0.0.0.1 /account -1 0
 *	0 PIN_FLD_ACCOUNT_NO      STR [0] "CH_112"
 *	0 PIN_FLD_MSISDN          STR [0] "service3"
 *	0 PIN_FLD_MEMBERS       ARRAY [0] allocated 20, used 1
 *	1     PIN_FLD_MSISDN          STR [0] "1631013011"
 *	0 PIN_FLD_OFFER         ARRAY [0] allocated 20, used 1
 *	1     PIN_FLD_DISCOUNT_INFO            STR [0] "DO_07092021"
 *	0 PIN_FLD_NAME            STR [0] "DSG_GRP_2000009"
 *	0 PIN_FLD_CORRELATION_ID    STR [0] "22112021_019"
 *	0 PIN_FLD_EXTERNAL_USER    STR [0] "CRM"
 *
 */

/**************************************************************************
 * Main routine for the TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP operation.
 *************************************************************************/
void
op_tab_subscription_create_sharing_group(
	cm_nap_connection_t     *connp,
	int                     opcode,
	int                     flags,
	pin_flist_t             *in_flistp,
	pin_flist_t             **ret_flistpp,
	pin_errbuf_t            *ebufp)
{
	pcm_context_t           *ctxp = connp->dm_ctx;
	poid_t                  *account_pdp = NULL;
	char			log_msg[512]= "";
	pin_flist_t             *r_flistp = NULL;
	pin_flist_t             *enrich_iflistp = NULL;
	int32                   status = PIN_BOOLEAN_TRUE;
	int32                   tab_order_flag = 0;
	int32                   error_clear_flag = 1;
	int32                   cerror_code = 0;
	int64			db_no = 0;

	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_create_sharing_group function entry error", ebufp);
		return;
	}

	*ret_flistpp = NULL;
	/*******************************************************************
	 * Insanity check.
	 *******************************************************************/
	if(opcode != TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP) {

		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			PIN_ERR_BAD_OPCODE, 0, 0, opcode);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_create_sharing_group bad opcode error",
			ebufp);
		return;
	}

	/*******************************************************************
	 * Check for the input flist details
	 *******************************************************************/
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_create_sharing_group input flist", in_flistp);

	r_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, r_flistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_MSISDN, r_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_NO, r_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, r_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, r_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	db_no = fm_tab_utils_common_get_db_no(ctxp, in_flistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_db_no:"
			"Error getting database number");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GET_DB_NO_FAIL, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_utils_common_get_db_no: Error while getting database no",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	/*Search for /tab_order object*/
	tab_order_flag = fm_tab_utils_common_get_tab_order_before(ctxp, in_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_get_tab_order_detail:"
			" input flist", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			" Error while searching /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_CSG;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_CSG )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_CSG, ebufp);
		}
		
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	PIN_FLIST_FLD_SET(in_flistp, TAB_FLD_EXCEPTION_FLAG, &tab_order_flag, ebufp);
	account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_OBJ, 1, ebufp);
    if(PIN_POID_IS_NULL(account_pdp))
    {
        account_pdp = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_POID, 1, ebufp);
    }

	/* open transaction */
	if (!fm_tab_utils_common_trans_open(ctxp, account_pdp, ebufp))
	{
		/* Validate the input arguments */
		fm_tab_utils_common_validate_and_normalize_input(ctxp, in_flistp, &enrich_iflistp, db_no, ebufp);
		if (PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group: "
				"fm_tab_utils_common_validate_and_normalize_input error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group:"
			" fm_tab_utils_common_validate_and_normalize_input output flist", enrich_iflistp);

		/* call main function */
		fm_tab_subscription_create_sharing_group(ctxp, enrich_iflistp, &r_flistp, db_no, ebufp);
		if(PIN_ERR_IS_ERR(ebufp))
		{
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "op_tab_subscription_create_sharing_group error", ebufp);
			status = TAB_FAIL;
			goto cleanup;
		}
	}
	else
	{
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_create_sharing_group:"
			"Error Opening transaction");
		pin_set_err(ebufp, PIN_ERRLOC_CM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_TRANS_OPEN, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"op_tab_subscription_create_sharing_group: Error while Opening transaction",ebufp);
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, cerror_code, &r_flistp, db_no, ebufp);
		PIN_ERR_CLEAR_ERR(ebufp);
		/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
		* in the response with the errorCode coming from the return flist*/
		fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);
		*ret_flistpp = r_flistp;
		return;
	}

	cleanup:
	/* To commit or abort the transaction and to update the order */
	fm_tab_utils_common_trans_manage_order(ctxp, in_flistp, status, account_pdp,
		"TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP", &r_flistp, db_no, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_trans_manage_order:"
			" input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"op_tab_subscription_create_sharing_group:"
			" Error while creating /tab_order object", ebufp);

		cerror_code = ebufp->pin_err;
		if(cerror_code < 1000 )
		{
			cerror_code = TAB_ERR_CODE_API_CREATE_CSG;
			sprintf(log_msg,"%d",cerror_code);
			PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);
		}
		fm_tab_utils_common_request_set_error(ctxp, in_flistp, error_clear_flag, 
				cerror_code, &r_flistp, db_no, ebufp);

		PIN_ERR_CLEAR_ERR(ebufp);

		sprintf(log_msg,"%d",cerror_code);
		PIN_ERR_LOG_MSG(PIN_ERR_LEVEL_DEBUG, log_msg);

		if(cerror_code == TAB_ERR_CODE_API_CREATE_CSG )
		{
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_CODE, log_msg, ebufp);
			PIN_FLIST_FLD_SET(r_flistp, PIN_FLD_ERROR_DESCR, TAB_ERR_DESCR_API_CREATE_CSG, ebufp);
		}
	}
	else
	{
		status = TAB_SUCCESS;
		/*Prepare Return Flist*/
		PIN_FLIST_FLD_SET(r_flistp, TAB_FLD_REQUEST_STATUS, &status, ebufp);
		
		if (PIN_FLIST_ELEM_GET(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, 1, ebufp))
			PIN_FLIST_ELEM_DROP(r_flistp, TAB_FLD_NOTIFICATION, PIN_ELEMID_ANY, ebufp);
	}

	/*The fm_tab_utils_common_error_ebuf() is used to populate the ebuf
	* in the response with the errorCode coming from the return flist*/
	fm_tab_utils_common_error_ebuf(ctxp, r_flistp, ebufp);

	*ret_flistpp = r_flistp;
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "op_tab_subscription_create_sharing_group output flist", *ret_flistpp);
	PIN_FLIST_DESTROY_EX(&enrich_iflistp, NULL);
	return;
}

/**
 * We use this function to create CSG/DSG.
 *
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_subscription_create_sharing_group(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	pin_flist_t         	**out_flistpp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{
	pin_flist_t         	*msisdn_flistp = NULL;
	pin_flist_t         	*result_flistp = NULL;
	pin_flist_t         	*get_msisdn_iflistp = NULL;
	pin_flist_t         	*get_msisdn_oflistp = NULL;
	pin_flist_t         	*offer_flistp = NULL;
	pin_flist_t         	*get_discount_offer_iflistp = NULL;
	pin_flist_t         	*get_discount_offer_oflistp = NULL;
	pin_flist_t         	*sharing_grp_create_iflistp = NULL;
	pin_flist_t         	*sharing_grp_create_oflistp = NULL;
	pin_flist_t         	*get_sponsorship_iflistp = NULL;
	pin_flist_t         	*get_sponsorship_oflistp = NULL;
	pin_flist_t         	*sponsors_flistp = NULL;
	pin_flist_t         	*members_flistp = NULL;
	pin_flist_t         	*discounts_flistp = NULL;
	pin_flist_t         	*ordered_balgrp_create_iflistp = NULL;
	pin_flist_t         	*ordered_balgrp_create_oflistp = NULL;
	pin_flist_t         	*ordered_balgrp_flistp = NULL;
	pin_flist_t         	*msisdn_results_flistp = NULL;
	pin_flist_t         	*context_info_flistp = NULL;
	pin_flist_t         	*discounts_sharing_flistp = NULL;
	pin_flist_t         	*sponsors_sharing_flistp = NULL;
	pin_flist_t         	*member_input_flistp = NULL;
	pin_flist_t         	*ordered_results_flistp = NULL;
	pin_flist_t         	*update_ordered_balgrp_iflistp = NULL;
	pin_flist_t         	*update_ordered_balgrp_oflistp = NULL;
	pin_flist_t         	*get_ord_balgrp_iflistp = NULL;
	pin_flist_t         	*get_ord_balgrp_oflistp = NULL;
	pin_flist_t				*notify_flistp = NULL;
	pin_flist_t				*notify_oflistp = NULL;
	pin_cookie_t        	input_member_cookie = NULL;
	pin_cookie_t        	results_cookie = NULL;
	pin_cookie_t        	offer_cookie = NULL;
	pin_cookie_t        	discounts_cookie = NULL;
	pin_cookie_t        	sponsors_cookie = NULL;
	pin_cookie_t        	members_cookie = NULL;
	char                	*grp_namep = NULL;
	char                	*msisdnp = NULL;
	char                	*discount_offerp = NULL;
	char                	*chargeshare_offerp = NULL;
	char                	*actionp = PIN_SUBS_ORDERED_BALGRP_ACTION_CREATE;
	char			*order_typep = NULL;
	char			*account_nop = NULL;
	int32               	results_elemid = 0;
	int32               	input_member_elemid = 0;
	int32               	offer_elemid = 0;
	int32               	discounts_elemid = 0;
	int32               	sponsors_elemid = 0;
	int32               	members_elemid = 0;
	int                 	members_count = 0;
	int                 	sponsors_count = 0;
	int                 	discounts_count = 0;
	int			discount_obj_found = 0;
	int			sponsor_obj_found = 0;
	poid_t              	*grp_sharing_discp = NULL;
	poid_t              	*input_pur_disc_pdp = NULL;
	poid_t              	*input_disc_pdp = NULL;
	poid_t              	*grp_pur_disc_pdp = NULL;
	poid_t              	*grp_disc_pdp = NULL;
	poid_t              	*input_sponsor_pdp = NULL;
	poid_t              	*grp_sponsor_pdp = NULL;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
			"fm_tab_subscription_create_sharing_group function entry error", ebufp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group "
		"input flist", in_flistp);
	
	/*Account Number not passed in input*/	
	account_nop = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp);
		
	if((account_nop && strlen(account_nop) == 0) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ACCOUNT_NO, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_ACCT_NO_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			"Account Number is not passed in request", ebufp);
		goto cleanup;
	}

	grp_namep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp);

	/*Group Name not passed in input*/
	if((grp_namep && strlen(grp_namep) == 0) || 
		(PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_NAME, 1, ebufp) == NULL))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_GRP_NAME_MISSING, 0, 0, 0);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			"Group Name is not passed in input", ebufp);
		goto cleanup;
	}

	/* Frame the input flist for PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE opcode call*/
	sharing_grp_create_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_NAME, sharing_grp_create_iflistp, PIN_FLD_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, sharing_grp_create_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, sharing_grp_create_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, sharing_grp_create_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
	context_info_flistp = PIN_FLIST_SUBSTR_ADD(sharing_grp_create_iflistp, PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	while ((msisdn_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_MEMBERS, 
		&input_member_elemid, 1, &input_member_cookie, ebufp)) != (pin_flist_t *)NULL)
	{
		msisdnp = PIN_FLIST_FLD_GET(msisdn_flistp, PIN_FLD_MSISDN, 1, ebufp);
		 if(cm_fm_is_multi_db() && fm_tab_utils_common_compare_db_no(ctxp, msisdn_flistp, db_no, ebufp))
        {
            pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
                TAB_ERR_CODE_ACCT_DB_NO_MS,0, 0, 0);
            PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR, "fm_tab_subscription_create_sharing_group:"
                "child account exists in different schema", ebufp);
            PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,
                "fm_tab_subscription_create_sharing_group input flist", in_flistp);
            goto cleanup;
        }
 
		if(msisdnp && strlen(msisdnp) != 0)
		{
			/* Get subscriber MSISDN details */
			get_msisdn_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_msisdn_iflistp, PIN_FLD_POID, ebufp);
			PIN_FLIST_FLD_COPY(msisdn_flistp, PIN_FLD_MSISDN, get_msisdn_iflistp, PIN_FLD_MSISDN, ebufp);
			fm_tab_utils_common_get_poid_from_msisdn_sim(ctxp, get_msisdn_iflistp, 
					&get_msisdn_oflistp, db_no, ebufp);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_msisdn_sim:"
					" input flist ", get_msisdn_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_get_poid_from_msisdn_sim:"
					" Error while getting subscriber MSISDN", ebufp);
				goto cleanup;
			}
			else
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_poid_from_msisdn_sim "
					"output flist", get_msisdn_oflistp);

				if (get_msisdn_oflistp && (msisdn_results_flistp = PIN_FLIST_ELEM_GET(get_msisdn_oflistp, PIN_FLD_RESULTS, 
					PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					/*Add members array*/
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_get_poid_from_msisdn_sim "
						"msisdn_results_flistp", msisdn_results_flistp);
					members_flistp = PIN_FLIST_ELEM_ADD(sharing_grp_create_iflistp, PIN_FLD_MEMBERS, members_count++, ebufp);
					PIN_FLIST_FLD_COPY(msisdn_results_flistp, PIN_FLD_POID, members_flistp, PIN_FLD_SERVICE_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(msisdn_results_flistp, PIN_FLD_ACCOUNT_OBJ, members_flistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				}
				else
				{
					pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
						TAB_ERR_CODE_MSISDN_NOT_FOUND, 0, 0, 0);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
						"Subscriber MSISDN is not present in BRM DB", ebufp);
					goto cleanup;
				}
			}

			PIN_FLIST_DESTROY_EX(&get_msisdn_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&get_msisdn_oflistp, NULL);
		}
		else
		{
			/*Subscriber MSISDN not passed in input*/
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MSISDN_MISSING, 0, 0, 0);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
				"Subscriber MSISDN is not passed in input", ebufp);
			goto cleanup;
		}
	}

	order_typep = PIN_FLIST_FLD_GET(in_flistp, PIN_FLD_ORDER_TYPE, 1, ebufp);

	if(order_typep && !strncmp(order_typep, TAB_ACTION_DSG_CREATE, strlen(order_typep)))
	{
		grp_sharing_discp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_GROUP_SHARING_DISCOUNTS, -1, ebufp);
		PIN_FLIST_FLD_PUT(sharing_grp_create_iflistp, PIN_FLD_GROUP_OBJ, (void *)grp_sharing_discp, ebufp);

		while ((offer_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_OFFER, 
			&offer_elemid, 1, &offer_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			/*Get discount offer name*/
			discount_offerp = PIN_FLIST_FLD_GET(offer_flistp, PIN_FLD_DISCOUNT_INFO, 1, ebufp);

			/*Discount offer details*/
			if(discount_offerp != NULL && strlen(discount_offerp) != 0)
			{
				get_discount_offer_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_discount_offer_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_discount_offer_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(offer_flistp, PIN_FLD_DISCOUNT_INFO, get_discount_offer_iflistp, PIN_FLD_NAME, ebufp);

				/*Get purchased discount & disount details based on discount offer name*/
				fm_tab_utils_common_subscr_get_discount_offer(ctxp, get_discount_offer_iflistp, 
						&get_discount_offer_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_discount_offer:"
						" input flist ", get_discount_offer_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_discount_offer:"
						" Error while getting discount offer", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_subscr_get_discount_offer "
						"output flist", get_discount_offer_oflistp);

					if (get_discount_offer_oflistp && (PIN_FLIST_ELEM_GET(get_discount_offer_oflistp, 
						PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) == NULL)
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_DISC_OFFER_NOT_PURCHASED, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
							"Discount offer is not purchased for the input account", ebufp);
						goto cleanup;
					}

					results_elemid = 0;
					results_cookie = NULL;
					while ((result_flistp = PIN_FLIST_ELEM_GET_NEXT(get_discount_offer_oflistp, PIN_FLD_RESULTS, 
						&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						input_pur_disc_pdp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID, 1, ebufp);
						input_disc_pdp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);

						PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "input_pur_disc_pdp:", input_pur_disc_pdp);
						PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "input_disc_pdp:", input_disc_pdp);

						discounts_elemid = 0;
						discounts_cookie = NULL;
						while ((discounts_sharing_flistp = PIN_FLIST_ELEM_GET_NEXT(sharing_grp_create_iflistp, 
							PIN_FLD_DISCOUNTS, &discounts_elemid, 1, &discounts_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							grp_pur_disc_pdp = PIN_FLIST_FLD_GET(discounts_sharing_flistp, PIN_FLD_OFFERING_OBJ, 1, ebufp);
							grp_disc_pdp = PIN_FLIST_FLD_GET(discounts_sharing_flistp, PIN_FLD_DISCOUNT_OBJ, 1, ebufp);

							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "grp_pur_disc_pdp:", grp_pur_disc_pdp);
							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "grp_disc_pdp:", grp_disc_pdp);

							if(!PIN_POID_COMPARE(input_pur_disc_pdp, grp_pur_disc_pdp, 0, ebufp) && 
								!PIN_POID_COMPARE(input_disc_pdp, grp_disc_pdp, 0, ebufp))
							{
								discount_obj_found = 1;
							}
						}

						if(discount_obj_found == 0)
						{
							discounts_flistp = PIN_FLIST_ELEM_ADD(sharing_grp_create_iflistp, PIN_FLD_DISCOUNTS, 
								discounts_count++, ebufp);
							PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID, discounts_flistp, 
									PIN_FLD_OFFERING_OBJ, ebufp);
							PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_DISCOUNT_OBJ, discounts_flistp, 
									PIN_FLD_DISCOUNT_OBJ, ebufp);
						}
					}
				}

				PIN_FLIST_DESTROY_EX(&get_discount_offer_iflistp, NULL);
				PIN_FLIST_DESTROY_EX(&get_discount_offer_oflistp, NULL);
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_CHRG_DIS_SHARE_NOT_PASSED, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
					"Discount offer is not passed in input", ebufp);
				goto cleanup;
			}
		}
	}

	if(order_typep && !strncmp(order_typep, TAB_ACTION_CSG_CREATE, strlen(order_typep)))
	{
		grp_sharing_discp = PIN_POID_CREATE(db_no, PIN_OBJ_TYPE_GROUP_SHARING_CHARGES, -1, ebufp);
		PIN_FLIST_FLD_PUT(sharing_grp_create_iflistp, PIN_FLD_GROUP_OBJ, (void *)grp_sharing_discp, ebufp);

		offer_elemid = 0;
		offer_cookie = NULL;
		while ((offer_flistp = PIN_FLIST_ELEM_GET_NEXT(in_flistp, PIN_FLD_OFFER, 
			&offer_elemid, 1, &offer_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			/*Get chargeshare offer name*/
			chargeshare_offerp = PIN_FLIST_FLD_GET(offer_flistp, PIN_FLD_PRODUCT_NAME, 1, ebufp);

			/*Chargeoffer details*/
			if(chargeshare_offerp != NULL && strlen(chargeshare_offerp) != 0)
			{
				get_sponsorship_iflistp = PIN_FLIST_CREATE(ebufp);
				PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, get_sponsorship_iflistp, PIN_FLD_POID, ebufp);
				PIN_FLIST_FLD_COPY(offer_flistp, PIN_FLD_PRODUCT_NAME, get_sponsorship_iflistp, PIN_FLD_NAME, ebufp);

				/*Get sponsorship details based on offer name*/
				fm_tab_utils_common_subscr_get_chargeshare_offer(ctxp, get_sponsorship_iflistp, 
						&get_sponsorship_oflistp, db_no, ebufp);

				if(PIN_ERR_IS_ERR(ebufp))
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_chargeshare_offer:"
						" input flist ", get_sponsorship_iflistp);
					PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_chargeshare_offer:"
						" Error while getting charge share offer", ebufp);
					goto cleanup;
				}
				else
				{
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_subscr_get_chargeshare_offer "
						"output flist", get_sponsorship_oflistp);

					if (get_sponsorship_oflistp && (PIN_FLIST_ELEM_GET(get_sponsorship_oflistp, PIN_FLD_RESULTS, 
						PIN_ELEMID_ANY, 1, ebufp)) == NULL)
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_CHRG_OFFER_NOT_FOUND, 0, 0, 0);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
							"Chargeshare offer is not present in BRM DB", ebufp);
						goto cleanup;
					}

					results_elemid = 0;
					results_cookie = NULL;
					while ((result_flistp = PIN_FLIST_ELEM_GET_NEXT(get_sponsorship_oflistp, PIN_FLD_RESULTS, 
						&results_elemid, 1, &results_cookie, ebufp)) != (pin_flist_t *)NULL)
					{
						input_sponsor_pdp = PIN_FLIST_FLD_GET(result_flistp, PIN_FLD_POID, 1, ebufp);

						PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "input_sponsor_pdp:", input_sponsor_pdp);

						sponsors_elemid = 0;
						sponsors_cookie = NULL;
						while ((sponsors_sharing_flistp = PIN_FLIST_ELEM_GET_NEXT(sharing_grp_create_iflistp, 
							PIN_FLD_SPONSORS, &sponsors_elemid, 1, &sponsors_cookie, ebufp)) != (pin_flist_t *)NULL)
						{
							grp_sponsor_pdp = PIN_FLIST_FLD_GET(sponsors_sharing_flistp, PIN_FLD_SPONSOR_OBJ, 1, ebufp);
							PIN_ERR_LOG_POID(PIN_ERR_LEVEL_DEBUG, "grp_sponsor_pdp:", grp_sponsor_pdp);
							if(!PIN_POID_COMPARE(input_sponsor_pdp, grp_sponsor_pdp, 0, ebufp))
							{
								sponsor_obj_found = 1;
							}
						}

						if(sponsor_obj_found == 0)
						{
							sponsors_flistp = PIN_FLIST_ELEM_ADD(sharing_grp_create_iflistp, 
								PIN_FLD_SPONSORS, sponsors_count++, ebufp);
							PIN_FLIST_FLD_COPY(result_flistp, PIN_FLD_POID, sponsors_flistp, PIN_FLD_SPONSOR_OBJ, ebufp);
						}
					}
				}
			}
			else
			{
				pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
					TAB_ERR_CODE_CHRG_DIS_SHARE_NOT_PASSED, 0, 0, 0);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
					"Charge share offer is not passed in input", ebufp);
				goto cleanup;
			}

			PIN_FLIST_DESTROY_EX(&get_sponsorship_iflistp, NULL);
			PIN_FLIST_DESTROY_EX(&get_sponsorship_oflistp, NULL);
		}
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group: "
		"PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE input", sharing_grp_create_iflistp);

	PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE, 0, sharing_grp_create_iflistp, &sharing_grp_create_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_API_CREATE_CSG, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE:"
			" input flist ", sharing_grp_create_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE:"
			" Error while creating resource sharing group", ebufp);
		goto cleanup;
	}
	/*adding output from PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE to notification input flist*/
	notify_flistp = PIN_FLIST_COPY(sharing_grp_create_oflistp, ebufp);
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group: "
		"PCM_OP_SUBSCRIPTION_SHARING_GROUP_CREATE output", sharing_grp_create_oflistp);

	/*Create Ordered Balance group for the created sharing group*/
	if(sharing_grp_create_oflistp != NULL)
	{
		/** Frame the input flist for PCM_OP_SUBSCRIPTION_ORDERED_BALGRP opcode call*/
		while ((member_input_flistp = PIN_FLIST_ELEM_GET_NEXT(sharing_grp_create_iflistp, PIN_FLD_MEMBERS, 
			&members_elemid, 1, &members_cookie, ebufp)) != (pin_flist_t *)NULL)
		{
			/*Get ordered_balgrp details based on service object*/
			get_ord_balgrp_iflistp = PIN_FLIST_CREATE(ebufp);
			PIN_FLIST_FLD_COPY(member_input_flistp, PIN_FLD_SERVICE_OBJ, get_ord_balgrp_iflistp, PIN_FLD_POID, ebufp);
			fm_tab_utils_common_subscr_get_ordered_bg_details(ctxp, get_ord_balgrp_iflistp, 
					&get_ord_balgrp_oflistp, db_no, ebufp);
			PIN_FLIST_DESTROY_EX(&get_ord_balgrp_iflistp, NULL);

			if(PIN_ERR_IS_ERR(ebufp))
			{
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_ordered_bg_details:"
						" input flist ", get_ord_balgrp_iflistp);
				PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_utils_common_subscr_get_ordered_bg_details:"
						" Error while getting ordered_balgrp details", ebufp);
				goto cleanup;
			}
			else
			{
				/*adding output from fm_tab_utils_common_subscr_get_ordered_bg_details to notification input flist*/
				PIN_FLIST_CONCAT(notify_flistp,get_ord_balgrp_oflistp, ebufp);
				
				PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_utils_common_subscr_get_ordered_bg_details "
					"output flist", get_ord_balgrp_oflistp);

				if(get_ord_balgrp_oflistp != NULL && (ordered_results_flistp = 
					PIN_FLIST_ELEM_GET(get_ord_balgrp_oflistp, PIN_FLD_RESULTS, PIN_ELEMID_ANY, 1, ebufp)) != NULL)
				{
					/*Get sponsorship details based on offer name and update ordered balance group with group object*/
					update_ordered_balgrp_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(member_input_flistp, PIN_FLD_SERVICE_OBJ, 
						update_ordered_balgrp_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(member_input_flistp, PIN_FLD_ACCOUNT_OBJ, 
						update_ordered_balgrp_iflistp, PIN_FLD_ACCOUNT_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(sharing_grp_create_oflistp, PIN_FLD_POID, 
						update_ordered_balgrp_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_COPY(ordered_results_flistp, PIN_FLD_POID, 
						update_ordered_balgrp_iflistp, PIN_FLD_ORDERED_BALGRP_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
						update_ordered_balgrp_iflistp, PIN_FLD_PROGRAM_NAME, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
						update_ordered_balgrp_iflistp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
						update_ordered_balgrp_iflistp, PIN_FLD_EXTERNAL_USER, ebufp);

					fm_tab_subscription_list_update_ordered_bg(ctxp, update_ordered_balgrp_iflistp,db_no, ebufp);
					PIN_FLIST_DESTROY_EX(&update_ordered_balgrp_iflistp, NULL);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_list_update_ordered_bg:"
							" input flist ", update_ordered_balgrp_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_list_update_ordered_bg:"
							" Error while updating ordered_balgrp object", ebufp);
						goto cleanup;
					}
					
				}
				else
				{
					/*Create a new ordered balance group object*/
					ordered_balgrp_create_iflistp = PIN_FLIST_CREATE(ebufp);
					PIN_FLIST_FLD_COPY(member_input_flistp, PIN_FLD_SERVICE_OBJ, 
						ordered_balgrp_create_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
					PIN_FLIST_FLD_COPY(member_input_flistp, PIN_FLD_ACCOUNT_OBJ, 
						ordered_balgrp_create_iflistp, PIN_FLD_POID, ebufp);
					PIN_FLIST_FLD_SET(ordered_balgrp_create_iflistp, 
						PIN_FLD_ACTION, actionp, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
						ordered_balgrp_create_iflistp,  PIN_FLD_PROGRAM_NAME, ebufp);

					context_info_flistp = PIN_FLIST_SUBSTR_ADD(ordered_balgrp_create_iflistp, 
						PIN_FLD_CONTEXT_INFO, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
						context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
					PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
						context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

					ordered_balgrp_flistp = PIN_FLIST_ELEM_ADD(ordered_balgrp_create_iflistp, 
						PIN_FLD_ORDERED_BALGROUPS, 1, ebufp);
					PIN_FLIST_FLD_COPY(sharing_grp_create_oflistp, PIN_FLD_POID, 
						ordered_balgrp_flistp, PIN_FLD_GROUP_OBJ, ebufp);

					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group: "
						"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP input", ordered_balgrp_create_iflistp);

					PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_ORDERED_BALGRP, 0, ordered_balgrp_create_iflistp, 
						&ordered_balgrp_create_oflistp, ebufp);
					PIN_FLIST_DESTROY_EX(&ordered_balgrp_create_iflistp, NULL);

					if(PIN_ERR_IS_ERR(ebufp))
					{
						pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
							TAB_ERR_CODE_CREATE_ORDERED_BALGRP, 0, 0, 0);
						PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
							" input flist ", ordered_balgrp_create_iflistp);
						PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
							" Error while creating ordered balance group", ebufp);
						goto cleanup;
					}
					
				/*adding output from PCM_OP_SUBSCRIPTION_ORDERED_BALGRP to notification input flist*/
					PIN_FLIST_CONCAT(notify_flistp,ordered_balgrp_create_oflistp, ebufp);
					
					PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_create_sharing_group: "
						"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP output", ordered_balgrp_create_oflistp);
					PIN_FLIST_DESTROY_EX(&ordered_balgrp_create_oflistp, NULL);
				}
			}
			PIN_FLIST_DESTROY_EX(&get_ord_balgrp_oflistp, NULL);
		}
	}

	
	/*Call function to enrich notification details*/
	fm_tab_subs_create_sharing_grp_notification(ctxp, in_flistp,notify_flistp, db_no,
			&notify_oflistp, ebufp);
	if(PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group:"
			" fm_tab_subs_create_sharing_grp_notification input flist ", in_flistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subscription_create_sharing_group: "
			" fm_tab_subs_create_sharing_grp_notification error", ebufp);
		goto cleanup;
	}

	if (notify_oflistp)
	{
		if (*out_flistpp == NULL){
			*out_flistpp = PIN_FLIST_CREATE(ebufp);
		}
		
		if ( ( PIN_FLIST_ELEM_GET(notify_oflistp, TAB_FLD_NOTIFICATION,
			PIN_ELEMID_ANY, 1, ebufp)) != NULL)
		{
			PIN_FLIST_ELEM_COPY(notify_oflistp, TAB_FLD_NOTIFICATION,
				PIN_ELEMID_ANY, *out_flistpp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
		else
		{
			PIN_FLIST_ELEM_SET(*out_flistpp, notify_oflistp, TAB_FLD_NOTIFICATION, 0, ebufp);
		}
	}
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subscription_create_sharing_group output flist", *out_flistpp);
	
	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_create_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_ord_balgrp_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&update_ordered_balgrp_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_msisdn_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_msisdn_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_discount_offer_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_discount_offer_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_sponsorship_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_sponsorship_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&sharing_grp_create_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_create_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&sharing_grp_create_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&get_ord_balgrp_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_oflistp, NULL);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subscription_create_sharing_group output flist", *out_flistpp);
	return;
}


/**
 * We use this function to update
 * ordered_balgrp with group object.
 * @param ctxp The context pointer.
 * @param in_flistp in the input flist.
 * @param ebufp The error buffer.
 * @return flistp.
 *
 */

void fm_tab_subscription_list_update_ordered_bg(
	pcm_context_t       	*ctxp,
	pin_flist_t         	*in_flistp,
	int64			db_no,
	pin_errbuf_t        	*ebufp)
{
	pin_flist_t         	*ordered_balgrp_list_iflistp = NULL;
	pin_flist_t         	*ordered_balgrp_list_oflistp = NULL;
	pin_flist_t         	*ordered_balgrp_modify_iflistp = NULL;
	pin_flist_t         	*ordered_balgrp_modify_oflistp = NULL;
	pin_flist_t         	*context_info_flistp = NULL;
	pin_flist_t         	*ordered_balgrp_flistp = NULL;
	char                	*action_listp = PIN_SUBS_ORDERED_BALGRP_ACTION_LIST;
	char                	*action_modifyp = PIN_SUBS_ORDERED_BALGRP_ACTION_MODIFY;
	unsigned long		ordered_balgrp_max = 0;

	if (PIN_ERR_IS_ERR(ebufp)) 
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,
				"fm_tab_subscription_list_update_ordered_bg function entry error", ebufp);
		return;
	}

	PIN_ERRBUF_RESET(ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, 
			"fm_tab_subscription_list_update_ordered_bg ordered balgrp flist", in_flistp);

	ordered_balgrp_list_iflistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
			ordered_balgrp_list_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, 
			ordered_balgrp_list_iflistp, PIN_FLD_POID, ebufp);
	PIN_FLIST_FLD_SET(ordered_balgrp_list_iflistp, 
			PIN_FLD_ACTION, action_listp, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
			ordered_balgrp_list_iflistp,  PIN_FLD_PROGRAM_NAME, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ORDERED_BALGRP_OBJ, 
			ordered_balgrp_list_iflistp, PIN_FLD_ORDERED_BALGRP_OBJ, ebufp);

	context_info_flistp = PIN_FLIST_SUBSTR_ADD(ordered_balgrp_list_iflistp, 
			PIN_FLD_CONTEXT_INFO, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, 
			context_info_flistp, PIN_FLD_CORRELATION_ID, ebufp);
	PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, 
			context_info_flistp, PIN_FLD_EXTERNAL_USER, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_list_update_ordered_bg: "
		"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP list input", ordered_balgrp_list_iflistp);

	PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_ORDERED_BALGRP, 0, ordered_balgrp_list_iflistp, &ordered_balgrp_list_oflistp, ebufp);

	if(PIN_ERR_IS_ERR(ebufp))
	{
		pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
			TAB_ERR_CODE_LIST_ORDERED_BALGRP, 0, 0, 0);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
			" list input flist ", ordered_balgrp_list_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
			" Error while creating listing ordered balance group", ebufp);
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_list_update_ordered_bg: "
		"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP list output", ordered_balgrp_list_oflistp);

	if(ordered_balgrp_list_oflistp != NULL)
	{
		ordered_balgrp_max = fm_tab_utils_common_get_max_elemid(ctxp, ordered_balgrp_list_oflistp, 
			PIN_FLD_ORDERED_BALGROUPS, ebufp);

		ordered_balgrp_modify_iflistp = PIN_FLIST_CREATE(ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_SERVICE_OBJ, 
				ordered_balgrp_modify_iflistp, PIN_FLD_SERVICE_OBJ, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ACCOUNT_OBJ, 
				ordered_balgrp_modify_iflistp, PIN_FLD_POID, ebufp);
		PIN_FLIST_FLD_SET(ordered_balgrp_modify_iflistp, 
				PIN_FLD_ACTION, action_modifyp, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_PROGRAM_NAME, 
				ordered_balgrp_modify_iflistp,  PIN_FLD_PROGRAM_NAME, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_ORDERED_BALGRP_OBJ, 
				ordered_balgrp_modify_iflistp, PIN_FLD_ORDERED_BALGRP_OBJ, ebufp);

		PIN_FLIST_FLD_COPY(ordered_balgrp_list_oflistp, PIN_FLD_ORDERED_BALGROUPS, 
				ordered_balgrp_modify_iflistp, PIN_FLD_ORDERED_BALGROUPS, ebufp);

		ordered_balgrp_flistp = PIN_FLIST_ELEM_ADD(ordered_balgrp_modify_iflistp, PIN_FLD_ORDERED_BALGROUPS, 
			++ordered_balgrp_max, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_POID, ordered_balgrp_flistp, 
				PIN_FLD_GROUP_OBJ, ebufp);

		context_info_flistp = PIN_FLIST_SUBSTR_ADD(ordered_balgrp_modify_iflistp, 
				PIN_FLD_CONTEXT_INFO, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_CORRELATION_ID, context_info_flistp, 
				PIN_FLD_CORRELATION_ID, ebufp);
		PIN_FLIST_FLD_COPY(in_flistp, PIN_FLD_EXTERNAL_USER, context_info_flistp, 
				PIN_FLD_EXTERNAL_USER, ebufp);

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_list_update_ordered_bg: "
			"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP modify input", ordered_balgrp_modify_iflistp);

		PCM_OP(ctxp, PCM_OP_SUBSCRIPTION_ORDERED_BALGRP, 0, ordered_balgrp_modify_iflistp, &ordered_balgrp_modify_oflistp, ebufp);

		if(PIN_ERR_IS_ERR(ebufp))
		{
			pin_set_err(ebufp, PIN_ERRLOC_FM, PIN_ERRCLASS_SYSTEM_DETERMINATE,
				TAB_ERR_CODE_MODIFY_ORDERED_BALGRP, 0, 0, 0);	
			PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
				" modify input flist ", ordered_balgrp_modify_iflistp);
			PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP:"
				" Error while creating modifying ordered balance group", ebufp);
			goto cleanup;
		}

		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subscription_list_update_ordered_bg: "
			"PCM_OP_SUBSCRIPTION_ORDERED_BALGRP modify output", ordered_balgrp_modify_oflistp);

	}

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_list_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_modify_oflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_list_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&ordered_balgrp_modify_iflistp, NULL);
	return;
}

void
fm_tab_subs_create_sharing_grp_notification(
	pcm_context_t		*ctxp,
	pin_flist_t		*i_flistp,
	pin_flist_t		*o_flistp,
	int64			db_no,
	pin_flist_t		**r_flistpp,
	pin_errbuf_t		*ebufp)
{
	pin_flist_t		*enrich_notify_flistp = NULL;
	pin_flist_t		*temp_flistp =NULL;
	pin_flist_t		*notify_iflistp = NULL;
	pin_flist_t		*notify_out_flistp = NULL;	
	pin_flist_t		*notify_flistp = NULL;
	poid_t			*notify_pdp = NULL;
	char			*api_name = NULL;

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR,"fm_tab_subs_create_sharing_grp_notification error", ebufp);
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR,"fm_tab_subs_create_sharing_grp_notification:"
			" input flist", i_flistp);
		return;
	}
	
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subs_create_sharing_grp_notification: "
		"input flist", i_flistp);
	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG, "fm_tab_subs_create_sharing_grp_notification: "
		"output flist", o_flistp);
	/*IN_FLIST*/
	notify_iflistp = PIN_FLIST_COPY(i_flistp, ebufp);
	PIN_FLIST_SUBSTR_SET(notify_iflistp, i_flistp, PIN_FLD_IN_FLIST, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subs_create_sharing_grp_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CREATE_SHARING_GROUP input flist ", notify_iflistp);
		
	/*OUT_FLIST*/
	temp_flistp = PIN_FLIST_COPY(o_flistp, ebufp);
	notify_out_flistp = PIN_FLIST_CREATE(ebufp);
	PIN_FLIST_ELEM_PUT(notify_out_flistp, temp_flistp, PIN_FLD_RESULTS_DATA, 0, ebufp);
	PIN_FLIST_SUBSTR_PUT(notify_iflistp, notify_out_flistp, PIN_FLD_OUT_FLIST, ebufp);
	
	/*TAB_FLD_NOTIFICATION*/
	api_name =PIN_FLIST_FLD_GET(i_flistp, PIN_FLD_ORDER_TYPE, 0, ebufp);
	
	
	notify_flistp = PIN_FLIST_CREATE(ebufp);
	if (api_name && (strcmp(api_name, TAB_ACTION_CSG_CREATE) == 0))
	{
		notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CREATE_CHARGE_SHARING_GROUP, -1, ebufp);
	}
	else if (api_name && (strcmp(api_name, TAB_ACTION_DSG_CREATE) == 0))
	{
		notify_pdp = PIN_POID_CREATE(db_no, TAB_NOTIFY_EVENT_CREATE_DISCOUNT_SHARING_GROUP, -1, ebufp);
	}
	PIN_FLIST_FLD_PUT(notify_flistp, PIN_FLD_POID, notify_pdp, ebufp);

	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ACCOUNT_NO, notify_flistp, PIN_FLD_ACCOUNT_NO, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_MSISDN, notify_flistp, PIN_FLD_MSISDN, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_NAME, notify_flistp, PIN_FLD_NAME, ebufp);
	PIN_FLIST_FLD_COPY(i_flistp, PIN_FLD_ORDER_TYPE, notify_flistp, PIN_FLD_API_USER, ebufp);

	PIN_FLIST_SUBSTR_SET(notify_iflistp, notify_flistp, TAB_FLD_NOTIFICATION, ebufp);

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subs_create_sharing_grp_notification:"
		"TAB_OP_NOTIFY_POL_ENRICH_CREATE_SHARING_GROUP input flist ", notify_iflistp);

	PCM_OP(ctxp, TAB_OP_NOTIFY_POL_ENRICH_CREATE_SHARING_GROUP, 0, notify_iflistp, &enrich_notify_flistp, ebufp);

	if (PIN_ERR_IS_ERR(ebufp))
	{
		PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_ERROR," fm_tab_subs_create_sharing_grp_notification:"
			" input flist ", notify_iflistp);
		PIN_ERR_LOG_EBUF(PIN_ERR_LEVEL_ERROR," fm_tab_subs_create_sharing_grp_notification:"
			" Error in create sharing group notification", ebufp);
		*r_flistpp = enrich_notify_flistp;
		goto cleanup;
	}

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,"fm_tab_subs_create_sharing_grp_notification:"
		" TAB_OP_NOTIFY_POL_ENRICH_CREATE_SHARING_GROUP output flist ", enrich_notify_flistp);

	cleanup:
	/******************************************************************
	 * Clean up.
	 ******************************************************************/
	PIN_FLIST_DESTROY_EX(&notify_iflistp, NULL);
	PIN_FLIST_DESTROY_EX(&notify_flistp, NULL);

	*r_flistpp = enrich_notify_flistp;

	PIN_ERR_LOG_FLIST(PIN_ERR_LEVEL_DEBUG,
		"fm_tab_subs_create_sharing_grp_notification output flist", *r_flistpp);
	return;
}

