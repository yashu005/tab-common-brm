
/*******************************************************************************
*
*	This material is the confidential property of Telenor/Oracle Corporation or its
*	licensors and may be used, reproduced, stored or transmitted only in
*	accordance with a valid agreement.
*
********************************************************************************/

/*************************************************************************************************
* Change History
*
* No | Date			| Programmer		| Req/bug/Gap   | Change details
*
#* 1  | 11/10/2021	| Darshan A.V	    | 		        | New File.
**************************************************************************************************/

#include <stdio.h>      /* for FILE * in pcm.h */
#include "ops/pymt.h"
#include "pcm.h"
#include "cm_fm.h"
#include "pcm_ops.h"
#include "tab_ops_flds.h"

#ifdef MSDOS
__declspec(dllexport) void * fm_tab_subscription_config_func();
#endif

/*******************************************************************
 * NOTE THAT THE DISPATCH ENTRIES ARE COMMENTED. WHEN YOU OVERRIDE
 * AN IMPLEMENTATION, UNCOMMENT THE LINE BELOW THAT MATCHES THE
 * OPCODE FOR WHICH YOU HAVE PROVIDED AN ALTERNATE IMPLEMENTATION.
 *******************************************************************/

struct cm_fm_config fm_tab_subscription_config[] = {
	/* opcode as a u_int, function name (as a string) */

	{ TAB_OP_SUBSCRIPTION_CREATE_SHARING_GROUP,	"op_tab_subscription_create_sharing_group", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_UPDATE_SERVICE_STATUS,    "op_tab_subscription_update_service_status", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_GET_BALANCES,		"op_tab_subscription_get_balances" },
	{ TAB_OP_SUBSCRIPTION_GET_RECHARGE_HISTORY,	"op_tab_sub_get_recharge_history" },
	{ TAB_OP_SUBSCRIPTION_RECHARGE,			"op_tab_subscription_recharge" },
	{ TAB_OP_SUBSCRIPTION_REVERSE_RECHARGE,		"op_tab_sub_reverse_recharge" },
	{ TAB_OP_SUBSCRIPTION_EXTEND_PREPAID_VALIDITY,	"op_tab_subscription_extend_prepaid_validity" },
	{ TAB_OP_SUBSCRIPTION_ADJUST_BALANCE_VALIDITY,	"op_tab_subscription_adjust_balance_validity" },
	{ TAB_OP_SUBSCRIPTION_ADJUST_NCR_BALANCE_VALIDITY,	"op_tab_subscription_adjust_ncr_balance_validity" },
	{ TAB_OP_SUBSCRIPTION_REQUEST_LOAN ,		"op_tab_subscription_request_loan" },
	{ TAB_OP_SUBSCRIPTION_BALANCE_TRANSFER,		"op_tab_subscription_balance_transfer" },
	{ TAB_OP_SUBSCRIPTION_GET_BALANCE_TRANSFER_HISTORY,	"op_tab_subscription_get_balance_transfer_history" },
	{ TAB_OP_SUBSCRIPTION_GET_LOAN_DETAILS,		"op_tab_subscription_get_loan_details" },
	{ TAB_OP_SUBSCRIPTION_DELETE_SHARING_GROUP,     "op_tab_subscription_delete_sharing_group", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_MODIFY_SHARING_GROUP,     "op_tab_subscription_modify_sharing_group", CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_GET_GRP_SHARING_MEMBERS,  "op_tab_subscription_get_grp_sharing_members",CM_FM_OP_OVERRIDABLE },
	{ TAB_OP_SUBSCRIPTION_GET_BILL_DEBIT_HISTORY,		"op_tab_subscription_get_bill_debit_history" },
	{ TAB_OP_SUBSCRIPTION_ADD_REMOVE_MULTI_SIM,     "op_tab_subscription_add_remove_mutli_sim", CM_FM_OP_OVERRIDABLE },
    { TAB_OP_SUBSCRIPTION_GET_SHARING_GROUPS,       "op_tab_subscription_get_sharing_groups", CM_FM_OP_OVERRIDABLE },
    { TAB_OP_SUBSCRIPTION_GET_BAL_TRANSFER_DENOMINATION, "op_tab_subscription_get_bal_transfer_denomination", },
	{ TAB_OP_SUBSCRIPTION_CONVERT_ALLOWANCE, "op_tab_subscription_convert_allowance", },
	{ 0,    (char *)0 }
};

#ifdef MSDOS
void *
fm_tlc_bill_config_func()
{
  return ((void *) (fm_tab_subscription_config));
}
#endif
