#!/bin/bash
#=======================================
# Calls all subdirectory build scripts.
#=======================================
set -e
trap 'catch $?' EXIT

catch() {
    echo
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
    echo "Verifying for Errors"

    if [ "$1" != "0" ]; then
        test -t 1 && tput bold; tput setf 4
        echo "Error $1 occurred - build aborted"
        test -t 1 && tput sgr0 # Reset terminal
    else
        echo "No errors identified"
    fi
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
}

error_flag=0

echo ""
echo "************************************************"
echo "* building all sub folders under custom"
echo "************************************************"

# Loop through the directories and call any subdirectories' build.sh file.
BUILD_SEQUENCE="include config source sys";

#for x in `ls -d */`; do
for x in $BUILD_SEQUENCE; do
  if [ -f "$x/build.sh" ]; then
    cd $x

    . ./build.sh

    error_flag=$(($error_flag|$?))

    cd ..

    if [ $error_flag != 0 ];then
        echo ""
        echo "Build Aborted - Last command returned $error_flag"
        echo ""
        exit $error_flag
    fi
  fi
done

