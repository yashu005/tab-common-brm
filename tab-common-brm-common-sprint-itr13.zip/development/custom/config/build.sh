#!/bin/bash
#=======================================
# Calls all subdirectory build scripts.
#=======================================
set -e
trap 'catch $?' EXIT

catch() {
    echo
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
    echo "Verifying for Errors"

    if [ "$1" != "0" ]; then
        test -t 1 && tput bold; tput setf 4
        echo "Error $1 occurred - build aborted"
        test -t 1 && tput sgr0 # Reset terminal
    else
        echo "No errors identified"
    fi
    echo "* * * * * * * * * * * * * * * * * * * * * * * * * * * *"
}

error_flag=0

echo ""
echo "**********************************************"
echo "* building all sub folders under custom/config"
echo "**********************************************"

for x in `ls -d */`; do
  if [ -f "$x/build.sh" ]; then
    cd $x

    . ./build.sh

    error_flag=$(($error_flag|$?))

    cd ..

    if [ $error_flag != 0 ];then
        echo ""
        echo "Build Aborted - Last command returned $error_flag"
        echo ""
        exit $error_flag
    fi
  fi
done

