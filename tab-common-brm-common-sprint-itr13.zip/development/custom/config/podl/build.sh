#!/bin/bash

#================================================================================
# build the podl files by copying them to the $TARGETDIR/brm/config/podl folder
# if $TARGETDIR is not set, then exit and do nothing
#================================================================================

echo ""
echo "***************************************"
echo "* building custom/config/podl"
echo "***************************************"

if [[ -z "${TARGETDIR}" ]]; then
    echo "Environment Variable TARGETDIR is not set - aborting build"
    exit 1
fi

mkdir -p $TARGETDIR/brm/config/podl

for x in `ls *.podl`; do
    echo "COPY $x to $TARGETDIR/brm/config/podl/$x"
    cp $x $TARGETDIR/brm/config/podl/$x
done
