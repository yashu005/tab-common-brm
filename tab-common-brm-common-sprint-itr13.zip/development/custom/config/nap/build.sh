#!/bin/bash

#================================================================================
# build the nap files by copying them to the $TARGETDIR/brm/config/nap folder
# if $TARGETDIR is not set, then exit and do nothing
#================================================================================
echo ""
echo "***************************************"
echo "* building custom/config/nap"
echo "***************************************"

if [[ -z "${TARGETDIR}" ]]; then
    echo "Environment Variable TARGETDIR is not setting - aborting build"
    exit 1
fi

mkdir -p $TARGETDIR/brm/config/nap

for x in `ls *.nap`; do
    echo "COPY $x to $TARGETDIR/brm/config/nap/$x"
    cp $x $TARGETDIR/brm/config/nap/$x
done

return $error_flag

