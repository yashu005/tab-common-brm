# Copyright (c) 2020 Oracle Corporation and/or its affiliates. All rights reserved.
#!/bin/sh
 
echo "INFO: Entered common config scripts..."
 
# Keep all podls.
cd /oms/sys/data/config; pin_deploy replace /oms/load/config_tab_offer_policy_label_map.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/config_tab_package_descr.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_order.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_migration_status.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/config_tab_sub_recharge_states.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_prepaid_subscriber_recharge.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_adjustment.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_bill_debit_info.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_item_bill_debit.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_billing_payment.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_billing_reversal.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_prepaid_loan_info.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_balance_transfer.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_billing_limit.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_writeoff.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_dispute.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_billing_settlement.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_profile_multisim_map.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_billing_refund.podl
cd /oms/sys/data/config; pin_deploy replace /oms/load/tab_event_modify_credit_limit.podl

# Keep all sql.
cd /oms/load; eval "echo \"$(cat I_TAB_ADJUST_REF__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_RCH_REF__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_RCH_POSTED__DT.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_BALTRANSFER_SOURCE_TARGET_DATE_DT.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_BALTRANSFER_TRANSID_DT.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_LOAN_EVT__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_LOAN_REF__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_PAY_TRANS__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_EVT_BILLING_SETTLEMENT_CD.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_REFUND_TRANS__ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_BILL_DEBIT_INFO_OBJ_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_EVENT_BALTRANSFER_POID_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_EVT_BILLDEBIT_MSISDN.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_EVT_BILLDEBIT_POID_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_EVT_BILLDEBIT_TRANSID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_RECHARGE_BONUS_OBJ_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_SUB_RECHARGE_POID_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_DISPUTE_TRANS_ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_PYMT_REVERSAL_TRANS_ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_ORDER_EXTERNAL_USER.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_ORDER_POID_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_TRANS_ID.sql)\"" | sqlplus /@$OMS_DB_ALIAS
cd /oms/load; eval "echo \"$(cat I_TAB_ORDER_BUF_OBJ_ID0.sql)\"" | sqlplus /@$OMS_DB_ALIAS

# Events to Trigger Operations
 
# Keep all nap files.
 
# Keep all configuration xmls.
 
#Loading localized string
 
# Mapping event types to services
