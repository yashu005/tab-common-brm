# Copyright (c) 2020 Oracle Corporation and/or its affiliates. All rights reserved.
#!/bin/sh
 
error_flag=0
 
sh /oms/load/common_config_scripts.sh
error_flag=$(($error_flag|$?))
if [ $error_flag != 0 ];then
        echo ""
        echo "Aborted - common_config_scripts returned $error_flag"
        echo ""
        exit $error_flag
fi
 
#FILE=/oms/load/localization_config_scripts.sh
#if [ -f "$FILE" ]; then
#        echo "$FILE exists."
#        sh /oms/load/localization_config_scripts.sh
#        error_flag=$(($error_flag|$?))
#        if [ $error_flag != 0 ];then
#                echo ""
#                echo "Aborted - localization_config_scripts returned $error_flag"
#                echo ""
#                exit $error_flag
#        fi
#else
#        echo "Local config scripts not found"
#fi
 
exit 0
