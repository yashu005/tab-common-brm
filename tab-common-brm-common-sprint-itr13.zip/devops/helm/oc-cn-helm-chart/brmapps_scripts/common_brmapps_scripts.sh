# Copyright (c) 2020 Oracle Corporation and/or its affiliates. All rights reserved.
#!/bin/sh
 
echo "INFO: Entered common brmapps scripts..."
 
 
exit 0
